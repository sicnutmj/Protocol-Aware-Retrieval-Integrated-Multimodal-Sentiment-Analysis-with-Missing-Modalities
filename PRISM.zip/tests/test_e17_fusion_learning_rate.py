import hashlib
import json

import pytest

from run_e17_fusion_learning_rate import (
    LEARNING_RATE_VALUES,
    METRICS,
    NEW_LEARNING_RATE_VALUES,
    SPLIT_SIZES,
    audit_matrix,
    build_matrix,
    command_for_spec,
    parent_run_id,
    reference_run_id,
)


def _sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _full_bank_record():
    return {
        "source": "complete_training_split_only",
        "available_count": 16326,
        "requested_size": 0,
        "actual_size": 16326,
        "subset_seed": 3407,
        "selection": "sha256_seeded_sample_id_nested_prefix",
        "selected_ids_sha256": "full-bank-ids",
        "validation_donors": 0,
        "test_donors": 0,
        "self_exclusion_ids": True,
        "runtime_only": True,
    }


def _result(protocol, value):
    result = {
        "best_epoch": 3,
        "best_loss": value,
        "selection_split": "development",
        "selection_metric": "mae",
        "test_evaluation_count": 1,
        "data_provenance": {
            "dataset_sha256": "mosei-data",
            "split_sizes": SPLIT_SIZES,
            "fixed_protocol": protocol,
            "strict_retrieval_bank": _full_bank_record(),
        },
        "adaptation_gate": {
            "outcome": "improved",
            "test_metrics_consulted": False,
        },
    }
    result.update({metric: value for metric in METRICS})
    return result


def _arguments(learning_rate):
    return {
        "retrieval_mode": "missing_aware",
        "retrieval_candidate_source": "train_bank",
        "retrieval_candidate_filter": "observed_only",
        "retrieval_composition": "prototype_neighbours",
        "retrieval_selection": "similarity",
        "retrieval_random_seed": 3407,
        "retrieval_top_k": 2,
        "retrieval_temperature": 0.1,
        "retrieval_queue_size": 0,
        "retrieval_reference_bank_size": 0,
        "retrieval_reference_bank_seed": 3407,
        "protocol_fusion_readaptation": True,
        "protocol_adaptation_scope": "fusion_all",
        "protocol_fusion_learning_rate": learning_rate,
        "protocol_transformer_learning_rate": 2e-5,
        "learning_rate": learning_rate,
        "load": 1,
    }


def _write_manifest(workspace, payload):
    manifest_dir = workspace / "paper_experiments" / "manifests"
    checkpoint_dir = workspace / "paper_checkpoints"
    manifest_dir.mkdir(parents=True, exist_ok=True)
    checkpoint_dir.mkdir(parents=True, exist_ok=True)
    checkpoint_path = checkpoint_dir / "{}_best.pt".format(payload["run_id"])
    checkpoint_path.write_bytes(payload["run_id"].encode("utf-8"))
    payload["outputs"] = {
        "best_model_path": str(checkpoint_path),
        "best_model_sha256": _sha(checkpoint_path),
    }
    (manifest_dir / "{}.json".format(payload["run_id"])).write_text(
        json.dumps(payload), encoding="utf-8"
    )


def _write_cell(workspace, specs):
    values = {1e-5: 0.53, 5e-5: 0.51, 1e-4: 0.50, 5e-4: 0.56}
    protocol, seed = specs[0].protocol, specs[0].seed
    parent = parent_run_id(protocol, seed)
    for spec in specs:
        _write_manifest(workspace, {
            "status": "complete", "run_id": spec.run_id,
            "method_id": "M2", "stage_id": "E17", "dataset": "mosei",
            "protocol": spec.protocol, "seed": spec.seed,
            "lineage": {
                "parent_method_id": "M1",
                "parent_run_id": spec.parent_run_id,
            },
            "code_sha256": {"main.py": "new"},
            "arguments": _arguments(spec.learning_rate),
            "result": _result(spec.protocol, values[spec.learning_rate]),
        })
    _write_manifest(workspace, {
        "status": "complete", "run_id": reference_run_id(protocol, seed),
        "method_id": "M2", "stage_id": "E06", "dataset": "mosei",
        "protocol": protocol, "seed": seed,
        "lineage": {"parent_method_id": "M1", "parent_run_id": parent},
        "code_sha256": {"main.py": "old"},
        "arguments": _arguments(1e-4),
        "result": _result(protocol, values[1e-4]),
    })


def test_e17_matrix_has_36_new_runs_and_learning_rate_reference(tmp_path):
    specs = build_matrix()
    assert len(specs) == 36
    assert len({spec.run_id for spec in specs}) == 36
    assert [spec.learning_rate for spec in specs[:3]] == list(
        NEW_LEARNING_RATE_VALUES
    )
    assert specs[0].run_id == "E17_LR1E5_mosei_p0_s1111"
    assert specs[-1].run_id == "E17_LR5E4_mosei_p6_s7777"
    assert LEARNING_RATE_VALUES == (1e-5, 5e-5, 1e-4, 5e-4)
    for spec in specs[:3]:
        command = command_for_spec(tmp_path, spec, resolve_parent=False)
        assert "--paper_method_id=M2" in command
        assert "--paper_stage_id=E17" in command
        assert "--paper_parent_run_id=E06R1_M1_mosei_p0_s1111" in command
        assert "--protocol_fusion_readaptation" in command
        assert "--protocol_adaptation_scope=fusion_all" in command
        formatted = "{:.0e}".format(spec.learning_rate)
        assert "--protocol_fusion_learning_rate={}".format(formatted) in command
        assert "--learning_rate={}".format(formatted) in command


def test_e17_audit_builds_four_learning_rates_and_pairwise_effects(tmp_path):
    specs = build_matrix(protocols=("3",), seeds=(1111,))
    _write_cell(tmp_path, specs)
    summary = audit_matrix(
        tmp_path, specs, perform_reference_preflight=False
    )
    assert summary["completed_new_run_count"] == 3
    assert summary["completed_reused_reference_count"] == 1
    assert summary["completed_total_sensitivity_cells"] == 4
    assert [item["learning_rate"] for item in summary["records"]] == list(
        LEARNING_RATE_VALUES
    )
    effect = summary["effects_vs_learning_rate_1e_4"]["5e-5"]["summary"]["test_mae"]
    assert effect["mean_gain"] == pytest.approx(-0.01)
    assert effect["losses"] == 1
    reference = summary["summary_by_learning_rate"]["1e-4"]
    assert reference["test_mae"]["mean"] == 0.50
    assert reference["adaptation_outcomes"]["improved"] == 1


def test_e17_rejects_missing_reference(tmp_path):
    specs = build_matrix(protocols=("0",), seeds=(1111,))
    _write_cell(tmp_path, specs)
    path = (
        tmp_path / "paper_experiments" / "manifests"
        / "E06R1_M2_mosei_p0_s1111.json"
    )
    path.unlink()
    with pytest.raises(RuntimeError, match="missing_reference=1"):
        audit_matrix(tmp_path, specs, perform_reference_preflight=False)


def test_e17_rejects_wrong_learning_rate_contract(tmp_path):
    spec = build_matrix(
        protocols=("0",), seeds=(1111,), learning_rates=(1e-5,)
    )[0]
    _write_manifest(tmp_path, {
        "status": "complete", "run_id": spec.run_id,
        "method_id": "M2", "stage_id": "E17", "dataset": "mosei",
        "protocol": "0", "seed": 1111,
        "lineage": {
            "parent_method_id": "M1", "parent_run_id": spec.parent_run_id,
        },
        "code_sha256": {"main.py": "new"},
        "arguments": _arguments(5e-5),
        "result": _result("0", 0.5),
    })
    with pytest.raises(RuntimeError, match="protocol_fusion_learning_rate"):
        audit_matrix(
            tmp_path, [spec], require_complete=False,
            perform_reference_preflight=False,
        )
