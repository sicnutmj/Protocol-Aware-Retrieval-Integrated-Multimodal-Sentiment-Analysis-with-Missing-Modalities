import tempfile
import unittest
from pathlib import Path

import torch

from freeze_seventh_checkpoints import export_protocol


class FreezeSeventhCheckpointTest(unittest.TestCase):
    def test_export_removes_only_prompt_tensors_and_preserves_source(self):
        with tempfile.TemporaryDirectory() as directory:
            checkpoint_dir = Path(directory)
            source = checkpoint_dir / (
                "iie_mosei_protocol_0_missing_aware_q0_"
                "ablation_head_only_best.pt"
            )
            original = {
                "bert.weight": torch.tensor([1.0]),
                "fusion_all.weight": torch.tensor([2.0]),
                "dynamic_prompt_adapter.prompt": torch.tensor([3.0]),
            }
            torch.save(original, source)

            export_protocol(checkpoint_dir, protocol=0)

            target = checkpoint_dir / (
                "iie_mosei_protocol_0_missing_aware_q0_"
                "seventh_head_best.pt"
            )
            clean = torch.load(target, map_location="cpu")
            source_after = torch.load(source, map_location="cpu")
            self.assertEqual(set(source_after), set(original))
            self.assertEqual(
                set(clean), {"bert.weight", "fusion_all.weight"}
            )
            self.assertTrue(
                torch.equal(clean["fusion_all.weight"], original["fusion_all.weight"])
            )

    def test_export_refuses_to_overwrite_by_default(self):
        with tempfile.TemporaryDirectory() as directory:
            checkpoint_dir = Path(directory)
            source = checkpoint_dir / (
                "iie_mosei_protocol_1_missing_aware_q0_"
                "ablation_head_only_best.pt"
            )
            torch.save({"fusion_all.weight": torch.tensor([1.0])}, source)
            export_protocol(checkpoint_dir, protocol=1)
            with self.assertRaises(FileExistsError):
                export_protocol(checkpoint_dir, protocol=1)


if __name__ == "__main__":
    unittest.main()
