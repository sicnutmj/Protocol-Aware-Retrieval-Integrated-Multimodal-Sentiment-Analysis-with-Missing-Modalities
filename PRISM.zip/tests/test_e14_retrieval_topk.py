import hashlib
import json

import pytest

from run_e14_retrieval_topk import (
    METRICS,
    NEW_TOP_K_VALUES,
    SPLIT_SIZES,
    TOP_K_VALUES,
    audit_matrix,
    build_matrix,
    command_for_spec,
    reference_run_id,
)


def _sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _result(protocol, value):
    result = {
        "best_epoch": 3,
        "best_loss": value,
        "selection_split": "development",
        "selection_metric": "mae",
        "test_evaluation_count": 1,
        "data_provenance": {
            "dataset_sha256": "mosei-data",
            "split_sizes": SPLIT_SIZES,
            "fixed_protocol": protocol,
        },
    }
    result.update({metric: value for metric in METRICS})
    return result


def _arguments(top_k):
    return {
        "retrieval_mode": "missing_aware",
        "retrieval_candidate_source": "train_bank",
        "retrieval_candidate_filter": "observed_only",
        "retrieval_composition": "prototype_neighbours",
        "retrieval_selection": "similarity",
        "retrieval_random_seed": 3407,
        "retrieval_top_k": top_k,
        "retrieval_queue_size": 0,
        "protocol_fusion_readaptation": False,
        "load": 0,
    }


def _write_manifest(workspace, payload, checkpoint=True):
    manifest_dir = workspace / "paper_experiments" / "manifests"
    checkpoint_dir = workspace / "paper_checkpoints"
    manifest_dir.mkdir(parents=True, exist_ok=True)
    checkpoint_dir.mkdir(parents=True, exist_ok=True)
    checkpoint_path = checkpoint_dir / "{}_best.pt".format(payload["run_id"])
    if checkpoint:
        checkpoint_path.write_bytes(payload["run_id"].encode("utf-8"))
    payload["outputs"] = {
        "best_model_path": str(checkpoint_path),
        "best_model_sha256": _sha(checkpoint_path) if checkpoint else "old-sha",
    }
    (manifest_dir / "{}.json".format(payload["run_id"])).write_text(
        json.dumps(payload), encoding="utf-8"
    )


def _write_cell(workspace, specs):
    values = {1: 0.53, 2: 0.50, 4: 0.51, 8: 0.54, 16: 0.56}
    for spec in specs:
        _write_manifest(workspace, {
            "status": "complete", "run_id": spec.run_id,
            "method_id": "M1", "stage_id": "E14",
            "dataset": "mosei", "protocol": spec.protocol,
            "seed": spec.seed, "lineage": None,
            "code_sha256": {"main.py": "new"},
            "arguments": _arguments(spec.top_k),
            "result": _result(spec.protocol, values[spec.top_k]),
        })
    protocol, seed = specs[0].protocol, specs[0].seed
    reference_arguments = _arguments(2)
    # Frozen E06 manifests predate these explicit fields. Their absent values
    # are the exact parser defaults and must remain reusable.
    for name in (
        "retrieval_candidate_filter",
        "retrieval_composition",
        "retrieval_selection",
        "retrieval_random_seed",
    ):
        reference_arguments.pop(name)
    _write_manifest(workspace, {
        "status": "complete", "run_id": reference_run_id(protocol, seed),
        "method_id": "M1", "stage_id": "E06",
        "dataset": "mosei", "protocol": protocol, "seed": seed,
        "lineage": None, "code_sha256": {"main.py": "old"},
        "arguments": reference_arguments,
        "result": _result(protocol, values[2]),
    }, checkpoint=False)


def test_e14_matrix_has_48_new_runs_and_frozen_scope(tmp_path):
    specs = build_matrix()
    assert len(specs) == 48
    assert len({spec.run_id for spec in specs}) == 48
    assert [spec.top_k for spec in specs[:4]] == [1, 4, 8, 16]
    assert specs[0].run_id == "E14_K1_mosei_p0_s1111"
    assert specs[-1].run_id == "E14_K16_mosei_p6_s7777"
    assert {spec.protocol for spec in specs} == {"0", "3", "5", "6"}
    assert {spec.seed for spec in specs} == {1111, 3407, 7777}
    assert tuple(NEW_TOP_K_VALUES) == (1, 4, 8, 16)
    assert tuple(TOP_K_VALUES) == (1, 2, 4, 8, 16)

    for spec in specs[:4]:
        command = command_for_spec(tmp_path, spec)
        assert "--paper_method_id=M1" in command
        assert "--paper_stage_id=E14" in command
        assert "--retrieval_top_k={}".format(spec.top_k) in command
        assert "--retrieval_candidate_source=train_bank" in command
        assert "--protocol_fusion_readaptation" not in command
        assert "--load=1" not in command


def test_e14_reference_is_exact_top_k_two_e06_m1():
    assert reference_run_id("3", 3407) == "E06R1_M1_mosei_p3_s3407"


def test_e14_audit_builds_five_values_and_pairwise_effects(tmp_path):
    specs = build_matrix(protocols=("3",), seeds=(1111,))
    _write_cell(tmp_path, specs)
    summary = audit_matrix(
        tmp_path, specs, perform_reference_preflight=False
    )
    assert summary["completed_new_run_count"] == 4
    assert summary["completed_reused_reference_count"] == 1
    assert summary["completed_total_sensitivity_cells"] == 5
    assert [item["top_k"] for item in summary["records"]] == list(TOP_K_VALUES)
    effect = summary["effects_vs_top_k_2"]["4"]["summary"]["test_mae"]
    assert effect["mean_gain"] == pytest.approx(-0.01)
    assert effect["losses"] == 1
    assert summary["summary_by_top_k"]["2"]["test_mae"]["mean"] == 0.50


def test_e14_audit_rejects_missing_reference(tmp_path):
    specs = build_matrix(protocols=("0",), seeds=(1111,))
    _write_cell(tmp_path, specs)
    path = (
        tmp_path / "paper_experiments" / "manifests"
        / "E06R1_M1_mosei_p0_s1111.json"
    )
    path.unlink()
    with pytest.raises(RuntimeError, match="missing_reference=1"):
        audit_matrix(
            tmp_path, specs, perform_reference_preflight=False
        )


def test_e14_rejects_wrong_top_k_contract(tmp_path):
    spec = build_matrix(
        protocols=("0",), seeds=(1111,), top_k_values=(4,)
    )[0]
    payload = {
        "status": "complete", "run_id": spec.run_id,
        "method_id": "M1", "stage_id": "E14", "dataset": "mosei",
        "protocol": "0", "seed": 1111, "lineage": None,
        "code_sha256": {"main.py": "new"},
        "arguments": _arguments(2),
        "result": _result("0", 0.5),
    }
    _write_manifest(tmp_path, payload)
    with pytest.raises(RuntimeError, match="retrieval_top_k"):
        audit_matrix(
            tmp_path, [spec], require_complete=False,
            perform_reference_preflight=False,
        )
