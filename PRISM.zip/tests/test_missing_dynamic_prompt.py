import unittest

import torch

from modules.missing_dynamic_prompt import MissingOnlyDynamicPrompt


class MissingOnlyDynamicPromptTest(unittest.TestCase):
    def setUp(self):
        torch.manual_seed(11)
        self.model = MissingOnlyDynamicPrompt(
            embedding_dim=8,
            hidden_dim=16,
            modality_embedding_dim=4,
            max_scale=0.8,
        )
        self.sample = torch.randn(4, 8)
        self.enhanced = tuple(torch.randn(4, 8) for _ in range(3))
        self.raw = tuple(torch.randn(4, 8) for _ in range(3))
        self.observed = torch.tensor(
            [[1, 0, 0], [0, 1, 0], [0, 0, 1], [1, 1, 1]]
        )

    def test_zero_scale_initialization_exactly_matches_q0(self):
        prompted, diagnostics = self.model(
            self.sample, self.enhanced, self.raw, self.observed
        )
        for original, output in zip(self.enhanced, prompted):
            self.assertTrue(torch.equal(original, output))
        self.assertTrue(torch.equal(diagnostics['scales'], torch.zeros(3)))
        self.assertTrue(
            torch.equal(diagnostics['residual_norms'], torch.zeros(4, 3))
        )

    def test_observed_rows_remain_exact_identity_after_learning(self):
        with torch.no_grad():
            self.model.residual_scale_logits.fill_(0.7)
        prompted, _ = self.model(
            self.sample, self.enhanced, self.raw, self.observed
        )
        for modality_index in range(3):
            selected = self.observed[:, modality_index].bool()
            self.assertTrue(
                torch.equal(
                    prompted[modality_index][selected],
                    self.enhanced[modality_index][selected],
                )
            )

    def test_only_missing_rows_receive_nonzero_residuals(self):
        with torch.no_grad():
            self.model.residual_scale_logits.fill_(0.7)
        prompted, diagnostics = self.model(
            self.sample, self.enhanced, self.raw, self.observed
        )
        for modality_index in range(3):
            missing = ~self.observed[:, modality_index].bool()
            if missing.any():
                difference = (
                    prompted[modality_index][missing]
                    - self.enhanced[modality_index][missing]
                )
                self.assertTrue(torch.any(difference != 0))
            self.assertTrue(
                torch.equal(
                    diagnostics['residual_norms'][:, modality_index] == 0,
                    self.observed[:, modality_index].bool(),
                )
            )

    def test_initial_backward_trains_residual_scales(self):
        prompted, _ = self.model(
            self.sample, self.enhanced, self.raw, self.observed
        )
        sum(value.sum() for value in prompted).backward()
        self.assertIsNotNone(self.model.residual_scale_logits.grad)
        self.assertTrue(
            torch.isfinite(self.model.residual_scale_logits.grad).all()
        )
        self.assertGreater(
            self.model.residual_scale_logits.grad.abs().sum().item(), 0.0
        )

    def test_all_seven_protocols_are_supported(self):
        protocols = torch.tensor(
            [
                [1, 0, 0], [0, 1, 0], [0, 0, 1],
                [1, 1, 0], [1, 0, 1], [0, 1, 1], [1, 1, 1],
            ]
        )
        sample = torch.randn(7, 8)
        enhanced = tuple(torch.randn(7, 8) for _ in range(3))
        raw = tuple(torch.randn(7, 8) for _ in range(3))
        prompted, diagnostics = self.model(sample, enhanced, raw, protocols)
        for value in prompted:
            self.assertTrue(torch.isfinite(value).all())
        self.assertEqual(diagnostics['weights'].shape, (7, 3))

    def test_invalid_masks_are_rejected(self):
        with self.assertRaisesRegex(ValueError, 'at least one observed'):
            self.model(
                self.sample,
                self.enhanced,
                self.raw,
                torch.zeros(4, 3),
            )
        invalid = self.observed.float()
        invalid[0, 0] = 0.5
        with self.assertRaisesRegex(ValueError, 'binary'):
            self.model(self.sample, self.enhanced, self.raw, invalid)


if __name__ == '__main__':
    unittest.main()
