import unittest

import torch

from modules.reliability_gate import (
    CounterfactualHarmGate,
    CounterfactualScaleGateV24,
    FixedScaleGate,
    QualityAwareReliabilityGate,
    QualityAwareReliabilityGateV22,
    ResidualReliabilityGate,
)


class FixedScaleGateTest(unittest.TestCase):
    def make_gate(self):
        return FixedScaleGate(scale=0.85, min_scale=0.7)

    def test_uniform_scale_is_exact_and_parameter_free(self):
        gate = self.make_gate()
        candidate = torch.randn(4, 5, requires_grad=True)
        calibrated, diagnostics = gate(
            candidate,
            torch.randn(4, 5),
            torch.tensor([True, False, True, False]),
            {},
        )

        torch.testing.assert_close(calibrated, candidate * 0.85)
        torch.testing.assert_close(
            diagnostics['multiplier'], torch.full((4,), 0.85)
        )
        torch.testing.assert_close(
            diagnostics['reliability'], torch.full((4,), 0.5)
        )
        self.assertEqual(sum(p.numel() for p in gate.parameters()), 0)

        calibrated.square().mean().backward()
        self.assertIsNotNone(candidate.grad)
        self.assertTrue(torch.isfinite(candidate.grad).all())

    def test_observed_status_does_not_change_scale(self):
        gate = self.make_gate()
        _, diagnostics = gate(
            torch.randn(3, 4),
            torch.randn(3, 4),
            torch.tensor([True, False, True]),
            {},
        )
        torch.testing.assert_close(
            diagnostics['multiplier'], torch.full((3,), 0.85)
        )

    def test_invalid_scale_is_rejected(self):
        with self.assertRaises(ValueError):
            FixedScaleGate(scale=0.6, min_scale=0.7)
        with self.assertRaises(ValueError):
            FixedScaleGate(scale=1.1, min_scale=0.7)


class ResidualReliabilityGateTest(unittest.TestCase):
    def make_gate(self):
        return ResidualReliabilityGate(
            embedding_dim=4,
            hidden_dim=8,
            dropout=0.0,
            max_adjustment=0.5,
        )

    def test_identity_initialization_for_observed_branches(self):
        gate = self.make_gate()
        candidate = torch.randn(3, 4)
        context = torch.randn(3, 4)

        for branch in (
            ResidualReliabilityGate.RAW_BRANCH,
            ResidualReliabilityGate.ENHANCED_BRANCH,
        ):
            calibrated, diagnostics = gate(
                candidate,
                context,
                torch.ones(3),
                modality_index=0,
                branch_index=branch,
            )
            torch.testing.assert_close(calibrated, candidate)
            torch.testing.assert_close(
                diagnostics["reliability"], torch.full((3,), 0.5)
            )
            torch.testing.assert_close(
                diagnostics["multiplier"], torch.ones(3)
            )

    def test_missing_raw_branch_is_exactly_zero(self):
        gate = self.make_gate()
        candidate = torch.randn(2, 4)
        context = torch.randn(2, 4)
        calibrated, _ = gate(
            candidate,
            context,
            torch.tensor([True, False]),
            modality_index=1,
            branch_index=ResidualReliabilityGate.RAW_BRANCH,
        )

        torch.testing.assert_close(calibrated[0], candidate[0])
        torch.testing.assert_close(calibrated[1], torch.zeros(4))

    def test_missing_enhanced_branch_remains_available(self):
        gate = self.make_gate()
        candidate = torch.randn(2, 4)
        context = torch.randn(2, 4)
        calibrated, _ = gate(
            candidate,
            context,
            torch.tensor([True, False]),
            modality_index=2,
            branch_index=ResidualReliabilityGate.ENHANCED_BRANCH,
        )

        torch.testing.assert_close(calibrated, candidate)

    def test_multiplier_stays_inside_configured_bounds(self):
        gate = self.make_gate()
        with torch.no_grad():
            gate.network[-1].weight.fill_(2.0)
            gate.network[-1].bias.fill_(1.0)
        _, diagnostics = gate(
            torch.randn(5, 4),
            torch.randn(5, 4),
            torch.ones(5),
            modality_index=0,
            branch_index=ResidualReliabilityGate.ENHANCED_BRANCH,
        )

        self.assertTrue((diagnostics["multiplier"] >= 0.5).all())
        self.assertTrue((diagnostics["multiplier"] <= 1.5).all())

    def test_backward_reaches_gate_and_representations(self):
        gate = self.make_gate()
        candidate = torch.randn(3, 4, requires_grad=True)
        context = torch.randn(3, 4, requires_grad=True)
        calibrated, _ = gate(
            candidate,
            context,
            torch.ones(3),
            modality_index=0,
            branch_index=ResidualReliabilityGate.ENHANCED_BRANCH,
        )
        calibrated.square().mean().backward()

        self.assertIsNotNone(candidate.grad)
        self.assertTrue(torch.isfinite(candidate.grad).all())
        self.assertIsNotNone(gate.network[-1].weight.grad)
        self.assertTrue(torch.isfinite(gate.network[-1].weight.grad).all())

    def test_invalid_inputs_raise_clear_errors(self):
        gate = self.make_gate()
        with self.assertRaises(ValueError):
            gate(
                torch.randn(2, 4),
                torch.randn(3, 4),
                torch.ones(2),
                modality_index=0,
                branch_index=ResidualReliabilityGate.RAW_BRANCH,
            )


class QualityAwareReliabilityGateTest(unittest.TestCase):
    def make_gate(self):
        return QualityAwareReliabilityGate(
            embedding_dim=4,
            hidden_dim=8,
            min_scale=0.7,
            init_bias=4.0,
        )

    @staticmethod
    def diagnostics(batch_size):
        return {
            "topk_confidence": torch.linspace(0.2, 0.8, batch_size),
            "valid_ratio": torch.ones(batch_size),
            "support_ratio": torch.linspace(0.4, 1.0, batch_size),
            "neighbour_dispersion": torch.linspace(0.1, 0.6, batch_size),
        }

    def test_near_identity_initialization_and_quality_outputs(self):
        gate = self.make_gate()
        candidate = torch.randn(3, 4)
        context = torch.randn(3, 4)
        calibrated, diagnostics = gate(
            candidate,
            context,
            torch.tensor([True, False, True]),
            self.diagnostics(3),
        )

        expected_reliability = torch.sigmoid(torch.tensor(4.0))
        expected_scale = 0.7 + 0.3 * expected_reliability
        torch.testing.assert_close(
            diagnostics["reliability"],
            expected_reliability.expand(3),
        )
        torch.testing.assert_close(
            diagnostics["multiplier"], expected_scale.expand(3)
        )
        torch.testing.assert_close(calibrated, candidate * expected_scale)
        self.assertEqual(
            set(diagnostics["quality"]),
            {
                "agreement",
                "difference",
                "topk_confidence",
                "valid_ratio",
                "support_ratio",
                "neighbour_dispersion",
            },
        )

    def test_v2_can_only_retain_or_suppress(self):
        gate = self.make_gate()
        with torch.no_grad():
            gate.network[-1].weight.fill_(3.0)
            gate.network[-1].bias.zero_()
        _, diagnostics = gate(
            torch.randn(5, 4),
            torch.randn(5, 4),
            torch.ones(5),
            self.diagnostics(5),
        )

        self.assertTrue((diagnostics["multiplier"] >= 0.7).all())
        self.assertTrue((diagnostics["multiplier"] <= 1.0).all())

    def test_v2_backward_reaches_gate_and_enhanced_feature(self):
        gate = self.make_gate()
        candidate = torch.randn(3, 4, requires_grad=True)
        context = torch.randn(3, 4, requires_grad=True)
        calibrated, _ = gate(
            candidate,
            context,
            torch.tensor([True, False, True]),
            self.diagnostics(3),
        )
        calibrated.square().mean().backward()

        self.assertIsNotNone(candidate.grad)
        self.assertTrue(torch.isfinite(candidate.grad).all())
        self.assertIsNotNone(gate.network[-1].weight.grad)
        self.assertTrue(torch.isfinite(gate.network[-1].weight.grad).all())
        self.assertIsNone(context.grad)

    def test_missing_quality_field_is_rejected(self):
        gate = self.make_gate()
        diagnostics = self.diagnostics(2)
        diagnostics.pop("support_ratio")
        with self.assertRaises(ValueError):
            gate(
                torch.randn(2, 4),
                torch.randn(2, 4),
                torch.ones(2),
                diagnostics,
            )


class QualityAwareReliabilityGateV22Test(
    QualityAwareReliabilityGateTest
):
    def make_gate(self):
        return QualityAwareReliabilityGateV22(
            embedding_dim=4,
            hidden_dim=8,
            min_scale=0.7,
            init_scale=0.98,
        )

    def test_near_identity_initialization_and_quality_outputs(self):
        gate = self.make_gate()
        candidate = torch.randn(4, 4)
        calibrated, diagnostics = gate(
            candidate,
            torch.randn(4, 4),
            torch.tensor([True, False, True, False]),
            self.diagnostics(4),
        )

        torch.testing.assert_close(
            diagnostics["multiplier"],
            torch.full((4,), 0.98),
        )
        torch.testing.assert_close(calibrated, candidate * 0.98)
        self.assertEqual(
            set(diagnostics["quality"]),
            {
                "agreement",
                "difference",
                "topk_confidence",
                "valid_ratio",
                "support_ratio",
                "neighbour_dispersion",
            },
        )
        self.assertLess(abs(gate.init_bias), 4.0)

    def test_v22_rejects_invalid_initial_scale(self):
        with self.assertRaises(ValueError):
            QualityAwareReliabilityGateV22(
                embedding_dim=4,
                hidden_dim=8,
                min_scale=0.7,
                init_scale=0.7,
            )


class CounterfactualHarmGateTest(unittest.TestCase):
    @staticmethod
    def diagnostics(batch_size):
        return QualityAwareReliabilityGateTest.diagnostics(batch_size)

    def make_gate(self):
        return CounterfactualHarmGate(
            embedding_dim=4,
            hidden_dim=8,
            min_scale=0.7,
            init_harm_probability=0.02,
        )

    def test_initial_harm_probability_and_multiplier(self):
        gate = self.make_gate()
        candidate = torch.randn(4, 4)
        calibrated, diagnostics = gate(
            candidate,
            torch.randn(4, 4),
            torch.tensor([True, False, True, False]),
            self.diagnostics(4),
        )

        expected_multiplier = 1.0 - 0.3 * 0.02
        torch.testing.assert_close(
            diagnostics["harm_probability"],
            torch.full((4,), 0.02),
        )
        torch.testing.assert_close(
            diagnostics["reliability"],
            torch.full((4,), 0.98),
        )
        torch.testing.assert_close(
            diagnostics["multiplier"],
            torch.full((4,), expected_multiplier),
        )
        torch.testing.assert_close(
            calibrated,
            candidate * expected_multiplier,
        )
        self.assertNotIn("observed", gate.QUALITY_NAMES)

    def test_task_path_is_detached_but_counterfactual_loss_trains_gate(self):
        gate = self.make_gate()
        candidate = torch.randn(3, 4, requires_grad=True)
        calibrated, diagnostics = gate(
            candidate,
            torch.randn(3, 4),
            torch.ones(3),
            self.diagnostics(3),
        )
        calibrated.square().mean().backward(retain_graph=True)

        self.assertIsNotNone(candidate.grad)
        self.assertIsNone(gate.network[-1].weight.grad)

        counterfactual_loss = torch.nn.functional.binary_cross_entropy_with_logits(
            diagnostics["harm_logit"],
            torch.ones(3),
        )
        counterfactual_loss.backward()
        self.assertIsNotNone(gate.network[-1].weight.grad)
        self.assertGreater(
            gate.network[-1].weight.grad.abs().sum().item(),
            0.0,
        )

    def test_invalid_initial_harm_probability_is_rejected(self):
        with self.assertRaises(ValueError):
            CounterfactualHarmGate(
                embedding_dim=4,
                init_harm_probability=0.0,
            )


class CounterfactualScaleGateV24Test(unittest.TestCase):
    @staticmethod
    def diagnostics(batch_size):
        return QualityAwareReliabilityGateTest.diagnostics(batch_size)

    def make_gate(self):
        return CounterfactualScaleGateV24(
            embedding_dim=4,
            hidden_dim=8,
            min_scale=0.7,
            init_scale=0.98,
            max_residual_logit=2.0,
        )

    def test_initial_scale_has_separate_group_prior_and_zero_residual(self):
        gate = self.make_gate()
        candidate = torch.randn(4, 4)
        calibrated, diagnostics = gate(
            candidate,
            torch.randn(4, 4),
            torch.tensor([True, False, True, False]),
            self.diagnostics(4),
            modality_index=2,
        )

        torch.testing.assert_close(
            diagnostics["multiplier"], torch.full((4,), 0.98)
        )
        torch.testing.assert_close(
            diagnostics["prior_scale"], torch.full((4,), 0.98)
        )
        torch.testing.assert_close(
            diagnostics["residual_logit"], torch.zeros(4)
        )
        torch.testing.assert_close(calibrated, candidate * 0.98)
        self.assertNotIn("observed", gate.QUALITY_NAMES)

    def test_group_prior_explicitly_separates_missing_and_observed(self):
        gate = self.make_gate()
        with torch.no_grad():
            gate.group_bias[1, 0] = torch.logit(torch.tensor(0.1))
            gate.group_bias[1, 1] = torch.logit(torch.tensor(0.9))
        _, diagnostics = gate(
            torch.randn(2, 4),
            torch.randn(2, 4),
            torch.tensor([False, True]),
            self.diagnostics(2),
            modality_index=1,
        )

        expected = torch.tensor([0.73, 0.97])
        torch.testing.assert_close(diagnostics["prior_scale"], expected)
        torch.testing.assert_close(diagnostics["multiplier"], expected)

    def test_task_path_is_detached_but_scale_loss_trains_gate(self):
        gate = self.make_gate()
        candidate = torch.randn(3, 4, requires_grad=True)
        calibrated, diagnostics = gate(
            candidate,
            torch.randn(3, 4),
            torch.tensor([True, False, True]),
            self.diagnostics(3),
            modality_index=0,
        )
        calibrated.square().mean().backward(retain_graph=True)

        self.assertIsNotNone(candidate.grad)
        self.assertIsNone(gate.network[-1].weight.grad)
        self.assertIsNone(gate.group_bias.grad)

        scale_loss = torch.nn.functional.smooth_l1_loss(
            diagnostics["scale_prediction"],
            torch.full((3,), 0.7),
            beta=0.05,
        )
        scale_loss.backward()
        self.assertIsNotNone(gate.network[-1].weight.grad)
        self.assertGreater(
            gate.network[-1].weight.grad.abs().sum().item(), 0.0
        )
        self.assertIsNotNone(gate.group_bias.grad)
        self.assertGreater(gate.group_bias.grad.abs().sum().item(), 0.0)

    def test_scale_and_sample_residual_remain_bounded(self):
        gate = self.make_gate()
        with torch.no_grad():
            gate.network[-1].weight.fill_(100.0)
        _, diagnostics = gate(
            torch.randn(5, 4),
            torch.randn(5, 4),
            torch.ones(5),
            self.diagnostics(5),
            modality_index=0,
        )

        self.assertTrue((diagnostics["multiplier"] >= 0.7).all())
        self.assertTrue((diagnostics["multiplier"] <= 1.0).all())
        self.assertTrue(
            (diagnostics["residual_logit"].abs() <= 2.0).all()
        )

    def test_invalid_configuration_and_modality_are_rejected(self):
        with self.assertRaises(ValueError):
            CounterfactualScaleGateV24(
                embedding_dim=4,
                min_scale=0.7,
                init_scale=0.7,
            )
        gate = self.make_gate()
        with self.assertRaises(ValueError):
            gate(
                torch.randn(2, 4),
                torch.randn(2, 4),
                torch.ones(2),
                self.diagnostics(2),
                modality_index=3,
            )


if __name__ == "__main__":
    unittest.main()
