import hashlib
import json
from pathlib import Path

import pytest

from run_e06_mosei_primary import (
    METRICS,
    audit_matrix,
    build_matrix,
    command_for_spec,
    write_immutable_json,
)


def test_e06_full_matrix_has_fixed_size_order_and_lineage(tmp_path):
    specs = build_matrix()
    assert len(specs) == 140
    assert [spec.method for spec in specs[:4]] == ["M0", "M1", "M2", "M3"]
    assert specs[2].parent_run_id == specs[1].run_id
    assert specs[3].parent_run_id == specs[2].run_id
    assert len({spec.run_id for spec in specs}) == 140
    assert specs[0].run_id == "E06R1_M0_mosei_p0_s1111"

    command = command_for_spec(tmp_path, specs[3], resolve_parent=False)
    joined = " ".join(command)
    assert "--paper_experiment" in command
    assert "--paper_stage_id=E06" in command
    assert "--paper_parent_run_id={}".format(specs[2].run_id) in command
    assert "--model_path=<PARENT_CHECKPOINT>" in command
    assert "--early_stopping_patience=12" in command
    assert "--protocol_fusion_readaptation" in command
    assert "paper_logs" not in joined
    assert "best_modules" not in joined


def _sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _write_complete(workspace, spec, code=None, dataset_sha="dataset"):
    manifest_dir = workspace / "paper_experiments" / "manifests"
    checkpoint_dir = workspace / "paper_checkpoints"
    manifest_dir.mkdir(parents=True, exist_ok=True)
    checkpoint_dir.mkdir(parents=True, exist_ok=True)
    checkpoint = checkpoint_dir / "{}_best.pt".format(spec.run_id)
    checkpoint.write_bytes(spec.run_id.encode("utf-8"))
    result = {
        "best_epoch": 2,
        "best_loss": 0.5,
        "selection_split": "development",
        "selection_metric": "mae",
        "test_evaluation_count": 1,
        "selected_state_sha256": "state-{}".format(spec.run_id),
        "data_provenance": {"dataset_sha256": dataset_sha},
    }
    result.update({metric: 0.6 for metric in METRICS})
    lineage = None
    if spec.parent_run_id:
        result["adaptation_gate"] = {
            "outcome": "improved",
            "dev_mae_gain": 0.01,
            "test_metrics_consulted": False,
        }
        lineage = {
            "parent_run_id": spec.parent_run_id,
            "parent_method_id": "M1" if spec.method == "M2" else "M2",
        }
    payload = {
        "run_id": spec.run_id,
        "method_id": spec.method,
        "stage_id": "E06",
        "status": "complete",
        "dataset": "mosei",
        "protocol": spec.protocol,
        "seed": spec.seed,
        "code_sha256": code or {"main.py": "same"},
        "lineage": lineage,
        "outputs": {
            "best_model_path": str(checkpoint),
            "best_model_sha256": _sha(checkpoint),
        },
        "result": result,
    }
    (manifest_dir / "{}.json".format(spec.run_id)).write_text(
        json.dumps(payload), encoding="utf-8"
    )


def test_e06_audit_accepts_complete_consistent_subset(tmp_path):
    specs = build_matrix(protocols=("0",), seeds=(1111,))
    for spec in specs:
        _write_complete(tmp_path, spec)
    summary = audit_matrix(tmp_path, specs)
    assert summary["completed_run_count"] == 4
    assert summary["missing_run_ids"] == []
    assert summary["test_evaluation_count_per_run"] == 1


def test_e06_audit_rejects_missing_or_mixed_code(tmp_path):
    specs = build_matrix(protocols=("0",), seeds=(1111,))
    for spec in specs[:-1]:
        _write_complete(tmp_path, spec)
    with pytest.raises(RuntimeError, match="Incomplete E06 matrix"):
        audit_matrix(tmp_path, specs)

    _write_complete(tmp_path, specs[-1], code={"main.py": "changed"})
    with pytest.raises(RuntimeError, match="different code fingerprints"):
        audit_matrix(tmp_path, specs)


def test_e06_rejects_nonfinal_manifest_instead_of_overwriting(tmp_path):
    spec = build_matrix(protocols=("0",), seeds=(1111,), methods=("M0",))[0]
    manifest_dir = tmp_path / "paper_experiments" / "manifests"
    manifest_dir.mkdir(parents=True)
    (manifest_dir / "{}.json".format(spec.run_id)).write_text(
        json.dumps({"status": "failed"}), encoding="utf-8"
    )
    with pytest.raises(RuntimeError, match="do not overwrite"):
        audit_matrix(tmp_path, (spec,))


def test_e06_audit_output_is_idempotent_but_immutable(tmp_path):
    path = tmp_path / "audit.json"
    write_immutable_json(path, {"complete": 140})
    write_immutable_json(path, {"complete": 140})
    with pytest.raises(FileExistsError, match="different content"):
        write_immutable_json(path, {"complete": 139})
