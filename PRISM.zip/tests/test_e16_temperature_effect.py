import torch

from modules.missing_aware_retrieval import MissingAwareRetrieval


def _run_temperature(temperature):
    retrieval = MissingAwareRetrieval(
        embedding_dim=2,
        top_k=2,
        temperature=temperature,
        candidate_source="train_bank",
    )
    bank = torch.tensor([
        [1.0, 0.0],
        [0.6, 0.8],
        [-1.0, 0.0],
    ])
    retrieval.set_reference_bank(bank, torch.tensor([0, 1, 2]))
    output, diagnostics = retrieval(
        torch.zeros(1, 2),
        torch.tensor([False]),
        update_memory=False,
        query_ids=torch.tensor([99]),
    )
    return output, diagnostics


def test_temperature_changes_weights_not_selected_neighbours():
    cold_output, cold = _run_temperature(0.05)
    warm_output, warm = _run_temperature(1.0)

    torch.testing.assert_close(
        cold["topk_indices"], warm["topk_indices"], rtol=0.0, atol=0.0
    )
    torch.testing.assert_close(
        cold["topk_valid"], warm["topk_valid"], rtol=0.0, atol=0.0
    )
    assert cold["topk_weights"].max() > warm["topk_weights"].max()
    assert not torch.allclose(cold["topk_weights"], warm["topk_weights"])
    assert not torch.allclose(cold_output, warm_output)


def test_temperature_endpoints_preserve_output_contract():
    for temperature in (0.05, 0.1, 0.2, 0.5, 1.0):
        output, diagnostics = _run_temperature(temperature)
        assert output.shape == (1, 4, 2)
        assert diagnostics["topk_weights"].shape == (1, 2)
        torch.testing.assert_close(
            diagnostics["topk_weights"].sum(dim=1), torch.ones(1)
        )
