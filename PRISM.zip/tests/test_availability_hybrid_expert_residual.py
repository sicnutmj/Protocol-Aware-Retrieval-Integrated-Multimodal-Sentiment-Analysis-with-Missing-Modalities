import pytest
import torch

from modules.availability_hybrid_expert_residual import (
    AvailabilityConstrainedHybridExpertResidual,
)


def make_inputs(batch=5, dimension=8):
    modalities = tuple(torch.randn(batch, dimension) for _ in range(3))
    sample = torch.randn(batch, dimension)
    mask = torch.tensor([
        [1, 0, 0],
        [1, 1, 0],
        [1, 0, 1],
        [0, 1, 1],
        [1, 1, 1],
    ], dtype=torch.float32)[:batch]
    base = torch.randn(batch, 1)
    return modalities, sample, mask, base


def test_zero_initialization_is_exact_identity():
    module = AvailabilityConstrainedHybridExpertResidual(8, dropout=0.0)
    inputs = make_inputs()

    prediction, orthogonality, diagnostics = module(*inputs)

    assert torch.equal(prediction, inputs[-1])
    assert orthogonality.ndim == 0
    assert diagnostics['residual_abs_mean'].item() == 0.0
    assert module.identity_diagnostics()['final_weight_max'] == 0.0


def test_residual_can_learn_and_backpropagate():
    module = AvailabilityConstrainedHybridExpertResidual(8, dropout=0.0)
    torch.nn.init.constant_(module.residual_head[-1].weight, 0.05)
    inputs = make_inputs()

    prediction, orthogonality, diagnostics = module(*inputs)
    loss = prediction.square().mean() + 0.01 * orthogonality
    loss.backward()

    assert not torch.equal(prediction, inputs[-1])
    assert diagnostics['residual_abs_mean'].item() > 0.0
    assert orthogonality.item() >= 0.0
    assert module.residual_head[-1].weight.grad is not None
    assert module.private_experts[0][0].network[0].weight.grad is not None


def test_routing_diagnostics_have_valid_mass_and_shapes():
    module = AvailabilityConstrainedHybridExpertResidual(
        8, private_experts=2, shared_experts=4, dropout=0.0
    )
    _, _, diagnostics = module(*make_inputs())

    assert diagnostics['routing_weights'].shape == (3, 6)
    assert diagnostics['routing_entropy'].shape == (3,)
    assert diagnostics['private_mass'].shape == (3,)
    assert diagnostics['shared_mass'].shape == (3,)
    assert torch.allclose(
        diagnostics['routing_weights'].sum(dim=1), torch.ones(3), atol=1e-6
    )
    assert torch.allclose(
        diagnostics['private_mass'] + diagnostics['shared_mass'],
        torch.ones(3),
        atol=1e-6,
    )


def test_shared_experts_are_one_parameter_shared_bank():
    module = AvailabilityConstrainedHybridExpertResidual(8)

    assert len(module.private_experts) == 3
    assert all(len(bank) == 3 for bank in module.private_experts)
    assert len(module.shared_experts) == 3
    names = [name for name, _ in module.named_parameters()]
    assert any(name.startswith('shared_experts.0.') for name in names)
    assert not any(name.startswith('shared_experts.3.') for name in names)


@pytest.mark.parametrize(
    'invalid_mask',
    (
        torch.tensor([[1.0, 0.5, 0.0]] * 5),
        torch.zeros(5, 3),
        torch.ones(5, 2),
    ),
)
def test_invalid_availability_masks_are_rejected(invalid_mask):
    module = AvailabilityConstrainedHybridExpertResidual(8, dropout=0.0)
    modalities, sample, _, base = make_inputs()

    with pytest.raises(ValueError):
        module(modalities, sample, invalid_mask, base)
