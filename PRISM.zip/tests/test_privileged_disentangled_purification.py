import ast
from pathlib import Path
import unittest

import torch

from modules.privileged_disentangled_purification import (
    PrivilegedDisentangledPurification,
    privileged_disentangled_objective,
)


class PrivilegedDisentangledPurificationTest(unittest.TestCase):
    def setUp(self):
        torch.manual_seed(7)
        self.model = PrivilegedDisentangledPurification(
            embedding_dim=8,
            hidden_dim=12,
            subspace_dim=4,
            max_scale=1.0,
        )
        self.sample = torch.randn(5, 8)
        self.enhanced = tuple(torch.randn(5, 8) for _ in range(3))
        self.raw = tuple(torch.randn(5, 8) for _ in range(3))
        self.protocol_five = torch.tensor(
            [[0.0, 1.0, 1.0]] * 5
        )

    def test_zero_scale_is_exact_fpfr_identity(self):
        corrected, diagnostics = self.model(
            self.sample, self.enhanced, self.raw, self.protocol_five
        )
        for actual, expected in zip(corrected, self.enhanced):
            self.assertTrue(torch.equal(actual, expected))
        self.assertTrue(torch.equal(diagnostics['scales'], torch.zeros(3)))

    def test_only_missing_modality_is_changed(self):
        with torch.no_grad():
            self.model.injection_scale_logits.fill_(0.5)
        corrected, _ = self.model(
            self.sample, self.enhanced, self.raw, self.protocol_five
        )
        self.assertFalse(torch.equal(corrected[0], self.enhanced[0]))
        self.assertTrue(torch.equal(corrected[1], self.enhanced[1]))
        self.assertTrue(torch.equal(corrected[2], self.enhanced[2]))

    def test_full_objective_is_finite_and_has_gradients(self):
        student = self.model(
            self.sample, self.enhanced, self.raw, self.protocol_five
        )[1]
        teacher = self.model(
            self.sample,
            self.enhanced,
            self.raw,
            torch.ones_like(self.protocol_five),
        )[1]
        losses = privileged_disentangled_objective(student, teacher)
        total = losses[0] + losses[1] + losses[2]
        self.assertTrue(torch.isfinite(total))
        total.backward()
        gradients = [
            parameter.grad for parameter in self.model.parameters()
            if parameter.grad is not None
        ]
        self.assertTrue(gradients)
        self.assertTrue(all(torch.isfinite(gradient).all() for gradient in gradients))

    def test_training_and_inference_both_apply_purification(self):
        source_path = Path(__file__).resolve().parents[1] / 'IIE_model.py'
        tree = ast.parse(source_path.read_text(encoding='utf-8'))
        model_class = next(
            node for node in tree.body
            if isinstance(node, ast.ClassDef) and node.name == 'IIEModel'
        )
        methods = {
            node.name: node
            for node in model_class.body
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
        }
        for method_name in ('forward', 'test'):
            calls_by_name = {
                name: [
                    node for node in ast.walk(methods[method_name])
                    if isinstance(node, ast.Call)
                    and isinstance(node.func, ast.Attribute)
                    and node.func.attr == name
                ]
                for name in (
                    'apply_reliability_gate',
                    'apply_privileged_purification',
                    'fuse_representations',
                )
            }
            calls = calls_by_name['apply_privileged_purification']
            self.assertEqual(
                len(calls),
                1,
                '{} must apply PDRP exactly once'.format(method_name),
            )
            first_line = {
                name: min(node.lineno for node in calls_by_name[name])
                for name in calls_by_name
            }
            self.assertLess(
                first_line['apply_reliability_gate'],
                first_line['apply_privileged_purification'],
            )
            self.assertLess(
                first_line['apply_privileged_purification'],
                first_line['fuse_representations'],
            )


if __name__ == '__main__':
    unittest.main()
