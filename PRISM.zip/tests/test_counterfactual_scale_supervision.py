import unittest

import torch

from modules.reliability_gate import select_counterfactual_scale_targets


class CounterfactualScaleTargetTest(unittest.TestCase):
    def test_selects_lowest_error_executable_scale(self):
        teacher_scales = torch.tensor([1.0, 0.85, 0.7])
        # [batch=3, modality=2, scale=3]
        candidate_errors = torch.tensor(
            [
                [[0.0, 0.1, 0.2], [0.3, 0.2, 0.1]],
                [[0.2, 0.0, 0.2], [0.0, 0.0, 0.0]],
                [[0.3, 0.2, 0.0], [0.1, 0.2, 0.3]],
            ]
        )

        targets, best_error, best_index = (
            select_counterfactual_scale_targets(
                candidate_errors, teacher_scales
            )
        )

        torch.testing.assert_close(
            targets,
            torch.tensor(
                [[1.0, 0.7], [0.85, 1.0], [0.7, 1.0]]
            ),
        )
        torch.testing.assert_close(
            best_error,
            torch.tensor([[0.0, 0.1], [0.0, 0.0], [0.0, 0.1]]),
        )
        torch.testing.assert_close(
            best_index,
            torch.tensor([[0, 2], [1, 0], [2, 0]]),
        )

    def test_rejects_mismatched_shapes(self):
        with self.assertRaises(ValueError):
            select_counterfactual_scale_targets(
                torch.zeros(2, 3), torch.tensor([1.0, 0.7])
            )
        with self.assertRaises(ValueError):
            select_counterfactual_scale_targets(
                torch.zeros(2, 3, 3), torch.tensor([1.0, 0.7])
            )


if __name__ == '__main__':
    unittest.main()
