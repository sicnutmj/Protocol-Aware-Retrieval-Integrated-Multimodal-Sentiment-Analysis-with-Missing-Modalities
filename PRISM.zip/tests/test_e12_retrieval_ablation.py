import hashlib
import json

import pytest

from run_e12_retrieval_ablation import (
    ARMS,
    METRICS,
    NEW_ARM_SETTINGS,
    SPLIT_SIZES,
    audit_matrix,
    build_matrix,
    command_for_spec,
    reference_run_id,
)


def _sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _result(protocol, value):
    result = {
        "best_epoch": 3,
        "best_loss": value,
        "selection_split": "development",
        "selection_metric": "mae",
        "test_evaluation_count": 1,
        "selected_state_sha256": "state",
        "data_provenance": {
            "dataset_sha256": "mosei-data",
            "split_sizes": SPLIT_SIZES,
            "fixed_protocol": protocol,
        },
    }
    result.update({metric: value for metric in METRICS})
    return result


def _write_manifest(workspace, payload, checkpoint=True):
    manifest_dir = workspace / "paper_experiments" / "manifests"
    checkpoint_dir = workspace / "paper_checkpoints"
    manifest_dir.mkdir(parents=True, exist_ok=True)
    checkpoint_dir.mkdir(parents=True, exist_ok=True)
    checkpoint_path = checkpoint_dir / "{}_best.pt".format(payload["run_id"])
    if checkpoint:
        checkpoint_path.write_bytes(payload["run_id"].encode("utf-8"))
    payload["outputs"] = {
        "best_model_path": str(checkpoint_path),
        "best_model_sha256": _sha(checkpoint_path) if checkpoint else "old-sha",
    }
    (manifest_dir / "{}.json".format(payload["run_id"])).write_text(
        json.dumps(payload), encoding="utf-8"
    )


def _write_cell(workspace, specs):
    values = {"B0": 0.60, "B1": 0.55, "B2": 0.50,
              "B3": 0.48, "B4": 0.45, "B5": 0.58}
    for spec in specs:
        settings = NEW_ARM_SETTINGS[spec.arm]
        _write_manifest(workspace, {
            "status": "complete", "run_id": spec.run_id,
            "method_id": spec.method, "stage_id": "E12",
            "dataset": "mosei", "protocol": spec.protocol,
            "seed": spec.seed, "lineage": None,
            "code_sha256": {"main.py": "new"},
            "arguments": {
                "retrieval_mode": "missing_aware",
                "retrieval_candidate_source": settings["candidate_source"],
                "retrieval_candidate_filter": settings["candidate_filter"],
                "retrieval_composition": settings["composition"],
                "retrieval_selection": settings["selection"],
                "retrieval_random_seed": (
                    spec.seed if spec.arm == "B5" else 3407
                ),
                "retrieval_queue_size": 0,
                "protocol_fusion_readaptation": False,
                "load": 0,
            },
            "result": _result(spec.protocol, values[spec.arm]),
        })
    protocol, seed = specs[0].protocol, specs[0].seed
    for arm, method, stage in (("B1", "A1", "E11"), ("B4", "M1", "E06")):
        _write_manifest(workspace, {
            "status": "complete",
            "run_id": reference_run_id(arm, protocol, seed),
            "method_id": method, "stage_id": stage,
            "dataset": "mosei", "protocol": protocol, "seed": seed,
            "lineage": None, "code_sha256": {"main.py": "old"},
            # Deliberately omit new E12 flags: frozen manifests use defaults.
            "arguments": {
                "retrieval_mode": "missing_aware",
                "retrieval_candidate_source": (
                    "batch" if arm == "B1" else "train_bank"
                ),
            },
            "result": _result(protocol, values[arm]),
        }, checkpoint=False)


def test_e12_matrix_has_48_new_runs_and_frozen_scope(tmp_path):
    specs = build_matrix()
    assert len(specs) == 48
    assert len({spec.run_id for spec in specs}) == 48
    assert [spec.arm for spec in specs[:4]] == ["B0", "B2", "B3", "B5"]
    assert specs[0].run_id == "E12_E12U_mosei_p0_s1111"
    assert specs[-1].run_id == "E12_E12R_mosei_p6_s7777"
    assert {spec.protocol for spec in specs} == {"0", "3", "5", "6"}
    assert {spec.seed for spec in specs} == {1111, 3407, 7777}

    commands = {spec.arm: command_for_spec(tmp_path, spec) for spec in specs[:4]}
    assert "--retrieval_candidate_filter=all" in commands["B0"]
    assert "--retrieval_composition=prototype_only" in commands["B2"]
    assert "--retrieval_composition=neighbours_only" in commands["B3"]
    assert "--retrieval_selection=random" in commands["B5"]
    assert "--retrieval_random_seed=1111" in commands["B5"]
    for command in commands.values():
        assert "--protocol_fusion_readaptation" not in command
        assert "--load=1" not in command


def test_e12_reference_mapping_is_immutable():
    assert reference_run_id("B1", "3", 1111) == (
        "E11_A1_mosei_p3_s1111"
    )
    assert reference_run_id("B4", "5", 7777) == (
        "E06R1_M1_mosei_p5_s7777"
    )


def test_e12_audit_builds_six_arms_and_random_control_effect(tmp_path):
    specs = build_matrix(protocols=("3",), seeds=(1111,))
    _write_cell(tmp_path, specs)
    summary = audit_matrix(
        tmp_path, specs, perform_reference_preflight=False
    )
    assert summary["completed_new_run_count"] == 4
    assert summary["completed_reused_reference_count"] == 2
    assert summary["completed_total_ablation_cells"] == 6
    assert [item["arm"] for item in summary["records"]] == list(ARMS)
    random_effect = summary["effects"]["similarity_over_random"]["summary"]
    assert random_effect["test_mae"]["mean_gain"] == pytest.approx(0.13)
    assert random_effect["test_mae"]["wins"] == 1
    exclusion = summary["effects"]["missing_candidate_exclusion"]["summary"]
    assert exclusion["test_mae"]["mean_gain"] == pytest.approx(0.05)


def test_e12_audit_rejects_missing_reference(tmp_path):
    specs = build_matrix(protocols=("0",), seeds=(1111,))
    _write_cell(tmp_path, specs)
    path = (
        tmp_path / "paper_experiments" / "manifests"
        / "E11_A1_mosei_p0_s1111.json"
    )
    path.unlink()
    with pytest.raises(RuntimeError, match="missing_reference=1"):
        audit_matrix(
            tmp_path, specs, perform_reference_preflight=False
        )


def test_e12_rejects_wrong_random_seed_contract(tmp_path):
    specs = build_matrix(
        protocols=("0",), seeds=(1111,), arms=("B5",)
    )
    spec = specs[0]
    _write_manifest(tmp_path, {
        "status": "complete", "run_id": spec.run_id,
        "method_id": spec.method, "stage_id": "E12",
        "dataset": "mosei", "protocol": "0", "seed": 1111,
        "lineage": None, "code_sha256": {"main.py": "new"},
        "arguments": {
            "retrieval_mode": "missing_aware",
            "retrieval_candidate_source": "train_bank",
            "retrieval_candidate_filter": "observed_only",
            "retrieval_composition": "prototype_neighbours",
            "retrieval_selection": "random",
            "retrieval_random_seed": 9999,
            "retrieval_queue_size": 0,
            "protocol_fusion_readaptation": False,
            "load": 0,
        },
        "result": _result("0", 0.5),
    })
    with pytest.raises(RuntimeError, match="retrieval_random_seed"):
        audit_matrix(
            tmp_path, specs, require_complete=False,
            perform_reference_preflight=False,
        )
