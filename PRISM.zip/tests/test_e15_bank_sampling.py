import torch

from modules.retrieval_bank_sampling import (
    deterministic_retrieval_bank_subset_indices,
)


def _selected_ids(sample_ids, size, seed=3407):
    indices = deterministic_retrieval_bank_subset_indices(sample_ids, size, seed)
    return sample_ids.index_select(0, indices)


def test_finite_bank_membership_is_order_independent_and_nested():
    ids = torch.arange(6000, dtype=torch.long)
    permutation = torch.randperm(ids.numel(), generator=torch.Generator().manual_seed(9))
    shuffled = ids.index_select(0, permutation)

    selected_512 = set(_selected_ids(ids, 512).tolist())
    selected_1024 = set(_selected_ids(ids, 1024).tolist())
    shuffled_512 = set(_selected_ids(shuffled, 512).tolist())
    shuffled_1024 = set(_selected_ids(shuffled, 1024).tolist())

    assert selected_512 == shuffled_512
    assert selected_1024 == shuffled_1024
    assert selected_512 < selected_1024


def test_full_bank_preserves_frozen_e06_order_and_global_rng():
    ids = torch.tensor([4, 1, 3, 0, 2])
    before = torch.random.get_rng_state().clone()
    full_zero = deterministic_retrieval_bank_subset_indices(ids, 0, 3407)
    full_explicit = deterministic_retrieval_bank_subset_indices(ids, 5, 3407)
    finite = deterministic_retrieval_bank_subset_indices(ids, 3, 3407)
    after = torch.random.get_rng_state()

    assert torch.equal(full_zero, torch.arange(5))
    assert torch.equal(full_explicit, torch.arange(5))
    assert finite.numel() == 3
    assert torch.equal(before, after)


def test_invalid_bank_sizes_fail_closed():
    ids = torch.arange(10)
    for size in (-1, 11):
        try:
            deterministic_retrieval_bank_subset_indices(ids, size, 3407)
        except ValueError:
            pass
        else:
            raise AssertionError("invalid finite bank size was accepted")
