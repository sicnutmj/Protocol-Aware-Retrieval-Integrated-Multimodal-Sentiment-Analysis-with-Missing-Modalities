import unittest

import torch

from modules.same_sample_bundle_retrieval import (
    SentimentConsistentBundleRetrieval,
)


class SentimentConsistentBundleRetrievalTest(unittest.TestCase):
    def setUp(self):
        self.module = SentimentConsistentBundleRetrieval(
            embedding_dim=2,
            top_k=2,
            temperature=0.1,
            sentiment_weight=1.0,
            sentiment_temperature=1.0,
        )
        self.banks = {
            "l": torch.tensor([[1.0, 0.0], [0.9, 0.1], [-1.0, 0.0]]),
            "a": torch.tensor([[10.0, 1.0], [20.0, 2.0], [30.0, 3.0]]),
            "v": torch.tensor([[11.0, 1.0], [21.0, 2.0], [31.0, 3.0]]),
        }
        self.labels = torch.tensor([-1.0, 1.0, 0.0])
        self.module.set_reference_bank(self.banks, self.labels)
        self.raw = (
            torch.tensor([[1.0, 0.0]]),
            torch.zeros(1, 2),
            torch.zeros(1, 2),
        )
        self.mask = torch.tensor([[1, 0, 0]], dtype=torch.bool)
        self.base = tuple(torch.randn(1, 4, 2) for _ in range(3))

    def test_zero_scale_is_exact_identity(self):
        completed, diagnostics = self.module(
            self.raw, self.mask, self.base, torch.tensor([1.0])
        )
        for actual, expected in zip(completed, self.base):
            self.assertTrue(torch.equal(actual, expected))
        self.assertEqual(diagnostics["injection_scale"].item(), 0.0)

    def test_observed_target_is_unchanged_at_full_scale(self):
        self.module.set_injection_scale(1.0)
        completed, _ = self.module(
            self.raw, self.mask, self.base, torch.tensor([1.0])
        )
        self.assertTrue(torch.equal(completed[0], self.base[0]))
        self.assertFalse(torch.equal(completed[1], self.base[1]))
        self.assertFalse(torch.equal(completed[2], self.base[2]))

    def test_all_missing_targets_use_the_same_donor_order(self):
        self.module.set_injection_scale(1.0)
        _, diagnostics = self.module(
            self.raw, self.mask, self.base, torch.tensor([1.0])
        )
        donors = diagnostics["donor_indices"]
        self.assertEqual(donors.shape, (1, 2))
        # Candidate 1 is slightly less similar than candidate 0, but its label
        # agrees with the frozen +1 sentiment anchor and must rank first.
        self.assertEqual(donors[0, 0].item(), 1)

    def test_invalid_scale_is_rejected(self):
        with self.assertRaises(ValueError):
            self.module.set_injection_scale(1.1)


if __name__ == "__main__":
    unittest.main()
