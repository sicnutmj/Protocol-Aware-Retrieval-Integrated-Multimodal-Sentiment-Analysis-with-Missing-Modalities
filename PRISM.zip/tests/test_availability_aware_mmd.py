import unittest

import torch
from torch import nn

from modules.availability_aware_mmd import AvailabilityAwareMMD


class MeanAlignmentLoss(nn.Module):
    def forward(self, x, y):
        return (x.mean(dim=0) - y.mean(dim=0)).pow(2).mean()


class AvailabilityAwareMMDTest(unittest.TestCase):
    def setUp(self):
        self.enhanced = torch.tensor(
            [[0.0], [2.0], [10.0], [14.0]], requires_grad=True
        )
        self.sample = torch.tensor([[0.0], [0.0], [10.0], [10.0]])
        self.observed = torch.tensor([True, True, False, False])

    def test_mixed_matches_original_loss(self):
        base = MeanAlignmentLoss()
        objective = AvailabilityAwareMMD(base, mode='mixed')
        loss, diagnostics = objective(
            self.enhanced, self.sample, self.observed
        )
        torch.testing.assert_close(loss, base(self.enhanced, self.sample))
        self.assertEqual(diagnostics['observed_count'], 2)
        self.assertEqual(diagnostics['missing_count'], 2)

    def test_status_separated_uses_conditional_losses(self):
        objective = AvailabilityAwareMMD(
            MeanAlignmentLoss(), mode='status_separated'
        )
        loss, diagnostics = objective(
            self.enhanced, self.sample, self.observed
        )
        torch.testing.assert_close(loss, torch.tensor(2.5))
        self.assertEqual(diagnostics['observed_weight'], 0.5)
        self.assertEqual(diagnostics['missing_weight'], 0.5)

    def test_small_group_is_skipped_and_remaining_weight_is_renormalized(self):
        objective = AvailabilityAwareMMD(
            MeanAlignmentLoss(), mode='status_separated', min_group_size=2
        )
        mask = torch.tensor([True, False, False, False])
        loss, diagnostics = objective(self.enhanced, self.sample, mask)
        expected = MeanAlignmentLoss()(self.enhanced[1:], self.sample[1:])
        torch.testing.assert_close(loss, expected)
        self.assertFalse(diagnostics['observed_used'])
        self.assertEqual(diagnostics['missing_weight'], 1.0)

    def test_observed_only_does_not_backpropagate_through_missing_rows(self):
        objective = AvailabilityAwareMMD(
            MeanAlignmentLoss(), mode='observed_only'
        )
        loss, _ = objective(self.enhanced, self.sample, self.observed)
        loss.backward()
        torch.testing.assert_close(
            self.enhanced.grad[2:], torch.zeros_like(self.enhanced.grad[2:])
        )

    def test_none_returns_differentiable_zero(self):
        objective = AvailabilityAwareMMD(MeanAlignmentLoss(), mode='none')
        loss, _ = objective(self.enhanced, self.sample, self.observed)
        loss.backward()
        self.assertEqual(loss.item(), 0.0)
        torch.testing.assert_close(
            self.enhanced.grad, torch.zeros_like(self.enhanced.grad)
        )


if __name__ == '__main__':
    unittest.main()
