import hashlib
import json

import pytest

from run_e08_protocol3_clean import (
    METRICS,
    SPLIT_SIZES,
    audit_matrix,
    build_matrix,
    command_for_spec,
    _reference_run_id,
)


def test_e08_matrix_has_fixed_size_order_and_clean_lineage(tmp_path):
    specs = build_matrix()
    assert len(specs) == 30
    assert [spec.method for spec in specs[:3]] == ["M0", "M1", "M2"]
    assert specs[2].parent_run_id == specs[1].run_id
    assert len({spec.run_id for spec in specs}) == 30
    assert specs[0].run_id == "E08_M0_mosei_p3_s1111"
    assert specs[15].run_id == "E08_M0_mosi_p3_s1111"
    assert all("_p3_" in spec.run_id for spec in specs)
    assert all(spec.method != "M3" for spec in specs)

    command = command_for_spec(tmp_path, specs[2], resolve_parent=False)
    joined = " ".join(command)
    assert "--dataset=mosei" in command
    assert "--fixed_protocol=3" in command
    assert "--paper_stage_id=E08" in command
    assert "--paper_parent_run_id={}".format(specs[1].run_id) in command
    assert "--model_path=<PARENT_CHECKPOINT>" in command
    assert "--protocol_fusion_readaptation" in command
    assert "E06" not in joined
    assert "E07" not in joined
    assert "best_modules" not in joined


def _sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _write_complete(workspace, spec, code=None, dataset_sha=None):
    manifest_dir = workspace / "paper_experiments" / "manifests"
    checkpoint_dir = workspace / "paper_checkpoints"
    manifest_dir.mkdir(parents=True, exist_ok=True)
    checkpoint_dir.mkdir(parents=True, exist_ok=True)
    checkpoint = checkpoint_dir / "{}_best.pt".format(spec.run_id)
    checkpoint.write_bytes(spec.run_id.encode("utf-8"))
    result = {
        "best_epoch": 2,
        "best_loss": 0.5,
        "selection_split": "development",
        "selection_metric": "mae",
        "test_evaluation_count": 1,
        "selected_state_sha256": "state-{}".format(spec.run_id),
        "data_provenance": {
            "dataset_sha256": dataset_sha or "{}-data".format(spec.dataset),
            "split_sizes": SPLIT_SIZES[spec.dataset],
        },
    }
    result.update({metric: 0.6 for metric in METRICS})
    lineage = None
    if spec.parent_run_id:
        result["adaptation_gate"] = {
            "outcome": "improved",
            "dev_mae_gain": 0.01,
            "test_metrics_consulted": False,
        }
        lineage = {
            "parent_run_id": spec.parent_run_id,
            "parent_method_id": "M1",
        }
    payload = {
        "run_id": spec.run_id,
        "method_id": spec.method,
        "stage_id": "E08",
        "status": "complete",
        "dataset": spec.dataset,
        "protocol": "3",
        "seed": spec.seed,
        "code_sha256": code or {"main.py": "same"},
        "lineage": lineage,
        "outputs": {
            "best_model_path": str(checkpoint),
            "best_model_sha256": _sha(checkpoint),
        },
        "result": result,
    }
    (manifest_dir / "{}.json".format(spec.run_id)).write_text(
        json.dumps(payload), encoding="utf-8"
    )


def test_e08_audit_accepts_complete_dual_dataset_subset(tmp_path):
    specs = build_matrix(datasets=("mosei", "mosi"), seeds=(1111,))
    for spec in specs:
        _write_complete(tmp_path, spec)
    summary = audit_matrix(tmp_path, specs)
    assert summary["completed_run_count"] == 6
    assert summary["dataset_sha256"] == {
        "mosei": "mosei-data", "mosi": "mosi-data"
    }
    assert summary["adaptation_outcomes"] == {
        "mosei:improved": 1, "mosi:improved": 1
    }
    json.dumps(summary)


def test_e08_audit_rejects_missing_or_mixed_code(tmp_path):
    specs = build_matrix(datasets=("mosei",), seeds=(1111,))
    for spec in specs[:-1]:
        _write_complete(tmp_path, spec)
    with pytest.raises(RuntimeError, match="Incomplete E08 matrix"):
        audit_matrix(tmp_path, specs)

    _write_complete(tmp_path, specs[-1], code={"main.py": "changed"})
    with pytest.raises(RuntimeError, match="different code fingerprints"):
        audit_matrix(tmp_path, specs)


def test_e08_rejects_nonfinal_manifest_instead_of_overwriting(tmp_path):
    spec = build_matrix(
        datasets=("mosi",), seeds=(1111,), methods=("M0",)
    )[0]
    manifest_dir = tmp_path / "paper_experiments" / "manifests"
    manifest_dir.mkdir(parents=True)
    (manifest_dir / "{}.json".format(spec.run_id)).write_text(
        json.dumps({"status": "failed"}), encoding="utf-8"
    )
    with pytest.raises(RuntimeError, match="do not overwrite"):
        audit_matrix(tmp_path, (spec,))


def test_e08_rejects_wrong_dataset_split_sizes(tmp_path):
    spec = build_matrix(
        datasets=("mosei",), seeds=(1111,), methods=("M0",)
    )[0]
    _write_complete(tmp_path, spec)
    path = (
        tmp_path / "paper_experiments" / "manifests"
        / "{}.json".format(spec.run_id)
    )
    payload = json.loads(path.read_text(encoding="utf-8"))
    payload["result"]["data_provenance"]["split_sizes"]["test"] = 1
    path.write_text(json.dumps(payload), encoding="utf-8")
    with pytest.raises(RuntimeError, match="split sizes"):
        audit_matrix(tmp_path, (spec,))


def test_e08_records_exact_primary_reference_replication(tmp_path):
    specs = build_matrix(datasets=("mosi",), seeds=(1111,))
    manifest_dir = tmp_path / "paper_experiments" / "manifests"
    for spec in specs:
        _write_complete(tmp_path, spec)
        rerun_path = manifest_dir / "{}.json".format(spec.run_id)
        reference = json.loads(rerun_path.read_text(encoding="utf-8"))
        reference["run_id"] = _reference_run_id(spec)
        reference["stage_id"] = "E07"
        (manifest_dir / "{}.json".format(reference["run_id"])).write_text(
            json.dumps(reference), encoding="utf-8"
        )
    summary = audit_matrix(
        tmp_path, specs, require_complete=True, require_reference=True
    )
    replication = summary["primary_reference_replication"]
    assert replication["completed_comparison_count"] == 3
    assert replication["exact_replication_count"] == 3
    assert replication["nonexact_replication_count"] == 0

    reference_path = manifest_dir / "{}.json".format(_reference_run_id(specs[0]))
    reference = json.loads(reference_path.read_text(encoding="utf-8"))
    reference["result"]["test_mae"] += 0.01
    reference_path.write_text(json.dumps(reference), encoding="utf-8")
    replication = audit_matrix(tmp_path, specs)["primary_reference_replication"]
    assert replication["exact_replication_count"] == 2
    assert replication["comparisons"][0]["mismatched_fields"] == ["test_mae"]
