import unittest
import torch

from modules.label_semantic_missing_text_residual import (
    LabelSemanticMissingTextResidual,
    label_semantic_missing_text_objective,
)


def _inputs(dim=8):
    protocols = torch.tensor(
        [
            [1, 0, 0],
            [0, 1, 0],
            [0, 0, 1],
            [1, 1, 0],
            [1, 0, 1],
            [0, 1, 1],
            [1, 1, 1],
        ]
    )
    sample = torch.randn(7, dim)
    enhanced = tuple(torch.randn(7, dim) for _ in range(3))
    raw = tuple(torch.randn(7, dim) for _ in range(3))
    return protocols, sample, enhanced, raw


class LabelSemanticMissingTextResidualTest(unittest.TestCase):
    def test_zero_scale_is_exact_fpfr_identity(self):
        torch.manual_seed(17)
        model = LabelSemanticMissingTextResidual(8, hidden_dim=16)
        protocols, sample, enhanced, raw = _inputs()
        corrected, diagnostics = model(sample, enhanced, raw, protocols)
        self.assertTrue(all(
            torch.equal(before, after)
            for before, after in zip(enhanced, corrected)
        ))
        self.assertEqual(diagnostics["scale"].item(), 0.0)
        self.assertEqual(diagnostics["eligible_count"].item(), 3.0)

    def test_only_missing_text_protocols_receive_a_residual(self):
        torch.manual_seed(19)
        model = LabelSemanticMissingTextResidual(
            8, hidden_dim=16, max_scale=0.8
        )
        protocols, sample, enhanced, raw = _inputs()
        with torch.no_grad():
            model.injection_scale_logit.fill_(0.7)
        corrected, _ = model(sample, enhanced, raw, protocols)
        changed = (corrected[0] != enhanced[0]).any(dim=1)
        self.assertTrue(torch.equal(
            changed,
            torch.tensor([False, True, True, False, False, True, False]),
        ))
        self.assertTrue(torch.equal(corrected[1], enhanced[1]))
        self.assertTrue(torch.equal(corrected[2], enhanced[2]))

    def test_unavailable_nonverbal_features_cannot_affect_prediction(self):
        torch.manual_seed(23)
        model = LabelSemanticMissingTextResidual(8, hidden_dim=16)
        protocols, sample, enhanced, raw = _inputs()
        first = model(sample, enhanced, raw, protocols)[1]["predicted_residual"]
        changed_raw = list(raw)
        changed_enhanced = list(enhanced)
        changed_raw[1] = raw[1] + 1000.0
        changed_enhanced[1] = enhanced[1] - 1000.0
        second = model(
            sample, tuple(changed_enhanced), tuple(changed_raw), protocols
        )[1]["predicted_residual"]
        audio_missing = protocols[:, 1] == 0
        self.assertTrue(torch.allclose(
            first[audio_missing], second[audio_missing]
        ))

    def test_pair_and_contrastive_losses_train_predictor_and_scale(self):
        torch.manual_seed(29)
        model = LabelSemanticMissingTextResidual(8, hidden_dim=16)
        protocols, sample, enhanced, raw = _inputs()
        _, diagnostics = model(sample, enhanced, raw, protocols)
        target = torch.randn(7, 8, requires_grad=True)
        labels = torch.linspace(-3, 3, 7)
        pair_loss, contrastive_loss, info = (
            label_semantic_missing_text_objective(
                diagnostics,
                target,
                labels,
                temperature=0.5,
                semantic_weighting=True,
            )
        )
        (pair_loss + contrastive_loss).backward()
        gradient = sum(
            parameter.grad.abs().sum().item()
            for parameter in model.residual_predictor.parameters()
            if parameter.grad is not None
        )
        self.assertGreater(gradient, 0.0)
        self.assertGreater(
            model.injection_scale_logit.grad.abs().item(), 0.0
        )
        self.assertIsNone(target.grad)
        self.assertEqual(info["eligible_count"].item(), 3.0)

    def test_label_weighting_changes_only_the_contrastive_objective(self):
        torch.manual_seed(31)
        model = LabelSemanticMissingTextResidual(8, hidden_dim=16)
        protocols, sample, enhanced, raw = _inputs()
        _, diagnostics = model(sample, enhanced, raw, protocols)
        target = torch.randn(7, 8)
        labels = torch.tensor([0.0, -3.0, 3.0, 0.0, 0.0, 2.0, 0.0])
        pair_plain, contrast_plain, _ = label_semantic_missing_text_objective(
            diagnostics, target, labels, semantic_weighting=False
        )
        pair_semantic, contrast_semantic, _ = (
            label_semantic_missing_text_objective(
                diagnostics, target, labels, semantic_weighting=True
            )
        )
        self.assertTrue(torch.equal(pair_plain, pair_semantic))
        self.assertFalse(torch.equal(contrast_plain, contrast_semantic))

    def test_no_missing_text_returns_differentiable_zero_losses(self):
        torch.manual_seed(37)
        model = LabelSemanticMissingTextResidual(8, hidden_dim=16)
        protocols = torch.ones(4, 3)
        sample = torch.randn(4, 8)
        enhanced = tuple(torch.randn(4, 8) for _ in range(3))
        raw = tuple(torch.randn(4, 8) for _ in range(3))
        _, diagnostics = model(sample, enhanced, raw, protocols)
        pair, contrast, info = label_semantic_missing_text_objective(
            diagnostics, torch.randn(4, 8), torch.randn(4)
        )
        (pair + contrast).backward()
        self.assertAlmostEqual(pair.item(), 0.0)
        self.assertAlmostEqual(contrast.item(), 0.0)
        self.assertEqual(info["eligible_count"].item(), 0.0)


if __name__ == "__main__":
    unittest.main()
