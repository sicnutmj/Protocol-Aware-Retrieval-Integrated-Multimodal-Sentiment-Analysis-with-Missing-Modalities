import unittest

import torch

from modules.unified_consensus_residual import (
    AvailabilityMaskedUnifiedConsensusResidual,
)


class UnifiedConsensusResidualTest(unittest.TestCase):
    def setUp(self):
        torch.manual_seed(7)
        self.module = AvailabilityMaskedUnifiedConsensusResidual(
            embedding_dim=12,
            output_dim=1,
            num_heads=3,
            num_layers=2,
            hidden_dim=8,
            dropout=0.2,
        )
        self.representations = tuple(torch.randn(4, 12) for _ in range(7))
        self.mask = torch.tensor([
            [1, 0, 0],
            [1, 1, 0],
            [1, 0, 1],
            [1, 1, 1],
        ])
        self.base = torch.randn(4, 1)

    def test_epoch_zero_is_exact_identity_even_in_train_mode(self):
        self.module.train()
        prediction, diagnostics = self.module(
            self.representations, self.mask, self.base
        )
        self.assertTrue(torch.equal(prediction, self.base))
        self.assertEqual(diagnostics['residual_abs_mean'].item(), 0.0)

    def test_missing_raw_is_masked_but_enhanced_remains_visible(self):
        self.module.eval()
        one_representations = tuple(item[:1] for item in self.representations)
        one_mask = torch.tensor([[1, 0, 1]])
        _, diagnostics = self.module(
            one_representations, one_mask, self.base[:1]
        )
        attention = diagnostics['attention_mean']
        self.assertEqual(attention.shape, torch.Size([7]))
        self.assertEqual(attention[5].item(), 0.0)
        self.assertGreater(attention[2].item(), 0.0)

    def test_only_adapter_output_layer_receives_first_step_signal(self):
        prediction, _ = self.module(
            self.representations, self.mask, self.base
        )
        prediction.sum().backward()
        final_layer = self.module.residual_head[-1]
        self.assertGreater(final_layer.weight.grad.abs().sum().item(), 0.0)

    def test_nonzero_residual_is_additive(self):
        final_layer = self.module.residual_head[-1]
        with torch.no_grad():
            final_layer.weight.fill_(0.1)
        prediction, diagnostics = self.module(
            self.representations, self.mask, self.base
        )
        self.assertTrue(torch.equal(
            prediction,
            self.base + diagnostics['residual'],
        ))
        self.assertGreater(diagnostics['residual_abs_mean'].item(), 0.0)

    def test_rejects_invalid_availability(self):
        invalid = self.mask.float()
        invalid[0, 1] = 0.5
        with self.assertRaises(ValueError):
            self.module(self.representations, invalid, self.base)

    def test_rejects_all_missing_sample(self):
        invalid = self.mask.clone()
        invalid[0] = 0
        with self.assertRaises(ValueError):
            self.module(self.representations, invalid, self.base)

    def test_head_count_must_divide_embedding_dimension(self):
        with self.assertRaises(ValueError):
            AvailabilityMaskedUnifiedConsensusResidual(
                embedding_dim=10,
                num_heads=3,
            )


if __name__ == '__main__':
    unittest.main()
