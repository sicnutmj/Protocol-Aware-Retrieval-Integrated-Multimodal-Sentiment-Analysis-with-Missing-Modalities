import unittest

import torch

from modules.missing_aware_retrieval import (
    MissingAwareRetrieval,
    legacy_batch_retrieval,
)


class MissingAwareRetrievalTest(unittest.TestCase):
    def test_e12_default_controls_are_exactly_backward_compatible(self):
        torch.manual_seed(7)
        default = MissingAwareRetrieval(
            embedding_dim=3, top_k=2, queue_size=0, temperature=0.2
        )
        torch.manual_seed(7)
        explicit = MissingAwareRetrieval(
            embedding_dim=3,
            top_k=2,
            queue_size=0,
            temperature=0.2,
            candidate_filter="observed_only",
            composition_mode="prototype_neighbours",
            selection_mode="similarity",
        )
        embeddings = torch.tensor([
            [1.0, 0.0, 0.0],
            [0.8, 0.2, 0.0],
            [0.0, 0.0, 0.0],
            [0.0, 1.0, 0.0],
        ])
        observed = torch.tensor([True, True, False, True])
        left, left_diag = default(
            embeddings, observed, update_memory=False
        )
        right, right_diag = explicit(
            embeddings, observed, update_memory=False
        )
        torch.testing.assert_close(left, right, rtol=0.0, atol=0.0)
        for key in (
            "topk_indices", "topk_valid", "topk_weights",
            "support_count", "weighted_similarity",
        ):
            torch.testing.assert_close(
                left_diag[key], right_diag[key], rtol=0.0, atol=0.0
            )

    def test_e12_unfiltered_control_can_select_missing_placeholder(self):
        embeddings = torch.tensor([
            [1.0, 0.0],
            [0.0, 0.0],
            [-1.0, 0.0],
        ])
        observed = torch.tensor([True, False, True])
        filtered = MissingAwareRetrieval(
            embedding_dim=2, top_k=1, candidate_filter="observed_only"
        )
        unfiltered = MissingAwareRetrieval(
            embedding_dim=2, top_k=1, candidate_filter="all"
        )
        _, filtered_diag = filtered(
            embeddings, observed, update_memory=False
        )
        result, unfiltered_diag = unfiltered(
            embeddings, observed, update_memory=False
        )
        self.assertEqual(filtered_diag["topk_indices"][0, 0].item(), 2)
        self.assertEqual(unfiltered_diag["topk_indices"][0, 0].item(), 1)
        torch.testing.assert_close(result[0, 1], embeddings[1])

    def test_e12_prototype_and_neighbour_compositions_preserve_shape(self):
        embeddings = torch.tensor([
            [1.0, 0.0],
            [0.8, 0.2],
            [0.0, 1.0],
        ])
        observed = torch.ones(3, dtype=torch.bool)
        prototype = MissingAwareRetrieval(
            embedding_dim=2, top_k=2, composition_mode="prototype_only"
        )
        neighbours = MissingAwareRetrieval(
            embedding_dim=2, top_k=2, composition_mode="neighbours_only"
        )
        prototype_result, _ = prototype(
            embeddings, observed, update_memory=False
        )
        neighbour_result, neighbour_diag = neighbours(
            embeddings, observed, update_memory=False
        )
        center = embeddings.mean(dim=0)
        self.assertEqual(prototype_result.shape, (3, 4, 2))
        torch.testing.assert_close(
            prototype_result[:, 1:],
            center.view(1, 1, -1).expand(3, 3, -1),
        )
        selected = embeddings[neighbour_diag["topk_indices"]]
        expected_summary = (
            selected * neighbour_diag["topk_weights"].unsqueeze(-1)
        ).sum(dim=1)
        torch.testing.assert_close(neighbour_result[:, -1], expected_summary)

    def test_e12_random_train_bank_is_stateless_and_batch_invariant(self):
        retrieval = MissingAwareRetrieval(
            embedding_dim=2,
            top_k=2,
            candidate_source="train_bank",
            selection_mode="random",
            random_seed=1111,
        )
        bank = torch.tensor([
            [1.0, 0.0], [0.8, 0.2], [0.0, 1.0], [0.2, 0.8]
        ])
        retrieval.set_reference_bank(bank, torch.arange(4))
        queries = torch.tensor([[0.9, 0.1], [0.1, 0.9], [0.7, 0.3]])
        ids = torch.tensor([10, 11, 12])
        together, together_diag = retrieval(
            queries,
            torch.ones(3, dtype=torch.bool),
            query_ids=ids,
            update_memory=False,
        )
        pieces = []
        indices = []
        for index in range(3):
            result, diagnostics = retrieval(
                queries[index:index + 1],
                torch.ones(1, dtype=torch.bool),
                query_ids=ids[index:index + 1],
                update_memory=False,
            )
            pieces.append(result)
            indices.append(diagnostics["topk_indices"])
        torch.testing.assert_close(together, torch.cat(pieces, dim=0))
        torch.testing.assert_close(
            together_diag["topk_indices"], torch.cat(indices, dim=0)
        )
        self.assertEqual(together_diag["selection_mode"], "random")

    def test_legacy_mode_keeps_original_shape(self):
        embeddings = torch.tensor([
            [1.0, 0.0],
            [0.0, 1.0],
            [1.0, 1.0],
        ])
        result, diagnostics = legacy_batch_retrieval(embeddings, top_k=2)

        self.assertEqual(result.shape, (3, 4, 2))
        self.assertTrue(
            torch.equal(
                diagnostics["support_count"],
                torch.tensor([2, 2, 2]),
            )
        )
        self.assertEqual(diagnostics["retrieval_loss"].ndim, 0)
        self.assertEqual(diagnostics["retrieval_loss"].item(), 0.0)
        self.assertEqual(diagnostics["topk_indices"].shape, (3, 2))
        self.assertTrue(diagnostics["topk_valid"].all().item())
        self.assertTrue(
            (diagnostics["topk_indices"] >= 0).all().item()
        )

    def test_missing_candidate_is_excluded(self):
        retrieval = MissingAwareRetrieval(
            embedding_dim=2,
            top_k=1,
            queue_size=0,
            temperature=0.1,
        )
        embeddings = torch.tensor([
            [1.0, 0.0],
            [1.0, 0.0],  # Most similar, but this modality is missing.
            [0.0, 1.0],
        ])
        observed = torch.tensor([True, False, True])

        result, diagnostics = retrieval(
            embeddings, observed, update_memory=False
        )

        torch.testing.assert_close(result[0, 1], embeddings[2])
        self.assertEqual(diagnostics["support_count"][0].item(), 1)

    def test_queue_contains_only_observed_representations(self):
        retrieval = MissingAwareRetrieval(
            embedding_dim=2,
            top_k=1,
            queue_size=4,
        )
        retrieval.train()
        first_batch = torch.tensor([
            [1.0, 0.0],
            [0.0, 1.0],
        ])
        retrieval(first_batch, torch.tensor([True, False]))

        self.assertEqual(retrieval.memory_size.item(), 1)
        torch.testing.assert_close(retrieval.memory[0], first_batch[0])

        query = torch.tensor([[0.9, 0.1]])
        result, diagnostics = retrieval(
            query, torch.tensor([False]), update_memory=False
        )
        torch.testing.assert_close(result[0, 1], first_batch[0])
        self.assertEqual(diagnostics["support_count"][0].item(), 1)

    def test_prototype_is_used_without_observed_support(self):
        retrieval = MissingAwareRetrieval(
            embedding_dim=3,
            top_k=2,
            queue_size=0,
        )
        embeddings = torch.zeros(1, 3)

        result, diagnostics = retrieval(
            embeddings, torch.tensor([False]), update_memory=False
        )

        expected = retrieval.fallback_prototype.detach()
        torch.testing.assert_close(result[0, 1], expected)
        torch.testing.assert_close(result[0, 2], expected)
        torch.testing.assert_close(result[0, 3], expected)
        self.assertEqual(diagnostics["support_count"][0].item(), 0)
        self.assertEqual(diagnostics["support_ratio"][0].item(), 0.0)
        self.assertEqual(diagnostics["valid_ratio"][0].item(), 0.0)
        self.assertEqual(diagnostics["topk_confidence"][0].item(), 0.0)
        self.assertEqual(diagnostics["neighbour_dispersion"][0].item(), 1.0)
        self.assertTrue(torch.isfinite(result).all())

    def test_more_similar_neighbour_gets_more_weight(self):
        retrieval = MissingAwareRetrieval(
            embedding_dim=2,
            top_k=2,
            queue_size=0,
            temperature=0.2,
        )
        embeddings = torch.tensor([
            [1.0, 0.0],
            [0.9, 0.1],
            [0.0, 1.0],
        ])
        _, diagnostics = retrieval(
            embeddings,
            torch.tensor([True, True, True]),
            update_memory=False,
        )

        weights = diagnostics["topk_weights"][0]
        self.assertGreater(weights[0].item(), weights[1].item())
        self.assertAlmostEqual(weights.sum().item(), 1.0, places=6)
        self.assertGreaterEqual(diagnostics["topk_confidence"][0].item(), 0.0)
        self.assertLessEqual(diagnostics["topk_confidence"][0].item(), 1.0)
        self.assertTrue(torch.isfinite(
            diagnostics["neighbour_dispersion"]
        ).all())

    def test_eval_does_not_mutate_queue(self):
        retrieval = MissingAwareRetrieval(
            embedding_dim=2,
            top_k=1,
            queue_size=4,
        )
        retrieval.eval()
        retrieval(
            torch.tensor([[1.0, 0.0]]),
            torch.tensor([True]),
        )
        self.assertEqual(retrieval.memory_size.item(), 0)

    def test_queue_update_does_not_break_backward(self):
        retrieval = MissingAwareRetrieval(
            embedding_dim=2,
            top_k=1,
            queue_size=4,
        )
        retrieval.train()
        retrieval(
            torch.tensor([[1.0, 0.0]]),
            torch.tensor([True]),
        )

        embeddings = torch.tensor(
            [[0.8, 0.2], [0.0, 1.0]],
            requires_grad=True,
        )
        result, _ = retrieval(embeddings, torch.tensor([True, True]))
        result.sum().backward()

        self.assertIsNotNone(embeddings.grad)
        self.assertTrue(torch.isfinite(embeddings.grad).all())

    def test_sentiment_guided_loss_trains_only_projection_space(self):
        retrieval = MissingAwareRetrieval(
            embedding_dim=2,
            top_k=1,
            queue_size=0,
            temperature=0.2,
            metric_mode="sentiment_guided",
            projection_dim=2,
            missing_query_mode="center",
            label_temperature=0.5,
        )
        embeddings = torch.tensor([
            [1.0, 0.0],
            [0.8, 0.2],
            [0.0, 1.0],
            [0.2, 0.8],
        ])
        labels = torch.tensor([-2.0, -1.0, 1.0, 2.0])

        result, diagnostics = retrieval(
            embeddings,
            torch.ones(4, dtype=torch.bool),
            labels=labels,
            update_memory=False,
        )
        loss = diagnostics["retrieval_loss"]
        self.assertTrue(torch.isfinite(loss))
        self.assertGreaterEqual(loss.item(), 0.0)
        loss.backward()
        self.assertIsNotNone(retrieval.key_projection.weight.grad)
        # Neighbour values still have the original feature dimension and are
        # not replaced by projected vectors.
        self.assertEqual(result.shape, (4, 3, 2))

    def test_sample_query_is_specific_to_each_missing_sample(self):
        retrieval = MissingAwareRetrieval(
            embedding_dim=2,
            top_k=1,
            queue_size=0,
            temperature=0.1,
            metric_mode="sentiment_guided",
            projection_dim=2,
            missing_query_mode="sample",
            sample_embedding_dim=2,
        )
        with torch.no_grad():
            retrieval.key_projection.weight.copy_(torch.eye(2))
            retrieval.sample_query_projection.weight.copy_(torch.eye(2))
        embeddings = torch.tensor([
            [1.0, 0.0],
            [0.0, 1.0],
            [0.0, 0.0],
            [0.0, 0.0],
        ])
        observed = torch.tensor([True, True, False, False])
        sample_query = torch.tensor([
            [0.0, 0.0],
            [0.0, 0.0],
            [1.0, 0.0],
            [0.0, 1.0],
        ])

        result, diagnostics = retrieval(
            embeddings,
            observed,
            sample_query=sample_query,
            update_memory=False,
        )

        torch.testing.assert_close(result[2, 1], embeddings[0])
        torch.testing.assert_close(result[3, 1], embeddings[1])
        self.assertEqual(diagnostics["topk_indices"][2, 0].item(), 0)
        self.assertEqual(diagnostics["topk_indices"][3, 0].item(), 1)

    def test_eval_retrieval_never_requires_labels(self):
        retrieval = MissingAwareRetrieval(
            embedding_dim=2,
            top_k=1,
            metric_mode="sentiment_guided",
            projection_dim=2,
        )
        _, diagnostics = retrieval(
            torch.tensor([[1.0, 0.0], [0.0, 1.0]]),
            torch.tensor([True, True]),
            labels=None,
            update_memory=False,
        )
        self.assertEqual(diagnostics["retrieval_loss"].item(), 0.0)

    def test_train_bank_excludes_the_training_query_itself(self):
        retrieval = MissingAwareRetrieval(
            embedding_dim=2,
            top_k=1,
            queue_size=0,
            temperature=0.1,
            candidate_source="train_bank",
        )
        bank = torch.tensor([
            [1.0, 0.0],
            [0.9, 0.1],
            [0.0, 1.0],
        ])
        bank_ids = torch.tensor([10, 11, 12])
        retrieval.set_reference_bank(bank, bank_ids)

        result, diagnostics = retrieval(
            bank[:1],
            torch.tensor([True]),
            query_ids=torch.tensor([10]),
            update_memory=False,
        )

        self.assertEqual(diagnostics["topk_indices"][0, 0].item(), 1)
        torch.testing.assert_close(result[0, 1], bank[1])
        self.assertTrue(
            diagnostics["topk_from_reference_bank"][0, 0].item()
        )

    def test_train_bank_is_independent_of_query_batch_partition(self):
        retrieval = MissingAwareRetrieval(
            embedding_dim=2,
            top_k=2,
            queue_size=0,
            temperature=0.2,
            candidate_source="train_bank",
        )
        bank = torch.tensor([
            [1.0, 0.0],
            [0.8, 0.2],
            [0.0, 1.0],
            [0.2, 0.8],
        ])
        retrieval.set_reference_bank(bank, torch.arange(4))
        queries = torch.tensor([
            [0.95, 0.05],
            [0.05, 0.95],
            [0.7, 0.3],
        ])
        observed = torch.tensor([True, True, True])

        together, _ = retrieval(
            queries, observed, update_memory=False
        )
        separate = torch.cat([
            retrieval(
                queries[index:index + 1],
                observed[index:index + 1],
                update_memory=False,
            )[0]
            for index in range(queries.size(0))
        ], dim=0)

        torch.testing.assert_close(together, separate)

    def test_train_bank_is_runtime_only(self):
        retrieval = MissingAwareRetrieval(
            embedding_dim=2,
            top_k=1,
            candidate_source="train_bank",
        )
        retrieval.set_reference_bank(
            torch.tensor([[1.0, 0.0], [0.0, 1.0]]),
            torch.tensor([0, 1]),
        )
        state = retrieval.state_dict()
        self.assertNotIn("reference_bank", state)
        self.assertNotIn("reference_ids", state)

    def test_train_bank_must_be_built_before_retrieval(self):
        retrieval = MissingAwareRetrieval(
            embedding_dim=2,
            top_k=1,
            candidate_source="train_bank",
        )
        with self.assertRaises(RuntimeError):
            retrieval(
                torch.tensor([[1.0, 0.0]]),
                torch.tensor([True]),
                update_memory=False,
            )


if __name__ == "__main__":
    unittest.main()
