import torch
from torch import nn

from IIE_model import DeterministicMaxPool1d


def test_deterministic_pool_matches_adaptive_pool_forward_and_gradient():
    # Use distinct maxima so both operations have the same unique subgradient.
    source = torch.tensor(
        [
            [[-1.0, 3.0, 2.0], [4.0, 0.0, -2.0]],
            [[5.0, 1.0, 0.0], [-3.0, -1.0, -2.0]],
        ],
        requires_grad=True,
    )
    reference_source = source.detach().clone().requires_grad_(True)

    actual = DeterministicMaxPool1d()(source)
    expected = nn.AdaptiveMaxPool1d(1)(reference_source)
    assert torch.equal(actual, expected)

    actual.sum().backward()
    expected.sum().backward()
    assert torch.equal(source.grad, reference_source.grad)
