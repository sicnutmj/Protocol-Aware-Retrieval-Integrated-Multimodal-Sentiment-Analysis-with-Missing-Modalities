import unittest

import torch
from torch import nn

from modules.missing_tag_fusion_bias import AdditiveMissingTagFusionBias


class MissingTagFusionBiasTest(unittest.TestCase):
    def test_all_seven_protocol_tags(self):
        masks = torch.tensor([
            [1, 0, 0],
            [0, 1, 0],
            [0, 0, 1],
            [1, 1, 0],
            [1, 0, 1],
            [0, 1, 1],
            [1, 1, 1],
        ])
        expected = torch.tensor([
            [0, 0, 1, 1],
            [0, 1, 0, 1],
            [0, 1, 1, 0],
            [0, 0, 0, 1],
            [0, 0, 1, 0],
            [0, 1, 0, 0],
            [1, 0, 0, 0],
        ], dtype=torch.float32)
        self.assertTrue(torch.equal(
            AdditiveMissingTagFusionBias.build_tag(masks),
            expected,
        ))

    def test_epoch_zero_shift_is_exactly_zero(self):
        module = AdditiveMissingTagFusionBias(12)
        shift, diagnostics = module(torch.tensor([[1, 0, 1], [1, 1, 1]]))
        self.assertEqual(torch.count_nonzero(shift).item(), 0)
        self.assertEqual(diagnostics['shift_abs_mean'].item(), 0.0)

    def test_zero_tag_injection_preserves_fusion_output(self):
        torch.manual_seed(3)
        first = nn.Linear(10, 6)
        activation = nn.ReLU()
        final = nn.Linear(6, 1)
        module = AdditiveMissingTagFusionBias(6)
        features = torch.randn(5, 10)
        mask = torch.tensor([[1, 0, 1]]).expand(5, -1)
        shift, _ = module(mask)
        baseline = final(activation(first(features)))
        tagged = final(activation(first(features) + shift))
        self.assertTrue(torch.equal(tagged, baseline))

    def test_projection_is_additive_by_missing_bit(self):
        module = AdditiveMissingTagFusionBias(2)
        with torch.no_grad():
            module.projection.weight.copy_(torch.tensor([
                [1.0, 2.0, 4.0, 8.0],
                [-1.0, -2.0, -4.0, -8.0],
            ]))
        shift, _ = module(torch.tensor([[1, 0, 1]]))
        self.assertTrue(torch.equal(
            shift,
            torch.tensor([[4.0, -4.0]]),
        ))

    def test_projection_receives_gradient_on_first_step(self):
        module = AdditiveMissingTagFusionBias(5)
        shift, _ = module(torch.tensor([[1, 0, 0], [0, 1, 1]]))
        shift.sum().backward()
        self.assertGreater(module.projection.weight.grad.abs().sum().item(), 0.0)

    def test_rejects_nonbinary_mask(self):
        with self.assertRaises(ValueError):
            AdditiveMissingTagFusionBias.build_tag(
                torch.tensor([[1.0, 0.5, 0.0]])
            )

    def test_rejects_all_missing(self):
        with self.assertRaises(ValueError):
            AdditiveMissingTagFusionBias.build_tag(torch.zeros(1, 3))


if __name__ == '__main__':
    unittest.main()
