import unittest

import torch
from torch import nn

from modules.layerwise_coupled_missing_prompt import (
    LayerwiseCoupledMissingPrompt,
)


class LayerwiseCoupledMissingPromptTest(unittest.TestCase):
    def setUp(self):
        torch.manual_seed(20)
        layer = nn.TransformerEncoderLayer(
            d_model=8,
            nhead=2,
            dim_feedforward=16,
            dropout=0.0,
        )
        self.encoder = nn.TransformerEncoder(layer, num_layers=2)
        self.encoder.eval()
        self.hidden = torch.randn(7, 5, 8)
        self.protocol_three = torch.tensor([[1.0, 1.0, 0.0]] * 5)
        self.complete = torch.ones(5, 3)

    def make_adapter(self, depth=2):
        return LayerwiseCoupledMissingPrompt(
            embedding_dim=8,
            num_layers=depth,
            prompt_length=2,
            hidden_dim=12,
            max_scale=0.5,
        )

    def test_zero_scale_exactly_reproduces_frozen_encoder(self):
        adapter = self.make_adapter()
        expected = self.encoder(self.hidden)
        actual, diagnostics = adapter(
            self.encoder, self.hidden, self.protocol_three
        )
        self.assertTrue(torch.equal(actual, expected))
        self.assertTrue(torch.equal(
            diagnostics['scales'], torch.zeros_like(diagnostics['scales'])
        ))

    def test_nonzero_prompt_changes_only_missing_token_before_layer(self):
        adapter = self.make_adapter()
        with torch.no_grad():
            adapter.residual_scale_logits.fill_(0.4)
        corrected, diagnostics = adapter._prompt_residual(
            self.hidden, self.protocol_three, layer_index=0
        )
        for token_index in (0, 1, 2, 4, 5, 6):
            self.assertTrue(torch.equal(
                corrected[token_index], self.hidden[token_index]
            ))
        self.assertFalse(torch.equal(corrected[3], self.hidden[3]))
        self.assertTrue(torch.equal(
            diagnostics['residual_norms'][:, :2],
            torch.zeros_like(diagnostics['residual_norms'][:, :2]),
        ))
        self.assertTrue(torch.all(diagnostics['residual_norms'][:, 2] > 0))

    def test_complete_protocol_is_always_exact_noop(self):
        adapter = self.make_adapter()
        with torch.no_grad():
            adapter.residual_scale_logits.fill_(0.8)
        expected = self.encoder(self.hidden)
        actual, _ = adapter(self.encoder, self.hidden, self.complete)
        self.assertTrue(torch.equal(actual, expected))

    def test_two_layers_are_coupled_and_trainable(self):
        adapter = self.make_adapter()
        with torch.no_grad():
            adapter.residual_scale_logits.fill_(0.2)
        output, diagnostics = adapter(
            self.encoder, self.hidden, self.protocol_three
        )
        output.square().mean().backward()
        self.assertEqual(tuple(diagnostics['attention'].shape), (5, 2, 3, 2))
        self.assertEqual(tuple(diagnostics['residual_norms'].shape), (5, 2, 3))
        for encoder in adapter.context_encoders:
            self.assertIsNotNone(encoder[0].weight.grad)
            self.assertTrue(torch.isfinite(encoder[0].weight.grad).all())

    def test_first_step_trains_zero_initialized_scales(self):
        adapter = self.make_adapter()
        output, _ = adapter(self.encoder, self.hidden, self.protocol_three)
        output.square().mean().backward()
        gradients = adapter.residual_scale_logits.grad
        self.assertIsNotNone(gradients)
        self.assertTrue(torch.isfinite(gradients).all())
        self.assertGreater(gradients[:, 2].abs().sum().item(), 0.0)
        self.assertEqual(gradients[:, :2].abs().sum().item(), 0.0)

    def test_single_layer_ablation_has_expected_diagnostics(self):
        adapter = self.make_adapter(depth=1)
        output, diagnostics = adapter(
            self.encoder, self.hidden, self.protocol_three
        )
        self.assertEqual(tuple(output.shape), tuple(self.hidden.shape))
        self.assertEqual(diagnostics['prompt_depth'], 1)
        self.assertEqual(tuple(diagnostics['scales'].shape), (1, 3))


if __name__ == '__main__':
    unittest.main()
