import hashlib
import json

import pytest

from run_e16_retrieval_temperature import (
    METRICS,
    NEW_TEMPERATURE_VALUES,
    SPLIT_SIZES,
    TEMPERATURE_VALUES,
    audit_matrix,
    build_matrix,
    command_for_spec,
    reference_run_id,
)


def _sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _full_bank_record():
    return {
        "source": "complete_training_split_only",
        "available_count": 16326,
        "requested_size": 0,
        "actual_size": 16326,
        "subset_seed": 3407,
        "selection": "sha256_seeded_sample_id_nested_prefix",
        "selected_ids_sha256": "full-bank-ids",
        "validation_donors": 0,
        "test_donors": 0,
        "self_exclusion_ids": True,
        "runtime_only": True,
    }


def _result(protocol, value, include_bank=True):
    provenance = {
        "dataset_sha256": "mosei-data",
        "split_sizes": SPLIT_SIZES,
        "fixed_protocol": protocol,
    }
    if include_bank:
        provenance["strict_retrieval_bank"] = _full_bank_record()
    result = {
        "best_epoch": 3, "best_loss": value,
        "selection_split": "development", "selection_metric": "mae",
        "test_evaluation_count": 1, "data_provenance": provenance,
    }
    result.update({metric: value for metric in METRICS})
    return result


def _arguments(temperature, include_new=True):
    output = {
        "retrieval_mode": "missing_aware",
        "retrieval_candidate_source": "train_bank",
        "retrieval_candidate_filter": "observed_only",
        "retrieval_composition": "prototype_neighbours",
        "retrieval_selection": "similarity", "retrieval_random_seed": 3407,
        "retrieval_top_k": 2, "retrieval_temperature": temperature,
        "retrieval_queue_size": 0,
        "protocol_fusion_readaptation": False, "load": 0,
    }
    if include_new:
        output.update({
            "retrieval_reference_bank_size": 0,
            "retrieval_reference_bank_seed": 3407,
        })
    return output


def _write_manifest(workspace, payload, checkpoint=True):
    manifest_dir = workspace / "paper_experiments" / "manifests"
    checkpoint_dir = workspace / "paper_checkpoints"
    manifest_dir.mkdir(parents=True, exist_ok=True)
    checkpoint_dir.mkdir(parents=True, exist_ok=True)
    checkpoint_path = checkpoint_dir / "{}_best.pt".format(payload["run_id"])
    if checkpoint:
        checkpoint_path.write_bytes(payload["run_id"].encode("utf-8"))
    payload["outputs"] = {
        "best_model_path": str(checkpoint_path),
        "best_model_sha256": _sha(checkpoint_path) if checkpoint else "old-sha",
    }
    (manifest_dir / "{}.json".format(payload["run_id"])).write_text(
        json.dumps(payload), encoding="utf-8"
    )


def _write_cell(workspace, specs):
    values = {0.05: 0.53, 0.1: 0.50, 0.2: 0.51, 0.5: 0.54, 1.0: 0.56}
    for spec in specs:
        _write_manifest(workspace, {
            "status": "complete", "run_id": spec.run_id,
            "method_id": "M1", "stage_id": "E16", "dataset": "mosei",
            "protocol": spec.protocol, "seed": spec.seed, "lineage": None,
            "code_sha256": {"main.py": "new"},
            "arguments": _arguments(spec.temperature),
            "result": _result(spec.protocol, values[spec.temperature]),
        })
    protocol, seed = specs[0].protocol, specs[0].seed
    reference_arguments = _arguments(0.1, include_new=False)
    for name in (
        "retrieval_candidate_filter", "retrieval_composition",
        "retrieval_selection", "retrieval_random_seed", "retrieval_temperature",
    ):
        reference_arguments.pop(name)
    _write_manifest(workspace, {
        "status": "complete", "run_id": reference_run_id(protocol, seed),
        "method_id": "M1", "stage_id": "E06", "dataset": "mosei",
        "protocol": protocol, "seed": seed, "lineage": None,
        "code_sha256": {"main.py": "old"}, "arguments": reference_arguments,
        "result": _result(protocol, values[0.1], include_bank=False),
    }, checkpoint=False)


def test_e16_matrix_has_48_new_runs_and_temperature_point_one_reuse(tmp_path):
    specs = build_matrix()
    assert len(specs) == 48
    assert len({spec.run_id for spec in specs}) == 48
    assert [spec.temperature for spec in specs[:4]] == list(NEW_TEMPERATURE_VALUES)
    assert specs[0].run_id == "E16_T005_mosei_p0_s1111"
    assert specs[-1].run_id == "E16_T100_mosei_p6_s7777"
    assert TEMPERATURE_VALUES == (0.05, 0.1, 0.2, 0.5, 1.0)
    for spec in specs[:4]:
        command = command_for_spec(tmp_path, spec)
        assert "--paper_method_id=M1" in command
        assert "--paper_stage_id=E16" in command
        assert "--retrieval_top_k=2" in command
        assert "--retrieval_temperature={}".format(spec.temperature) in command
        assert "--retrieval_reference_bank_size=0" in command
        assert "--protocol_fusion_readaptation" not in command


def test_e16_audit_builds_five_temperatures_and_pairwise_effects(tmp_path):
    specs = build_matrix(protocols=("3",), seeds=(1111,))
    _write_cell(tmp_path, specs)
    summary = audit_matrix(
        tmp_path, specs, perform_reference_preflight=False
    )
    assert summary["completed_new_run_count"] == 4
    assert summary["completed_reused_reference_count"] == 1
    assert summary["completed_total_sensitivity_cells"] == 5
    assert [item["temperature"] for item in summary["records"]] == list(
        TEMPERATURE_VALUES
    )
    effect = summary["effects_vs_temperature_0_1"]["0.2"]["summary"]["test_mae"]
    assert effect["mean_gain"] == pytest.approx(-0.01)
    assert effect["losses"] == 1
    assert summary["summary_by_temperature"]["0.1"]["test_mae"]["mean"] == 0.50


def test_e16_rejects_missing_reference(tmp_path):
    specs = build_matrix(protocols=("0",), seeds=(1111,))
    _write_cell(tmp_path, specs)
    path = (
        tmp_path / "paper_experiments" / "manifests"
        / "E06R1_M1_mosei_p0_s1111.json"
    )
    path.unlink()
    with pytest.raises(RuntimeError, match="missing_reference=1"):
        audit_matrix(tmp_path, specs, perform_reference_preflight=False)


def test_e16_rejects_wrong_temperature_contract(tmp_path):
    spec = build_matrix(
        protocols=("0",), seeds=(1111,), temperatures=(0.05,)
    )[0]
    payload = {
        "status": "complete", "run_id": spec.run_id,
        "method_id": "M1", "stage_id": "E16", "dataset": "mosei",
        "protocol": "0", "seed": 1111, "lineage": None,
        "code_sha256": {"main.py": "new"}, "arguments": _arguments(0.2),
        "result": _result("0", 0.5),
    }
    _write_manifest(tmp_path, payload)
    with pytest.raises(RuntimeError, match="retrieval_temperature"):
        audit_matrix(
            tmp_path, [spec], require_complete=False,
            perform_reference_preflight=False,
        )
