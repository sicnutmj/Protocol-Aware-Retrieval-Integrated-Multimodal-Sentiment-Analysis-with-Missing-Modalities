import hashlib
import json

import pytest

from run_e11_component_ablation import (
    ARMS,
    CORE_CODE_FILES,
    MODEL_CORE_FILES,
    METRICS,
    SPLIT_SIZES,
    audit_matrix,
    build_matrix,
    command_for_spec,
    preflight_references,
    reference_run_id,
)


def _sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _result(dataset, protocol, value=0.5, adaptation=False):
    result = {
        "best_epoch": 2,
        "best_loss": value,
        "selection_split": "development",
        "selection_metric": "mae",
        "test_evaluation_count": 1,
        "selected_state_sha256": "state",
        "data_provenance": {
            "dataset_sha256": "{}-data".format(dataset),
            "split_sizes": SPLIT_SIZES[dataset],
            "fixed_protocol": protocol,
        },
    }
    result.update({metric: value for metric in METRICS})
    if adaptation:
        result["adaptation_gate"] = {
            "outcome": "improved",
            "dev_mae_gain": 0.01,
            "test_metrics_consulted": False,
        }
    return result


def _core_hashes(suffix="same"):
    return {name: "{}-{}".format(name, suffix) for name in CORE_CODE_FILES}


def _write_manifest(workspace, payload, checkpoint=True):
    manifest_dir = workspace / "paper_experiments" / "manifests"
    checkpoint_dir = workspace / "paper_checkpoints"
    manifest_dir.mkdir(parents=True, exist_ok=True)
    checkpoint_dir.mkdir(parents=True, exist_ok=True)
    path = checkpoint_dir / "{}_best.pt".format(payload["run_id"])
    if checkpoint:
        path.write_bytes(payload["run_id"].encode("utf-8"))
    payload["outputs"] = {
        "best_model_path": str(path),
        "best_model_sha256": _sha(path) if checkpoint else "recorded-sha",
    }
    (manifest_dir / "{}.json".format(payload["run_id"])).write_text(
        json.dumps(payload), encoding="utf-8"
    )


def _write_ablation_cell(workspace, spec):
    common = {
        "status": "complete",
        "dataset": spec.dataset,
        "protocol": spec.protocol,
        "seed": spec.seed,
        "code_sha256": _core_hashes(),
    }
    _write_manifest(workspace, {
        **common,
        "run_id": spec.run_id,
        "method_id": "A1",
        "stage_id": "E11",
        "lineage": None,
        "arguments": {
            "retrieval_mode": "missing_aware",
            "retrieval_candidate_source": "batch",
            "retrieval_queue_size": 0,
            "protocol_fusion_readaptation": False,
            "load": 0,
        },
        "result": _result(spec.dataset, spec.protocol, value=0.45),
    })
    for arm, method, value in (
        ("A0", "M0", 0.55),
        ("A2", "M1", 0.40),
        ("A3", "M2", 0.35),
    ):
        run_id = reference_run_id(
            spec.dataset, arm, spec.protocol, spec.seed
        )
        adaptation = arm == "A3"
        parent = (
            reference_run_id(spec.dataset, "A2", spec.protocol, spec.seed)
            if adaptation else None
        )
        _write_manifest(workspace, {
            **common,
            "run_id": run_id,
            "method_id": method,
            "stage_id": "E06" if spec.dataset == "mosei" else "E07",
            "lineage": ({
                "parent_run_id": parent,
                "parent_method_id": "M1",
            } if adaptation else None),
            "arguments": {
                "retrieval_mode": "legacy" if arm == "A0" else "missing_aware",
                "retrieval_candidate_source": "batch" if arm == "A0" else "train_bank",
                "protocol_fusion_readaptation": adaptation,
            },
            "result": _result(
                spec.dataset, spec.protocol, value=value,
                adaptation=adaptation,
            ),
        }, checkpoint=False)


def test_e11_matrix_has_70_new_runs_and_explicit_a1_contract(tmp_path):
    specs = build_matrix()
    assert len(specs) == 70
    assert len({spec.run_id for spec in specs}) == 70
    assert specs[0].run_id == "E11_A1_mosei_p0_s1111"
    assert specs[35].run_id == "E11_A1_mosi_p0_s1111"
    command = command_for_spec(tmp_path, specs[0])
    assert "--paper_method_id=A1" in command
    assert "--paper_stage_id=E11" in command
    assert "--retrieval_mode=missing_aware" in command
    assert "--retrieval_candidate_source=batch" in command
    assert "--retrieval_queue_size=0" in command
    assert "--load=1" not in command
    assert "--protocol_fusion_readaptation" not in command


def test_e11_reference_mapping_is_frozen():
    assert reference_run_id("mosei", "A0", "3", 1111) == (
        "E06R1_M0_mosei_p3_s1111"
    )
    assert reference_run_id("mosei", "A3", "3", 1111) == (
        "E06R1_M2_mosei_p3_s1111"
    )
    assert reference_run_id("mosi", "A2", "3", 1111) == (
        "E07_M1_mosi_p3_s1111"
    )


def test_e11_audit_builds_four_arms_and_directional_effects(tmp_path):
    specs = build_matrix(datasets=("mosei",), protocols=("3",), seeds=(1111,))
    _write_ablation_cell(tmp_path, specs[0])
    summary = audit_matrix(
        tmp_path, specs, require_entrypoint_bridge=False
    )
    assert summary["completed_new_run_count"] == 1
    assert summary["completed_reused_reference_count"] == 3
    assert summary["completed_total_ablation_cells"] == 4
    assert [item["arm"] for item in summary["records"]] == list(ARMS)
    retrieval = summary["effects"]["retrieval_logic"]["summary"]["mosei"]
    assert retrieval["test_mae"]["mean_gain"] == pytest.approx(0.10)
    assert retrieval["test_mae"]["wins"] == 1
    strict_bank = summary["effects"]["strict_training_bank"]["summary"]["mosei"]
    assert strict_bank["test_mae"]["mean_gain"] == pytest.approx(0.05)
    # Accuracy-like metrics are direction-normalized in the opposite direction.
    assert strict_bank["test_acc2"]["mean_gain"] == pytest.approx(-0.05)


def test_e11_audit_rejects_missing_reference(tmp_path):
    specs = build_matrix(datasets=("mosi",), protocols=("0",), seeds=(1111,))
    _write_ablation_cell(tmp_path, specs[0])
    missing = (
        tmp_path / "paper_experiments" / "manifests"
        / "E07_M1_mosi_p0_s1111.json"
    )
    missing.unlink()
    with pytest.raises(RuntimeError, match="missing_reference=1"):
        audit_matrix(tmp_path, specs, require_entrypoint_bridge=False)


def test_e11_audit_rejects_training_core_drift(tmp_path):
    specs = build_matrix(datasets=("mosei",), protocols=("0",), seeds=(1111,))
    _write_ablation_cell(tmp_path, specs[0])
    path = (
        tmp_path / "paper_experiments" / "manifests"
        / "E06R1_M0_mosei_p0_s1111.json"
    )
    payload = json.loads(path.read_text(encoding="utf-8"))
    payload["code_sha256"][MODEL_CORE_FILES[0]] = "changed"
    path.write_text(json.dumps(payload), encoding="utf-8")
    with pytest.raises(RuntimeError, match="different model core"):
        audit_matrix(tmp_path, specs, require_entrypoint_bridge=False)


def test_e11_preflight_rejects_missing_reference_before_training(
    tmp_path, monkeypatch
):
    specs = build_matrix(datasets=("mosi",), protocols=("0",), seeds=(1111,))
    _write_ablation_cell(tmp_path, specs[0])
    missing = (
        tmp_path / "paper_experiments" / "manifests"
        / "E07_M2_mosi_p0_s1111.json"
    )
    missing.unlink()
    monkeypatch.setattr(
        "run_e11_component_ablation.resolve_dataset_path",
        lambda workspace, dataset: workspace / "dataset.pkl",
    )
    def fake_sha(path):
        normalized = str(path).replace("\\", "/")
        if normalized.endswith("dataset.pkl"):
            return "mosi-data"
        for name in CORE_CODE_FILES:
            if normalized.endswith(name):
                return "{}-same".format(name)
        raise AssertionError("unexpected path: {}".format(path))
    monkeypatch.setattr("run_e11_component_ablation.sha256_file", fake_sha)
    with pytest.raises(FileNotFoundError, match="reference manifest"):
        preflight_references(tmp_path, specs)
