import ast
from pathlib import Path
import unittest

import torch

from modules.availability_tagged_language_hyper_residual import (
    AvailabilityTaggedLanguageHyperResidual,
)


class AvailabilityTaggedLanguageHyperResidualTest(unittest.TestCase):
    def setUp(self):
        torch.manual_seed(19)
        self.sample = torch.randn(6, 8)
        self.enhanced = tuple(torch.randn(6, 8) for _ in range(3))
        self.raw = tuple(torch.randn(6, 8) for _ in range(3))
        self.protocol_three = torch.tensor([[1.0, 1.0, 0.0]] * 6)

    def make_model(self, mode='language_query'):
        return AvailabilityTaggedLanguageHyperResidual(
            embedding_dim=8,
            hidden_dim=12,
            max_scale=0.5,
            mode=mode,
        )

    def test_zero_scale_is_exact_fpfr_identity(self):
        model = self.make_model()
        corrected, diagnostics = model(
            self.sample, self.enhanced, self.raw, self.protocol_three
        )
        for actual, expected in zip(corrected, self.enhanced):
            self.assertTrue(torch.equal(actual, expected))
        self.assertEqual(diagnostics['scale'].item(), 0.0)

    def test_only_observed_language_is_corrected(self):
        model = self.make_model()
        with torch.no_grad():
            model.injection_scale_logit.fill_(0.5)
        corrected, diagnostics = model(
            self.sample, self.enhanced, self.raw, self.protocol_three
        )
        self.assertFalse(torch.equal(corrected[0], self.enhanced[0]))
        self.assertTrue(torch.equal(corrected[1], self.enhanced[1]))
        self.assertTrue(torch.equal(corrected[2], self.enhanced[2]))
        self.assertTrue(torch.equal(
            diagnostics['attention'][:, 3],
            torch.zeros_like(diagnostics['attention'][:, 3]),
        ))

        text_missing = torch.tensor([[0.0, 1.0, 1.0]] * 6)
        missing_corrected, _ = model(
            self.sample, self.enhanced, self.raw, text_missing
        )
        for actual, expected in zip(missing_corrected, self.enhanced):
            self.assertTrue(torch.equal(actual, expected))

    def test_language_query_changes_attention_but_control_does_not(self):
        control = self.make_model('availability_only')
        full = self.make_model('language_query')
        changed = list(self.enhanced)
        changed[0] = changed[0] * -5.0 + 3.0

        control_first = control(
            self.sample, self.enhanced, self.raw, self.protocol_three
        )[1]['attention']
        control_second = control(
            self.sample, tuple(changed), self.raw, self.protocol_three
        )[1]['attention']
        self.assertTrue(torch.equal(control_first, control_second))

        full_first = full(
            self.sample, self.enhanced, self.raw, self.protocol_three
        )[1]['attention']
        full_second = full(
            self.sample, tuple(changed), self.raw, self.protocol_three
        )[1]['attention']
        self.assertFalse(torch.equal(full_first, full_second))

    def test_control_and_full_have_identical_parameterization(self):
        control = self.make_model('availability_only')
        full = self.make_model('language_query')
        control_shapes = {
            name: tuple(tensor.shape)
            for name, tensor in control.state_dict().items()
        }
        full_shapes = {
            name: tuple(tensor.shape)
            for name, tensor in full.state_dict().items()
        }
        self.assertEqual(control_shapes, full_shapes)
        self.assertEqual(
            sum(parameter.numel() for parameter in control.parameters()),
            sum(parameter.numel() for parameter in full.parameters()),
        )

    def test_nonzero_scale_trains_language_attention(self):
        model = self.make_model('language_query')
        with torch.no_grad():
            model.injection_scale_logit.fill_(0.2)
        corrected, _ = model(
            self.sample, self.enhanced, self.raw, self.protocol_three
        )
        corrected[0].square().mean().backward()
        for parameter in (
            model.query_projection.weight,
            model.key_projection.weight,
            model.value_projection.weight,
        ):
            self.assertIsNotNone(parameter.grad)
            self.assertTrue(torch.isfinite(parameter.grad).all())

    def test_training_and_inference_use_the_same_adapter_position(self):
        source_path = Path(__file__).resolve().parents[1] / 'IIE_model.py'
        tree = ast.parse(source_path.read_text(encoding='utf-8'))
        model_class = next(
            node for node in tree.body
            if isinstance(node, ast.ClassDef) and node.name == 'IIEModel'
        )
        methods = {
            node.name: node
            for node in model_class.body
            if isinstance(node, ast.FunctionDef)
        }
        call_names = (
            'apply_reliability_gate',
            'apply_language_hyper_residual',
            'fuse_representations',
        )
        for method_name in ('forward', 'test'):
            calls = {
                name: [
                    node for node in ast.walk(methods[method_name])
                    if isinstance(node, ast.Call)
                    and isinstance(node.func, ast.Attribute)
                    and node.func.attr == name
                ]
                for name in call_names
            }
            self.assertEqual(len(calls['apply_language_hyper_residual']), 1)
            first_line = {
                name: min(node.lineno for node in nodes)
                for name, nodes in calls.items()
            }
            self.assertLess(
                first_line['apply_reliability_gate'],
                first_line['apply_language_hyper_residual'],
            )
            self.assertLess(
                first_line['apply_language_hyper_residual'],
                first_line['fuse_representations'],
            )


if __name__ == '__main__':
    unittest.main()
