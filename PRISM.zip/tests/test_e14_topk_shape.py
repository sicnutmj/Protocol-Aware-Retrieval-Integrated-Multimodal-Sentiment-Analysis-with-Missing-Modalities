import pytest
import torch
from einops import rearrange, repeat

from latent_transformer import LatentTransformer


@pytest.mark.parametrize("top_k", [1, 2, 4, 8, 16])
def test_mixup_latent_transformer_accepts_all_e14_context_lengths(top_k):
    model = LatentTransformer(
        num_latents=4,
        latent_dim=8,
        input_dim=8,
        depth=1,
        heads=2,
        latent_heads=2,
        latent_dim_head=4,
        dim_head=4,
        mixup=True,
    )
    # Retrieval context contains the query, top-k neighbours, and one context
    # slot.  Its length must not be required to equal num_latents.
    context = torch.randn(3, top_k + 2, 8)
    output = model(context)
    assert output.shape == (3, 8)


def test_top_k_two_path_is_exactly_legacy_equivalent():
    torch.manual_seed(3407)
    model = LatentTransformer(
        num_latents=4,
        latent_dim=8,
        input_dim=8,
        depth=1,
        heads=2,
        latent_heads=2,
        latent_dim_head=4,
        dim_head=4,
        mixup=True,
    ).eval()
    context = torch.randn(3, 4, 8)

    data = rearrange(context, 'b ... d -> b (...) d')
    x = repeat(model.latents, 'n d -> b n d', b=data.shape[0])
    for cross_attn, cross_ff, self_attns in model.layers:
        legacy_residual = repeat(
            data[:, -1, :], 'b d -> b n d', n=data.shape[1]
        )
        x = (
            cross_attn(x, context=data)
            + 0.99 * x
            + 0.01 * legacy_residual
        )
        x = cross_ff(x) + 0.99 * x + 0.01 * legacy_residual
        for self_attn, self_ff in self_attns:
            x = self_attn(x) + x
            x = self_ff(x) + x
    legacy_output = model.to_embedds(x)

    current_output = model(context)
    assert torch.equal(current_output, legacy_output)
