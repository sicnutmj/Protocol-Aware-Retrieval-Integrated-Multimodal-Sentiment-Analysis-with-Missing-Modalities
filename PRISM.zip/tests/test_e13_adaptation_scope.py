import torch
from torch import nn

from IIE_model import IIEModel


class TinyAdaptationModel(nn.Module):
    configure_protocol_consistency_finetuning = (
        IIEModel.configure_protocol_consistency_finetuning
    )
    enforce_protocol_consistency_finetune_mode = (
        IIEModel.enforce_protocol_consistency_finetune_mode
    )

    def __init__(self, scope):
        super().__init__()
        self.protocol_consistency_mode = "none"
        self.protocol_fusion_readaptation = True
        self.protocol_adaptation_scope = scope
        self.fusion_mode = "flat"
        self.foundation = nn.Linear(4, 4)
        self.transformer_encoder_all = nn.Sequential(nn.Linear(4, 4))
        self.fusion_all = nn.Sequential()
        self.fusion_all.add_module("fusion_layer_all", nn.Linear(4, 4))
        self.fusion_all.add_module("fusion_layer_all_dropout", nn.Dropout(0.1))
        self.fusion_all.add_module("fusion_layer_all_activation", nn.ReLU())
        self.fusion_all.add_module("fusion_layer_all_all", nn.Linear(4, 1))


def _trainable(model):
    return {name for name, parameter in model.named_parameters() if parameter.requires_grad}


def test_e13_last_layer_scope_exposes_only_prediction_layer():
    model = TinyAdaptationModel("last_layer")
    record = model.configure_protocol_consistency_finetuning()
    assert _trainable(model) == {
        "fusion_all.fusion_layer_all_all.weight",
        "fusion_all.fusion_layer_all_all.bias",
    }
    assert set(record["trainable_names"]) == _trainable(model)
    model.enforce_protocol_consistency_finetune_mode()
    assert model.fusion_all.fusion_layer_all_all.training is True
    assert model.fusion_all.fusion_layer_all_dropout.training is False
    assert model.transformer_encoder_all.training is False


def test_e13_complete_fusion_scope_preserves_retained_m2_contract():
    model = TinyAdaptationModel("fusion_all")
    model.configure_protocol_consistency_finetuning()
    assert _trainable(model)
    assert all(name.startswith("fusion_all.") for name in _trainable(model))
    model.enforce_protocol_consistency_finetune_mode()
    assert model.fusion_all.training is True
    assert model.transformer_encoder_all.training is False


def test_e13_late_scope_exposes_transformer_and_fusion_only():
    model = TinyAdaptationModel("late_transformer_fusion")
    model.configure_protocol_consistency_finetuning()
    names = _trainable(model)
    assert names
    assert {name.split(".", 1)[0] for name in names} == {
        "transformer_encoder_all", "fusion_all"
    }
    model.enforce_protocol_consistency_finetune_mode()
    assert model.transformer_encoder_all.training is True
    assert model.fusion_all.training is True
    assert model.foundation.training is False
