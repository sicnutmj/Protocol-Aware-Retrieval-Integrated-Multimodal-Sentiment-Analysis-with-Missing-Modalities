import pytest

from evaluate_e05_fpfr_gate import evaluate_fpfr_gate


def make_records(gain):
    return [
        {
            "protocol": str(protocol),
            "seed": seed,
            "outcome": "improved" if gain > 0 else "fallback_parent",
            "dev_mae_gain": gain,
            "test_metrics_consulted": False,
            # Deliberately present but never consumed by the gate.
            "test_mae": -999.0,
        }
        for protocol in range(7)
        for seed in (1111, 2222, 3407, 5576, 7777)
    ]


def test_e05_gate_retains_consistent_practical_development_gain():
    decision = evaluate_fpfr_gate(make_records(0.002))
    assert decision["decision"] == "retain_M3"
    assert decision["record_count"] == 35
    assert decision["test_metrics_consulted"] is False


def test_e05_gate_stops_for_subthreshold_gain():
    decision = evaluate_fpfr_gate(make_records(0.0001))
    assert decision["decision"] == "stop_at_M2"
    assert not decision["criteria"]["global_mean_gain"]["passed"]


def test_e05_gate_requires_complete_unique_matrix():
    records = make_records(0.002)
    with pytest.raises(ValueError, match="Incomplete"):
        evaluate_fpfr_gate(records[:-1])
    with pytest.raises(ValueError, match="Duplicate"):
        evaluate_fpfr_gate(records + [records[0]])


def test_e05_gate_rejects_test_informed_or_harmful_record():
    records = make_records(0.002)
    records[0]["test_metrics_consulted"] = True
    with pytest.raises(ValueError, match="development-only"):
        evaluate_fpfr_gate(records)

    records = make_records(0.002)
    records[0]["dev_mae_gain"] = -0.01
    with pytest.raises(ValueError, match="development-worse"):
        evaluate_fpfr_gate(records)
