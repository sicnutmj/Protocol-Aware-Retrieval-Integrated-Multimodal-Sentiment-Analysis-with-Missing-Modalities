import unittest

import torch

from modules.text_guided_reconstruction import (
    TextGuidedMissingNonverbalReconstruction,
)


class TextGuidedMissingNonverbalReconstructionTest(unittest.TestCase):
    def setUp(self):
        torch.manual_seed(17)
        self.model = TextGuidedMissingNonverbalReconstruction(
            embedding_dim=8,
            hidden_dim=16,
            max_scale=0.8,
        )
        self.protocols = torch.tensor(
            [
                [1, 0, 0],
                [0, 1, 0],
                [0, 0, 1],
                [1, 1, 0],
                [1, 0, 1],
                [0, 1, 1],
                [1, 1, 1],
            ]
        )
        self.sample = torch.randn(7, 8)
        self.text = torch.randn(7, 8)
        self.raw = tuple(torch.randn(7, 8) for _ in range(3))
        self.targets = (torch.randn(7, 8), torch.randn(7, 8))

    def test_zero_scale_is_exact_foundation_identity(self):
        filled, loss, diagnostics = self.model(
            self.sample,
            self.text,
            self.raw,
            self.protocols,
            complete_targets=self.targets,
        )
        for original, output in zip(self.raw, filled):
            self.assertTrue(torch.equal(original, output))
        self.assertTrue(torch.equal(diagnostics["scales"], torch.zeros(2)))
        self.assertIsNotNone(loss)

    def test_only_text_observed_missing_nonverbal_branches_change(self):
        with torch.no_grad():
            self.model.injection_scale_logits.fill_(0.7)
        filled, _, _ = self.model(
            self.sample, self.text, self.raw, self.protocols
        )
        audio_changed = (filled[1] != self.raw[1]).any(dim=1)
        video_changed = (filled[2] != self.raw[2]).any(dim=1)
        self.assertTrue(
            torch.equal(
                audio_changed,
                torch.tensor([True, False, False, False, True, False, False]),
            )
        )
        self.assertTrue(
            torch.equal(
                video_changed,
                torch.tensor([True, False, False, True, False, False, False]),
            )
        )
        self.assertTrue(torch.equal(filled[0], self.raw[0]))

    def test_direct_reconstruction_loss_trains_predictors_and_scale(self):
        targets = tuple(value.clone().requires_grad_(True) for value in self.targets)
        _, loss, _ = self.model(
            self.sample,
            self.text,
            self.raw,
            self.protocols,
            complete_targets=targets,
        )
        loss.backward()
        predictor_gradient = sum(
            parameter.grad.abs().sum().item()
            for parameter in self.model.predictors.parameters()
            if parameter.grad is not None
        )
        self.assertGreater(predictor_gradient, 0.0)
        self.assertGreater(
            self.model.injection_scale_logits.grad.abs().sum().item(), 0.0
        )
        self.assertTrue(all(value.grad is None for value in targets))

    def test_inference_does_not_require_complete_targets(self):
        _, loss, diagnostics = self.model(
            self.sample, self.text, self.raw, self.protocols
        )
        self.assertIsNone(loss)
        self.assertEqual(diagnostics["eligible_count"].tolist(), [2.0, 2.0])

    def test_invalid_availability_is_rejected(self):
        invalid = self.protocols.float()
        invalid[0, 0] = 0.5
        with self.assertRaisesRegex(ValueError, "binary"):
            self.model(self.sample, self.text, self.raw, invalid)
        with self.assertRaisesRegex(ValueError, "observed"):
            self.model(
                self.sample,
                self.text,
                self.raw,
                torch.zeros_like(self.protocols),
            )


if __name__ == "__main__":
    unittest.main()
