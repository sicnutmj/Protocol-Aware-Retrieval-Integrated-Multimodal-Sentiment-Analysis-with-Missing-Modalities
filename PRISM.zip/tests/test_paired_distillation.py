import unittest

import torch

from modules.paired_distillation import paired_hierarchical_distillation


class PairedHierarchicalDistillationTest(unittest.TestCase):
    def test_identical_representations_have_zero_loss(self):
        sample = torch.randn(4, 8)
        fusion = torch.randn(4, 56)
        losses = paired_hierarchical_distillation(
            sample, sample.clone(), fusion, fusion.clone()
        )
        self.assertEqual(losses['sample'].item(), 0.0)
        self.assertEqual(losses['fusion'].item(), 0.0)

    def test_gradients_reach_only_student_representations(self):
        student_sample = torch.randn(3, 4, requires_grad=True)
        teacher_sample = torch.randn(3, 4, requires_grad=True)
        student_fusion = torch.randn(3, 12, requires_grad=True)
        teacher_fusion = torch.randn(3, 12, requires_grad=True)
        losses = paired_hierarchical_distillation(
            student_sample,
            teacher_sample,
            student_fusion,
            teacher_fusion,
        )
        (losses['sample'] + losses['fusion']).backward()
        self.assertIsNotNone(student_sample.grad)
        self.assertIsNotNone(student_fusion.grad)
        self.assertIsNone(teacher_sample.grad)
        self.assertIsNone(teacher_fusion.grad)

    def test_shape_mismatch_is_rejected(self):
        with self.assertRaisesRegex(ValueError, 'sample representations'):
            paired_hierarchical_distillation(
                torch.zeros(2, 3),
                torch.zeros(2, 4),
                torch.zeros(2, 9),
                torch.zeros(2, 9),
            )


if __name__ == '__main__':
    unittest.main()
