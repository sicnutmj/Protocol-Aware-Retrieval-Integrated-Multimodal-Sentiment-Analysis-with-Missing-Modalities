import unittest

import torch

from modules.pns_audit import (
    PNSAuditAccumulator,
    evaluate_enhanced_branch_counterfactuals,
)


class PNSAuditTest(unittest.TestCase):
    @staticmethod
    def fuse(representations):
        prediction = sum(representations)
        return prediction, prediction

    def test_continuous_margins_identify_helpful_and_harmful_branches(self):
        representations = (
            torch.zeros(2, 1),
            torch.ones(2, 1),
            torch.full((2, 1), 2.0),
            torch.full((2, 1), -1.0),
            torch.zeros(2, 1),
            torch.zeros(2, 1),
            torch.zeros(2, 1),
        )
        labels = torch.full((2,), 3.0)
        observed = torch.tensor([[1, 0, 1], [1, 0, 1]])
        diagnostics = evaluate_enhanced_branch_counterfactuals(
            self.fuse,
            representations,
            labels,
            observed,
            threshold=1.5,
        )
        self.assertTrue(
            torch.allclose(
                diagnostics['l']['necessity_margin'],
                torch.ones(2),
            )
        )
        self.assertTrue(
            torch.allclose(
                diagnostics['a']['sufficiency_margin'],
                torch.full((2,), 2.0),
            )
        )
        self.assertTrue(diagnostics['v']['harmful'].all())
        self.assertTrue(diagnostics['l']['observed'].all())
        self.assertFalse(diagnostics['a']['observed'].any())

    def test_accumulator_reports_rates_and_means(self):
        representations = tuple(torch.ones(3, 1) for _ in range(7))
        labels = torch.zeros(3)
        observed = torch.tensor([[1, 0, 1], [1, 0, 1], [1, 0, 1]])
        diagnostics = evaluate_enhanced_branch_counterfactuals(
            self.fuse,
            representations,
            labels,
            observed,
        )
        accumulator = PNSAuditAccumulator()
        accumulator.update(diagnostics)
        summary = accumulator.summaries()
        self.assertEqual(summary['l']['count'], 3)
        self.assertEqual(summary['l']['observed_rate'], 1.0)
        self.assertEqual(summary['a']['observed_rate'], 0.0)
        self.assertAlmostEqual(
            summary['l']['pns_event_score'],
            summary['l']['necessity_event_rate']
            + summary['l']['sufficiency_event_rate'],
        )

    def test_invalid_shapes_and_threshold_are_rejected(self):
        representations = tuple(torch.zeros(2, 1) for _ in range(7))
        with self.assertRaisesRegex(ValueError, 'shape'):
            evaluate_enhanced_branch_counterfactuals(
                self.fuse,
                representations,
                torch.zeros(2),
                torch.zeros(2, 2),
            )
        with self.assertRaisesRegex(ValueError, 'positive'):
            evaluate_enhanced_branch_counterfactuals(
                self.fuse,
                representations,
                torch.zeros(2),
                torch.zeros(2, 3),
                threshold=0,
            )


if __name__ == '__main__':
    unittest.main()
