import unittest

import torch

from modules.cross_modal_query_retrieval import (
    AvailabilityGuidedCrossModalQueryRetrieval,
)


class CrossModalQueryRetrievalTest(unittest.TestCase):
    def setUp(self):
        torch.manual_seed(7)
        self.module = AvailabilityGuidedCrossModalQueryRetrieval(
            embedding_dim=8,
            hidden_dim=12,
            top_k=2,
            temperature=0.2,
            match_temperature=0.2,
        )
        self.module.set_reference_banks({
            modality: torch.randn(10, 8)
            for modality in ('l', 'a', 'v')
        })
        self.raw = tuple(torch.randn(4, 8) for _ in range(3))
        self.base = tuple(torch.randn(4, 4, 8) for _ in range(3))

    def test_zero_mix_is_exact_q0_identity(self):
        observed = torch.tensor([
            [1, 0, 0],
            [1, 1, 0],
            [0, 1, 1],
            [1, 1, 1],
        ])
        outputs, _, diagnostics = self.module(
            self.raw, observed, self.base
        )
        for original, output in zip(self.base, outputs):
            self.assertTrue(torch.equal(original, output))
        self.assertTrue(torch.equal(
            diagnostics['mix_scales'], torch.zeros(3)
        ))

    def test_only_missing_targets_are_replaced(self):
        observed = torch.tensor([[1, 0, 1]] * 4)
        with torch.no_grad():
            self.module.mix_parameters.fill_(1.0)
        outputs, _, _ = self.module(self.raw, observed, self.base)
        self.assertTrue(torch.equal(outputs[0], self.base[0]))
        self.assertFalse(torch.equal(outputs[1], self.base[1]))
        self.assertTrue(torch.equal(outputs[2], self.base[2]))

    def test_matching_loss_trains_source_to_target_mappers(self):
        observed = torch.tensor([[1, 0, 1]] * 4)
        complete_targets = tuple(torch.randn(4, 8) for _ in range(3))
        outputs, query_loss, diagnostics = self.module(
            self.raw,
            observed,
            self.base,
            complete_targets=complete_targets,
        )
        (query_loss + outputs[1].sum()).backward()
        gradient = self.module.mappers['l_to_a'][0].weight.grad
        self.assertIsNotNone(gradient)
        self.assertGreater(gradient.abs().sum().item(), 0.0)
        self.assertTrue(torch.isfinite(query_loss))
        self.assertEqual(diagnostics['eligible_count'][1].item(), 4)

    def test_complete_protocol_is_noop_even_with_full_mix(self):
        observed = torch.ones(4, 3, dtype=torch.long)
        with torch.no_grad():
            self.module.mix_parameters.fill_(1.0)
        outputs, _, diagnostics = self.module(
            self.raw, observed, self.base
        )
        for original, output in zip(self.base, outputs):
            self.assertTrue(torch.equal(original, output))
        self.assertEqual(diagnostics['eligible_count'].sum().item(), 0)

    def test_reference_banks_are_runtime_only(self):
        bank_keys = [
            name for name in self.module.state_dict()
            if name.startswith('bank_')
        ]
        self.assertEqual(bank_keys, [])


if __name__ == '__main__':
    unittest.main()
