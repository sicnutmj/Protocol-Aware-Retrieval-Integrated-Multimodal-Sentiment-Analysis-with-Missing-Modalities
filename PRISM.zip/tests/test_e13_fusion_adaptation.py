import hashlib
import json

import pytest

from run_e13_fusion_adaptation import (
    ARMS,
    METRICS,
    NEW_METHODS,
    SPLIT_SIZES,
    audit_matrix,
    build_matrix,
    command_for_spec,
    reference_run_id,
)


def _sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _result(protocol, value, adaptation):
    result = {
        "best_epoch": 3,
        "best_loss": value,
        "baseline_dev_mae": value + 0.01 if adaptation else None,
        "selection_split": "development",
        "selection_metric": "mae",
        "test_evaluation_count": 1,
        "selected_state_sha256": "state-{}".format(value),
        "data_provenance": {
            "dataset_sha256": "mosei-data",
            "split_sizes": SPLIT_SIZES,
            "fixed_protocol": protocol,
        },
    }
    result.update({metric: value for metric in METRICS})
    if adaptation:
        result["adaptation_gate"] = {
            "outcome": "improved",
            "dev_mae_gain": 0.01,
            "test_metrics_consulted": False,
        }
    return result


def _write_manifest(workspace, payload, checkpoint=True):
    manifest_dir = workspace / "paper_experiments" / "manifests"
    checkpoint_dir = workspace / "paper_checkpoints"
    manifest_dir.mkdir(parents=True, exist_ok=True)
    checkpoint_dir.mkdir(parents=True, exist_ok=True)
    checkpoint_path = checkpoint_dir / "{}_best.pt".format(payload["run_id"])
    if checkpoint:
        checkpoint_path.write_bytes(payload["run_id"].encode("utf-8"))
    payload["outputs"] = {
        "best_model_path": str(checkpoint_path),
        "best_model_sha256": _sha(checkpoint_path) if checkpoint else "old-sha",
    }
    (manifest_dir / "{}.json".format(payload["run_id"])).write_text(
        json.dumps(payload), encoding="utf-8"
    )


def _write_cell(workspace, specs):
    values = {"D0": 0.60, "D1": 0.56, "D2": 0.54, "D3": 0.55, "D4": 0.54}
    for spec in specs:
        _write_manifest(workspace, {
            "status": "complete", "run_id": spec.run_id,
            "method_id": spec.method, "stage_id": "E13",
            "dataset": "mosei", "protocol": spec.protocol,
            "seed": spec.seed,
            "lineage": {
                "parent_run_id": spec.parent_run_id,
                "parent_method_id": "M1",
            },
            "code_sha256": {"main.py": "new"},
            "arguments": {
                "retrieval_mode": "missing_aware",
                "retrieval_candidate_source": "train_bank",
                "retrieval_candidate_filter": "observed_only",
                "retrieval_composition": "prototype_neighbours",
                "retrieval_selection": "similarity",
                "retrieval_queue_size": 0,
                "protocol_fusion_readaptation": True,
                "protocol_adaptation_scope": spec.scope,
                "protocol_fusion_learning_rate": 1e-4,
                "protocol_transformer_learning_rate": 2e-5,
                "load": 1,
            },
            "result": _result(spec.protocol, values[spec.arm], True),
        })
    protocol, seed = specs[0].protocol, specs[0].seed
    for arm, parent in (("D0", None), ("D2", "M1"), ("D4", "M2")):
        method = {"D0": "M1", "D2": "M2", "D4": "M3"}[arm]
        _write_manifest(workspace, {
            "status": "complete",
            "run_id": reference_run_id(arm, protocol, seed),
            "method_id": method, "stage_id": "E06",
            "dataset": "mosei", "protocol": protocol, "seed": seed,
            "lineage": None if parent is None else {"parent_method_id": parent},
            "code_sha256": {"utils.py": "old", "latent_transformer.py": "old"},
            "arguments": {
                "retrieval_mode": "missing_aware",
                "retrieval_candidate_source": "train_bank",
                "protocol_fusion_readaptation": arm != "D0",
            },
            "result": _result(protocol, values[arm], arm != "D0"),
        })


def test_e13_matrix_has_70_new_runs_and_exact_scope(tmp_path):
    specs = build_matrix()
    assert len(specs) == 70
    assert len({spec.run_id for spec in specs}) == 70
    assert [spec.arm for spec in specs[:2]] == ["D1", "D3"]
    assert specs[0].run_id == "E13_E13L_mosei_p0_s1111"
    assert specs[-1].run_id == "E13_E13T_mosei_p6_s7777"
    assert {spec.protocol for spec in specs} == set("0123456")
    assert {spec.seed for spec in specs} == {1111, 2222, 3407, 5576, 7777}

    commands = {spec.arm: command_for_spec(tmp_path, spec, False) for spec in specs[:2]}
    assert "--protocol_adaptation_scope=last_layer" in commands["D1"]
    assert "--protocol_adaptation_scope=late_transformer_fusion" in commands["D3"]
    for command in commands.values():
        assert "--protocol_fusion_readaptation" in command
        assert "--protocol_fusion_learning_rate=1e-4" in command
        assert "--protocol_transformer_learning_rate=2e-5" in command
        assert "--paper_parent_run_id=E06R1_M1_mosei_p0_s1111" in command


def test_e13_reference_mapping_reuses_frozen_e06():
    assert reference_run_id("D0", "3", 1111) == "E06R1_M1_mosei_p3_s1111"
    assert reference_run_id("D2", "3", 1111) == "E06R1_M2_mosei_p3_s1111"
    assert reference_run_id("D4", "3", 1111) == "E06R1_M3_mosei_p3_s1111"


def test_e13_audit_builds_five_unique_computational_arms(tmp_path):
    specs = build_matrix(protocols=("3",), seeds=(1111,))
    _write_cell(tmp_path, specs)
    summary = audit_matrix(tmp_path, specs, perform_preflight=False)
    assert summary["completed_new_run_count"] == 2
    assert summary["completed_reused_reference_count"] == 3
    assert summary["completed_total_ablation_cells"] == 5
    assert [item["arm"] for item in summary["records"]] == list(ARMS)
    full = summary["effects"]["full_fusion_adaptation"]["summary"]
    assert full["test_mae"]["mean_gain"] == pytest.approx(0.06)
    late = summary["effects"]["late_transformer_expansion"]["summary"]
    assert late["test_mae"]["mean_gain"] == pytest.approx(-0.01)
    assert summary["shared_model_control_deferred_for_common_root"] is True


def test_e13_rejects_wrong_trainable_scope(tmp_path):
    specs = build_matrix(protocols=("0",), seeds=(1111,), arms=("D1",))
    spec = specs[0]
    _write_manifest(tmp_path, {
        "status": "complete", "run_id": spec.run_id,
        "method_id": spec.method, "stage_id": "E13",
        "dataset": "mosei", "protocol": "0", "seed": 1111,
        "lineage": {"parent_run_id": spec.parent_run_id, "parent_method_id": "M1"},
        "code_sha256": {"main.py": "new"},
        "arguments": {
            "retrieval_mode": "missing_aware",
            "retrieval_candidate_source": "train_bank",
            "retrieval_candidate_filter": "observed_only",
            "retrieval_composition": "prototype_neighbours",
            "retrieval_selection": "similarity",
            "retrieval_queue_size": 0,
            "protocol_fusion_readaptation": True,
            "protocol_adaptation_scope": "fusion_all",
            "protocol_fusion_learning_rate": 1e-4,
            "protocol_transformer_learning_rate": 2e-5,
            "load": 1,
        },
        "result": _result("0", 0.5, True),
    })
    with pytest.raises(RuntimeError, match="protocol_adaptation_scope"):
        audit_matrix(
            tmp_path, specs, require_complete=False, perform_preflight=False
        )
