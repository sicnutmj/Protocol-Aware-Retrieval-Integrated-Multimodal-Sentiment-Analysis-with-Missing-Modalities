import json
from argparse import Namespace

import numpy as np
import pytest

from paper_experiment import (
    DEFAULT_CODE_FILES,
    FinalTestGate,
    build_data_provenance,
    evaluate_staged_adaptation,
    fixed_protocol_mask_record,
    resolve_dataset_path,
    sha256_file,
    state_dict_content_sha256,
    validate_formal_lineage,
    validate_formal_method_identity,
    finalize_paper_manifest,
    start_paper_manifest,
)
from prepare_paper_experiments import initialize_workspace
from refresh_paper_registry import rebuild_registry


def make_args(tmp_path):
    return Namespace(
        paper_run_id="E00_M1_mosei_p0_s1111",
        paper_method_id="M1",
        paper_stage_id="E00",
        paper_manifest_dir=str(tmp_path / "paper_experiments" / "manifests"),
        dataset="mosei",
        fixed_protocol="0",
        seed=1111,
    )


def test_formal_workspace_and_manifest_lifecycle(tmp_path):
    initialize_workspace(tmp_path)
    args = make_args(tmp_path)
    checkpoint = tmp_path / "paper_checkpoints" / "model.pt"
    checkpoint.write_bytes(b"checkpoint")

    manifest_path = start_paper_manifest(
        args,
        tmp_path / "paper_logs" / "run.log",
        checkpoint,
        workspace=tmp_path,
    )
    with open(manifest_path, "r", encoding="utf-8") as stream:
        running = json.load(stream)
    assert running["status"] == "running"
    assert running["run_id"] == args.paper_run_id

    finalize_paper_manifest(
        manifest_path,
        "complete",
        result={
            "best_epoch": 3,
            "best_loss": 0.5,
            "test_mae": 0.6,
            "test_corr": 0.7,
            "test_acc2": 0.8,
            "test_f1": 0.79,
            "test_evaluation_count": 1,
        },
    )
    with open(manifest_path, "r", encoding="utf-8") as stream:
        complete = json.load(stream)
    assert complete["status"] == "complete"
    assert complete["outputs"]["best_model_sha256"]

    registry_path = rebuild_registry(tmp_path)
    registry = registry_path.read_text(encoding="utf-8")
    assert args.paper_run_id in registry
    assert "complete" in registry
    assert "0.6" in registry


def test_formal_run_id_cannot_be_reused(tmp_path):
    initialize_workspace(tmp_path)
    args = make_args(tmp_path)
    start_paper_manifest(
        args,
        tmp_path / "paper_logs" / "run.log",
        tmp_path / "paper_checkpoints" / "model.pt",
        workspace=tmp_path,
    )
    with pytest.raises(FileExistsError):
        start_paper_manifest(
            args,
            tmp_path / "paper_logs" / "run.log",
            tmp_path / "paper_checkpoints" / "model.pt",
            workspace=tmp_path,
        )


def test_final_test_gate_fails_closed_and_allows_exactly_one_access():
    gate = FinalTestGate(enabled=True)
    with pytest.raises(RuntimeError, match="before checkpoint selection"):
        gate.record_access()

    gate.arm()
    gate.record_access()
    assert gate.evaluation_count == 1

    with pytest.raises(RuntimeError, match="only once"):
        gate.record_access()
    with pytest.raises(RuntimeError, match="cannot be re-armed"):
        gate.arm()


def test_final_test_gate_is_transparent_for_nonformal_runs():
    gate = FinalTestGate(enabled=False)
    gate.record_access()
    gate.record_access()
    assert gate.evaluation_count == 0


def test_formal_policy_code_is_fingerprinted():
    assert "paper_experiment.py" in DEFAULT_CODE_FILES


def test_fixed_protocol_mask_fingerprint_is_stable_and_protocol_specific():
    first = fixed_protocol_mask_record(5, "3")
    repeated = fixed_protocol_mask_record(5, "3")
    different = fixed_protocol_mask_record(5, "4")
    assert first == repeated
    assert first["modalities"] == [1, 1, 0]
    assert first["available_entries"] == [5, 5, 0]
    assert first["sha256_uint8_row_major"] != (
        different["sha256_uint8_row_major"]
    )


def test_data_provenance_fingerprints_dataset_and_all_splits(tmp_path):
    dataset = tmp_path / "aligned_mosei.pkl"
    dataset.write_bytes(b"frozen-dataset")
    provenance = build_data_provenance(
        dataset,
        {"train": 3, "dev": 2, "test": 4},
        "5",
    )
    assert provenance["dataset_sha256"]
    assert provenance["split_sizes"]["test"] == 4
    assert set(provenance["mask_records"]) == {"train", "dev", "test"}
    assert provenance["mask_records"]["train"]["modalities"] == [0, 1, 1]


def test_dataset_path_prefers_flat_layout_and_supports_hme_fallback(tmp_path):
    nested = tmp_path / "datasets" / "HME_NeurIPS_25" / "aligned_mosi.pkl"
    nested.parent.mkdir(parents=True)
    nested.write_bytes(b"nested")
    assert resolve_dataset_path(tmp_path, "mosi") == nested.resolve()

    flat = tmp_path / "datasets" / "aligned_mosi.pkl"
    flat.write_bytes(b"flat")
    assert resolve_dataset_path(tmp_path, "mosi") == flat.resolve()


def test_dataset_path_reports_every_checked_location(tmp_path):
    with pytest.raises(FileNotFoundError, match="HME_NeurIPS_25"):
        resolve_dataset_path(tmp_path, "mosi")


def test_state_dict_content_hash_ignores_mapping_order():
    class FakeTensor:
        def __init__(self, value):
            self.value = np.asarray(value)
            self.dtype = self.value.dtype
            self.shape = self.value.shape

        def detach(self):
            return self

        def cpu(self):
            return self

        def contiguous(self):
            return self

        def numpy(self):
            return self.value

    first = {
        "weight": FakeTensor([[1.0, 2.0]]),
        "bias": FakeTensor([3.0]),
    }
    reordered = {
        "bias": FakeTensor([3.0]),
        "weight": FakeTensor([[1.0, 2.0]]),
    }
    changed = {
        "weight": FakeTensor([[1.0, 2.5]]),
        "bias": FakeTensor([3.0]),
    }
    assert state_dict_content_sha256(first) == (
        state_dict_content_sha256(reordered)
    )
    assert state_dict_content_sha256(first) != (
        state_dict_content_sha256(changed)
    )


def make_method_args(tmp_path, method_id):
    values = {
        "paper_method_id": method_id,
        "paper_parent_run_id": "",
        "paper_manifest_dir": str(tmp_path / "manifests"),
        "dataset": "mosei",
        "fixed_protocol": "3",
        "seed": 1111,
        "model_path": "unused.pt",
        "retrieval_queue_size": 0,
        "retrieval_metric_mode": "raw",
        "retrieval_missing_query": "center",
        "protocol_fusion_readaptation": False,
        "protocol_adaptation_scope": "fusion_all",
        "protocol_fusion_learning_rate": 1e-4,
        "protocol_transformer_learning_rate": 2e-5,
        "load": 0,
        "retrieval_mode": "missing_aware",
        "retrieval_candidate_source": "train_bank",
        "retrieval_candidate_filter": "observed_only",
        "retrieval_composition": "prototype_neighbours",
        "retrieval_selection": "similarity",
        "retrieval_random_seed": 3407,
        "gate_mode": "none",
        "consistency_mode": "mixed",
        "distill_mode": "none",
        "fusion_mode": "flat",
        "prompt_mode": "none",
        "reconstruction_mode": "none",
        "consensus_mode": "none",
        "tag_mode": "none",
        "cross_modal_retrieval_mode": "none",
        "training_prior_mode": "none",
        "hybrid_expert_mode": "none",
        "protocol_consistency_mode": "none",
        "relation_distill_mode": "none",
        "missing_text_contrast_mode": "none",
        "privileged_purification_mode": "none",
        "language_hyper_mode": "none",
        "coupled_prompt_mode": "none",
        "pns_audit": False,
    }
    if method_id == "M0":
        values.update({
            "retrieval_mode": "legacy",
            "retrieval_candidate_source": "batch",
        })
    if method_id == "A1":
        values.update({
            "retrieval_mode": "missing_aware",
            "retrieval_candidate_source": "batch",
        })
    if method_id in ("M2", "M3"):
        values.update({
            "paper_parent_run_id": "parent",
            "protocol_fusion_readaptation": True,
            "load": 1,
        })
    if method_id in ("E13L", "E13T"):
        values.update({
            "paper_parent_run_id": "parent",
            "protocol_fusion_readaptation": True,
            "protocol_adaptation_scope": (
                "last_layer"
                if method_id == "E13L"
                else "late_transformer_fusion"
            ),
            "load": 1,
        })
    e12 = {
        "E12U": ("batch", "all", "prototype_neighbours", "similarity"),
        "E12P": ("train_bank", "observed_only", "prototype_only", "similarity"),
        "E12N": ("train_bank", "observed_only", "neighbours_only", "similarity"),
        "E12R": ("train_bank", "observed_only", "prototype_neighbours", "random"),
    }
    if method_id in e12:
        source, candidate_filter, composition, selection = e12[method_id]
        values.update({
            "retrieval_mode": "missing_aware",
            "retrieval_candidate_source": source,
            "retrieval_candidate_filter": candidate_filter,
            "retrieval_composition": composition,
            "retrieval_selection": selection,
            "retrieval_random_seed": 1111 if method_id == "E12R" else 3407,
        })
    return Namespace(**values)


@pytest.mark.parametrize(
    "method_id",
    ["M0", "A1", "M1", "M2", "M3", "E12U", "E12P", "E12N", "E12R",
     "E13L", "E13T"],
)
def test_formal_method_contract_accepts_only_its_active_path(
    tmp_path, method_id
):
    args = make_method_args(tmp_path, method_id)
    validate_formal_method_identity(args)


def test_pre_e12_namespace_uses_new_parser_defaults(tmp_path):
    args = make_method_args(tmp_path, "M1")
    for name in (
        "retrieval_candidate_filter",
        "retrieval_composition",
        "retrieval_selection",
        "retrieval_random_seed",
    ):
        delattr(args, name)
    validate_formal_method_identity(args)


def test_pre_e12_method_rejects_explicit_nondefault_retrieval_control(tmp_path):
    args = make_method_args(tmp_path, "M1")
    args.retrieval_selection = "random"
    with pytest.raises(ValueError, match="retrieval_selection"):
        validate_formal_method_identity(args)
    args.gate_mode = "reliability"
    with pytest.raises(ValueError, match="gate_mode"):
        validate_formal_method_identity(args)


def test_e15_method_contract_allows_only_registered_finite_banks(tmp_path):
    args = make_method_args(tmp_path, "M1")
    args.paper_stage_id = "E15"
    args.retrieval_top_k = 2
    args.retrieval_reference_bank_size = 512
    args.retrieval_reference_bank_seed = 3407
    validate_formal_method_identity(args)

    args.retrieval_reference_bank_size = 513
    with pytest.raises(ValueError, match="finite reference-bank size"):
        validate_formal_method_identity(args)

    args.retrieval_reference_bank_size = 512
    args.retrieval_reference_bank_seed = 1111
    with pytest.raises(ValueError, match="reference_bank_seed=3407"):
        validate_formal_method_identity(args)


def test_e16_method_contract_allows_only_registered_temperatures(tmp_path):
    args = make_method_args(tmp_path, "M1")
    args.paper_stage_id = "E16"
    args.retrieval_top_k = 2
    args.retrieval_temperature = 0.05
    args.retrieval_reference_bank_size = 0
    args.retrieval_reference_bank_seed = 3407
    validate_formal_method_identity(args)

    args.retrieval_temperature = 0.1
    with pytest.raises(ValueError, match="new-run temperature"):
        validate_formal_method_identity(args)

    args.retrieval_temperature = 0.2
    args.retrieval_reference_bank_size = 512
    with pytest.raises(ValueError, match="complete retrieval reference bank"):
        validate_formal_method_identity(args)


def test_e17_method_contract_allows_only_registered_fusion_learning_rates(tmp_path):
    args = make_method_args(tmp_path, "M2")
    args.paper_stage_id = "E17"
    args.retrieval_top_k = 2
    args.retrieval_temperature = 0.1
    args.retrieval_reference_bank_size = 0
    args.retrieval_reference_bank_seed = 3407
    args.protocol_fusion_learning_rate = 1e-5
    args.learning_rate = 1e-5
    validate_formal_method_identity(args)

    args.protocol_fusion_learning_rate = 1e-4
    args.learning_rate = 1e-4
    with pytest.raises(ValueError, match="new-run fusion learning rate"):
        validate_formal_method_identity(args)

    args.paper_method_id = "M1"
    args.paper_parent_run_id = ""
    args.protocol_fusion_readaptation = False
    args.load = 0
    args.protocol_fusion_learning_rate = 5e-5
    args.learning_rate = 5e-5
    with pytest.raises(ValueError, match="requires M2"):
        validate_formal_method_identity(args)


def test_m2_lineage_requires_matching_m1_checkpoint(tmp_path):
    checkpoint = tmp_path / "m1_best.pt"
    checkpoint.write_bytes(b"m1-checkpoint")
    manifest_dir = tmp_path / "manifests"
    manifest_dir.mkdir()
    parent = {
        "run_id": "parent",
        "method_id": "M1",
        "status": "complete",
        "dataset": "mosei",
        "protocol": "3",
        "seed": 1111,
        "outputs": {
            "best_model_path": str(checkpoint),
            "best_model_sha256": sha256_file(checkpoint),
        },
        "result": {
            "best_loss": 0.5,
            "selected_state_sha256": "parent-state",
        },
    }
    (manifest_dir / "parent.json").write_text(
        json.dumps(parent), encoding="utf-8"
    )
    args = make_method_args(tmp_path, "M2")
    args.model_path = str(checkpoint)
    lineage = validate_formal_lineage(args)
    assert lineage["parent_method_id"] == "M1"
    assert lineage["parent_checkpoint_sha256"] == sha256_file(checkpoint)
    assert lineage["parent_best_dev_mae"] == 0.5

    parent["seed"] = 2222
    (manifest_dir / "parent.json").write_text(
        json.dumps(parent), encoding="utf-8"
    )
    with pytest.raises(ValueError, match="lineage mismatch"):
        validate_formal_lineage(args)


def test_staged_adaptation_gate_accepts_improvement_or_exact_fallback():
    lineage = {
        "parent_best_dev_mae": 0.5,
        "parent_state_sha256": "parent-state",
    }
    improved = evaluate_staged_adaptation(
        "M3", 4, 0.5, 0.49, "new-state", lineage
    )
    assert improved["outcome"] == "improved"
    assert improved["dev_mae_gain"] == pytest.approx(0.01)
    fallback = evaluate_staged_adaptation(
        "M3", 0, 0.5, 0.5, "parent-state", lineage
    )
    assert fallback["outcome"] == "fallback_parent"

    with pytest.raises(RuntimeError, match="does not match"):
        evaluate_staged_adaptation(
            "M3", 0, 0.5, 0.5, "wrong-state", lineage
        )
