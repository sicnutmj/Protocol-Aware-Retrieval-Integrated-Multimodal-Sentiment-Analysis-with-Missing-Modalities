import math
import unittest

import torch

from modules.training_similar_prior_enhancement import (
    TrainingSimilarPriorEnhancement,
)


class TrainingSimilarPriorEnhancementTest(unittest.TestCase):
    def setUp(self):
        self.module = TrainingSimilarPriorEnhancement(
            mix_ratio=0.1,
            top_k=2,
            similarity_min=0.90,
            similarity_max=0.95,
            score_temperature=0.1,
            label_weight=0.25,
            label_temperature=0.5,
        )
        angle = 0.35
        self.features = torch.tensor([
            [1.0, 0.0],
            [math.cos(angle), math.sin(angle)],
            [math.cos(angle), -math.sin(angle)],
        ])
        self.modalities = tuple(self.features.clone() for _ in range(3))
        self.labels = torch.tensor([0.0, 0.1, -0.1])

    def test_evaluation_without_labels_is_exact_identity(self):
        mask = torch.ones(3, 3, dtype=torch.bool)
        enhanced, diagnostics = self.module(
            self.modalities, mask, labels=None
        )
        for actual, expected in zip(enhanced, self.modalities):
            self.assertIs(actual, expected)
            self.assertTrue(torch.equal(actual, expected))
        self.assertFalse(diagnostics['enabled'])

    def test_eval_mode_is_identity_even_if_labels_are_supplied(self):
        self.module.eval()
        mask = torch.ones(3, 3, dtype=torch.bool)
        enhanced, diagnostics = self.module(
            self.modalities, mask, labels=self.labels
        )
        for actual, expected in zip(enhanced, self.modalities):
            self.assertIs(actual, expected)
        self.assertFalse(diagnostics['enabled'])

    def test_two_valid_neighbours_enhance_observed_anchor(self):
        mask = torch.ones(3, 3, dtype=torch.bool)
        enhanced, diagnostics = self.module(
            self.modalities, mask, self.labels
        )
        self.assertTrue(diagnostics['enabled'])
        self.assertTrue(torch.all(diagnostics['eligible_count'] == 1))
        for modality in enhanced:
            self.assertFalse(torch.equal(modality[0], self.features[0]))
            self.assertTrue(torch.equal(modality[1], self.features[1]))
            self.assertTrue(torch.equal(modality[2], self.features[2]))

    def test_missing_modality_is_never_changed_or_used_as_donor(self):
        mask = torch.ones(3, 3, dtype=torch.bool)
        mask[:, 1] = False
        enhanced, diagnostics = self.module(
            self.modalities, mask, self.labels
        )
        self.assertTrue(torch.equal(enhanced[1], self.modalities[1]))
        self.assertEqual(diagnostics['observed_count'][1].item(), 0)
        self.assertEqual(diagnostics['eligible_count'][1].item(), 0)

    def test_requires_full_top_k_and_preserves_no_candidate_rows(self):
        mask = torch.ones(3, 3, dtype=torch.bool)
        mask[2, :] = False
        enhanced, diagnostics = self.module(
            self.modalities, mask, self.labels
        )
        for actual, expected in zip(enhanced, self.modalities):
            self.assertTrue(torch.equal(actual, expected))
        self.assertEqual(
            torch.count_nonzero(diagnostics['eligible_count']).item(), 0
        )

    def test_invalid_configuration_is_rejected(self):
        with self.assertRaises(ValueError):
            TrainingSimilarPriorEnhancement(mix_ratio=0.0)
        with self.assertRaises(ValueError):
            TrainingSimilarPriorEnhancement(
                similarity_min=0.95,
                similarity_max=0.90,
            )


if __name__ == '__main__':
    unittest.main()
