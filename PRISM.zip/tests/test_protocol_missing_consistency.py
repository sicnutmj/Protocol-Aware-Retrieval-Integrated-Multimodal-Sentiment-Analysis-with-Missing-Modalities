import pytest
import torch

from modules.protocol_missing_consistency import (
    confidence_gated_polarity_consistency,
)


def test_identical_predictions_have_zero_consistency_loss():
    prediction = torch.tensor([[-2.0], [-1.0], [1.0], [2.0]])

    loss, diagnostics = confidence_gated_polarity_consistency(
        prediction, prediction, temperature=0.5, confidence_threshold=0.95
    )

    assert loss.item() == pytest.approx(0.0, abs=1e-7)
    assert diagnostics['coverage'].item() == 1.0
    assert diagnostics['polarity_disagreement'].item() == 0.0


def test_low_confidence_teachers_are_excluded():
    student = torch.tensor([[2.0], [-2.0]], requires_grad=True)
    teacher = torch.tensor([[0.01], [-0.01]])

    loss, diagnostics = confidence_gated_polarity_consistency(
        student, teacher, temperature=0.5, confidence_threshold=0.95
    )
    loss.backward()

    assert loss.item() == 0.0
    assert diagnostics['coverage'].item() == 0.0
    assert torch.equal(student.grad, torch.zeros_like(student))


def test_confident_disagreement_produces_gradient():
    student = torch.tensor([[-2.0], [2.0]], requires_grad=True)
    teacher = torch.tensor([[2.0], [-2.0]], requires_grad=True)

    loss, diagnostics = confidence_gated_polarity_consistency(
        student, teacher, temperature=0.5, confidence_threshold=0.95
    )
    loss.backward()

    assert loss.item() > 0.0
    assert diagnostics['eligible_polarity_disagreement'].item() == 1.0
    assert student.grad is not None
    assert teacher.grad is None


@pytest.mark.parametrize(
    'temperature,confidence',
    ((0.0, 0.95), (0.5, 0.49), (0.5, 1.01)),
)
def test_invalid_hyperparameters_are_rejected(temperature, confidence):
    prediction = torch.ones(2, 1)

    with pytest.raises(ValueError):
        confidence_gated_polarity_consistency(
            prediction,
            prediction,
            temperature=temperature,
            confidence_threshold=confidence,
        )
