import unittest

import torch

from modules.availability_aware_fusion import (
    AvailabilityAwareMultiStageFusion,
)


class AvailabilityAwareMultiStageFusionTest(unittest.TestCase):
    def setUp(self):
        torch.manual_seed(7)
        self.model = AvailabilityAwareMultiStageFusion(
            embedding_dim=8, output_dim=1, dropout=0.0
        )
        self.sample = torch.randn(4, 8, requires_grad=True)
        self.enhanced = tuple(
            torch.randn(4, 8, requires_grad=True) for _ in range(3)
        )
        self.raw = tuple(
            torch.randn(4, 8, requires_grad=True) for _ in range(3)
        )

    def test_forward_shape_and_gradients(self):
        observed = torch.tensor(
            [[1, 0, 0], [0, 1, 0], [0, 0, 1], [1, 1, 1]]
        )
        output, hidden, diagnostics = self.model(
            self.sample, self.enhanced, self.raw, observed
        )
        self.assertEqual(output.shape, (4, 1))
        self.assertEqual(hidden.shape, (4, 32))
        self.assertEqual(diagnostics['bimodal_weights'].shape, (4, 3))
        output.sum().backward()
        self.assertIsNotNone(self.sample.grad)
        for feature in self.enhanced + self.raw:
            self.assertIsNotNone(feature.grad)

    def test_unobserved_only_pair_is_excluded(self):
        observed = torch.tensor([[1, 0, 0]] * 4)
        _, _, diagnostics = self.model(
            self.sample, self.enhanced, self.raw, observed
        )
        # Pair order is LA, LV, AV.  AV has no observed input for this batch.
        self.assertFalse(diagnostics['pair_valid'][:, 2].any())
        self.assertTrue(
            torch.equal(
                diagnostics['bimodal_weights'][:, 2], torch.zeros(4)
            )
        )
        self.assertTrue(
            torch.equal(
                diagnostics['trimodal_weights'][:, 2], torch.zeros(4)
            )
        )

    def test_all_seven_protocols_have_finite_normalized_weights(self):
        protocols = torch.tensor(
            [
                [1, 0, 0],
                [0, 1, 0],
                [0, 0, 1],
                [1, 1, 0],
                [1, 0, 1],
                [0, 1, 1],
                [1, 1, 1],
            ]
        )
        sample = torch.randn(7, 8)
        enhanced = tuple(torch.randn(7, 8) for _ in range(3))
        raw = tuple(torch.randn(7, 8) for _ in range(3))
        output, hidden, diagnostics = self.model(
            sample, enhanced, raw, protocols
        )
        self.assertTrue(torch.isfinite(output).all())
        self.assertTrue(torch.isfinite(hidden).all())
        for key in (
            'unimodal_weights',
            'bimodal_weights',
            'trimodal_weights',
        ):
            weights = diagnostics[key]
            self.assertTrue(torch.isfinite(weights).all())
            self.assertTrue(
                torch.allclose(weights.sum(dim=1), torch.ones(7))
            )

    def test_each_sample_requires_an_observed_modality(self):
        observed = torch.zeros(4, 3)
        with self.assertRaisesRegex(ValueError, 'at least one observed'):
            self.model(self.sample, self.enhanced, self.raw, observed)

    def test_availability_values_must_be_binary(self):
        observed = torch.ones(4, 3)
        observed[0, 0] = 0.5
        with self.assertRaisesRegex(ValueError, 'binary'):
            self.model(self.sample, self.enhanced, self.raw, observed)

    def test_invalid_feature_shape_is_rejected(self):
        invalid = (torch.zeros(4, 7),) + self.enhanced[1:]
        observed = torch.ones(4, 3)
        with self.assertRaisesRegex(ValueError, 'enhanced_features'):
            self.model(self.sample, invalid, self.raw, observed)


if __name__ == '__main__':
    unittest.main()
