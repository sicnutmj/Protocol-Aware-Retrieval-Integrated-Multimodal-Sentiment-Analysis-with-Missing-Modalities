import pytest
import torch
import torch.nn as nn

from modules.teacher_advantage_relation_distillation import (
    FrozenLateFusionTeacher,
    modality_relation_graph,
    teacher_advantage_relation_distillation,
)


def test_identical_modality_graphs_have_zero_loss_when_teacher_is_better():
    student = torch.randn(2, 7 * 4, requires_grad=True)
    teacher_nodes = student.detach().reshape(2, 7, 4)[:, 1:4].clone()
    student_prediction = torch.tensor([[1.0], [-1.0]])
    teacher_prediction = torch.tensor([[0.1], [-0.1]])
    labels = torch.zeros(2, 1)

    loss, diagnostics = teacher_advantage_relation_distillation(
        student,
        teacher_nodes,
        student_prediction,
        teacher_prediction,
        labels,
    )

    assert loss.item() == pytest.approx(0.0, abs=1e-7)
    assert diagnostics['coverage'].item() == 1.0


def test_worse_teacher_is_gated_and_produces_zero_gradient():
    student = torch.randn(2, 7 * 4, requires_grad=True)
    teacher_nodes = torch.randn(2, 3, 4)
    student_prediction = torch.tensor([[0.1], [-0.1]])
    teacher_prediction = torch.tensor([[1.0], [-1.0]])
    labels = torch.zeros(2, 1)

    loss, diagnostics = teacher_advantage_relation_distillation(
        student,
        teacher_nodes,
        student_prediction,
        teacher_prediction,
        labels,
    )
    loss.backward()

    assert diagnostics['coverage'].item() == 0.0
    assert torch.equal(student.grad, torch.zeros_like(student))


def test_eligible_relation_mismatch_produces_student_gradient_only():
    student = torch.randn(3, 7 * 5, requires_grad=True)
    teacher_nodes = torch.randn(3, 3, 5, requires_grad=True)
    student_prediction = torch.ones(3, 1)
    teacher_prediction = torch.zeros(3, 1)
    labels = torch.zeros(3, 1)

    loss, _ = teacher_advantage_relation_distillation(
        student,
        teacher_nodes,
        student_prediction,
        teacher_prediction,
        labels,
    )
    loss.backward()

    assert loss.item() > 0.0
    assert student.grad is not None
    assert teacher_nodes.grad is None


def test_relation_graph_rejects_wrong_node_count():
    with pytest.raises(ValueError):
        modality_relation_graph(torch.randn(2, 4, 8))


def test_frozen_teacher_is_a_snapshot_and_stays_in_eval_mode():
    transformer = nn.Identity()
    fusion = nn.Linear(7 * 3, 1)
    teacher = FrozenLateFusionTeacher(transformer, fusion)
    representations = tuple(torch.randn(2, 3) for _ in range(7))

    nodes_before, prediction_before = teacher(representations)
    with torch.no_grad():
        fusion.weight.add_(10.0)
    teacher.train()
    nodes_after, prediction_after = teacher(representations)

    assert not teacher.training
    assert torch.equal(nodes_before, nodes_after)
    assert torch.equal(prediction_before, prediction_after)
