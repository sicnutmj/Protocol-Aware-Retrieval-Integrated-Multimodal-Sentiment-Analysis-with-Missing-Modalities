import hashlib
import json

import pytest

from run_e15_retrieval_bank_size import (
    BANK_SIZE_VALUES,
    FINITE_BANK_SIZES,
    FULL_BANK_SIZE,
    METRICS,
    SPLIT_SIZES,
    audit_matrix,
    build_matrix,
    command_for_spec,
    reference_run_id,
)


def _sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _bank_record(size):
    return {
        "source": "complete_training_split_only",
        "available_count": FULL_BANK_SIZE,
        "requested_size": size,
        "actual_size": size,
        "subset_seed": 3407,
        "selection": "sha256_seeded_sample_id_nested_prefix",
        "selected_ids_sha256": "selected-{}".format(size),
        "validation_donors": 0,
        "test_donors": 0,
        "self_exclusion_ids": True,
        "runtime_only": True,
    }


def _result(protocol, value, bank_size=None):
    provenance = {
        "dataset_sha256": "mosei-data",
        "split_sizes": SPLIT_SIZES,
        "fixed_protocol": protocol,
    }
    if bank_size is not None:
        provenance["strict_retrieval_bank"] = _bank_record(bank_size)
    result = {
        "best_epoch": 3, "best_loss": value,
        "selection_split": "development", "selection_metric": "mae",
        "test_evaluation_count": 1, "data_provenance": provenance,
    }
    result.update({metric: value for metric in METRICS})
    return result


def _arguments(bank_size, include_new=True):
    output = {
        "retrieval_mode": "missing_aware",
        "retrieval_candidate_source": "train_bank",
        "retrieval_candidate_filter": "observed_only",
        "retrieval_composition": "prototype_neighbours",
        "retrieval_selection": "similarity", "retrieval_random_seed": 3407,
        "retrieval_top_k": 2, "retrieval_queue_size": 0,
        "protocol_fusion_readaptation": False, "load": 0,
    }
    if include_new:
        output.update({
            "retrieval_reference_bank_size": bank_size,
            "retrieval_reference_bank_seed": 3407,
        })
    return output


def _write_manifest(workspace, payload, checkpoint=True):
    manifest_dir = workspace / "paper_experiments" / "manifests"
    checkpoint_dir = workspace / "paper_checkpoints"
    manifest_dir.mkdir(parents=True, exist_ok=True)
    checkpoint_dir.mkdir(parents=True, exist_ok=True)
    checkpoint_path = checkpoint_dir / "{}_best.pt".format(payload["run_id"])
    if checkpoint:
        checkpoint_path.write_bytes(payload["run_id"].encode("utf-8"))
    payload["outputs"] = {
        "best_model_path": str(checkpoint_path),
        "best_model_sha256": _sha(checkpoint_path) if checkpoint else "old-sha",
    }
    (manifest_dir / "{}.json".format(payload["run_id"])).write_text(
        json.dumps(payload), encoding="utf-8"
    )


def _write_cell(workspace, specs):
    values = {512: 0.55, 1024: 0.53, 2048: 0.51, 4096: 0.50}
    for spec in specs:
        _write_manifest(workspace, {
            "status": "complete", "run_id": spec.run_id,
            "method_id": "M1", "stage_id": "E15", "dataset": "mosei",
            "protocol": spec.protocol, "seed": spec.seed, "lineage": None,
            "code_sha256": {"main.py": "new"},
            "arguments": _arguments(spec.bank_size),
            "result": _result(spec.protocol, values[spec.bank_size], spec.bank_size),
        })
    protocol, seed = specs[0].protocol, specs[0].seed
    reference_arguments = _arguments(0, include_new=False)
    for name in (
        "retrieval_candidate_filter", "retrieval_composition",
        "retrieval_selection", "retrieval_random_seed",
    ):
        reference_arguments.pop(name)
    _write_manifest(workspace, {
        "status": "complete", "run_id": reference_run_id(protocol, seed),
        "method_id": "M1", "stage_id": "E06", "dataset": "mosei",
        "protocol": protocol, "seed": seed, "lineage": None,
        "code_sha256": {"main.py": "old"}, "arguments": reference_arguments,
        "result": _result(protocol, 0.49),
    }, checkpoint=False)


def test_e15_matrix_has_48_new_runs_and_full_bank_reuse(tmp_path):
    specs = build_matrix()
    assert len(specs) == 48
    assert len({spec.run_id for spec in specs}) == 48
    assert [spec.bank_size for spec in specs[:4]] == list(FINITE_BANK_SIZES)
    assert specs[0].run_id == "E15_B512_mosei_p0_s1111"
    assert specs[-1].run_id == "E15_B4096_mosei_p6_s7777"
    assert BANK_SIZE_VALUES == (512, 1024, 2048, 4096, 16326)
    for spec in specs[:4]:
        command = command_for_spec(tmp_path, spec)
        assert "--paper_method_id=M1" in command
        assert "--paper_stage_id=E15" in command
        assert "--retrieval_top_k=2" in command
        assert "--retrieval_reference_bank_size={}".format(spec.bank_size) in command
        assert "--retrieval_reference_bank_seed=3407" in command
        assert "--protocol_fusion_readaptation" not in command


def test_e15_audit_builds_five_sizes_and_effects_vs_full(tmp_path):
    specs = build_matrix(protocols=("3",), seeds=(1111,))
    _write_cell(tmp_path, specs)
    summary = audit_matrix(
        tmp_path, specs, perform_reference_preflight=False
    )
    assert summary["completed_new_run_count"] == 4
    assert summary["completed_reused_reference_count"] == 1
    assert summary["completed_total_sensitivity_cells"] == 5
    assert [item["bank_size_label"] for item in summary["records"]] == [
        "512", "1024", "2048", "4096", "full"
    ]
    effect = summary["effects_vs_full_bank"]["4096"]["summary"]["test_mae"]
    assert effect["mean_gain"] == pytest.approx(-0.01)
    assert effect["losses"] == 1
    assert summary["summary_by_bank_size"]["full"]["test_mae"]["mean"] == 0.49


def test_e15_rejects_missing_full_reference(tmp_path):
    specs = build_matrix(protocols=("0",), seeds=(1111,))
    _write_cell(tmp_path, specs)
    path = (
        tmp_path / "paper_experiments" / "manifests"
        / "E06R1_M1_mosei_p0_s1111.json"
    )
    path.unlink()
    with pytest.raises(RuntimeError, match="missing_reference=1"):
        audit_matrix(tmp_path, specs, perform_reference_preflight=False)


def test_e15_rejects_wrong_bank_size_contract(tmp_path):
    spec = build_matrix(
        protocols=("0",), seeds=(1111,), bank_sizes=(512,)
    )[0]
    payload = {
        "status": "complete", "run_id": spec.run_id,
        "method_id": "M1", "stage_id": "E15", "dataset": "mosei",
        "protocol": "0", "seed": 1111, "lineage": None,
        "code_sha256": {"main.py": "new"}, "arguments": _arguments(1024),
        "result": _result("0", 0.5, 512),
    }
    _write_manifest(tmp_path, payload)
    with pytest.raises(RuntimeError, match="retrieval_reference_bank_size"):
        audit_matrix(
            tmp_path, [spec], require_complete=False,
            perform_reference_preflight=False,
        )
