import numpy as np
import pytest

from run_e19_random_missing import (
    MASK_SEED,
    MISSING_RATES,
    PROTOCOL_MASKS,
    TEST_SIZE,
    build_export_matrix,
    compose_routed_predictions,
    compute_metrics,
    deterministic_protocol_assignments,
    normalized_curve_area,
)


def test_e19_export_matrix_has_63_unique_frozen_sources():
    specs = build_export_matrix()
    assert len(specs) == 63
    assert len({spec.export_id for spec in specs}) == 63
    assert len({spec.source_run_id for spec in specs}) == 63
    assert specs[0].export_id == "E19P_M0_mosei_p0_s1111"
    assert specs[-1].export_id == "E19P_M2_mosei_p6_s7777"
    assert all(spec.source_run_id.startswith("E06R1_") for spec in specs)


def test_e19_masks_are_deterministic_valid_and_rate_sensitive():
    first, first_record = deterministic_protocol_assignments(
        TEST_SIZE, 0.7, MASK_SEED
    )
    second, second_record = deterministic_protocol_assignments(
        TEST_SIZE, 0.7, MASK_SEED
    )
    higher, higher_record = deterministic_protocol_assignments(
        TEST_SIZE, 0.9, MASK_SEED
    )
    assert np.array_equal(first, second)
    assert first_record == second_record
    assert set(np.unique(first)).issubset(set(PROTOCOL_MASKS))
    assert first_record["protocol_assignment_sha256_uint8"] != higher_record[
        "protocol_assignment_sha256_uint8"
    ]
    assert first_record["realized_missing_entry_rate"] < higher_record[
        "realized_missing_entry_rate"
    ]


def test_e19_conditioned_missing_rates_are_monotone_and_accounted():
    realized = []
    for missing_rate in MISSING_RATES:
        assignments, record = deterministic_protocol_assignments(
            TEST_SIZE, missing_rate
        )
        assert assignments.shape == (TEST_SIZE,)
        assert sum(record["protocol_counts"].values()) == TEST_SIZE
        assert all(value > 0 for value in record["protocol_counts"].values())
        realized.append(record["realized_missing_entry_rate"])
    assert realized == sorted(realized)
    assert len(set(realized)) == len(MISSING_RATES)


def test_e19_routes_each_sample_to_its_matching_specialist():
    assignments = np.asarray([0, 1, 2, 3, 4, 5, 6], dtype=np.uint8)
    predictions = {
        protocol: np.full(7, protocol + 0.25, dtype=np.float64)
        for protocol in range(7)
    }
    routed = compose_routed_predictions(predictions, assignments)
    assert routed.tolist() == pytest.approx(
        [protocol + 0.25 for protocol in range(7)]
    )


def test_e19_metric_and_normalized_area_helpers():
    labels = np.asarray([-3, -2, -1, 0, 1, 2, 3], dtype=np.float64)
    predictions = labels.copy()
    metrics = compute_metrics(predictions, labels)
    assert metrics["test_mae"] == 0.0
    assert metrics["test_corr"] == pytest.approx(1.0)
    assert metrics["test_acc7"] == 1.0
    assert metrics["test_acc2_non_zero"] == 1.0
    assert normalized_curve_area([0.1, 0.5, 0.9], [1.0, 0.5, 0.0]) == pytest.approx(0.5)

