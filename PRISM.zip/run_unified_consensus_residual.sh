set -e

SEVENTH_CHECKPOINT_DIR="${SEVENTH_CHECKPOINT_DIR:-best_modules}"
PROTOCOLS="${PROTOCOLS:-0 3 4}"
ALLOW_FROZEN_NINTH="${ALLOW_FROZEN_NINTH:-0}"

if [ "${ALLOW_FROZEN_NINTH}" != "1" ]; then
  echo "Improvement 9 is frozen after an unsuccessful ablation." >&2
  echo "Set ALLOW_FROZEN_NINTH=1 only for exact reproduction." >&2
  exit 1
fi

CONSENSUS_ARGS=(
  --retrieval_mode=missing_aware
  --retrieval_queue_size=0
  --retrieval_metric_mode=raw
  --retrieval_missing_query=center
  --gate_mode=none
  --consistency_mode=mixed
  --distill_mode=none
  --fusion_mode=flat
  --prompt_mode=none
  --reconstruction_mode=none
  --consensus_mode=amucr
  --consensus_num_heads=4
  --consensus_num_layers=2
  --consensus_hidden_dim=96
  --consensus_dropout=0.1
  --consensus_learning_rate=1e-3
  --load=1
  --n_epochs=40
  --early_stopping_patience=12
  --early_stopping_min_delta=0.0
)

echo "Frozen failed improvement 9: AMUCR"
echo "Foundation: frozen first-improvement q0 + seventh fusion head"
echo "Checkpoint directory: ${SEVENTH_CHECKPOINT_DIR}"
echo "Pilot protocols: ${PROTOCOLS}"

run_protocol() {
  local protocol="$1"
  local train_batch_size="$2"
  local representation_dim="$3"
  local description="$4"
  shift 4

  local checkpoint="${SEVENTH_CHECKPOINT_DIR}/iie_mosei_protocol_${protocol}_missing_aware_q0_seventh_head_best.pt"
  if [ ! -s "${checkpoint}" ]; then
    echo "Missing clean first+seventh checkpoint: ${checkpoint}" >&2
    exit 1
  fi

  echo "AMUCR: protocol ${protocol} (${description})"
  python3 main.py "${CONSENSUS_ARGS[@]}" \
    --fixed_protocol="${protocol}" \
    --model_path="${checkpoint}" \
    --learning_rate=1e-4 \
    --d_l="${representation_dim}" \
    --latent_dim="${representation_dim}" \
    --train_batch_size="${train_batch_size}" \
    --dataset=mosei \
    "$@"
}

for protocol in ${PROTOCOLS}; do
  case "${protocol}" in
    0) run_protocol 0 128 192 "L observed" ;;
    3) run_protocol 3 256 96  "L+A observed" ;;
    4) run_protocol 4 256 96  "L+V observed" ;;
    *)
      echo "Pilot supports protocols 0, 3, and 4; received ${protocol}" >&2
      exit 1
      ;;
  esac
done
