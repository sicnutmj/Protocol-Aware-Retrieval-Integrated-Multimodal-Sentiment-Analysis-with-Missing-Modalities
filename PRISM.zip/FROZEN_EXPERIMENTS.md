# Frozen experiment boundary

## Active foundation for future improvements

The next improvement starts from these two verified components:

1. First improvement: missing-aware q0 retrieval with queue size 0, raw metric,
   center query, mixed MMD, flat fusion, and no reliability gate.
2. Seventh improvement: freeze the complete q0 backbone and fine-tune only
   `fusion_all` with learning rate `1e-4`, early-stopping patience 12, and
   deterministic development/test loaders.

Clean seventh checkpoints use this name:

`iie_mosei_protocol_<0-6>_missing_aware_q0_seventh_head_best.pt`

They contain the first-improvement q0 parameters plus the tuned `fusion_all`
parameters and have no dynamic-prompt tensors.

## Frozen failed branch

`MissingOnlyDynamicPrompt`, `prompt_mode=missing_dynamic`, and
`prompt_finetune_scope=prompt_head` remain only for reproducing the completed
seventh ablation. They are not part of the active foundation. The ablation found
that prompt residual norms remained near zero and prompt+head did not outperform
head-only on aggregate development loss.

`run_missing_dynamic_prompt.sh` now runs head-only by default. Set
`RUN_PROMPT_HEAD=1` explicitly only to reproduce the frozen prompt branch.

## Frozen failed improvement eight

Improvement eight loads the clean `_seventh_head_best.pt` checkpoint, freezes
the complete first+seventh foundation (including `fusion_all`), and trains only
`TextGuidedMissingNonverbalReconstruction`. It reconstructs audio/video only
when text is observed and the target nonverbal modality is missing. Protocols
with missing text and the complete protocol remain exact foundation paths.

The completed protocol 0/3/4 experiment showed that the reconstruction losses
decreased and the injection scales became non-zero, but sentiment performance
did not improve consistently. Protocol 0 changed only negligibly, protocol 3
had mixed metric trade-offs, and protocol 4 selected the epoch-0 foundation.
The branch is therefore frozen and excluded from future improvements.

`run_text_guided_reconstruction.sh` now requires
`ALLOW_FROZEN_EIGHTH=1` for exact reproduction. Future work must continue from
the clean first+seventh `_seventh_head_best.pt` checkpoints, not from a
`recon_tgnv` checkpoint.

## Frozen failed improvement nine

Improvement nine loads the clean `_seventh_head_best.pt` checkpoint, freezes
the complete first+seventh foundation, and trains only the UniMF-inspired
`AvailabilityMaskedUnifiedConsensusResidual` (AMUCR). Missing raw-modality
tokens are masked while missing retrieval-enhanced tokens remain available;
the prediction residual is initialized to exactly zero.

The protocol 0/3/4 pilot selected epoch 0 in all three cases. Baseline versus
best non-zero-epoch development losses were 0.517315 versus 0.517746 for
protocol 0, 0.527860 versus 0.528012 for protocol 3, and 0.516317 versus
0.517209 for protocol 4. Attention and prediction residuals became non-zero,
but every departure from the foundation worsened development L1 loss. AMUCR
is therefore frozen and excluded from future improvements.

`run_unified_consensus_residual.sh` now requires
`ALLOW_FROZEN_NINTH=1` for exact reproduction. Future work must continue from
the clean first+seventh `_seventh_head_best.pt` checkpoints, not from a
`consensus_amucr` checkpoint. Reproduction outputs use the suffix
`_consensus_amucr_frozen` so they cannot overwrite the completed pilot.

## Frozen failed improvement ten

Improvement ten loads the clean `_seventh_head_best.pt` checkpoint, freezes
the complete first+seventh foundation, and trains only a zero-initialized
four-bit additive missing-tag projection. The tag encodes complete status and
missing text/audio/video status, and shifts the first `fusion_all` hidden
pre-activation without modifying any modality representation.

The protocol 0/3/4 pilot selected epoch 0 in all three cases. Baseline versus
best non-zero-epoch development losses were 0.517315 versus 0.518745 for
protocol 0, 0.527860 versus 0.529631 for protocol 3, and 0.516317 versus
0.517573 for protocol 4. Projection and shift norms grew normally, proving
that the branch trained, but regression performance worsened. Some Acc2/F1
values increased, especially for protocol 4, indicating threshold calibration
rather than improved continuous sentiment prediction. AMTFB is therefore
excluded from the active foundation.

`run_missing_tag_fusion_bias.sh` now requires `ALLOW_FROZEN_TENTH=1` for exact
reproduction. Future work must continue from the clean first+seventh
`_seventh_head_best.pt` checkpoints, not from a `tag_amtfb` checkpoint.
Reproduction outputs use `_tag_amtfb_frozen` and cannot overwrite the pilot.

## Frozen improvement eleven

Improvement eleven is Availability-Guided Cross-Modal Query Retrieval
(AGCQR). It loads the clean `_seventh_head_best.pt` checkpoint and freezes the
entire first+seventh foundation. Complete raw modality representations from a
deterministically sampled subset of the training split form runtime-only
reference banks; validation and test samples are never inserted.

For a missing target modality, lightweight source-to-target mappers use only
observed modalities to produce a target-space query. The query retrieves real
target representations from the train-only bank. A per-target mixing scalar is
initialized to exactly zero, so epoch 0 is bitwise identical to the foundation;
observed targets and protocol 6 remain exact no-op paths at every mix value.
During training, effectively identical bank entries are excluded to prevent a
sample from retrieving its own complete target. Only AGCQR mapper and mixing
parameters are trainable; `fusion_all` remains frozen.

The first pilot should run protocols 0, 3, and 4 with:

```bash
PROTOCOLS="0 3 4" bash run_cross_modal_query_retrieval.sh
```

Outputs use the suffix `_retrieval_agcqr`. The reference bank is intentionally
not stored in checkpoints and is rebuilt deterministically from the training
split when a run starts.

The completed protocol 0/3/4 pilot did not improve the foundation reliably.
Protocol 0 changed only marginally and worsened test metrics, while protocols
3 and 4 selected the exact epoch-0 no-op. AGCQR remains available only for
reproduction and is not part of the active foundation.

## Frozen failed improvement twelve

Improvement twelve is Sentiment-Consistent Same-Sample Bundle Retrieval
(SCBR). It loads the clean `_seventh_head_best.pt` checkpoint and freezes every
foundation parameter. A deterministic subset of complete training views forms
aligned T/A/V banks, and their training labels are retained only as a donor
ranking prior. Validation and test labels are never used by retrieval.

SCBR computes similarity only in the native spaces of observed modalities. A
first frozen foundation pass supplies a continuous sentiment anchor; observable
similarity and donor-label distance rank the bank. The same donor indices then
fill the neighbour slots of every missing modality, preserving A/V pairing for
protocol 0. Raw branches, observed retrieval branches, q0 MMD, and `fusion_all`
remain unchanged.

There are no trainable SCBR parameters. Each run evaluates injection scales
`0,0.1,0.25,0.5,1.0` on the development split, selects the lowest development
MAE, and evaluates the test split only at that selected scale. Scale 0 is the
strict first+seventh baseline and prevents a harmful completion from being
saved as an improvement.

The protocol 0/3/4 pilot completed unusually quickly because SCBR has no
trainable parameters and only performs a small development-scale grid search.
It did not improve the first+seventh foundation reliably, so SCBR is excluded
from future foundations. Its code and run script remain available only for
reproduction.

The completed pilot can be reproduced with:

```bash
PROTOCOLS="0 3 4" bash run_same_sample_bundle_retrieval.sh
```

Outputs use `_retrieval_scbr`. Reference banks are runtime-only and rebuilt
from the training split; the selected scale is stored in the checkpoint.

## Frozen failed improvement thirteen

Improvement thirteen was Training-only Similar Prior Enhancement (TSPE), a
conservative adaptation of the similar-prior idea in FDBG. It loads a clean
`_seventh_head_best.pt` checkpoint, freezes the entire first+seventh feature
foundation, and re-adapts only `fusion_all`.

For each observed pooled modality representation in a training batch, TSPE
selects two other observed samples whose cosine similarity lies in the
configured high-similarity interval. Sentiment-label distance is used only to
rank valid training donors. The selected prior is weakly mixed into the
observed representation with a default ratio of 0.1. Missing modalities are
never changed and cannot act as donors.

TSPE is disabled whenever labels are absent. Development and test calls do not
pass labels, making their representation and prediction paths exactly the
first+seventh model. Epoch 0 is evaluated and saved before adaptation, so an
unsuccessful run cannot replace the foundation with a worse checkpoint.

The protocol 0/3/4 pilot did not produce a reliable gain. The epoch-0
first+seventh development losses were 0.517315, 0.527860, and 0.516317. The
best nonzero-epoch losses were respectively 0.517760 (epoch 3), 0.527949
(epoch 1), and 0.519182 (epoch 10), so all three saved checkpoints correctly
remained at epoch 0. The mechanism was active, but the retrieved visual donors
had large sentiment-label gaps (roughly 0.7--0.9 in the logs), and the
training-only perturbation also introduced a train/evaluation path mismatch.
TSPE is therefore excluded from future foundations and kept only for
reproduction:

```bash
PROTOCOLS="0 3 4" bash run_training_similar_prior_enhancement.sh
```

Outputs use `_prior_tspe`. The default pilot uses similarity interval
`[0.90,0.95]`, `top_k=2`, head learning rate `1e-4`, 40 maximum epochs, and
patience 12.

## Frozen failed improvement fourteen

Improvement fourteen is Availability-Constrained Hybrid Expert Residual
(ACHER), a conservative adaptation of DERL's private/shared Hybrid Expert
Disentanglement idea. It loads a clean `_seventh_head_best.pt` checkpoint and
freezes the complete first+seventh foundation, including `fusion_all`. Only a
new additive expert residual is trained.

Each of the three frozen retrieval-enhanced modality representations is routed
through three modality-private experts and one parameter-shared bank of three
experts. The router sees the modality representation, the frozen sample
representation, and the three-bit availability mask. Private and shared expert
outputs, the sample context, and the same mask feed a small residual prediction
head. Its final layer is initialized to exact zero, so epoch 0 exactly
reproduces the first+seventh prediction and is evaluated and saved before any
optimization.

The auxiliary separation term uses squared cosine similarity between private
and shared outputs. This is intentionally safer than minimizing the paper's
printed raw cosine expression, whose mathematical minimum is anti-parallel
rather than orthogonal. Routing entropy, private/shared probability mass,
per-expert usage, learned temperature, residual magnitude, and separation loss
are logged every epoch. Labels are never inputs to ACHER, so training,
development, and test use the same computation path.

The protocol 0/3/4 pilot did not improve development MAE. Epoch-0 losses were
0.517315, 0.527860, and 0.516317; the best nonzero losses were 0.517451,
0.527866, and 0.516842. All three runs therefore retained epoch 0. Diagnostics
also showed winner-take-all routing: several modalities assigned roughly
0.99 probability to a single expert, while the orthogonality loss collapsed
without improving regression. ACHER is excluded from future foundations and
kept only for reproduction:

```bash
PROTOCOLS="0 3 4" bash run_availability_hybrid_expert_residual.sh
```

Outputs use `_expert_acher`. Defaults are three private plus three shared
experts, expert learning rate `1e-3`, orthogonality weight `0.01`, 40 maximum
epochs, and patience 12. Reconstruction and the paper's broader modality
routing fusion are deliberately omitted because those directions overlap with
earlier unsuccessful IIE experiments.

## Retained improvement fifteen: fixed-protocol fusion re-adaptation

The retained fifteenth improvement is Fixed-Protocol Fusion Re-adaptation
(FPFR). It is explicitly a second training stage after the seventh improvement,
not a new inference-time module. Each clean first+seventh checkpoint is loaded,
the feature foundation remains frozen, and only `fusion_all` is re-adapted with
the corresponding fixed missing protocol. The optimizer is restarted for this
stage. No teacher pass, PCMC loss, or new persistent parameter is used.

Run all seven protocols with:

```bash
bash run_fixed_protocol_fusion_readaptation.sh
```

Outputs use `_fusion_fpfr`. Each saved checkpoint therefore contains the
retained first, seventh, and fifteenth improvements and is the required
foundation for subsequent experiments. Defaults are fusion learning rate
`1e-4`, 40 maximum epochs, and patience 12. Epoch 0 preserves an exact copy of
the first+seventh checkpoint when second-stage re-adaptation does not improve
development MAE.

## Frozen improvement fifteen PCMC audit

Improvement fifteen is Protocol-Conditioned Missing Consistency (PCMC), a
minimal adaptation of SSLMM's weak/strong view consistency. It loads the clean
first+seventh checkpoint, freezes the complete feature foundation, and
re-adapts only `fusion_all`. It introduces no persistent parameters and adds no
inference-time branch.

For every training sample, a complete three-modality pass supplies a
stop-gradient teacher prediction. The student pass uses the exact fixed mask
of the protocol being trained, rather than the paper's random partial sequence
masking. The two scalar regression predictions are converted to polarity
distributions with logits `[-y/T, y/T]`. A teacher-to-student KL term is used
only when the complete-view confidence reaches the configured threshold. The
student still receives the ordinary labeled L1 regression loss.

The complete and missing passes use paired dropout streams. Epoch 0 is
evaluated and saved before re-adaptation, preserving an exact first+seventh
fallback. Logs report confidence coverage, teacher/student prediction gap,
overall polarity disagreement, and high-confidence disagreement. Validation
and test use only the original missing-view inference path.

The first pilot is restricted to protocols 0, 3, and 4:

```bash
PROTOCOLS="0 3 4" bash run_protocol_missing_consistency.sh
```

Outputs use `_consistency_pcmc`. Defaults follow the conservative MOSEI-scale
setting: consistency weight `0.01`, polarity temperature `0.5`, teacher
confidence threshold `0.95`, fusion-head learning rate `1e-4`, 40 maximum
epochs, and patience 12. Development MAE remains the checkpoint-selection
criterion; test classification gains alone are not sufficient.

The key mechanism ablation keeps the same checkpoint, fixed protocol masks,
trainable `fusion_all`, optimizer settings, epoch-0 evaluation, and early
stopping, but sets the PCMC weight to exactly zero:

```bash
PROTOCOLS="0 3 4" bash run_protocol_missing_consistency_ablation.sh
```

The complete-view teacher pass remains active only to preserve matched PCMC
diagnostics; its RNG scope is restored before the student pass and its loss is
multiplied by zero. Ablation logs and checkpoints use the distinct
`_ablation_fusion_head` suffix, so they cannot overwrite `_consistency_pcmc`
artifacts.

The completed zero-weight ablation showed that protocols 3 and 4 retained
nearly all gains without the PCMC term. PCMC is therefore frozen only for
reproduction and is not part of the retained three-improvement foundation.

## Frozen improvement sixteen

Improvement sixteen is Teacher-Advantage-Gated Modality Relation Distillation
(TAG-MRD), a minimal adaptation of HCKD's heterogeneous graph distillation. It
loads the retained first+seventh+FPFR checkpoint, freezes the feature and
retrieval foundation, and trains only `transformer_encoder_all` and
`fusion_all`.

A compact frozen snapshot of the late-fusion Transformer and fusion head
processes detached complete-view representations. The student processes the
fixed missing protocol. Per-sample 3-by-3 cosine relation graphs are built from
the contextualized enhanced language, audio, and visual nodes. Graph alignment
is enabled only where the complete teacher has lower absolute training-label
error than the missing student. The teacher snapshot is training-only, is not
serialized, and adds no inference parameters or branch.

The pilot runs protocols 1, 3, and 4 and includes a mandatory weight-zero
late-fusion control from the same FPFR checkpoint:

```bash
bash run_teacher_advantage_relation_distillation.sh
```

Control outputs use `_ablation_late_fusion`; full outputs use
`_distill_tag_mrd`. Defaults are graph weight `0.01`, advantage margin `0`,
late-fusion Transformer learning rate `2e-5`, fusion-head learning rate `1e-4`,
40 maximum epochs, and patience 12. TAG-MRD is considered effective only if it
beats the matched weight-zero control, not merely the epoch-0 FPFR foundation.

The completed pilot reduced the modality-relation gap but did not beat the
matched late-fusion control on development MAE. TAG-MRD is therefore frozen
for reproduction and is not part of the retained foundation.

## Active improvement seventeen pilot

Improvement seventeen is Label-Semantic Contrastive Missing-Text Residual
(LSCMR), adapted from TCTR's sentiment-aware contrastive supplementation. It
loads the retained first+seventh+FPFR checkpoint and freezes every foundation
parameter, including `transformer_encoder_all` and `fusion_all`. Only the new
missing-text adapter is trainable.

The adapter reads the sample representation and availability-masked audio and
visual raw/enhanced representations. It predicts a residual for the existing
seventh-improvement text branch and injects it only when text is absent. Its
bounded injection scale starts at exact zero, so epoch 0 exactly reproduces
FPFR. During training, a complete-view pass supplies a detached enhanced-text
positive target. Smooth-L1 paired reconstruction and in-batch InfoNCE train
the adapter. Sentiment labels affect only the full variant's negative weights;
labels and complete views are never needed at inference.

The pilot is restricted to text-missing protocols 1, 2, and 5. Protocol 5 is
the default first test. Run the ordinary-InfoNCE control and the matched
label-semantic variant with:

```bash
bash run_label_semantic_missing_text_contrast.sh
```

Control outputs use `_ablation_text_feature_contrast`; full outputs use
`_contrast_lscmr`. Defaults are adapter learning rate `1e-3`, paired loss
weight `0.1`, contrastive loss weight `0.01`, temperature `0.5`, 40 maximum
epochs, and patience 12. LSCMR is attributed to label semantics only when the
full variant beats both the existing FPFR result and the matched feature-only
InfoNCE control.

## One-time export of existing checkpoints

Existing completed head-only checkpoints can be converted without retraining:

```bash
python3 freeze_seventh_checkpoints.py --checkpoint_dir best_modules
```

The source `_ablation_head_only_best.pt` files are preserved. The exporter writes
new `_seventh_head_best.pt` files and refuses to overwrite existing exports unless
`--overwrite` is supplied.

## Frozen failed improvement twenty: layerwise coupled missing prompt

Improvement twenty is Layerwise Coupled Missing Prompt Re-adaptation (LCMPR),
adapted from HyPLe-MKD's deeply coupled soft prompts. It loads the retained
first+seventh+FPFR checkpoint and freezes every foundation parameter, including
`transformer_encoder_all` and `fusion_all`. Only the new
`layerwise_coupled_missing_prompt` module is trainable.

LCMPR operates inside the two-layer flat fusion Transformer. Before each frozen
layer, a length-two prompt bank is selected from the current sample token, the
availability-masked raw-modality summary, and the fixed three-bit availability
mask. The second prompt therefore reads the representation produced by the
first frozen layer. Residuals are applied only to missing enhanced-modality
tokens. Per-layer/per-modality scales start at exact zero, so epoch 0 exactly
reproduces the loaded FPFR checkpoint; complete protocol 6 is always a no-op.

The strict pilot is limited to text-observed protocols 0, 3, and 4. Run the
two-layer candidate with:

```bash
bash run_layerwise_coupled_missing_prompt.sh
```

Set `RUN_SINGLE_LAYER=1` to add the matched depth-one ablation. Full outputs use
`_fusion_lcmpr`; single-layer outputs use `_ablation_lcmpr_single_layer`.
Defaults are prompt length 2, adapter learning rate `1e-3`, hidden dimension 64,
maximum residual scale 0.5, 40 maximum epochs, and patience 12. The ordinary
labeled L1 task loss is the only training objective; no reconstruction,
distillation, CMD extension, or additional fusion-head adaptation is enabled.

The completed protocol-3 run selected epoch 0. The exact FPFR baseline had
development MAE `0.523544`; every trained epoch was worse, reaching `0.527439`
at epoch 12. The two visual residual scales grew to approximately
`-0.1867/+0.1833`, residual norms grew to `0.6601/0.6514`, and the two prompt
attentions collapsed toward opposite slots. This proves that the branch learned
non-trivial corrections but traded worse development MAE and fine-grained
accuracy for higher binary accuracy. LCMPR is therefore frozen as a failed
experiment. Protocols 0 and 4 and the single-layer ablation are not required.

Future improvements must set `coupled_prompt_mode=none` and load the original
per-protocol `_fusion_fpfr_best.pt` checkpoint. The saved protocol-3
`_fusion_lcmpr_best.pt` is only a functionally identical epoch-0 reproduction
artifact and is not part of the active foundation.

The reproduction script is locked by default. It can be run only with an
explicit opt-in:

```bash
ALLOW_FROZEN_TWENTIETH=1 bash run_layerwise_coupled_missing_prompt.sh
```
