"""Development-only pre-registered gate for retaining M3 (FPFR)."""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path

DEFAULT_PROTOCOLS = tuple(str(value) for value in range(7))
DEFAULT_SEEDS = (1111, 2222, 3407, 5576, 7777)


def evaluate_fpfr_gate(
    records,
    protocols=DEFAULT_PROTOCOLS,
    seeds=DEFAULT_SEEDS,
    minimum_global_gain=0.001,
    minimum_positive_protocols=4,
    minimum_positive_seeds=3,
    positive_epsilon=1e-6,
):
    """Evaluate a complete protocol-by-seed M3 development-gain matrix."""
    protocols = tuple(str(value) for value in protocols)
    seeds = tuple(int(value) for value in seeds)
    expected = {(protocol, seed) for protocol in protocols for seed in seeds}
    indexed = {}
    for record in records:
        key = (str(record["protocol"]), int(record["seed"]))
        if key in indexed:
            raise ValueError("Duplicate M3 gate record: {}".format(key))
        indexed[key] = record
    missing = sorted(expected - set(indexed))
    extra = sorted(set(indexed) - expected)
    if missing or extra:
        raise ValueError(
            "Incomplete M3 gate matrix | missing={} | extra={}".format(
                missing, extra
            )
        )

    gains = []
    outcomes = {"improved": 0, "fallback_parent": 0}
    for key in sorted(expected):
        record = indexed[key]
        if record.get("test_metrics_consulted") is not False:
            raise ValueError("E05 gate record is not development-only")
        outcome = record["outcome"]
        if outcome not in outcomes:
            raise ValueError("Unknown adaptation outcome: {}".format(outcome))
        gain = float(record["dev_mae_gain"])
        if gain < -1e-8:
            raise ValueError("M3 selected a development-worse checkpoint")
        if outcome == "fallback_parent" and abs(gain) > 1e-8:
            raise ValueError("Fallback outcome changed development MAE")
        if outcome == "improved" and gain <= 0.0:
            raise ValueError("Improved outcome lacks positive development gain")
        outcomes[outcome] += 1
        gains.append(gain)

    protocol_mean_gains = {
        protocol: sum(
            float(indexed[(protocol, seed)]["dev_mae_gain"])
            for seed in seeds
        ) / len(seeds)
        for protocol in protocols
    }
    seed_mean_gains = {
        str(seed): sum(
            float(indexed[(protocol, seed)]["dev_mae_gain"])
            for protocol in protocols
        ) / len(protocols)
        for seed in seeds
    }
    global_mean_gain = sum(gains) / len(gains)
    positive_protocols = sum(
        gain > positive_epsilon for gain in protocol_mean_gains.values()
    )
    positive_seeds = sum(
        gain > positive_epsilon for gain in seed_mean_gains.values()
    )
    criteria = {
        "global_mean_gain": {
            "value": global_mean_gain,
            "minimum": minimum_global_gain,
            "passed": global_mean_gain >= minimum_global_gain,
        },
        "positive_protocols": {
            "value": positive_protocols,
            "minimum": minimum_positive_protocols,
            "passed": positive_protocols >= minimum_positive_protocols,
        },
        "positive_seeds": {
            "value": positive_seeds,
            "minimum": minimum_positive_seeds,
            "passed": positive_seeds >= minimum_positive_seeds,
        },
        "safety": {
            "value": True,
            "minimum": True,
            "passed": True,
        },
    }
    retained = all(item["passed"] for item in criteria.values())
    return {
        "decision": "retain_M3" if retained else "stop_at_M2",
        "retained": retained,
        "test_metrics_consulted": False,
        "record_count": len(records),
        "protocols": list(protocols),
        "seeds": list(seeds),
        "outcomes": outcomes,
        "global_mean_dev_mae_gain": global_mean_gain,
        "protocol_mean_dev_mae_gain": protocol_mean_gains,
        "seed_mean_dev_mae_gain": seed_mean_gains,
        "criteria": criteria,
    }


def load_m3_gate_records(manifest_dir, dataset):
    """Read only lineage and adaptation-gate fields from complete M3 runs."""
    records = []
    for path in sorted(Path(manifest_dir).glob("*.json")):
        with open(path, "r", encoding="utf-8") as stream:
            manifest = json.load(stream)
        if (
            manifest.get("status") != "complete"
            or manifest.get("method_id") != "M3"
            or manifest.get("dataset") != dataset
        ):
            continue
        lineage = manifest.get("lineage") or {}
        if lineage.get("parent_method_id") != "M2":
            raise ValueError("M3 manifest lacks valid M2 lineage: {}".format(path))
        gate = (manifest.get("result") or {}).get("adaptation_gate")
        if not isinstance(gate, dict):
            raise ValueError("M3 manifest lacks adaptation gate: {}".format(path))
        records.append({
            "run_id": manifest["run_id"],
            "protocol": str(manifest["protocol"]),
            "seed": int(manifest["seed"]),
            "outcome": gate["outcome"],
            "dev_mae_gain": float(gate["dev_mae_gain"]),
            "test_metrics_consulted": gate["test_metrics_consulted"],
        })
    return records


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest_dir",
        type=Path,
        default=Path("paper_experiments/manifests"),
    )
    parser.add_argument("--dataset", choices=("mosei", "mosi"), default="mosei")
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("paper_results/E05_fpfr_gate_mosei.json"),
    )
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError(
            "E05 decision already exists and will not be overwritten: {}"
            .format(args.output)
        )
    records = load_m3_gate_records(args.manifest_dir, args.dataset)
    decision = evaluate_fpfr_gate(records)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    temporary = args.output.with_suffix(args.output.suffix + ".tmp")
    with open(temporary, "w", encoding="utf-8", newline="\n") as stream:
        json.dump(decision, stream, ensure_ascii=False, indent=2, sort_keys=True)
        stream.write("\n")
    os.replace(temporary, args.output)
    print(json.dumps(decision, ensure_ascii=False, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
