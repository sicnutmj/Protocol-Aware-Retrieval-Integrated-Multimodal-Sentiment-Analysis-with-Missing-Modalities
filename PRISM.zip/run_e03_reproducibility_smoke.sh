set -e

if [ "${E03_SMOKE:-0}" != "1" ]; then
  echo "Set E03_SMOKE=1 to run the paired reproducibility smoke test." >&2
  exit 2
fi

SMOKE_ROOT="${SMOKE_ROOT:-tmp/e03_smoke}"
PAIR_ID="$(date +%Y%m%d_%H%M%S)"
mkdir -p \
  "${SMOKE_ROOT}/checkpoints" \
  "${SMOKE_ROOT}/logs" \
  "${SMOKE_ROOT}/manifests"

CUBLAS_WORKSPACE_CONFIG=:4096:8 python3 - <<'PY'
import torch

from IIE_model import DeterministicMaxPool1d

torch.use_deterministic_algorithms(True)
features = torch.randn(4, 8, 16, device="cuda", requires_grad=True)
DeterministicMaxPool1d()(features).sum().backward()
print("E03 CUDA deterministic max-pool backward probe passed")
PY

run_once() {
  REPEAT="$1"
  RUN_ID="E03_SMOKE_R${REPEAT}_M1_mosei_p6_s1111_${PAIR_ID}"
  echo "E03 reproducibility smoke repeat ${REPEAT}: ${RUN_ID}"
  python3 main.py \
    --paper_experiment \
    --paper_run_id="${RUN_ID}" \
    --paper_method_id=M1 \
    --paper_stage_id=E03 \
    --paper_manifest_dir="${SMOKE_ROOT}/manifests" \
    --best_model_dir="${SMOKE_ROOT}/checkpoints" \
    --log_dir="${SMOKE_ROOT}/logs" \
    --retrieval_mode=missing_aware \
    --retrieval_candidate_source=train_bank \
    --retrieval_queue_size=0 \
    --retrieval_metric_mode=raw \
    --retrieval_missing_query=center \
    --retrieval_bank_batch_size=256 \
    --retrieval_bank_refresh_epochs=1 \
    --gate_mode=none \
    --consistency_mode=mixed \
    --fusion_mode=flat \
    --prompt_mode=none \
    --fixed_protocol=6 \
    --learning_rate=2e-5 \
    --d_l=192 \
    --latent_dim=192 \
    --train_batch_size=128 \
    --dev_batch_size=128 \
    --test_batch_size=128 \
    --dataset=mosei \
    --seed=1111 \
    --n_epochs=1 \
    --early_stopping_patience=0
}

run_once 1
run_once 2

python3 - \
  "${SMOKE_ROOT}/manifests/E03_SMOKE_R1_M1_mosei_p6_s1111_${PAIR_ID}.json" \
  "${SMOKE_ROOT}/manifests/E03_SMOKE_R2_M1_mosei_p6_s1111_${PAIR_ID}.json" <<'PY'
import json
import sys

with open(sys.argv[1], "r", encoding="utf-8") as stream:
    first = json.load(stream)
with open(sys.argv[2], "r", encoding="utf-8") as stream:
    second = json.load(stream)

assert first["status"] == second["status"] == "complete"

left = first["result"]
right = second["result"]
for key in (
    "best_epoch",
    "best_loss",
    "development_mae_history",
    "selected_state_sha256",
    "test_mae",
    "test_corr",
    "test_acc7",
    "test_acc5",
    "test_acc2_non_zero",
    "test_f1_non_zero",
    "test_acc2",
    "test_f1",
    "data_provenance",
    "reproducibility",
):
    assert left[key] == right[key], key

assert left["test_evaluation_count"] == 1
assert right["test_evaluation_count"] == 1
print("E03 paired reproducibility verification passed")
print("state_sha256:", left["selected_state_sha256"])
print("checkpoint_file_sha256_repeat_1:",
      first["outputs"]["best_model_sha256"])
print("checkpoint_file_sha256_repeat_2:",
      second["outputs"]["best_model_sha256"])
print("dataset_sha256:", left["data_provenance"]["dataset_sha256"])
PY
