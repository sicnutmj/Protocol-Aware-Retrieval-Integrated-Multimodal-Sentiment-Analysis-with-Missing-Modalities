# IIE: Intra-sample and Intra-modal Enhancement for Multimodal Sentiment Analysis with Missing Modalities
The code for Intra-sample and Intra-modal Enhancement for Multimodal Sentiment Analysis with Missing Modalities, which is accepted by IEEE Transactions on Multimedia ([TMM](https://ieeexplore.ieee.org/document/11303977)). The code is being organized and will be released.

### Prerequisites:
```
* Python 3.8.10
* CUDA 11.5
* pytorch 1.12.1+cu113
* sentence-transformers 3.1.1
* transformers 4.30.2
```
**Note that the torch version can be changed to your cuda version, but please keep the transformers==4.30.2 as some functions will change in later versions**

### Pretrained model:
Downlaod the [BERT-base](https://huggingface.co/google-bert/bert-base-uncased/tree/main) , and put into directory ./BERT-EN/.

### Datasets:
**Please move the following datasets into directory ```./datasets/```**

The aligned CMU-MOSI and CMU-MOSEI datasets can be downloaded from [Baidu Netdisk](https://pan.baidu.com/s/1FW7A-gfbzomKjj_-7ZR8Og?pwd=8xii) with extraction code 8xii, rename the pkl as ```aligned_{dataset}.pkl```. 

### Run IIE
For fixed missing scenarios on MOSI and MOSEI datasets, please run the following code by changing ```--dataset``` in ```run.sh```:
```
bash run.sh
```

Each fixed-missing run uses validation loss for model selection, saves the best
model to `best_modules/`, and writes a timestamped training log to
`train_logs/`. The supplied `run.sh` completes all configured epochs; optional
early stopping can be enabled with:

```
--early_stopping_patience 0
--early_stopping_min_delta 0.0
--best_model_dir best_modules
--log_dir train_logs
```

`--early_stopping_patience 0` disables early stopping. Training still saves the
checkpoint with the lowest validation loss across all configured epochs.

Intra-modal enhancement now uses missing-aware batch retrieval. Missing
placeholders are excluded and neighbours are cosine-similarity weighted. The
main configuration does not use a cross-batch memory queue:

```
--retrieval_mode missing_aware
--retrieval_top_k 2
--retrieval_queue_size 0
--retrieval_temperature 0.1
--gate_mode none
```

This is the frozen first-improvement baseline used by the active `run.sh`,
which runs all seven fixed missing-modality protocols with their original
protocol-specific batch sizes and representation dimensions. It writes the
original q0-style name, for example
`iie_mosei_protocol_0_missing_aware_q0`, and does not instantiate or optimize
any reliability gate.

## Frozen ablation: HMRF-inspired paired hierarchical distillation

This experiment was screened on L, V, and A+V and did not improve the frozen
q0 baseline consistently, with a clear degradation on the V protocol. It is
therefore retained only as a failed ablation and must not be used by the active
baseline. The implementation aligns the incomplete representation with the
complete view of the same sample at two levels: `eh_sample` and the final
seven-branch fusion representation. The complete teacher is detached, shares
the student's dropout masks without advancing its RNG stream, and is not used
during validation or testing.

For historical reproduction only, run:

```bash
bash run_hmrf_distill.sh
```

The script uses:

```text
--distill_mode paired_hierarchical
--distill_sample_weight 0.05
--distill_fusion_weight 0.05
```

Outputs use the `distill_phd` tag and therefore do not overwrite frozen q0
logs or checkpoints. `--distill_mode none` remains the default, and the active
`run.sh` does not pass any distillation argument.

## Read-only PNS branch audit

`run_pns_audit.sh` loads the seven frozen q0 checkpoints and measures the
necessity and sufficiency of each enhanced branch (`eh_l`, `eh_a`, `eh_v`). It
does not train, update, or save model parameters. For every branch it compares
the factual prediction with branch removal, and compares an enhancement-null
prediction with adding only that branch. Both continuous MAE margins and the
paper-style thresholded PNS event rates are logged.

The audit is optional and can be deferred without affecting any subsequent
experiment. When evidence is needed, run:

```bash
bash run_pns_audit.sh
```

Audit logs use the `audit_pns` tag and do not overwrite q0 outputs. The active
training path keeps `--pns_audit` disabled by default.

The unsuccessful fourth-improvement Stage A remains frozen for reproducibility.
It can be re-enabled explicitly without changing the q0 path:

```
--retrieval_metric_mode sentiment_guided
--retrieval_projection_dim 64
--retrieval_missing_query center
--retrieval_label_temperature 0.5
--retrieval_loss_weight 0.1
```

The KL target is built only from continuous training labels. Development and
test retrieval never receives labels; test labels are consulted only after
Top-K selection to log mean neighbour-label distance and same-polarity ratio.
Stage B is already available by changing
`--retrieval_missing_query sample`; it predicts each missing-modality query
from `eh_sample`. Use `--retrieval_metric_mode raw --retrieval_missing_query
center` to recover the exact q0 retrieval path. The original mixed MMD remains
enabled in all of these configurations unless `--consistency_mode` is changed.

Set `--retrieval_queue_size 2048` to reproduce the optional memory-queue
ablation. The queue is updated only during training.
Set `--retrieval_mode legacy` to reproduce the original IIE hard Top-K
retrieval, which does not filter missing placeholders.

The quality-aware reliability gate (Gate-V2) conservatively calibrates only the
three retrieved intra-modal enhancements. Observed raw representations bypass
the gate, and missing raw representations remain hard-masked. Gate-V2 uses
explicit sample-level quality signals: agreement with the sample representation,
normalized representation difference, Top-K confidence, valid-neighbour ratio,
retrieval support ratio, neighbour dispersion, and modality availability. Its
shared MLP cannot amplify an enhancement; multipliers remain in `[0.7, 1.0]`.

The archived Gate-V2.4 diagnostic ablation removes the learned gate entirely and
multiplies all three enhanced branches by the same constant:

```
--gate_mode fixed_scale_ablation
--gate_min_scale 0.7
--gate_fixed_scale 0.85
```

This mode has no gate parameters, counterfactual teacher, warm-up, or auxiliary
loss. The complete q0 raw path is left untouched, so its only difference from
q0 is the uniform `0.85` enhanced-branch multiplier. It uses the
`gate_fixed_s085` output tag when selected explicitly.

Gate-V2.4 itself remains available with:

```
--gate_mode counterfactual_scale_v24
--gate_hidden_dim 32
--gate_min_scale 0.7
--gate_init_scale 0.98
--gate_teacher_mid_scale 0.85
--gate_scale_loss_beta 0.05
--gate_max_residual_logit 8.0
--gate_init_seed 3407
--gate_lr_multiplier 10.0
--gate_scale_loss_weight 1.0
--gate_scale_warmup_epochs 5
```

Set `--gate_mode none` for the frozen Missing-Aware q0 result. V2.4 writes
outputs with the `gate_cfsg_v24` tag and uses an action-aligned counterfactual teacher. For
each enhanced branch it evaluates scales `1.0`, `0.85`, and `0.7`, then directly
regresses the scale with the lowest sample-level absolute error. The gate is
decomposed into an explicit `modality x availability` prior plus a bounded,
shared sample-quality residual. The task-loss path into the gate remains
detached. Training and development logs report scale-choice frequencies and
within-group target/prediction means, standard deviations, and correlations;
these diagnostics expose a gate that has collapsed to fixed group scaling.
Supervision starts after five warm-up epochs.

Gate-V2.3 remains available as `--gate_mode counterfactual_harm_v23` with the
`gate_cfhg_v23` tag and its original `--gate_cf_*` arguments. It uses the
archived branch-removal harm-classification objective.

Gate-V2.2 remains available as `--gate_mode quality_reliability_v22` with the
`gate_qrg_v22` tag, and Gate-V2.1 remains available as
`--gate_mode quality_reliability` with the `gate_qrg_v21` tag. All quality gates
are created only after Hugging Face pretrained loading finishes and validate
their configured initial multiplier. The
gate is initialized after the q0 backbone under an isolated RNG state, so its
construction does not alter baseline parameter initialization. Test logs report
the reliability/multiplier mean, standard deviation and range, plus correlations
between reliability and the explicit quality signals.

The archived six-branch Gate-V1 remains available as
`--gate_mode reliability_v1` (or the backward-compatible alias
`--gate_mode reliability`). To reproduce its original configuration, also pass
`--gate_hidden_dim 96 --gate_dropout 0.1 --gate_max_adjustment 0.5`.

### Citation:
Please cite our paper if you find our work useful for your research:
```
@article{zhuang2026iie,
  author={Zhuang, Yan and Zhang, Yanru and Deng, Jiawen and Ren, Fuji},
  journal={IEEE Transactions on Multimedia}, 
  title={Intra-Sample and Intra-Modal Enhancement for Multimodal Sentiment Analysis With Missing Modalities}, 
  year={2026},
  volume={28},
  number={},
  pages={1847-1859},
  doi={10.1109/TMM.2025.3645559}}
```

### Acknowledgement
Thanks to [MIB](https://github.com/TmacMai/Multimodal-Information-Bottleneck), [MAG](https://github.com/WasifurRahman/BERT_multimodal_transformer), [MCL](https://github.com/TmacMai/Multimodal-Correlation-Learning), [HKT](https://github.com/matalvepu/HKT), [LFMIM](https://github.com/sunjunaimer/LFMIM) and [GCNet](https://github.com/zeroQiaoba/GCNet) for their great help to our codes and research. 
