"""Execute and audit the formal E13 fusion-adaptation ablation."""

from __future__ import annotations

import argparse
import json
import math
import os
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path

from paper_experiment import code_fingerprints, resolve_dataset_path, sha256_file
from run_e06_mosei_primary import METRICS, PROTOCOL_SETTINGS, write_immutable_json


DATASET = "mosei"
PROTOCOLS = tuple(str(value) for value in range(7))
SEEDS = (1111, 2222, 3407, 5576, 7777)
ARMS = ("D0", "D1", "D2", "D3", "D4")
NEW_METHODS = {
    "D1": {"method": "E13L", "scope": "last_layer"},
    "D3": {"method": "E13T", "scope": "late_transformer_fusion"},
}
REFERENCE_METHODS = {"D0": "M1", "D2": "M2", "D4": "M3"}
EFFECTS = {
    "last_layer_adaptation": ("D0", "D1"),
    "full_fusion_adaptation": ("D0", "D2"),
    "full_fusion_over_last_layer": ("D1", "D2"),
    "late_transformer_expansion": ("D2", "D3"),
    "second_stage_adaptation": ("D2", "D4"),
}
SPLIT_SIZES = {"train": 16326, "dev": 1871, "test": 4659}
REPORT_METRICS = ("best_dev_mae",) + METRICS
LOWER_IS_BETTER = frozenset(("best_dev_mae", "test_mae"))
UNCHANGED_CORE_FILES = ("utils.py", "latent_transformer.py")


@dataclass(frozen=True)
class RunSpec:
    arm: str
    method: str
    scope: str
    protocol: str
    seed: int
    run_id: str
    parent_run_id: str


def build_matrix(protocols=PROTOCOLS, seeds=SEEDS, arms=tuple(NEW_METHODS)):
    protocols = tuple(str(value) for value in protocols)
    seeds = tuple(int(value) for value in seeds)
    arms = tuple(arms)
    unknown_protocols = sorted(set(protocols) - set(PROTOCOLS))
    unknown_seeds = sorted(set(seeds) - set(SEEDS))
    unknown_arms = sorted(set(arms) - set(NEW_METHODS))
    if unknown_protocols or unknown_seeds or unknown_arms:
        raise ValueError(
            "Unknown E13 selection | protocols={} | seeds={} | arms={}"
            .format(unknown_protocols, unknown_seeds, unknown_arms)
        )
    ordered_arms = tuple(arm for arm in NEW_METHODS if arm in arms)
    return [
        RunSpec(
            arm=arm,
            method=NEW_METHODS[arm]["method"],
            scope=NEW_METHODS[arm]["scope"],
            protocol=protocol,
            seed=seed,
            run_id="E13_{}_mosei_p{}_s{}".format(
                NEW_METHODS[arm]["method"], protocol, seed
            ),
            parent_run_id="E06R1_M1_mosei_p{}_s{}".format(protocol, seed),
        )
        for seed in seeds for protocol in protocols for arm in ordered_arms
    ]


def _manifest_path(workspace, run_id):
    return workspace / "paper_experiments" / "manifests" / (run_id + ".json")


def _read_json(path):
    with open(path, "r", encoding="utf-8") as stream:
        return json.load(stream)


def reference_run_id(arm, protocol, seed):
    if arm not in REFERENCE_METHODS:
        raise ValueError("E13 arm {} is not a reused reference".format(arm))
    return "E06R1_{}_mosei_p{}_s{}".format(
        REFERENCE_METHODS[arm], protocol, seed
    )


def _parent_checkpoint(workspace, spec):
    path = _manifest_path(workspace, spec.parent_run_id)
    if not path.is_file():
        raise FileNotFoundError("E13 parent manifest is missing: {}".format(path))
    manifest = _read_json(path)
    expected = {
        "status": "complete", "run_id": spec.parent_run_id,
        "method_id": "M1", "dataset": DATASET,
        "protocol": spec.protocol, "seed": spec.seed,
    }
    mismatches = {
        key: (value, manifest.get(key)) for key, value in expected.items()
        if manifest.get(key) != value
    }
    if mismatches:
        raise RuntimeError("E13 parent mismatch: {}".format(mismatches))
    outputs = manifest.get("outputs") or {}
    checkpoint = Path(outputs.get("best_model_path", ""))
    if not checkpoint.is_file():
        raise FileNotFoundError("E13 parent checkpoint is missing: {}".format(checkpoint))
    if sha256_file(checkpoint) != outputs.get("best_model_sha256"):
        raise RuntimeError("E13 parent checkpoint SHA256 mismatch")
    return checkpoint.resolve()


def command_for_spec(workspace, spec, resolve_parent=True):
    settings = PROTOCOL_SETTINGS[spec.protocol]
    checkpoint = (
        _parent_checkpoint(workspace, spec)
        if resolve_parent else Path("<PARENT_CHECKPOINT>")
    )
    return [
        sys.executable, "main.py", "--paper_experiment",
        "--paper_run_id={}".format(spec.run_id),
        "--paper_method_id={}".format(spec.method),
        "--paper_stage_id=E13",
        "--paper_manifest_dir=paper_experiments/manifests",
        "--paper_parent_run_id={}".format(spec.parent_run_id),
        "--model_path={}".format(checkpoint), "--load=1",
        "--dataset=mosei", "--fixed_protocol={}".format(spec.protocol),
        "--seed={}".format(spec.seed),
        "--train_batch_size={}".format(settings["train_batch_size"]),
        "--dev_batch_size=128", "--test_batch_size=128",
        "--d_l={}".format(settings["representation_dim"]),
        "--latent_dim={}".format(settings["representation_dim"]),
        "--layers={}".format(settings["layers"]),
        "--latent_layers={}".format(settings["latent_layers"]),
        "--missing_rate={}".format(settings["missing_rate"]),
        "--weight_decay=1e-4", "--retrieval_mode=missing_aware",
        "--retrieval_candidate_source=train_bank",
        "--retrieval_candidate_filter=observed_only",
        "--retrieval_composition=prototype_neighbours",
        "--retrieval_selection=similarity", "--retrieval_random_seed=3407",
        "--retrieval_queue_size=0", "--retrieval_metric_mode=raw",
        "--retrieval_missing_query=center", "--retrieval_bank_batch_size=256",
        "--retrieval_bank_refresh_epochs=1", "--gate_mode=none",
        "--consistency_mode=mixed", "--distill_mode=none",
        "--fusion_mode=flat", "--prompt_mode=none",
        "--reconstruction_mode=none", "--consensus_mode=none",
        "--tag_mode=none", "--cross_modal_retrieval_mode=none",
        "--training_prior_mode=none", "--hybrid_expert_mode=none",
        "--protocol_consistency_mode=none", "--relation_distill_mode=none",
        "--missing_text_contrast_mode=none",
        "--privileged_purification_mode=none", "--language_hyper_mode=none",
        "--coupled_prompt_mode=none", "--early_stopping_min_delta=0.0",
        "--protocol_fusion_readaptation",
        "--protocol_adaptation_scope={}".format(spec.scope),
        "--protocol_fusion_learning_rate=1e-4",
        "--protocol_transformer_learning_rate=2e-5",
        "--learning_rate=1e-4", "--n_epochs=40",
        "--early_stopping_patience=12",
    ]


def _validate_result(manifest, label, adaptation=True):
    result = manifest.get("result") or {}
    if result.get("test_evaluation_count") != 1:
        raise RuntimeError("{} must evaluate test exactly once".format(label))
    if result.get("selection_split") != "development":
        raise RuntimeError("{} was not selected on development".format(label))
    if result.get("selection_metric") != "mae":
        raise RuntimeError("{} selection metric is not MAE".format(label))
    for key in ("best_loss",) + METRICS:
        value = result.get(key)
        if not isinstance(value, (int, float)) or not math.isfinite(value):
            raise RuntimeError("{} lacks finite {}".format(label, key))
    provenance = result.get("data_provenance") or {}
    if provenance.get("split_sizes") != SPLIT_SIZES:
        raise RuntimeError("{} has wrong MOSEI split sizes".format(label))
    if provenance.get("fixed_protocol") != str(manifest.get("protocol")):
        raise RuntimeError("{} has wrong protocol provenance".format(label))
    if not provenance.get("dataset_sha256"):
        raise RuntimeError("{} lacks dataset SHA256".format(label))
    if adaptation:
        gate = result.get("adaptation_gate") or {}
        if gate.get("outcome") not in ("improved", "fallback_parent"):
            raise RuntimeError("{} lacks a valid adaptation gate".format(label))
        if gate.get("test_metrics_consulted") is not False:
            raise RuntimeError("{} adaptation gate consulted test".format(label))
    return result


def _verify_checkpoint(manifest, label, verify_checkpoint):
    outputs = manifest.get("outputs") or {}
    checkpoint = Path(outputs.get("best_model_path", ""))
    if verify_checkpoint:
        if not checkpoint.is_file():
            raise FileNotFoundError("{} checkpoint is missing: {}".format(label, checkpoint))
        if sha256_file(checkpoint) != outputs.get("best_model_sha256"):
            raise RuntimeError("{} checkpoint SHA256 mismatch".format(label))
    elif not outputs.get("best_model_sha256"):
        raise RuntimeError("{} lacks checkpoint SHA256".format(label))


def _validate_new_manifest(workspace, spec, verify_checkpoint=True):
    path = _manifest_path(workspace, spec.run_id)
    if not path.is_file():
        return None
    manifest = _read_json(path)
    if manifest.get("status") != "complete":
        raise RuntimeError(
            "E13 run id exists with status {!r}; inspect it and do not "
            "overwrite it: {}".format(manifest.get("status"), path)
        )
    expected = {
        "run_id": spec.run_id, "method_id": spec.method,
        "stage_id": "E13", "dataset": DATASET,
        "protocol": spec.protocol, "seed": spec.seed,
    }
    mismatches = {
        key: (value, manifest.get(key)) for key, value in expected.items()
        if manifest.get(key) != value
    }
    if mismatches:
        raise RuntimeError("E13 new-run identity mismatch: {}".format(mismatches))
    lineage = manifest.get("lineage") or {}
    if lineage.get("parent_run_id") != spec.parent_run_id:
        raise RuntimeError("E13 new-run parent mismatch")
    if lineage.get("parent_method_id") != "M1":
        raise RuntimeError("E13 new-run parent method mismatch")
    args = manifest.get("arguments") or {}
    expected_args = {
        "retrieval_mode": "missing_aware",
        "retrieval_candidate_source": "train_bank",
        "retrieval_candidate_filter": "observed_only",
        "retrieval_composition": "prototype_neighbours",
        "retrieval_selection": "similarity",
        "retrieval_queue_size": 0,
        "protocol_fusion_readaptation": True,
        "protocol_adaptation_scope": spec.scope,
        "protocol_fusion_learning_rate": 1e-4,
        "protocol_transformer_learning_rate": 2e-5,
        "load": 1,
    }
    for name, value in expected_args.items():
        if args.get(name) != value:
            raise RuntimeError("E13 {} argument mismatch".format(name))
    _validate_result(manifest, spec.run_id, adaptation=True)
    _verify_checkpoint(manifest, spec.run_id, verify_checkpoint)
    return manifest


def _arg_default(arguments, name, default):
    return arguments[name] if name in arguments else default


def _validate_reference_manifest(
    workspace, arm, protocol, seed, dataset_sha, verify_checkpoint=True
):
    run_id = reference_run_id(arm, protocol, seed)
    path = _manifest_path(workspace, run_id)
    if not path.is_file():
        raise FileNotFoundError("E13 reference manifest is missing: {}".format(path))
    manifest = _read_json(path)
    expected = {
        "status": "complete", "run_id": run_id,
        "method_id": REFERENCE_METHODS[arm], "dataset": DATASET,
        "protocol": protocol, "seed": seed,
    }
    mismatches = {
        key: (value, manifest.get(key)) for key, value in expected.items()
        if manifest.get(key) != value
    }
    if mismatches:
        raise RuntimeError("E13 reference identity mismatch: {}".format(mismatches))
    expected_parent = {"D0": None, "D2": "M1", "D4": "M2"}[arm]
    lineage = manifest.get("lineage")
    if expected_parent is None:
        if lineage is not None:
            raise RuntimeError("E13 M1 reference unexpectedly has lineage")
    elif not lineage or lineage.get("parent_method_id") != expected_parent:
        raise RuntimeError("E13 reference lineage mismatch")
    args = manifest.get("arguments") or {}
    if args.get("retrieval_mode") != "missing_aware":
        raise RuntimeError("E13 reference is not missing-aware")
    if args.get("retrieval_candidate_source") != "train_bank":
        raise RuntimeError("E13 reference does not use the training bank")
    if _arg_default(args, "protocol_adaptation_scope", "fusion_all") != "fusion_all":
        raise RuntimeError("E13 reference adaptation scope mismatch")
    expected_adaptation = arm in ("D2", "D4")
    if args.get("protocol_fusion_readaptation") is not expected_adaptation:
        raise RuntimeError("E13 reference adaptation flag mismatch")
    result = _validate_result(manifest, run_id, adaptation=expected_adaptation)
    if result["data_provenance"]["dataset_sha256"] != dataset_sha:
        raise RuntimeError("E13 reference dataset SHA256 mismatch")
    _verify_checkpoint(manifest, run_id, verify_checkpoint)
    return manifest


def _manifest_hashes(manifest, names):
    fingerprints = manifest.get("code_sha256") or {}
    missing = [name for name in names if name not in fingerprints]
    if missing:
        raise RuntimeError("E13 manifest lacks code hashes: {}".format(missing))
    return {name: fingerprints[name] for name in names}


def _validate_e05_decision(workspace):
    path = workspace / "paper_results" / "E05_fpfr_gate_mosei.json"
    if not path.is_file():
        raise FileNotFoundError("E13 requires the frozen E05 decision: {}".format(path))
    decision = _read_json(path)
    if decision.get("decision") != "stop_at_M2" or decision.get("retained") is not False:
        raise RuntimeError("E13 frozen E05 decision mismatch")
    if decision.get("record_count") != 35:
        raise RuntimeError("E13 frozen E05 record count mismatch")
    return {"path": str(path.resolve()), "sha256": sha256_file(path), "decision": "stop_at_M2"}


def preflight_references(workspace, protocols, seeds):
    dataset_sha = sha256_file(resolve_dataset_path(workspace, DATASET))
    e05 = _validate_e05_decision(workspace)
    current_unchanged = {
        name: sha256_file(workspace / name) for name in UNCHANGED_CORE_FILES
    }
    old_unchanged = None
    checked = []
    for seed in seeds:
        for protocol in protocols:
            for arm in ("D0", "D2", "D4"):
                manifest = _validate_reference_manifest(
                    workspace, arm, protocol, seed, dataset_sha
                )
                hashes = _manifest_hashes(manifest, UNCHANGED_CORE_FILES)
                if old_unchanged is None:
                    old_unchanged = hashes
                elif hashes != old_unchanged:
                    raise RuntimeError("E13 references mix unchanged-core hashes")
                if hashes != current_unchanged:
                    raise RuntimeError("E13 unchanged model core drifted")
                checked.append(manifest["run_id"])
    print("E13 reference preflight verified | records={}".format(len(checked)))
    return {
        "reference_count": len(checked), "dataset_sha256": dataset_sha,
        "unchanged_core_sha256": current_unchanged,
        "frozen_E05_decision": e05,
    }


def _record(arm, manifest, reused):
    result = manifest["result"]
    item = {
        "arm": arm, "protocol": manifest["protocol"], "seed": manifest["seed"],
        "source_stage": manifest["stage_id"], "source_run_id": manifest["run_id"],
        "reused_reference": bool(reused), "best_epoch": result["best_epoch"],
        "best_dev_mae": result["best_loss"],
    }
    item.update({metric: result[metric] for metric in METRICS})
    if arm != "D0":
        item["adaptation_outcome"] = result["adaptation_gate"]["outcome"]
    return item


def _gain(metric, baseline, candidate):
    return (
        float(baseline) - float(candidate)
        if metric in LOWER_IS_BETTER
        else float(candidate) - float(baseline)
    )


def summarize_effects(records, protocols, seeds):
    indexed = {(r["protocol"], r["seed"], r["arm"]): r for r in records}
    output = {}
    for effect, (baseline_arm, candidate_arm) in EFFECTS.items():
        pairs = []
        for seed in seeds:
            for protocol in protocols:
                baseline = indexed.get((protocol, seed, baseline_arm))
                candidate = indexed.get((protocol, seed, candidate_arm))
                if baseline is None or candidate is None:
                    continue
                pairs.append({
                    "protocol": protocol, "seed": seed,
                    "baseline_arm": baseline_arm, "candidate_arm": candidate_arm,
                    "gains": {
                        metric: _gain(metric, baseline[metric], candidate[metric])
                        for metric in REPORT_METRICS
                    },
                })
        summary = {}
        for metric in REPORT_METRICS:
            values = [pair["gains"][metric] for pair in pairs]
            summary[metric] = {
                "count": len(values),
                "mean_gain": sum(values) / len(values) if values else None,
                "wins": sum(value > 1e-12 for value in values),
                "ties": sum(abs(value) <= 1e-12 for value in values),
                "losses": sum(value < -1e-12 for value in values),
            }
        output[effect] = {
            "baseline_arm": baseline_arm, "candidate_arm": candidate_arm,
            "gain_definition": "positive_always_favors_candidate",
            "summary": summary, "pairs": pairs,
        }
    return output


def audit_matrix(workspace, specs, require_complete=True, perform_preflight=True):
    protocols = tuple(dict.fromkeys(spec.protocol for spec in specs))
    seeds = tuple(dict.fromkeys(spec.seed for spec in specs))
    records, missing_new, missing_reference = [], [], []
    new_code, dataset_sha = None, None
    for spec in specs:
        manifest = _validate_new_manifest(workspace, spec)
        if manifest is None:
            missing_new.append(spec.run_id)
            continue
        if new_code is None:
            new_code = manifest.get("code_sha256")
        elif new_code != manifest.get("code_sha256"):
            raise RuntimeError("E13 new runs mix code fingerprints")
        current_data = manifest["result"]["data_provenance"]["dataset_sha256"]
        if dataset_sha is None:
            dataset_sha = current_data
        elif dataset_sha != current_data:
            raise RuntimeError("E13 new runs mix MOSEI files")
        records.append(_record(spec.arm, manifest, reused=False))
    if dataset_sha is None:
        dataset_sha = sha256_file(resolve_dataset_path(workspace, DATASET))
    for seed in seeds:
        for protocol in protocols:
            for arm in ("D0", "D2", "D4"):
                run_id = reference_run_id(arm, protocol, seed)
                try:
                    manifest = _validate_reference_manifest(
                        workspace, arm, protocol, seed, dataset_sha
                    )
                except FileNotFoundError:
                    missing_reference.append(run_id)
                    continue
                records.append(_record(arm, manifest, reused=True))
    if require_complete and (missing_new or missing_reference):
        raise RuntimeError(
            "Incomplete E13 ablation | missing_new={} first_new={} | "
            "missing_reference={} first_reference={}".format(
                len(missing_new), missing_new[:5],
                len(missing_reference), missing_reference[:5],
            )
        )
    records.sort(key=lambda item: (
        seeds.index(int(item["seed"])), protocols.index(str(item["protocol"])),
        ARMS.index(item["arm"]),
    ))
    preflight = None
    if require_complete and perform_preflight:
        preflight = preflight_references(workspace, protocols, seeds)
    outcomes = {}
    for arm in ARMS[1:]:
        selected = [r for r in records if r["arm"] == arm]
        outcomes[arm] = {
            "improved": sum(r.get("adaptation_outcome") == "improved" for r in selected),
            "fallback_parent": sum(r.get("adaptation_outcome") == "fallback_parent" for r in selected),
        }
    return {
        "schema_version": 1, "stage_id": "E13", "dataset": DATASET,
        "purpose": "fusion adaptation scope and stage ablation",
        "protocols": list(protocols), "seeds": list(seeds), "arms": list(ARMS),
        "expected_new_run_count": len(specs),
        "completed_new_run_count": len(specs) - len(missing_new),
        "expected_reused_reference_count": len(protocols) * len(seeds) * 3,
        "completed_reused_reference_count": len(protocols) * len(seeds) * 3 - len(missing_reference),
        "expected_total_ablation_cells": len(protocols) * len(seeds) * 5,
        "completed_total_ablation_cells": len(records),
        "missing_new_run_ids": missing_new,
        "missing_reference_run_ids": missing_reference,
        "dataset_sha256": dataset_sha, "new_run_code_sha256": new_code,
        "reference_preflight": preflight,
        "selection_split": "development", "selection_metric": "mae",
        "test_evaluation_count_per_new_run": 1,
        "test_metrics_consulted_for_training_or_selection": False,
        "checklist_aliases": {
            "full_fusion_all": "D2", "one_stage": "D2",
            "per_protocol_independent": "D2", "two_stage": "D4",
        },
        "shared_model_control_deferred_for_common_root": True,
        "adaptation_outcomes": outcomes,
        "effects": summarize_effects(records, protocols, seeds),
        "records": records,
    }


def execute_matrix(workspace, specs):
    protocols = tuple(dict.fromkeys(spec.protocol for spec in specs))
    seeds = tuple(dict.fromkeys(spec.seed for spec in specs))
    preflight_references(workspace, protocols, seeds)
    completed_manifests = []
    for spec in specs:
        manifest = _validate_new_manifest(workspace, spec)
        if manifest is not None:
            completed_manifests.append(manifest)
    if completed_manifests:
        expected_code = code_fingerprints(workspace)
        expected_data = sha256_file(resolve_dataset_path(workspace, DATASET))
        for manifest in completed_manifests:
            if manifest.get("code_sha256") != expected_code:
                raise RuntimeError("E13 resume refused because code changed")
            actual = manifest["result"]["data_provenance"]["dataset_sha256"]
            if actual != expected_data:
                raise RuntimeError("E13 resume refused because MOSEI changed")
    environment = os.environ.copy()
    environment["CUBLAS_WORKSPACE_CONFIG"] = ":4096:8"
    completed = skipped = 0
    for index, spec in enumerate(specs, start=1):
        if _validate_new_manifest(workspace, spec) is not None:
            skipped += 1
            print("[{}/{}] SKIP complete {}".format(index, len(specs), spec.run_id))
            continue
        print("[{}/{}] RUN {}".format(index, len(specs), spec.run_id), flush=True)
        subprocess.check_call(command_for_spec(workspace, spec), cwd=str(workspace), env=environment)
        _validate_new_manifest(workspace, spec)
        subprocess.check_call(
            [sys.executable, "refresh_paper_registry.py", "--workspace", "."],
            cwd=str(workspace), env=environment,
        )
        completed += 1
    print("E13 execution finished | new={} | skipped={}".format(completed, skipped))


def _csv_values(value, cast):
    return tuple(cast(item.strip()) for item in value.split(",") if item.strip())


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--workspace", type=Path, default=Path("."))
    parser.add_argument("--protocols", default=",".join(PROTOCOLS))
    parser.add_argument("--seeds", default=",".join(str(seed) for seed in SEEDS))
    parser.add_argument("--arms", default=",".join(NEW_METHODS))
    parser.add_argument("--execute", action="store_true")
    parser.add_argument("--audit", action="store_true")
    parser.add_argument(
        "--audit_output", type=Path,
        default=Path("paper_results/E13_fusion_adaptation_audit.json"),
    )
    return parser.parse_args()


def main():
    args = parse_args()
    workspace = args.workspace.resolve()
    specs = build_matrix(
        _csv_values(args.protocols, str), _csv_values(args.seeds, int),
        _csv_values(args.arms, str),
    )
    if not args.execute and not args.audit:
        cells = len(set((spec.protocol, spec.seed) for spec in specs))
        print(
            "E13 dry-run plan | new_runs={} | reused_reference_records={} | "
            "total_ablation_cells={}".format(len(specs), cells * 3, cells * 5)
        )
        for spec in specs:
            refs = [reference_run_id(arm, spec.protocol, spec.seed) for arm in ("D0", "D2", "D4")]
            print("{} | arm={} | references={} | {}".format(
                spec.run_id, spec.arm, ",".join(refs),
                " ".join(command_for_spec(workspace, spec, resolve_parent=False)),
            ))
        return
    if args.execute:
        if os.environ.get("E13_EXECUTE") != "1":
            raise RuntimeError("Set E13_EXECUTE=1 to authorize the formal 70-run matrix")
        execute_matrix(workspace, specs)
    if args.audit:
        summary = audit_matrix(workspace, specs, require_complete=True)
        output = args.audit_output
        if not output.is_absolute():
            output = workspace / output
        write_immutable_json(output, summary)
        print("E13 audit verified: {}".format(output))


if __name__ == "__main__":
    main()
