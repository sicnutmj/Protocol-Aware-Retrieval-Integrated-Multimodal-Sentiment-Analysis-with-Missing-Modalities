set -e

FPFR_CHECKPOINT_DIR="${FPFR_CHECKPOINT_DIR:-best_modules}"
PROTOCOLS="${PROTOCOLS:-1 3 4}"
RUN_CONTROL="${RUN_CONTROL:-1}"
RUN_FULL="${RUN_FULL:-1}"
GRAPH_WEIGHT="${GRAPH_WEIGHT:-0.01}"
ADVANTAGE_MARGIN="${ADVANTAGE_MARGIN:-0.0}"
TRANSFORMER_LR="${TRANSFORMER_LR:-2e-5}"
FUSION_LR="${FUSION_LR:-1e-4}"

TAG_MRD_ARGS=(
  --retrieval_mode=missing_aware
  --retrieval_queue_size=0
  --retrieval_metric_mode=raw
  --retrieval_missing_query=center
  --gate_mode=none
  --consistency_mode=mixed
  --distill_mode=none
  --fusion_mode=flat
  --prompt_mode=none
  --reconstruction_mode=none
  --consensus_mode=none
  --tag_mode=none
  --cross_modal_retrieval_mode=none
  --training_prior_mode=none
  --hybrid_expert_mode=none
  --protocol_consistency_mode=none
  --relation_distill_mode=tag_mrd
  --relation_distill_advantage_margin="${ADVANTAGE_MARGIN}"
  --relation_distill_transformer_learning_rate="${TRANSFORMER_LR}"
  --relation_distill_fusion_learning_rate="${FUSION_LR}"
  --load=1
  --n_epochs=40
  --early_stopping_patience=12
  --early_stopping_min_delta=0.0
)

echo "Improvement 16 pilot: teacher-advantage-gated modality relation distillation (TAG-MRD)"
echo "Foundation: first + seventh + FPFR"
echo "Checkpoint directory: ${FPFR_CHECKPOINT_DIR}"
echo "Protocols: ${PROTOCOLS}"
echo "Runs: late-fusion control=${RUN_CONTROL}; TAG-MRD full=${RUN_FULL}"
echo "Graph weight=${GRAPH_WEIGHT}; advantage margin=${ADVANTAGE_MARGIN}"
echo "Transformer LR=${TRANSFORMER_LR}; fusion LR=${FUSION_LR}"

run_protocol() {
  local protocol="$1"
  local train_batch_size="$2"
  local representation_dim="$3"
  local description="$4"
  shift 4
  local extra_args=("$@")

  local checkpoint="${FPFR_CHECKPOINT_DIR}/iie_mosei_protocol_${protocol}_missing_aware_q0_fusion_fpfr_best.pt"
  if [ ! -s "${checkpoint}" ]; then
    echo "Missing first+seventh+FPFR checkpoint: ${checkpoint}" >&2
    exit 1
  fi

  run_variant() {
    local weight="$1"
    local variant="$2"
    echo "TAG-MRD ${variant}: protocol ${protocol} (${description})"
    python3 main.py "${TAG_MRD_ARGS[@]}" \
      --relation_distill_weight="${weight}" \
      --fixed_protocol="${protocol}" \
      --model_path="${checkpoint}" \
      --learning_rate=1e-4 \
      --d_l="${representation_dim}" \
      --latent_dim="${representation_dim}" \
      --train_batch_size="${train_batch_size}" \
      --dataset=mosei \
      "${extra_args[@]}"
  }

  if [ "${RUN_CONTROL}" = "1" ]; then
    run_variant 0 "late-fusion-only control"
  fi
  if [ "${RUN_FULL}" = "1" ]; then
    run_variant "${GRAPH_WEIGHT}" "full relation distillation"
  fi
}

for protocol in ${PROTOCOLS}; do
  case "${protocol}" in
    0) run_protocol 0 128 192 "L observed" ;;
    1) run_protocol 1 128 192 "A observed" \
         --missing_rate=0.05 \
         --layers=2 \
         --latent_layers=3 ;;
    2) run_protocol 2 256 192 "V observed" ;;
    3) run_protocol 3 256 96  "L+A observed" ;;
    4) run_protocol 4 256 96  "L+V observed" ;;
    5) run_protocol 5 256 192 "A+V observed" ;;
    6) run_protocol 6 128 192 "L+A+V observed" ;;
    *)
      echo "Unknown protocol: ${protocol}; expected values from 0 to 6" >&2
      exit 1
      ;;
  esac
done
