set -euo pipefail

python3 -m py_compile \
  main.py \
  paper_experiment.py \
  run_e08_protocol3_clean.py \
  tests/test_e08_protocol3_clean.py

python3 -m pytest \
  tests/test_paper_experiment.py \
  tests/test_missing_aware_retrieval.py \
  tests/test_deterministic_pooling.py \
  tests/test_e05_fpfr_gate.py \
  tests/test_e06_mosei_primary.py \
  tests/test_e07_mosi_external.py \
  tests/test_e08_protocol3_clean.py \
  -q

python3 - <<'PY'
import json
from pathlib import Path

from paper_experiment import resolve_dataset_path

with open(
    "paper_experiments/configs/E08_protocol3_clean_replication.json",
    "r",
    encoding="utf-8",
) as stream:
    config = json.load(stream)
assert config["datasets"] == ["mosei", "mosi"]
assert config["protocol"] == "3"
assert config["methods"] == ["M0", "M1", "M2"]
assert config["excluded_method"]["method_id"] == "M3"
assert config["required_runs"] == 30
assert config["independence_policy"]["reuse_E06_or_E07_checkpoint"] is False
assert config["independence_policy"]["reuse_historical_exploratory_checkpoint"] is False
assert config["resume_policy"]["overwrite"] == "forbidden"
for dataset in config["datasets"]:
    print("E08 dataset resolved:", dataset, resolve_dataset_path(Path("."), dataset))
print("E08 protocol-3 clean-replication configuration verified")
PY

PLAN_FILE="$(mktemp)"
trap 'rm -f "${PLAN_FILE}"' EXIT
python3 run_e08_protocol3_clean.py \
  --datasets=mosei,mosi \
  --seeds=1111 \
  > "${PLAN_FILE}"
grep -q 'E08 dry-run plan | runs=6' "${PLAN_FILE}"
grep -q 'E08_M0_mosei_p3_s1111' "${PLAN_FILE}"
grep -q 'E08_M2_mosei_p3_s1111' "${PLAN_FILE}"
grep -q 'E08_M0_mosi_p3_s1111' "${PLAN_FILE}"
grep -q 'E08_M2_mosi_p3_s1111' "${PLAN_FILE}"
grep -q -- '--model_path=<PARENT_CHECKPOINT>' "${PLAN_FILE}"
if grep -q 'E08_M3_' "${PLAN_FILE}"; then
  echo "E08 dry-run unexpectedly includes rejected M3" >&2
  exit 1
fi
if grep -Eq 'E06|E07|best_modules' "${PLAN_FILE}"; then
  echo "E08 dry-run unexpectedly references a non-E08 checkpoint" >&2
  exit 1
fi
echo "E08 30-run clean matrix and independent lineage verified"

if [ "${E08_GPU_SMOKE:-0}" != "1" ]; then
  echo "Set E08_GPU_SMOKE=1 to run one-epoch M0/M1/M2 on MOSEI and MOSI."
  exit 0
fi

SMOKE_ROOT="${SMOKE_ROOT:-tmp/e08_protocol3_smoke}"
STAMP="$(date +%Y%m%d_%H%M%S)"
mkdir -p \
  "${SMOKE_ROOT}/checkpoints" \
  "${SMOKE_ROOT}/logs" \
  "${SMOKE_ROOT}/manifests"

run_smoke_dataset() {
  local dataset="$1"
  local m0_id="E08_SMOKE_M0_${dataset}_p3_s1111_${STAMP}"
  local m1_id="E08_SMOKE_M1_${dataset}_p3_s1111_${STAMP}"
  local m2_id="E08_SMOKE_M2_${dataset}_p3_s1111_${STAMP}"
  local common_args=(
    --paper_experiment
    --paper_stage_id=E08_SMOKE
    --paper_manifest_dir="${SMOKE_ROOT}/manifests"
    --best_model_dir="${SMOKE_ROOT}/checkpoints"
    --log_dir="${SMOKE_ROOT}/logs"
    --dataset="${dataset}"
    --fixed_protocol=3
    --seed=1111
    --train_batch_size=256
    --dev_batch_size=128
    --test_batch_size=128
    --d_l=96
    --latent_dim=96
    --layers=3
    --latent_layers=2
    --missing_rate=0.3
    --weight_decay=1e-4
    --retrieval_queue_size=0
    --retrieval_metric_mode=raw
    --retrieval_missing_query=center
    --retrieval_bank_batch_size=256
    --retrieval_bank_refresh_epochs=1
    --gate_mode=none
    --consistency_mode=mixed
    --distill_mode=none
    --fusion_mode=flat
    --prompt_mode=none
    --reconstruction_mode=none
    --consensus_mode=none
    --tag_mode=none
    --cross_modal_retrieval_mode=none
    --training_prior_mode=none
    --hybrid_expert_mode=none
    --protocol_consistency_mode=none
    --relation_distill_mode=none
    --missing_text_contrast_mode=none
    --privileged_purification_mode=none
    --language_hyper_mode=none
    --coupled_prompt_mode=none
    --early_stopping_min_delta=0.0
    --n_epochs=1
    --early_stopping_patience=0
  )

  python3 main.py \
    "${common_args[@]}" \
    --paper_run_id="${m0_id}" \
    --paper_method_id=M0 \
    --retrieval_mode=legacy \
    --retrieval_candidate_source=batch \
    --learning_rate=2e-5

  python3 main.py \
    "${common_args[@]}" \
    --paper_run_id="${m1_id}" \
    --paper_method_id=M1 \
    --retrieval_mode=missing_aware \
    --retrieval_candidate_source=train_bank \
    --learning_rate=2e-5

  python3 main.py \
    "${common_args[@]}" \
    --paper_run_id="${m2_id}" \
    --paper_method_id=M2 \
    --paper_parent_run_id="${m1_id}" \
    --model_path="${SMOKE_ROOT}/checkpoints/${m1_id}_best.pt" \
    --load=1 \
    --protocol_fusion_readaptation \
    --protocol_fusion_learning_rate=1e-4 \
    --retrieval_mode=missing_aware \
    --retrieval_candidate_source=train_bank \
    --learning_rate=1e-4
}

run_smoke_dataset mosei
run_smoke_dataset mosi

python3 - "${SMOKE_ROOT}" "${STAMP}" <<'PY'
import json
import sys
from pathlib import Path

root = Path(sys.argv[1])
stamp = sys.argv[2]
sizes = {
    "mosei": {"train": 16326, "dev": 1871, "test": 4659},
    "mosi": {"train": 1284, "dev": 229, "test": 686},
}
for dataset in ("mosei", "mosi"):
    manifests = []
    for method in ("M0", "M1", "M2"):
        run_id = "E08_SMOKE_{}_{}_p3_s1111_{}".format(
            method, dataset, stamp
        )
        with (root / "manifests" / "{}.json".format(run_id)).open(
            encoding="utf-8"
        ) as stream:
            manifests.append(json.load(stream))
    assert [item["method_id"] for item in manifests] == ["M0", "M1", "M2"]
    for manifest in manifests:
        result = manifest["result"]
        assert manifest["status"] == "complete"
        assert manifest["dataset"] == dataset
        assert manifest["protocol"] == "3"
        assert result["completed_epochs"] == 1
        assert result["test_evaluation_count"] == 1
        assert result["data_provenance"]["split_sizes"] == sizes[dataset]
    assert manifests[0]["lineage"] is None
    assert manifests[1]["lineage"] is None
    assert manifests[2]["lineage"]["parent_run_id"] == manifests[1]["run_id"]
    gate = manifests[2]["result"]["adaptation_gate"]
    assert gate["outcome"] in {"improved", "fallback_parent"}
    assert gate["test_metrics_consulted"] is False
    print("E08 GPU lineage verified:", dataset)
print("E08 dual-dataset one-epoch clean replication verified")
PY
