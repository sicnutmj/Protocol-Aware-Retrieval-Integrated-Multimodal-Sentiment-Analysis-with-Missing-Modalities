set -e

python3 -m py_compile \
  main.py \
  paper_experiment.py \
  tests/test_paper_experiment.py

python3 -m pytest tests/test_paper_experiment.py -q

python3 - <<'PY'
import json

with open(
    "paper_experiments/configs/E04_method_contracts.json",
    "r",
    encoding="utf-8",
) as stream:
    config = json.load(stream)
assert set(config["methods"]) == {"M0", "M1", "M2", "M3"}
assert config["methods"]["M2"]["parent"].startswith("M1_")
assert config["methods"]["M3"]["parent"].startswith("M2_")
print("E04 method-contract configuration verified")
PY
