set -euo pipefail

python3 -m py_compile \
  main.py \
  paper_experiment.py \
  run_e07_mosi_external.py \
  tests/test_e07_mosi_external.py

python3 -m pytest \
  tests/test_paper_experiment.py \
  tests/test_missing_aware_retrieval.py \
  tests/test_deterministic_pooling.py \
  tests/test_e05_fpfr_gate.py \
  tests/test_e06_mosei_primary.py \
  tests/test_e07_mosi_external.py \
  -q

python3 - <<'PY'
import json
from pathlib import Path

from paper_experiment import resolve_dataset_path

with open(
    "paper_experiments/configs/E07_mosi_external_validation.json",
    "r",
    encoding="utf-8",
) as stream:
    config = json.load(stream)
assert config["dataset"] == "mosi"
assert config["split_sizes"] == {"train": 1284, "dev": 229, "test": 686}
assert config["methods"] == ["M0", "M1", "M2"]
assert config["excluded_method"]["method_id"] == "M3"
assert config["required_runs"] == 105
assert config["hyperparameter_policy"].endswith("without MOSI test-set retuning")
assert config["resume_policy"]["overwrite"] == "forbidden"
dataset_path = resolve_dataset_path(Path("."), "mosi")
print("E07 formal MOSI external-validation configuration verified")
print("E07 MOSI dataset resolved:", dataset_path)
PY

PLAN_FILE="$(mktemp)"
trap 'rm -f "${PLAN_FILE}"' EXIT
python3 run_e07_mosi_external.py \
  --protocols=6 \
  --seeds=1111 \
  > "${PLAN_FILE}"
grep -q 'E07 dry-run plan | runs=3' "${PLAN_FILE}"
grep -q 'E07_M0_mosi_p6_s1111' "${PLAN_FILE}"
grep -q 'E07_M2_mosi_p6_s1111' "${PLAN_FILE}"
grep -q -- '--dataset=mosi' "${PLAN_FILE}"
grep -q -- '--model_path=<PARENT_CHECKPOINT>' "${PLAN_FILE}"
if grep -q 'E07_M3_' "${PLAN_FILE}"; then
  echo "E07 dry-run unexpectedly includes rejected M3" >&2
  exit 1
fi
echo "E07 105-run matrix and three-stage lineage verified"

if [ "${E07_GPU_SMOKE:-0}" != "1" ]; then
  echo "Set E07_GPU_SMOKE=1 to run the one-epoch MOSI M0/M1/M2 GPU path."
  exit 0
fi

SMOKE_ROOT="${SMOKE_ROOT:-tmp/e07_mosi_smoke}"
STAMP="$(date +%Y%m%d_%H%M%S)"
M0_ID="E07_SMOKE_M0_mosi_p0_s1111_${STAMP}"
M1_ID="E07_SMOKE_M1_mosi_p0_s1111_${STAMP}"
M2_ID="E07_SMOKE_M2_mosi_p0_s1111_${STAMP}"
mkdir -p \
  "${SMOKE_ROOT}/checkpoints" \
  "${SMOKE_ROOT}/logs" \
  "${SMOKE_ROOT}/manifests"

COMMON_ARGS=(
  --paper_experiment
  --paper_stage_id=E07_SMOKE
  --paper_manifest_dir="${SMOKE_ROOT}/manifests"
  --best_model_dir="${SMOKE_ROOT}/checkpoints"
  --log_dir="${SMOKE_ROOT}/logs"
  --dataset=mosi
  --fixed_protocol=0
  --seed=1111
  --train_batch_size=128
  --dev_batch_size=128
  --test_batch_size=128
  --d_l=192
  --latent_dim=192
  --layers=3
  --latent_layers=2
  --missing_rate=0.3
  --weight_decay=1e-4
  --retrieval_queue_size=0
  --retrieval_metric_mode=raw
  --retrieval_missing_query=center
  --retrieval_bank_batch_size=256
  --retrieval_bank_refresh_epochs=1
  --gate_mode=none
  --consistency_mode=mixed
  --distill_mode=none
  --fusion_mode=flat
  --prompt_mode=none
  --reconstruction_mode=none
  --consensus_mode=none
  --tag_mode=none
  --cross_modal_retrieval_mode=none
  --training_prior_mode=none
  --hybrid_expert_mode=none
  --protocol_consistency_mode=none
  --relation_distill_mode=none
  --missing_text_contrast_mode=none
  --privileged_purification_mode=none
  --language_hyper_mode=none
  --coupled_prompt_mode=none
  --early_stopping_min_delta=0.0
  --n_epochs=1
  --early_stopping_patience=0
)

python3 main.py \
  "${COMMON_ARGS[@]}" \
  --paper_run_id="${M0_ID}" \
  --paper_method_id=M0 \
  --retrieval_mode=legacy \
  --retrieval_candidate_source=batch \
  --learning_rate=2e-5

python3 main.py \
  "${COMMON_ARGS[@]}" \
  --paper_run_id="${M1_ID}" \
  --paper_method_id=M1 \
  --retrieval_mode=missing_aware \
  --retrieval_candidate_source=train_bank \
  --learning_rate=2e-5

python3 main.py \
  "${COMMON_ARGS[@]}" \
  --paper_run_id="${M2_ID}" \
  --paper_method_id=M2 \
  --paper_parent_run_id="${M1_ID}" \
  --model_path="${SMOKE_ROOT}/checkpoints/${M1_ID}_best.pt" \
  --load=1 \
  --protocol_fusion_readaptation \
  --protocol_fusion_learning_rate=1e-4 \
  --retrieval_mode=missing_aware \
  --retrieval_candidate_source=train_bank \
  --learning_rate=1e-4

python3 - \
  "${SMOKE_ROOT}/manifests/${M0_ID}.json" \
  "${SMOKE_ROOT}/manifests/${M1_ID}.json" \
  "${SMOKE_ROOT}/manifests/${M2_ID}.json" <<'PY'
import json
import sys

manifests = []
for path in sys.argv[1:]:
    with open(path, "r", encoding="utf-8") as stream:
        manifests.append(json.load(stream))
assert [item["method_id"] for item in manifests] == ["M0", "M1", "M2"]
for manifest in manifests:
    result = manifest["result"]
    assert manifest["status"] == "complete"
    assert manifest["dataset"] == "mosi"
    assert result["completed_epochs"] == 1
    assert result["test_evaluation_count"] == 1
    assert result["data_provenance"]["split_sizes"] == {
        "train": 1284, "dev": 229, "test": 686
    }
assert manifests[2]["lineage"]["parent_run_id"] == manifests[1]["run_id"]
assert manifests[2]["result"]["adaptation_gate"]["outcome"] in {
    "improved", "fallback_parent"
}
assert manifests[2]["result"]["adaptation_gate"]["test_metrics_consulted"] is False
print("E07 one-epoch MOSI M0/M1/M2 GPU lineage verified")
for manifest in manifests:
    result = manifest["result"]
    print(manifest["method_id"], "dev_mae=", result["best_loss"],
          "test_mae=", result["test_mae"])
PY
