set -euo pipefail

python3 -m py_compile \
  main.py \
  IIE_model.py \
  paper_experiment.py \
  run_e17_fusion_learning_rate.py \
  tests/test_e17_fusion_learning_rate.py

python3 -m pytest \
  tests/test_paper_experiment.py \
  tests/test_missing_aware_retrieval.py \
  tests/test_deterministic_pooling.py \
  tests/test_e05_fpfr_gate.py \
  tests/test_e06_mosei_primary.py \
  tests/test_e07_mosi_external.py \
  tests/test_e08_protocol3_clean.py \
  tests/test_e11_component_ablation.py \
  tests/test_e12_retrieval_ablation.py \
  tests/test_e13_adaptation_scope.py \
  tests/test_e13_fusion_adaptation.py \
  tests/test_e14_retrieval_topk.py \
  tests/test_e14_topk_shape.py \
  tests/test_e15_bank_sampling.py \
  tests/test_e15_retrieval_bank_size.py \
  tests/test_e16_retrieval_temperature.py \
  tests/test_e16_temperature_effect.py \
  tests/test_e17_fusion_learning_rate.py \
  -q

python3 - <<'PY'
import json
from pathlib import Path

from paper_experiment import resolve_dataset_path
from run_e17_fusion_learning_rate import preflight_references

path = Path("paper_experiments/configs/E17_fusion_learning_rate.json")
with path.open(encoding="utf-8") as stream:
    config = json.load(stream)
assert config["dataset"] == "mosei"
assert config["protocols"] == ["0", "3", "5", "6"]
assert config["seeds"] == [1111, 3407, 7777]
assert config["fusion_learning_rate_values"] == [1e-5, 5e-5, 1e-4, 5e-4]
assert config["reference_fusion_learning_rate"] == 1e-4
assert config["new_required_runs"] == 36
assert config["reused_reference_records"] == 12
assert config["total_sensitivity_cells"] == 48
assert config["shared"]["method_id"] == "M2"
assert config["shared"]["protocol_adaptation_scope"] == "fusion_all"
assert config["shared"]["retrieval_top_k"] == 2
assert config["shared"]["retrieval_temperature"] == 0.1
assert config["shared"]["retrieval_reference_bank_size"] == "full"
assert config["resume_policy"]["overwrite"] == "forbidden"
print("E17 dataset resolved:", resolve_dataset_path(Path("."), "mosei"))
preflight = preflight_references(Path(".").resolve(), ("0",), (1111,))
assert preflight["parent_count"] == 1
assert preflight["reference_count"] == 1
print("E17 fusion-learning-rate configuration verified")
PY

PLAN_FILE="$(mktemp)"
trap 'rm -f "${PLAN_FILE}"' EXIT
python3 run_e17_fusion_learning_rate.py \
  --protocols=0 \
  --seeds=1111 \
  > "${PLAN_FILE}"
grep -q 'E17 dry-run plan | new_runs=3 | reused_reference_records=1 | total_sensitivity_cells=4' "${PLAN_FILE}"
grep -q 'E17_LR1E5_mosei_p0_s1111' "${PLAN_FILE}"
grep -q 'E17_LR5E5_mosei_p0_s1111' "${PLAN_FILE}"
grep -q 'E17_LR5E4_mosei_p0_s1111' "${PLAN_FILE}"
grep -q 'E06R1_M1_mosei_p0_s1111' "${PLAN_FILE}"
grep -q 'E06R1_M2_mosei_p0_s1111' "${PLAN_FILE}"
for value in 1e-05 5e-05 5e-04; do
  grep -q -- "--protocol_fusion_learning_rate=${value}" "${PLAN_FILE}"
  grep -q -- "--learning_rate=${value}" "${PLAN_FILE}"
done
grep -q -- '--protocol_adaptation_scope=fusion_all' "${PLAN_FILE}"
echo "E17 36-new-run plan and 12-record learning_rate=1e-4 reuse mapping verified"

if [ "${E17_GPU_SMOKE:-0}" != "1" ]; then
  echo "Set E17_GPU_SMOKE=1 to run one epoch for all three new learning rates."
  exit 0
fi

SMOKE_ROOT="${SMOKE_ROOT:-tmp/e17_fusion_learning_rate_smoke}"
STAMP="$(date +%Y%m%d_%H%M%S)"
mkdir -p \
  "${SMOKE_ROOT}/checkpoints" \
  "${SMOKE_ROOT}/logs" \
  "${SMOKE_ROOT}/manifests"

cp \
  paper_experiments/manifests/E06R1_M1_mosei_p0_s1111.json \
  "${SMOKE_ROOT}/manifests/E06R1_M1_mosei_p0_s1111.json"

PARENT_CHECKPOINT="$(python3 - <<'PY'
import json
from pathlib import Path
path = Path("paper_experiments/manifests/E06R1_M1_mosei_p0_s1111.json")
with path.open(encoding="utf-8") as stream:
    manifest = json.load(stream)
print(manifest["outputs"]["best_model_path"])
PY
)"

run_smoke_learning_rate() {
  local tag="$1"
  local learning_rate="$2"
  local run_id="E17_SMOKE_LR${tag}_mosei_p0_s1111_${STAMP}"
  python3 main.py \
    --paper_experiment \
    --paper_run_id="${run_id}" \
    --paper_method_id=M2 \
    --paper_stage_id=E17 \
    --paper_parent_run_id=E06R1_M1_mosei_p0_s1111 \
    --paper_manifest_dir="${SMOKE_ROOT}/manifests" \
    --best_model_dir="${SMOKE_ROOT}/checkpoints" \
    --log_dir="${SMOKE_ROOT}/logs" \
    --model_path="${PARENT_CHECKPOINT}" \
    --load=1 \
    --dataset=mosei \
    --fixed_protocol=0 \
    --seed=1111 \
    --train_batch_size=128 \
    --dev_batch_size=128 \
    --test_batch_size=128 \
    --d_l=192 \
    --latent_dim=192 \
    --layers=3 \
    --latent_layers=2 \
    --missing_rate=0.3 \
    --weight_decay=1e-4 \
    --retrieval_mode=missing_aware \
    --retrieval_candidate_source=train_bank \
    --retrieval_candidate_filter=observed_only \
    --retrieval_composition=prototype_neighbours \
    --retrieval_selection=similarity \
    --retrieval_random_seed=3407 \
    --retrieval_top_k=2 \
    --retrieval_temperature=0.1 \
    --retrieval_queue_size=0 \
    --retrieval_metric_mode=raw \
    --retrieval_missing_query=center \
    --retrieval_bank_batch_size=256 \
    --retrieval_bank_refresh_epochs=1 \
    --retrieval_reference_bank_size=0 \
    --retrieval_reference_bank_seed=3407 \
    --gate_mode=none \
    --consistency_mode=mixed \
    --distill_mode=none \
    --fusion_mode=flat \
    --prompt_mode=none \
    --reconstruction_mode=none \
    --consensus_mode=none \
    --tag_mode=none \
    --cross_modal_retrieval_mode=none \
    --training_prior_mode=none \
    --hybrid_expert_mode=none \
    --protocol_consistency_mode=none \
    --relation_distill_mode=none \
    --missing_text_contrast_mode=none \
    --privileged_purification_mode=none \
    --language_hyper_mode=none \
    --coupled_prompt_mode=none \
    --early_stopping_min_delta=0.0 \
    --protocol_fusion_readaptation \
    --protocol_adaptation_scope=fusion_all \
    --protocol_fusion_learning_rate="${learning_rate}" \
    --protocol_transformer_learning_rate=2e-5 \
    --learning_rate="${learning_rate}" \
    --n_epochs=1 \
    --early_stopping_patience=0
}

run_smoke_learning_rate 1E5 1e-5
run_smoke_learning_rate 5E5 5e-5
run_smoke_learning_rate 5E4 5e-4

python3 - "${SMOKE_ROOT}" "${STAMP}" <<'PY'
import json
import sys
from pathlib import Path

root = Path(sys.argv[1])
stamp = sys.argv[2]
for tag, learning_rate in (("1E5", 1e-5), ("5E5", 5e-5), ("5E4", 5e-4)):
    run_id = "E17_SMOKE_LR{}_mosei_p0_s1111_{}".format(tag, stamp)
    path = root / "manifests" / "{}.json".format(run_id)
    with path.open(encoding="utf-8") as stream:
        manifest = json.load(stream)
    result = manifest["result"]
    args = manifest["arguments"]
    bank = result["data_provenance"]["strict_retrieval_bank"]
    assert manifest["status"] == "complete"
    assert manifest["method_id"] == "M2"
    assert manifest["lineage"]["parent_method_id"] == "M1"
    assert manifest["lineage"]["parent_run_id"] == "E06R1_M1_mosei_p0_s1111"
    assert args["protocol_fusion_readaptation"] is True
    assert args["protocol_adaptation_scope"] == "fusion_all"
    assert args["protocol_fusion_learning_rate"] == learning_rate
    assert args["learning_rate"] == learning_rate
    assert args["retrieval_top_k"] == 2
    assert args["retrieval_temperature"] == 0.1
    assert args["retrieval_reference_bank_size"] == 0
    assert bank["available_count"] == 16326
    assert bank["actual_size"] == 16326
    assert bank["validation_donors"] == 0
    assert bank["test_donors"] == 0
    assert result["completed_epochs"] == 1
    assert result["test_evaluation_count"] == 1
    assert result["adaptation_gate"]["outcome"] in (
        "improved", "fallback_parent"
    )
    assert result["adaptation_gate"]["test_metrics_consulted"] is False
    print("E17 GPU contract verified: fusion_learning_rate={}".format(learning_rate))
print("E17 three-learning-rate one-epoch GPU smoke verified")
PY
