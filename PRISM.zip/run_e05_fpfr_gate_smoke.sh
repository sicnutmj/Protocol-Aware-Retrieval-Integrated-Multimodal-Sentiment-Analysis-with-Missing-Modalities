set -e

if [ "${E05_SMOKE:-0}" != "1" ]; then
  echo "Set E05_SMOKE=1 to run the E05 lineage/adaptation GPU smoke." >&2
  exit 2
fi

python3 -m py_compile \
  main.py \
  paper_experiment.py \
  evaluate_e05_fpfr_gate.py \
  tests/test_e05_fpfr_gate.py

python3 -m pytest \
  tests/test_paper_experiment.py \
  tests/test_e05_fpfr_gate.py \
  -q

python3 - <<'PY'
import json

with open(
    "paper_experiments/configs/E05_fpfr_gate.json",
    "r",
    encoding="utf-8",
) as stream:
    config = json.load(stream)
assert config["aggregate_gate"]["required_pairs"] == 35
assert config["aggregate_gate"]["test_metrics_consulted"] is False
assert config["decision"]["all_criteria_pass"] == "retain_M3"
print("E05 FPFR gate configuration verified")
PY

PARENT_INFO="$(python3 - <<'PY'
import glob
import json
import os

candidates = []
for path in glob.glob(
    "tmp/e03_smoke/manifests/E03_SMOKE_R1_M1_mosei_p6_s1111_*.json"
):
    with open(path, "r", encoding="utf-8") as stream:
        manifest = json.load(stream)
    checkpoint = (manifest.get("outputs") or {}).get("best_model_path")
    result = manifest.get("result") or {}
    if (
        manifest.get("status") == "complete"
        and manifest.get("method_id") == "M1"
        and result.get("selected_state_sha256")
        and checkpoint
        and os.path.isfile(checkpoint)
    ):
        candidates.append((manifest["started_at"], manifest, checkpoint))
if not candidates:
    raise SystemExit(
        "No completed E03 R1 M1 smoke parent found under tmp/e03_smoke"
    )
_, parent, checkpoint = max(candidates, key=lambda item: item[0])
print(parent["run_id"])
print(os.path.abspath(checkpoint))
PY
)"
PARENT_RUN_ID="$(printf '%s\n' "${PARENT_INFO}" | sed -n '1p')"
PARENT_CHECKPOINT="$(printf '%s\n' "${PARENT_INFO}" | sed -n '2p')"
RUN_ID="E05_SMOKE_M2_mosei_p6_s1111_$(date +%Y%m%d_%H%M%S)"
SMOKE_ROOT="${SMOKE_ROOT:-tmp/e05_smoke}"
mkdir -p "${SMOKE_ROOT}/checkpoints" "${SMOKE_ROOT}/logs"

echo "E05 staged-adaptation smoke: ${PARENT_RUN_ID} -> ${RUN_ID}"
python3 main.py \
  --paper_experiment \
  --paper_run_id="${RUN_ID}" \
  --paper_method_id=M2 \
  --paper_stage_id=E05 \
  --paper_parent_run_id="${PARENT_RUN_ID}" \
  --paper_manifest_dir=tmp/e03_smoke/manifests \
  --best_model_dir="${SMOKE_ROOT}/checkpoints" \
  --log_dir="${SMOKE_ROOT}/logs" \
  --model_path="${PARENT_CHECKPOINT}" \
  --load=1 \
  --protocol_fusion_readaptation \
  --protocol_fusion_learning_rate=1e-4 \
  --retrieval_mode=missing_aware \
  --retrieval_candidate_source=train_bank \
  --retrieval_queue_size=0 \
  --retrieval_metric_mode=raw \
  --retrieval_missing_query=center \
  --retrieval_bank_batch_size=256 \
  --retrieval_bank_refresh_epochs=1 \
  --gate_mode=none \
  --consistency_mode=mixed \
  --fusion_mode=flat \
  --prompt_mode=none \
  --fixed_protocol=6 \
  --learning_rate=1e-4 \
  --d_l=192 \
  --latent_dim=192 \
  --train_batch_size=128 \
  --dev_batch_size=128 \
  --test_batch_size=128 \
  --dataset=mosei \
  --seed=1111 \
  --n_epochs=1 \
  --early_stopping_patience=0

python3 - "tmp/e03_smoke/manifests/${RUN_ID}.json" <<'PY'
import json
import sys

with open(sys.argv[1], "r", encoding="utf-8") as stream:
    manifest = json.load(stream)
result = manifest["result"]
gate = result["adaptation_gate"]
assert manifest["status"] == "complete"
assert manifest["method_id"] == "M2"
assert manifest["lineage"]["parent_method_id"] == "M1"
assert gate["outcome"] in ("improved", "fallback_parent")
assert gate["dev_mae_gain"] >= 0.0
assert gate["test_metrics_consulted"] is False
assert result["test_evaluation_count"] == 1
print("E05 staged-adaptation GPU smoke verified")
print("outcome:", gate["outcome"])
print("dev_mae_gain:", gate["dev_mae_gain"])
PY
