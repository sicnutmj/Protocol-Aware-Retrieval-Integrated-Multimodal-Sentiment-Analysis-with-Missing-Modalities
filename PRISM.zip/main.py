from __future__ import absolute_import, division, print_function
import math
import hashlib
import sys
import argparse
import random
import pickle
import os
import argparse
import numpy as np
from typing import *
from utils import *
import time
from tqdm import tqdm, trange
from sklearn.metrics import classification_report, confusion_matrix, precision_recall_fscore_support, accuracy_score, f1_score
import torch
import torch.nn as nn
from torch.nn import CrossEntropyLoss, L1Loss, MSELoss
from torch.utils.data import (
    DataLoader,
    RandomSampler,
    SequentialSampler,
    Subset,
    TensorDataset,
)
from torch.utils.data.distributed import DistributedSampler
from scipy.stats import pearsonr, spearmanr
from sklearn.metrics import matthews_corrcoef
from transformers import BertConfig, BertTokenizer, XLNetTokenizer, get_cosine_schedule_with_warmup
#from transformers.optimization import AdamW
from torch.optim import AdamW
from itertools import chain
from IIE_model import IIEModel
from modules.paired_distillation import paired_hierarchical_distillation
from modules.protocol_missing_consistency import (
    confidence_gated_polarity_consistency,
)
from modules.teacher_advantage_relation_distillation import (
    FrozenLateFusionTeacher,
    teacher_advantage_relation_distillation,
)
from modules.label_semantic_missing_text_residual import (
    label_semantic_missing_text_objective,
)
from modules.privileged_disentangled_purification import (
    privileged_disentangled_objective,
)
from modules.pns_audit import (
    PNSAuditAccumulator,
    evaluate_enhanced_branch_counterfactuals,
)
from modules.retrieval_bank_sampling import (
    deterministic_retrieval_bank_subset_indices,
)
from paper_experiment import (
    FinalTestGate,
    build_data_provenance,
    finalize_paper_manifest,
    sha256_file,
    state_dict_content_sha256,
    start_paper_manifest,
    evaluate_staged_adaptation,
    resolve_dataset_path,
    validate_formal_lineage,
)
import warnings
import logging
from datetime import datetime
warnings.filterwarnings("ignore")
_CONFIG_FOR_DOC = "BertConfig"
_TOKENIZER_FOR_DOC = "BertTokenizer"
os.environ["CUDA_VISIBLE_DEVICES"] = "0"
DEVICE = torch.device("cuda:0")
logger = logging.getLogger("IIE")
FINAL_TEST_GATE = None


def str2bool(s):
    if isinstance(s, bool):
        return s
    if s.lower() in ("yes", "true", "t", "y", "1"):
        return True
    elif s.lower() in ("no", "false", "f", "n", "0"):
        return False
    else:
        raise argparse.ArgumentTypeError(
            "Boolean value expected. Recieved {0}".format(s)
        )

def seed(s):
    if isinstance(s, int):
        if 0 <= s <= 9999:
            return s
        else:
            raise argparse.ArgumentTypeError(
                "Seed must be between 0 and 2**32 - 1. Received {0}".format(s)
            )
    elif s == "random":
        return random.randint(0, 9999)
    else:
        raise argparse.ArgumentTypeError(
            "Integer value is expected. Recieved {0}".format(s)
        )


def return_unk():
    return 0


class InputFeatures(object):
    """A single set of features of data."""

    def __init__(self, input_ids, visual, acoustic, input_mask, segment_ids, label_id):
        self.input_ids = input_ids
        self.visual = visual
        self.acoustic = acoustic
        self.input_mask = input_mask
        self.segment_ids = segment_ids
        self.label_id = label_id


def convert_to_features(args, examples, max_seq_length, tokenizer):
    features = []

    for (ex_index, example) in enumerate(examples):

        (words, visual, acoustic), label_id, segment = example
        acoustic[acoustic == -np.inf] = 0
        visual[visual == -np.inf] = 0
        tokens, inversions = [], []
        for idx, word in enumerate(words):
            tokenized = tokenizer.tokenize(word)
            tokens.extend(tokenized)
            inversions.extend([idx] * len(tokenized))

        # Check inversion
        assert len(tokens) == len(inversions)


        if len(tokens) > args.text_length - 2:
            tokens = tokens[: args.text_length - 2]
        if len(acoustic) > args.acoustic_length - 2:
            acoustic = acoustic[: args.acoustic_length - 2]
        if len(visual) > args.visual_length - 2:
            visual = visual[: args.visual_length - 2]

        if args.model == "bert-base-uncased":
            prepare_input = prepare_bert_input

        input_ids, visual, acoustic, input_mask, segment_ids = prepare_input(
            args, tokens, visual, acoustic, tokenizer
        )

        # Check input length
        assert len(input_ids) == args.max_seq_length
        assert len(input_mask) == args.max_seq_length
        assert len(segment_ids) == args.max_seq_length
        assert acoustic.shape[0] == args.acoustic_length
        assert visual.shape[0] == args.visual_length

        features.append(
            InputFeatures(
                input_ids=input_ids,
                input_mask=input_mask,
                segment_ids=segment_ids,
                visual=visual,
                acoustic=acoustic,
                label_id=label_id,
            )
        )
    return features


def prepare_bert_input(args, tokens, visual, acoustic, tokenizer):
    CLS = tokenizer.cls_token
    SEP = tokenizer.sep_token
    tokens = [CLS] + tokens + [SEP]

    # Pad zero vectors for acoustic / visual vectors to account for [CLS] / [SEP] tokens
    acoustic_zero = np.zeros((1, args.ACOUSTIC_DIM))
    acoustic = np.concatenate((acoustic_zero, acoustic, acoustic_zero))
    visual_zero = np.zeros((1, args.VISUAL_DIM))
    visual = np.concatenate((visual_zero, visual, visual_zero))

    input_ids = tokenizer.convert_tokens_to_ids(tokens)
    segment_ids = [0] * len(input_ids)
    input_mask = [1] * len(input_ids)

    pad_length = args.max_seq_length - len(input_ids)

    pad_length_audio = args.acoustic_length - len(acoustic)
    pad_length_video = args.visual_length - len(visual)

    acoustic_padding = np.zeros((pad_length_audio, args.ACOUSTIC_DIM))
    acoustic = np.concatenate((acoustic, acoustic_padding))

    visual_padding = np.zeros((pad_length_video, args.VISUAL_DIM))
    visual = np.concatenate((visual, visual_padding))

    padding = [0] * pad_length

    # Pad inputs
    input_ids += padding
    input_mask += padding
    segment_ids += padding

    return input_ids, visual, acoustic, input_mask, segment_ids


def get_tokenizer(model):
    if model == "bert-base-uncased":
        return BertTokenizer.from_pretrained('./BERT_EN/')
    
    else:
        raise ValueError(
            "Expected 'bert-base-uncased' or 'xlnet-base-cased, but received {}".format(
                model
            )
        )


def get_appropriate_dataset(data):
    tokenizer = get_tokenizer(args.model)
    features = convert_to_features(args, data, args.max_seq_length, tokenizer)
    all_input_ids = torch.tensor(
        [f.input_ids for f in features], dtype=torch.long)
    all_input_mask = torch.tensor(
        [f.input_mask for f in features], dtype=torch.long)
    all_segment_ids = torch.tensor(
        [f.segment_ids for f in features], dtype=torch.long)
    all_visual = torch.tensor([f.visual for f in features], dtype=torch.float)
    all_acoustic = torch.tensor(
        [f.acoustic for f in features], dtype=torch.float)
    all_label_ids = torch.tensor(
        [f.label_id for f in features], dtype=torch.float)
    all_sample_ids = torch.arange(len(features), dtype=torch.long)

    dataset = TensorDataset(
        all_input_ids,
        all_visual,
        all_acoustic,
        all_input_mask,
        all_segment_ids,
        all_label_ids,
        all_sample_ids,
    )
    return dataset


def unpack_dataset_batch(batch):
    if len(batch) != 7:
        raise ValueError(
            "IIE datasets must provide six feature tensors plus sample ids"
        )
    return batch


def set_up_data_loader():
    dataset_path = str(resolve_dataset_path(os.getcwd(), args.dataset))
    with open(dataset_path, "rb") as handle:
        data = pickle.load(handle)

    train_data = data["train"]
    dev_data = data["dev"]
    test_data = data["test"]

    train_dataset = get_appropriate_dataset(train_data)
    dev_dataset = get_appropriate_dataset(dev_data)
    test_dataset = get_appropriate_dataset(test_data)

    split_sizes = {
        "train": len(train_dataset),
        "dev": len(dev_dataset),
        "test": len(test_dataset),
    }
    expected_sizes = {
        "train": int(args.train_nums),
        "dev": int(args.dev_nums),
        "test": int(args.test_nums),
    }
    if args.paper_experiment and split_sizes != expected_sizes:
        raise RuntimeError(
            "Formal dataset split sizes differ from the frozen protocol: "
            "actual={} expected={}".format(split_sizes, expected_sizes)
        )

    data_provenance = None
    if args.paper_experiment:
        data_provenance = build_data_provenance(
            dataset_path,
            split_sizes,
            args.fixed_protocol,
        )
        logger.info(
            "E03 data provenance | dataset_sha256=%s | "
            "split_sizes=%s | mask_sha_train/dev/test=%s/%s/%s",
            data_provenance["dataset_sha256"],
            split_sizes,
            data_provenance["mask_records"]["train"][
                "sha256_uint8_row_major"
            ],
            data_provenance["mask_records"]["dev"][
                "sha256_uint8_row_major"
            ],
            data_provenance["mask_records"]["test"][
                "sha256_uint8_row_major"
            ],
        )

    num_train_optimization_steps = (
        int(
            len(train_dataset) / args.train_batch_size /
            args.gradient_accumulation_step
        )
        * args.n_epochs
    )

    train_loader_generator = None
    if args.paper_experiment:
        # Keep sample ordering independent from random numbers consumed by
        # model initialization or method-specific branches.
        train_loader_generator = torch.Generator()
        train_loader_generator.manual_seed(args.seed)
    train_dataloader = DataLoader(
        train_dataset,
        batch_size=args.train_batch_size,
        shuffle=True,
        generator=train_loader_generator,
    )

    train_bank_dataloader = DataLoader(
        train_dataset,
        batch_size=args.retrieval_bank_batch_size,
        shuffle=False,
    )

    dev_dataloader = DataLoader(
        dev_dataset, batch_size=args.dev_batch_size, shuffle=False
    )

    test_dataloader = DataLoader(
        test_dataset, batch_size=args.test_batch_size, shuffle=False,
    )

    return (
        train_dataloader,
        dev_dataloader,
        test_dataloader,
        train_bank_dataloader,
        num_train_optimization_steps,
        data_provenance,
    )


def set_random_seed(seed: int):
    """
    Helper function to seed experiment for reproducibility.
    If -1 is provided as seed, experiment uses random seed from 0~9999

    Args:
        seed (int): integer to be used as seed, use -1 to randomly seed experiment
    """
 
    logger.info("Seed: %s", seed)

    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.enabled = False
    torch.backends.cudnn.deterministic = True

    random.seed(seed)
    os.environ["PYTHONHASHSEED"] = str(seed)
    if args.paper_experiment:
        # This variable must be present before the first cuBLAS operation.
        os.environ["CUBLAS_WORKSPACE_CONFIG"] = ":4096:8"
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    if args.paper_experiment:
        torch.use_deterministic_algorithms(True)
        logger.info(
            "E03 deterministic execution enabled | seed=%d | "
            "train_loader_generator=isolated | cudnn_benchmark=false | "
            "cudnn_enabled=false | deterministic_algorithms=true | "
            "cublas_workspace_config=%s",
            seed,
            os.environ["CUBLAS_WORKSPACE_CONFIG"],
        )


def prep_for_training(num_train_optimization_steps: int):
    if args.model == "bert-base-uncased":
        model = IIEModel.from_pretrained(
            './BERT_EN/', num_labels=1, args = args,
        )

    hybrid_expert_initialization = (
        model.initialize_availability_hybrid_expert_residual()
    )
    if hybrid_expert_initialization is not None:
        logger.info(
            "Improvement-14 identity verified | final_weight_max=%.6f | "
            "final_bias_max=%.6f | routing_temperature=%.6f",
            hybrid_expert_initialization['final_weight_max'],
            hybrid_expert_initialization['final_bias_max'],
            hybrid_expert_initialization['temperature'],
        )

    consensus_initialization = model.initialize_unified_consensus_residual()
    if consensus_initialization is not None:
        logger.info(
            "Improvement-9 identity verified | final_weight_max=%.6f | "
            "final_bias_max=%.6f",
            consensus_initialization['final_weight_max'],
            consensus_initialization['final_bias_max'],
        )
    tag_initialization = model.initialize_missing_tag_fusion_bias()
    if tag_initialization is not None:
        logger.info(
            "Improvement-10 identity verified | projection_weight_max=%.6f",
            tag_initialization['projection_weight_max'],
        )
    coupled_prompt_initialization = (
        model.initialize_layerwise_coupled_missing_prompt()
    )
    if coupled_prompt_initialization is not None:
        logger.info(
            "Improvement-20 identity verified | scale_logit_max=%.6f | "
            "prompt_depth=%d | prompt_length=%d",
            coupled_prompt_initialization['scale_logit_max'],
            coupled_prompt_initialization['prompt_depth'],
            coupled_prompt_initialization['prompt_length'],
        )

    gate_initialization = model.initialize_quality_reliability_gate()
    if gate_initialization is not None:
        logger.info(
            "%s initialization verified | reliability=%.6f | "
            "scale=%.6f | min_scale=%.6f | init_bias=%.6f",
            gate_initialization["version"],
            gate_initialization["reliability"],
            gate_initialization["scale"],
            gate_initialization["min_scale"],
            gate_initialization["init_bias"],
        )
    if args.gate_mode == 'fixed_scale_ablation':
        logger.info(
            "Fixed-scale ablation verified | enhanced_scale=%.6f | "
            "learnable_gate_parameters=0",
            args.gate_fixed_scale,
        )
    elif args.gate_mode == 'none':
        if args.coupled_prompt_mode == 'lcmpr':
            logger.info(
                "Improvement-20 requested | adapter=lcmpr | "
                "location=frozen_fusion_transformer_layers | "
                "eligible=missing_enhanced_tokens_only | depth=%d | "
                "prompt_length=%d | foundation=first+seventh+fpfr | "
                "foundation_frozen=true | fusion_all_trainable=false | "
                "adapter_lr=%.8g | max_scale=%.4f",
                args.coupled_prompt_depth,
                args.coupled_prompt_length,
                args.coupled_prompt_learning_rate,
                args.coupled_prompt_max_scale,
            )
        elif args.language_hyper_mode in (
            'availability_only', 'language_query'
        ):
            logger.info(
                "Improvement-19 requested | adapter=at_ldhr | mode=%s | "
                "query=language | auxiliary=enhanced+raw_audio_video | "
                "availability_tags=true | eligible=text_observed | "
                "foundation=first+seventh+fpfr | foundation_frozen=true | "
                "fusion_all_trainable=false | trainable=at_ldhr_only | "
                "adapter_lr=%.8g | max_scale=%.4f",
                args.language_hyper_mode,
                args.language_hyper_learning_rate,
                args.language_hyper_max_scale,
            )
        elif args.privileged_purification_mode in ('task_only', 'full'):
            logger.info(
                "Improvement-18 requested | adapter=pdrp | mode=%s | "
                "teacher=complete_view_training_only | "
                "eligible=missing_enhanced_tokens_only | "
                "foundation=first+seventh+fpfr | foundation_frozen=true | "
                "fusion_all_trainable=false | trainable=pdrp_only | "
                "adapter_lr=%.8g | shared_weight=%.6f | "
                "orthogonality_weight=%.6f | separation_weight=%.6f",
                args.privileged_purification_mode,
                args.privileged_purification_learning_rate,
                args.privileged_purification_shared_weight,
                args.privileged_purification_orthogonality_weight,
                args.privileged_purification_separation_weight,
            )
        elif args.missing_text_contrast_mode in ('feature', 'label'):
            logger.info(
                "Improvement-17 requested | adapter=lscmr | mode=%s | "
                "eligible=text_missing_only | source=observed_audio_visual | "
                "positive=frozen_complete_text | negative=in_batch_text | "
                "foundation=first+seventh+fpfr | foundation_frozen=true | "
                "fusion_all_trainable=false | trainable=lscmr_only | "
                "adapter_lr=%.8g | pair_weight=%.6f | "
                "contrast_weight=%.6f | temperature=%.4f",
                args.missing_text_contrast_mode,
                args.missing_text_contrast_learning_rate,
                args.missing_text_pair_loss_weight,
                args.missing_text_contrast_loss_weight,
                args.missing_text_contrast_temperature,
            )
        elif args.relation_distill_mode == 'tag_mrd':
            logger.info(
                "Improvement-16 requested | distillation=tag_mrd | "
                "teacher=frozen_complete_view_late_fusion_snapshot | "
                "student=fixed_protocol_%s | graph=enhanced_l/a/v_cosine | "
                "teacher_advantage_margin=%.6f | graph_weight=%.6f | "
                "foundation=first+seventh+fpfr | "
                "trainable=transformer_encoder_all+fusion_all | "
                "transformer_lr=%.8g | fusion_lr=%.8g | "
                "inference_branch=none",
                args.fixed_protocol,
                args.relation_distill_advantage_margin,
                args.relation_distill_weight,
                args.relation_distill_transformer_learning_rate,
                args.relation_distill_fusion_learning_rate,
            )
        elif args.protocol_fusion_readaptation:
            if args.paper_experiment:
                logger.info(
                    "E04 formal fusion adaptation requested | method=%s | "
                    "parent_method=%s | parent_run=%s | protocol=%s | "
                    "foundation_frozen=true | adaptation_scope=%s | "
                    "teacher_branch=off | auxiliary_consistency=off | "
                    "fusion_lr=%.8g | transformer_lr=%.8g",
                    args.paper_method_id,
                    args.paper_lineage["parent_method_id"],
                    args.paper_parent_run_id,
                    args.fixed_protocol,
                    args.protocol_adaptation_scope,
                    args.protocol_fusion_learning_rate,
                    args.protocol_transformer_learning_rate,
                )
            else:
                logger.info(
                    "Retained improvement-15 requested | "
                    "strategy=fixed_protocol_fusion_readaptation | "
                    "stage=second_after_seventh | protocol=%s | "
                    "foundation=first_q0+seventh_head | "
                    "feature_foundation_frozen=true | "
                    "trainable=fusion_all | teacher_branch=off | "
                    "auxiliary_consistency=off | fusion_lr=%.8g",
                    args.fixed_protocol,
                    args.protocol_fusion_learning_rate,
                )
        elif args.protocol_consistency_mode == 'pcmc':
            if args.protocol_consistency_weight == 0.0:
                logger.info(
                    "Improvement-15 key ablation requested | "
                    "consistency_gradient=off | consistency_weight=0 | "
                    "diagnostic_teacher_pass=on | "
                    "student=fixed_protocol_%s | "
                    "foundation=first_q0+seventh_head | "
                    "feature_foundation_frozen=true | "
                    "trainable=fusion_all | fusion_lr=%.8g",
                    args.fixed_protocol,
                    args.protocol_consistency_learning_rate,
                )
            else:
                logger.info(
                    "Fifteenth improvement requested | consistency=pcmc | "
                    "teacher=complete_view_stop_gradient | "
                    "student=fixed_protocol_%s | confidence=%.4f | "
                    "temperature=%.4f | weight=%.6f | "
                    "foundation=first_q0+seventh_head | "
                    "feature_foundation_frozen=true | trainable=fusion_all | "
                    "fusion_lr=%.8g",
                    args.fixed_protocol,
                    args.protocol_consistency_confidence,
                    args.protocol_consistency_temperature,
                    args.protocol_consistency_weight,
                    args.protocol_consistency_learning_rate,
                )
        elif args.hybrid_expert_mode == 'acher':
            logger.info(
                "Fourteenth improvement requested | expert=acher | "
                "input=three_retrieval_enhanced_modalities | "
                "router_context=sample+availability_mask | "
                "private_experts=%d | shared_experts=%d | "
                "orthogonality=squared_cosine | "
                "foundation=first_q0+seventh_head | foundation_frozen=true | "
                "fusion_all_trainable=false | trainable=acher_only | "
                "expert_lr=%.8g | orthogonality_weight=%.6f",
                args.hybrid_expert_private_count,
                args.hybrid_expert_shared_count,
                args.hybrid_expert_learning_rate,
                args.hybrid_expert_orthogonality_weight,
            )
        elif args.training_prior_mode == 'tspe':
            logger.info(
                "Thirteenth improvement requested | prior=tspe | "
                "scope=training_only | target=observed_pooled_modalities | "
                "evaluation_path=exact_identity | foundation=first_q0+seventh_head | "
                "foundation_frozen=true | trainable=fusion_all | "
                "mix_ratio=%.6f | top_k=%d | similarity_interval=[%.4f,%.4f] | "
                "label_weight=%.6f",
                args.training_prior_mix_ratio,
                args.training_prior_top_k,
                args.training_prior_similarity_min,
                args.training_prior_similarity_max,
                args.training_prior_label_weight,
            )
        elif args.cross_modal_retrieval_mode == 'scbr':
            logger.info(
                "Twelfth improvement requested | retrieval=scbr | "
                "reference=train_complete_only | donor=single_paired_bundle | "
                "query=native_observed_modalities | sentiment_anchor=frozen_prediction | "
                "foundation=first_q0+seventh_head | foundation_frozen=true | "
                "trainable_parameters=0 | scales=%s | sentiment_weight=%.6f",
                args.bundle_injection_scales,
                args.bundle_sentiment_weight,
            )
        elif args.cross_modal_retrieval_mode == 'agcqr':
            logger.info(
                "Eleventh improvement requested | retrieval=agcqr | "
                "reference=train_complete_only | foundation=first_q0+seventh_head | "
                "foundation_frozen=true | trainable=query_mappers+mix_scales | "
                "mapper_lr=%.8g | match_weight=%.6f | bank_size=%d",
                args.cross_modal_retrieval_learning_rate,
                args.cross_modal_match_loss_weight,
                args.cross_modal_reference_bank_size,
            )
        elif args.tag_mode == 'amtfb':
            logger.info(
                "Tenth improvement requested | tag=amtfb | "
                "tag_bits=complete,missing_l,missing_a,missing_v | "
                "injection=fusion_first_layer_preactivation | "
                "foundation=first_q0+seventh_head | foundation_frozen=true | "
                "trainable=missing_tag_fusion_bias | tag_lr=%.8g",
                args.tag_learning_rate,
            )
        elif args.consensus_mode == 'amucr':
            logger.info(
                "Ninth improvement requested | consensus=amucr | "
                "source=seven_frozen_iie_representations | "
                "missing_raw_masked=true | missing_enhanced_visible=true | "
                "foundation=first_q0+seventh_head | foundation_frozen=true | "
                "trainable=unified_consensus_residual | consensus_lr=%.8g",
                args.consensus_learning_rate,
            )
        elif args.reconstruction_mode == 'text_guided_nonverbal':
            logger.info(
                "Eighth improvement requested | "
                "reconstruction=text_guided_nonverbal | "
                "eligible=text_observed_and_nonverbal_missing | "
                "foundation=first_q0+seventh_head | "
                "foundation_frozen=true | trainable=reconstructor | "
                "reconstruction_lr=%.8g | loss_weight=%.6f",
                args.reconstruction_learning_rate,
                args.reconstruction_loss_weight,
            )
        elif args.prompt_mode == 'missing_dynamic':
            if args.prompt_finetune_scope == 'head_only':
                logger.info(
                    "Seventh improvement ablation requested | "
                    "scope=head_only | dynamic_prompt=bypassed | "
                    "q0_backbone=frozen | trainable=fusion_all | "
                    "head_lr=%.8g",
                    args.learning_rate,
                )
            else:
                logger.info(
                    "Seventh improvement ablation requested | "
                    "scope=prompt_head | prompt=missing_dynamic | "
                    "observed_branches=identity | q0_backbone=frozen | "
                    "trainable=prompt_adapter+fusion_all | "
                    "prompt_lr=%.8g | head_lr=%.8g",
                    args.prompt_learning_rate,
                    args.learning_rate,
                )
        elif args.fusion_mode == 'availability_multistage':
            logger.info(
                "Frozen failed sixth ablation requested | "
                "fusion=availability_multistage | "
                "availability_source=ps | stages=unimodal,bimodal,trimodal | "
                "empty_observed_pairs=masked | q0_retrieval=frozen"
            )
        elif args.distill_mode == 'paired_hierarchical':
            logger.info(
                "Paired hierarchical distillation verified | "
                "complete_teacher=training_only | sample_weight=%.6f | "
                "fusion_weight=%.6f | inference_path=q0",
                args.distill_sample_weight,
                args.distill_fusion_weight,
            )
        elif (
            args.consistency_mode == 'mixed'
            and args.retrieval_metric_mode == 'raw'
            and args.retrieval_missing_query == 'center'
        ):
            logger.info(
                "Frozen q0 baseline verified | retrieval_mode=%s | "
                "queue_size=%d | reliability_gate=disabled | "
                "paired_distillation=disabled",
                args.retrieval_mode,
                args.retrieval_queue_size,
            )
        else:
            logger.info(
                "Training configuration verified | retrieval_mode=%s | "
                "queue_size=%d | metric_mode=%s | missing_query=%s | "
                "retrieval_loss_weight=%.6f | consistency_mode=%s | "
                "consistency_min_group_size=%d | reliability_gate=disabled",
                args.retrieval_mode,
                args.retrieval_queue_size,
                args.retrieval_metric_mode,
                args.retrieval_missing_query,
                args.retrieval_loss_weight,
                args.consistency_mode,
                args.consistency_min_group_size,
            )

    if args.load:
        checkpoint = torch.load(args.model_path, map_location="cpu")
        if args.coupled_prompt_mode == 'lcmpr':
            incompatible = model.load_state_dict(checkpoint, strict=False)
            prefix = 'layerwise_coupled_missing_prompt.'
            invalid_missing = [
                name for name in incompatible.missing_keys
                if not name.startswith(prefix)
            ]
            if invalid_missing or incompatible.unexpected_keys:
                raise RuntimeError(
                    "FPFR checkpoint mismatch | invalid_missing={} | "
                    "unexpected={}".format(
                        invalid_missing, incompatible.unexpected_keys
                    )
                )
            if not incompatible.missing_keys:
                raise RuntimeError(
                    "expected an FPFR checkpoint without LCMPR parameters"
                )
            model.layerwise_coupled_missing_prompt.reset_identity()
            logger.info(
                "First+seventh+FPFR checkpoint loaded for improvement 20 | "
                "path=%s | new_lcmpr_tensors=%d | residual_scales=0",
                os.path.abspath(args.model_path),
                len(incompatible.missing_keys),
            )
        elif args.language_hyper_mode in (
            'availability_only', 'language_query'
        ):
            incompatible = model.load_state_dict(checkpoint, strict=False)
            prefix = 'availability_tagged_language_hyper_residual.'
            invalid_missing = [
                name for name in incompatible.missing_keys
                if not name.startswith(prefix)
            ]
            if invalid_missing or incompatible.unexpected_keys:
                raise RuntimeError(
                    "FPFR checkpoint mismatch | invalid_missing={} | "
                    "unexpected={}".format(
                        invalid_missing, incompatible.unexpected_keys
                    )
                )
            if not incompatible.missing_keys:
                raise RuntimeError(
                    "expected an FPFR checkpoint without AT-LDHR parameters"
                )
            model.availability_tagged_language_hyper_residual.reset_identity()
            logger.info(
                "First+seventh+FPFR checkpoint loaded for improvement 19 | "
                "path=%s | new_at_ldhr_tensors=%d | injection_scale=0",
                os.path.abspath(args.model_path),
                len(incompatible.missing_keys),
            )
        elif args.privileged_purification_mode in ('task_only', 'full'):
            incompatible = model.load_state_dict(checkpoint, strict=False)
            invalid_missing = [
                name for name in incompatible.missing_keys
                if not name.startswith(
                    'privileged_disentangled_purification.'
                )
            ]
            if invalid_missing or incompatible.unexpected_keys:
                raise RuntimeError(
                    "FPFR checkpoint mismatch | invalid_missing={} | "
                    "unexpected={}".format(
                        invalid_missing, incompatible.unexpected_keys
                    )
                )
            if not incompatible.missing_keys:
                raise RuntimeError(
                    "expected an FPFR checkpoint without PDRP parameters"
                )
            model.privileged_disentangled_purification.reset_identity()
            logger.info(
                "First+seventh+FPFR checkpoint loaded for improvement 18 | "
                "path=%s | new_pdrp_tensors=%d | injection_scales=0/0/0",
                os.path.abspath(args.model_path),
                len(incompatible.missing_keys),
            )
        elif args.missing_text_contrast_mode in ('feature', 'label'):
            incompatible = model.load_state_dict(checkpoint, strict=False)
            invalid_missing = [
                name for name in incompatible.missing_keys
                if not name.startswith('missing_text_contrast_residual.')
            ]
            if invalid_missing or incompatible.unexpected_keys:
                raise RuntimeError(
                    "FPFR checkpoint mismatch | invalid_missing={} | "
                    "unexpected={}".format(
                        invalid_missing, incompatible.unexpected_keys
                    )
                )
            if not incompatible.missing_keys:
                raise RuntimeError(
                    "expected an FPFR checkpoint without improvement-17 parameters"
                )
            with torch.no_grad():
                model.missing_text_contrast_residual.injection_scale_logit.zero_()
            logger.info(
                "First+seventh+FPFR checkpoint loaded for improvement 17 | "
                "path=%s | new_lscmr_tensors=%d | injection_scale=0",
                os.path.abspath(args.model_path),
                len(incompatible.missing_keys),
            )
        elif args.relation_distill_mode == 'tag_mrd':
            model.load_state_dict(checkpoint)
            logger.info(
                "First+seventh+FPFR checkpoint loaded for improvement 16 | "
                "path=%s | new_persistent_tensors=0",
                os.path.abspath(args.model_path),
            )
        elif (
            args.protocol_consistency_mode == 'pcmc'
            or args.protocol_fusion_readaptation
        ):
            model.load_state_dict(checkpoint)
            if args.paper_experiment:
                logger.info(
                    "E04 formal parent checkpoint loaded | child_method=%s | "
                    "parent_method=%s | parent_run=%s | path=%s | "
                    "new_persistent_tensors=0",
                    args.paper_method_id,
                    args.paper_lineage["parent_method_id"],
                    args.paper_parent_run_id,
                    os.path.abspath(args.model_path),
                )
            else:
                logger.info(
                    "First+seventh checkpoint loaded for improvement 15 | "
                    "path=%s | mode=%s | new_persistent_tensors=0",
                    os.path.abspath(args.model_path),
                    (
                        'fixed_protocol_fusion_readaptation'
                        if args.protocol_fusion_readaptation
                        else 'pcmc_reproduction'
                    ),
                )
        elif args.hybrid_expert_mode == 'acher':
            incompatible = model.load_state_dict(checkpoint, strict=False)
            invalid_missing = [
                name for name in incompatible.missing_keys
                if not name.startswith(
                    'availability_hybrid_expert_residual.'
                )
            ]
            if invalid_missing or incompatible.unexpected_keys:
                raise RuntimeError(
                    "seventh checkpoint mismatch | invalid_missing={} | "
                    "unexpected={}".format(
                        invalid_missing, incompatible.unexpected_keys
                    )
                )
            if not incompatible.missing_keys:
                raise RuntimeError(
                    "expected a clean seventh checkpoint without ACHER parameters"
                )
            model.availability_hybrid_expert_residual.reset_identity()
            logger.info(
                "First+seventh checkpoint loaded for improvement 14 | "
                "path=%s | new_acher_tensors=%d",
                os.path.abspath(args.model_path),
                len(incompatible.missing_keys),
            )
        elif args.training_prior_mode == 'tspe':
            model.load_state_dict(checkpoint)
            logger.info(
                "First+seventh checkpoint loaded for improvement 13 | path=%s | "
                "new_persistent_tensors=0",
                os.path.abspath(args.model_path),
            )
        elif args.cross_modal_retrieval_mode == 'scbr':
            incompatible = model.load_state_dict(checkpoint, strict=False)
            invalid_missing = [
                name for name in incompatible.missing_keys
                if not name.startswith('same_sample_bundle_retrieval.')
            ]
            if invalid_missing or incompatible.unexpected_keys:
                raise RuntimeError(
                    "seventh checkpoint mismatch | invalid_missing={} | "
                    "unexpected={}".format(
                        invalid_missing, incompatible.unexpected_keys
                    )
                )
            if not incompatible.missing_keys:
                raise RuntimeError(
                    "expected a clean seventh checkpoint without SCBR buffers"
                )
            model.set_bundle_injection_scale(0.0)
            logger.info(
                "First+seventh checkpoint loaded for improvement 12 | "
                "path=%s | new_scbr_tensors=%d",
                os.path.abspath(args.model_path),
                len(incompatible.missing_keys),
            )
        elif args.cross_modal_retrieval_mode == 'agcqr':
            incompatible = model.load_state_dict(checkpoint, strict=False)
            invalid_missing = [
                name for name in incompatible.missing_keys
                if not name.startswith('cross_modal_query_retrieval.')
            ]
            if invalid_missing or incompatible.unexpected_keys:
                raise RuntimeError(
                    "seventh checkpoint mismatch | invalid_missing={} | "
                    "unexpected={}".format(
                        invalid_missing, incompatible.unexpected_keys
                    )
                )
            if not incompatible.missing_keys:
                raise RuntimeError(
                    "expected a clean seventh checkpoint without AGCQR parameters"
                )
            model.cross_modal_query_retrieval.reset_identity()
            logger.info(
                "First+seventh checkpoint loaded for improvement 11 | "
                "path=%s | new_agcqr_tensors=%d",
                os.path.abspath(args.model_path),
                len(incompatible.missing_keys),
            )
        elif args.tag_mode == 'amtfb':
            incompatible = model.load_state_dict(checkpoint, strict=False)
            invalid_missing = [
                name for name in incompatible.missing_keys
                if not name.startswith('missing_tag_fusion_bias.')
            ]
            if invalid_missing or incompatible.unexpected_keys:
                raise RuntimeError(
                    "seventh checkpoint mismatch | invalid_missing={} | "
                    "unexpected={}".format(
                        invalid_missing, incompatible.unexpected_keys
                    )
                )
            if not incompatible.missing_keys:
                raise RuntimeError(
                    "expected a clean seventh checkpoint without AMTFB parameters"
                )
            model.missing_tag_fusion_bias.reset_identity()
            logger.info(
                "First+seventh checkpoint loaded for improvement 10 | "
                "path=%s | new_tag_tensors=%d",
                os.path.abspath(args.model_path),
                len(incompatible.missing_keys),
            )
        elif args.consensus_mode == 'amucr':
            incompatible = model.load_state_dict(checkpoint, strict=False)
            invalid_missing = [
                name for name in incompatible.missing_keys
                if not name.startswith('unified_consensus_residual.')
            ]
            if invalid_missing or incompatible.unexpected_keys:
                raise RuntimeError(
                    "seventh checkpoint mismatch | invalid_missing={} | "
                    "unexpected={}".format(
                        invalid_missing, incompatible.unexpected_keys
                    )
                )
            if not incompatible.missing_keys:
                raise RuntimeError(
                    "expected a clean seventh checkpoint without AMUCR parameters"
                )
            model.unified_consensus_residual.reset_identity()
            logger.info(
                "First+seventh checkpoint loaded for improvement 9 | "
                "path=%s | new_consensus_tensors=%d",
                os.path.abspath(args.model_path),
                len(incompatible.missing_keys),
            )
        elif args.reconstruction_mode == 'text_guided_nonverbal':
            incompatible = model.load_state_dict(checkpoint, strict=False)
            invalid_missing = [
                name for name in incompatible.missing_keys
                if not name.startswith('text_guided_reconstructor.')
            ]
            if invalid_missing or incompatible.unexpected_keys:
                raise RuntimeError(
                    "seventh checkpoint mismatch | invalid_missing={} | "
                    "unexpected={}".format(
                        invalid_missing, incompatible.unexpected_keys
                    )
                )
            if not incompatible.missing_keys:
                raise RuntimeError(
                    "expected a clean seventh checkpoint without "
                    "text-guided reconstruction parameters"
                )
            logger.info(
                "First+seventh checkpoint loaded for improvement 8 | "
                "path=%s | new_reconstruction_tensors=%d",
                os.path.abspath(args.model_path),
                len(incompatible.missing_keys),
            )
        elif args.prompt_mode == 'missing_dynamic':
            incompatible = model.load_state_dict(checkpoint, strict=False)
            invalid_missing = [
                name for name in incompatible.missing_keys
                if not name.startswith('dynamic_prompt_adapter.')
            ]
            if invalid_missing or incompatible.unexpected_keys:
                raise RuntimeError(
                    "q0 checkpoint mismatch | invalid_missing={} | "
                    "unexpected={}".format(
                        invalid_missing, incompatible.unexpected_keys
                    )
                )
            if not incompatible.missing_keys:
                raise RuntimeError(
                    "expected a q0 checkpoint without dynamic prompt parameters"
                )
            logger.info(
                "q0 checkpoint loaded for prompt tuning | path=%s | "
                "new_prompt_tensors=%d",
                os.path.abspath(args.model_path),
                len(incompatible.missing_keys),
            )
        else:
            model.load_state_dict(checkpoint)

    prompt_freeze = model.configure_missing_prompt_finetuning()
    if prompt_freeze is not None:
        logger.info(
            "Prompt fine-tuning freeze verified | trainable_parameters=%d | "
            "total_parameters=%d | trainable_tensors=%d",
            prompt_freeze['trainable_parameters'],
            prompt_freeze['total_parameters'],
            len(prompt_freeze['trainable_names']),
        )

    reconstruction_freeze = (
        model.configure_text_guided_reconstruction_finetuning()
    )
    if reconstruction_freeze is not None:
        logger.info(
            "Improvement-8 freeze verified | trainable_parameters=%d | "
            "total_parameters=%d | trainable_tensors=%d | "
            "fusion_all_trainable=false",
            reconstruction_freeze['trainable_parameters'],
            reconstruction_freeze['total_parameters'],
            len(reconstruction_freeze['trainable_names']),
        )

    consensus_freeze = model.configure_unified_consensus_finetuning()
    if consensus_freeze is not None:
        logger.info(
            "Improvement-9 freeze verified | trainable_parameters=%d | "
            "total_parameters=%d | trainable_tensors=%d | "
            "foundation_trainable=false | fusion_all_trainable=false",
            consensus_freeze['trainable_parameters'],
            consensus_freeze['total_parameters'],
            len(consensus_freeze['trainable_names']),
        )

    tag_freeze = model.configure_missing_tag_finetuning()
    if tag_freeze is not None:
        logger.info(
            "Improvement-10 freeze verified | trainable_parameters=%d | "
            "total_parameters=%d | trainable_tensors=%d | "
            "foundation_trainable=false | fusion_all_trainable=false",
            tag_freeze['trainable_parameters'],
            tag_freeze['total_parameters'],
            len(tag_freeze['trainable_names']),
        )

    cross_modal_retrieval_freeze = (
        model.configure_cross_modal_retrieval_finetuning()
    )
    if cross_modal_retrieval_freeze is not None:
        logger.info(
            "Improvement-11 freeze verified | trainable_parameters=%d | "
            "total_parameters=%d | trainable_tensors=%d | "
            "foundation_trainable=false | fusion_all_trainable=false",
            cross_modal_retrieval_freeze['trainable_parameters'],
            cross_modal_retrieval_freeze['total_parameters'],
            len(cross_modal_retrieval_freeze['trainable_names']),
        )

    bundle_retrieval_freeze = model.configure_bundle_retrieval_evaluation()
    if bundle_retrieval_freeze is not None:
        logger.info(
            "Improvement-12 freeze verified | trainable_parameters=0 | "
            "total_parameters=%d | foundation_trainable=false | "
            "fusion_all_trainable=false | selection=dev_scale_grid",
            bundle_retrieval_freeze['total_parameters'],
        )

    training_prior_freeze = model.configure_training_prior_head_finetuning()
    if training_prior_freeze is not None:
        invalid_trainable = [
            name for name in training_prior_freeze['trainable_names']
            if not name.startswith('fusion_all.')
        ]
        if invalid_trainable or not training_prior_freeze['trainable_names']:
            raise RuntimeError(
                "TSPE freeze mismatch | invalid_trainable={} | trainable={}".format(
                    invalid_trainable,
                    training_prior_freeze['trainable_names'],
                )
            )
        logger.info(
            "Improvement-13 freeze verified | trainable_parameters=%d | "
            "total_parameters=%d | trainable_tensors=%d | "
            "foundation_trainable=false | trainable=fusion_all",
            training_prior_freeze['trainable_parameters'],
            training_prior_freeze['total_parameters'],
            len(training_prior_freeze['trainable_names']),
        )

    hybrid_expert_freeze = (
        model.configure_availability_hybrid_expert_finetuning()
    )
    if hybrid_expert_freeze is not None:
        invalid_trainable = [
            name for name in hybrid_expert_freeze['trainable_names']
            if not name.startswith('availability_hybrid_expert_residual.')
        ]
        if invalid_trainable or not hybrid_expert_freeze['trainable_names']:
            raise RuntimeError(
                "ACHER freeze mismatch | invalid_trainable={} | trainable={}".format(
                    invalid_trainable,
                    hybrid_expert_freeze['trainable_names'],
                )
            )
        logger.info(
            "Improvement-14 freeze verified | trainable_parameters=%d | "
            "total_parameters=%d | trainable_tensors=%d | "
            "foundation_trainable=false | fusion_all_trainable=false | "
            "trainable=acher_only",
            hybrid_expert_freeze['trainable_parameters'],
            hybrid_expert_freeze['total_parameters'],
            len(hybrid_expert_freeze['trainable_names']),
        )

    protocol_fusion_freeze = (
        model.configure_protocol_consistency_finetuning()
    )
    if protocol_fusion_freeze is not None:
        adaptation_scope = (
            'fusion_all'
            if args.protocol_consistency_mode == 'pcmc'
            else args.protocol_adaptation_scope
        )
        if adaptation_scope == 'last_layer':
            allowed_prefixes = ('fusion_all.fusion_layer_all_all.',)
        elif adaptation_scope == 'fusion_all':
            allowed_prefixes = ('fusion_all.',)
        else:
            allowed_prefixes = ('transformer_encoder_all.', 'fusion_all.')
        invalid_trainable = [
            name for name in protocol_fusion_freeze['trainable_names']
            if not name.startswith(allowed_prefixes)
        ]
        if (
            invalid_trainable
            or not protocol_fusion_freeze['trainable_names']
        ):
            raise RuntimeError(
                "protocol fusion freeze mismatch | invalid_trainable={} | "
                "trainable={}".format(
                    invalid_trainable,
                    protocol_fusion_freeze['trainable_names'],
                )
            )
        logger.info(
            "Protocol fusion freeze verified | mode=%s | scope=%s | "
            "trainable_parameters=%d | "
            "total_parameters=%d | trainable_tensors=%d | "
            "feature_foundation_trainable=false",
            (
                'fixed_protocol_fusion_readaptation'
                if args.protocol_fusion_readaptation
                else 'pcmc_reproduction'
            ),
            adaptation_scope,
            protocol_fusion_freeze['trainable_parameters'],
            protocol_fusion_freeze['total_parameters'],
            len(protocol_fusion_freeze['trainable_names']),
        )

    missing_text_contrast_freeze = (
        model.configure_missing_text_contrast_finetuning()
    )
    if missing_text_contrast_freeze is not None:
        invalid_trainable = [
            name for name in missing_text_contrast_freeze['trainable_names']
            if not name.startswith('missing_text_contrast_residual.')
        ]
        if invalid_trainable or not missing_text_contrast_freeze['trainable_names']:
            raise RuntimeError(
                "LSCMR freeze mismatch | invalid_trainable={} | trainable={}".format(
                    invalid_trainable,
                    missing_text_contrast_freeze['trainable_names'],
                )
            )
        logger.info(
            "Improvement-17 freeze verified | trainable_parameters=%d | "
            "total_parameters=%d | trainable_tensors=%d | "
            "foundation_trainable=false | fusion_all_trainable=false | "
            "trainable=lscmr_only",
            missing_text_contrast_freeze['trainable_parameters'],
            missing_text_contrast_freeze['total_parameters'],
            len(missing_text_contrast_freeze['trainable_names']),
        )

    privileged_purification_freeze = (
        model.configure_privileged_purification_finetuning()
    )
    if privileged_purification_freeze is not None:
        prefix = 'privileged_disentangled_purification.'
        invalid_trainable = [
            name for name in privileged_purification_freeze['trainable_names']
            if not name.startswith(prefix)
        ]
        if (
            invalid_trainable
            or not privileged_purification_freeze['trainable_names']
        ):
            raise RuntimeError(
                "PDRP freeze mismatch | invalid_trainable={} | trainable={}".format(
                    invalid_trainable,
                    privileged_purification_freeze['trainable_names'],
                )
            )
        logger.info(
            "Improvement-18 freeze verified | trainable_parameters=%d | "
            "total_parameters=%d | trainable_tensors=%d | "
            "foundation_trainable=false | fusion_all_trainable=false | "
            "trainable=pdrp_only",
            privileged_purification_freeze['trainable_parameters'],
            privileged_purification_freeze['total_parameters'],
            len(privileged_purification_freeze['trainable_names']),
        )

    language_hyper_freeze = model.configure_language_hyper_finetuning()
    if language_hyper_freeze is not None:
        prefix = 'availability_tagged_language_hyper_residual.'
        invalid_trainable = [
            name for name in language_hyper_freeze['trainable_names']
            if not name.startswith(prefix)
        ]
        if invalid_trainable or not language_hyper_freeze['trainable_names']:
            raise RuntimeError(
                "AT-LDHR freeze mismatch | invalid_trainable={} | "
                "trainable={}".format(
                    invalid_trainable,
                    language_hyper_freeze['trainable_names'],
                )
            )
        logger.info(
            "Improvement-19 freeze verified | trainable_parameters=%d | "
            "total_parameters=%d | trainable_tensors=%d | "
            "foundation_trainable=false | fusion_all_trainable=false | "
            "trainable=at_ldhr_only",
            language_hyper_freeze['trainable_parameters'],
            language_hyper_freeze['total_parameters'],
            len(language_hyper_freeze['trainable_names']),
        )

    coupled_prompt_freeze = model.configure_coupled_prompt_finetuning()
    if coupled_prompt_freeze is not None:
        prefix = 'layerwise_coupled_missing_prompt.'
        invalid_trainable = [
            name for name in coupled_prompt_freeze['trainable_names']
            if not name.startswith(prefix)
        ]
        if invalid_trainable or not coupled_prompt_freeze['trainable_names']:
            raise RuntimeError(
                "LCMPR freeze mismatch | invalid_trainable={} | "
                "trainable={}".format(
                    invalid_trainable,
                    coupled_prompt_freeze['trainable_names'],
                )
            )
        logger.info(
            "Improvement-20 freeze verified | trainable_parameters=%d | "
            "total_parameters=%d | trainable_tensors=%d | "
            "foundation_trainable=false | fusion_all_trainable=false | "
            "trainable=lcmpr_only",
            coupled_prompt_freeze['trainable_parameters'],
            coupled_prompt_freeze['total_parameters'],
            len(coupled_prompt_freeze['trainable_names']),
        )

    relation_distill_freeze = (
        model.configure_relation_distillation_finetuning()
    )
    if relation_distill_freeze is not None:
        allowed_prefixes = ('transformer_encoder_all.', 'fusion_all.')
        invalid_trainable = [
            name for name in relation_distill_freeze['trainable_names']
            if not name.startswith(allowed_prefixes)
        ]
        trainable_prefixes = {
            name.split('.', 1)[0]
            for name in relation_distill_freeze['trainable_names']
        }
        if (
            invalid_trainable
            or trainable_prefixes != {'transformer_encoder_all', 'fusion_all'}
        ):
            raise RuntimeError(
                "TAG-MRD freeze mismatch | invalid_trainable={} | "
                "trainable_prefixes={}".format(
                    invalid_trainable, sorted(trainable_prefixes)
                )
            )
        logger.info(
            "Improvement-16 freeze verified | trainable_parameters=%d | "
            "total_parameters=%d | trainable_tensors=%d | "
            "feature_foundation_trainable=false | "
            "trainable=transformer_encoder_all+fusion_all",
            relation_distill_freeze['trainable_parameters'],
            relation_distill_freeze['total_parameters'],
            len(relation_distill_freeze['trainable_names']),
        )

    total_para = sum(parameter.numel() for parameter in model.parameters())
    trainable_para = sum(
        parameter.numel() for parameter in model.parameters()
        if parameter.requires_grad
    )
    logger.info(
        "Total parameters: %s | trainable parameters: %s",
        total_para,
        trainable_para,
    )

    model.to(DEVICE)

    return model


def build_cross_modal_reference_banks(model, train_dataloader):
    """Build aligned complete-training banks for AGCQR or SCBR."""
    if args.cross_modal_retrieval_mode not in ('agcqr', 'scbr'):
        return None
    item_count = len(train_dataloader.dataset)
    bank_size = min(args.cross_modal_reference_bank_size, item_count)
    generator = torch.Generator(device='cpu')
    generator.manual_seed(args.cross_modal_reference_seed)
    selected = torch.randperm(
        item_count, generator=generator
    )[:bank_size].tolist()
    bank_dataset = Subset(train_dataloader.dataset, selected)
    sequential_loader = DataLoader(
        bank_dataset,
        batch_size=args.dev_batch_size,
        shuffle=False,
    )
    collected = {'l': [], 'a': [], 'v': []}
    collected_labels = []
    was_training = model.training
    model.eval()
    with torch.no_grad():
        for batch in tqdm(sequential_loader, desc="Complete reference bank"):
            batch = tuple(t.to(DEVICE) for t in batch)
            (
                input_ids,
                visual,
                acoustic,
                input_mask,
                segment_ids,
                label_ids,
                sample_ids,
            ) = unpack_dataset_batch(batch)
            visual = torch.squeeze(visual, 1)
            acoustic = torch.squeeze(acoustic, 1)
            features = model.encode_complete_raw_features(
                input_ids,
                visual,
                acoustic,
                attention_mask=input_mask,
                token_type_ids=segment_ids,
            )
            for modality, feature in zip(('l', 'a', 'v'), features):
                collected[modality].append(feature.detach().cpu())
            collected_labels.append(label_ids.detach().view(-1).cpu())

    banks = {
        modality: torch.cat(chunks, dim=0)
        for modality, chunks in collected.items()
    }
    banks = {
        modality: bank.to(DEVICE)
        for modality, bank in banks.items()
    }
    labels = torch.cat(collected_labels, dim=0).to(DEVICE)
    if args.cross_modal_retrieval_mode == 'agcqr':
        model.set_cross_modal_reference_banks(banks)
    else:
        model.set_bundle_reference_bank(banks, labels)
    if was_training:
        model.train()
        if args.cross_modal_retrieval_mode == 'agcqr':
            model.enforce_cross_modal_retrieval_finetune_mode()
    logger.info(
        "%s reference banks built | source=train_complete_only | "
        "available=%d | selected=%d | seed=%d | sizes_l/a/v=%d/%d/%d",
        args.cross_modal_retrieval_mode.upper(),
        item_count,
        bank_size,
        args.cross_modal_reference_seed,
        banks['l'].size(0),
        banks['a'].size(0),
        banks['v'].size(0),
    )
    return banks, labels


def build_strict_retrieval_reference_banks(model, train_bank_dataloader):
    """Rebuild E01 donors exclusively from complete training samples."""
    if args.retrieval_candidate_source != 'train_bank':
        return None
    if args.retrieval_mode != 'missing_aware':
        raise RuntimeError("strict train banks require missing-aware retrieval")

    collected = {'l': [], 'a': [], 'v': []}
    collected_ids = []
    was_training = model.training
    model.eval()
    with torch.no_grad():
        for batch in tqdm(
            train_bank_dataloader,
            desc="Strict complete-training retrieval bank",
        ):
            batch = tuple(t.to(DEVICE) for t in batch)
            (
                input_ids,
                visual,
                acoustic,
                input_mask,
                segment_ids,
                label_ids,
                sample_ids,
            ) = unpack_dataset_batch(batch)
            visual = torch.squeeze(visual, 1)
            acoustic = torch.squeeze(acoustic, 1)
            features = model.encode_complete_raw_features(
                input_ids,
                visual,
                acoustic,
                attention_mask=input_mask,
                token_type_ids=segment_ids,
            )
            for modality, feature in zip(('l', 'a', 'v'), features):
                collected[modality].append(feature.detach().cpu())
            collected_ids.append(sample_ids.detach().view(-1).cpu())

    banks = {
        modality: torch.cat(chunks, dim=0)
        for modality, chunks in collected.items()
    }
    sample_ids = torch.cat(collected_ids, dim=0)
    expected_count = len(train_bank_dataloader.dataset)
    if sample_ids.numel() != expected_count:
        raise RuntimeError(
            "strict train bank count mismatch: expected {}, got {}".format(
                expected_count, sample_ids.numel()
            )
        )
    if torch.unique(sample_ids).numel() != expected_count:
        raise RuntimeError("strict train bank contains duplicate sample ids")
    expected_ids = torch.arange(
        expected_count, device=sample_ids.device, dtype=torch.long
    )
    if not torch.equal(torch.sort(sample_ids).values, expected_ids):
        raise RuntimeError(
            "strict train bank ids do not cover the complete training split"
        )

    subset_indices = deterministic_retrieval_bank_subset_indices(
        sample_ids,
        requested_size=args.retrieval_reference_bank_size,
        subset_seed=args.retrieval_reference_bank_seed,
    )
    banks = {
        modality: bank.index_select(0, subset_indices).to(DEVICE)
        for modality, bank in banks.items()
    }
    sample_ids = sample_ids.index_select(0, subset_indices).to(DEVICE)
    actual_count = int(sample_ids.numel())
    id_payload = ",".join(str(int(value)) for value in sample_ids.cpu().tolist())
    selected_ids_sha256 = hashlib.sha256(id_payload.encode("ascii")).hexdigest()

    model.set_strict_retrieval_reference_banks(banks, sample_ids)
    if was_training:
        model.train()
    logger.info(
        "E01 strict retrieval banks built | source=train_complete_only | "
        "validation_donors=0 | test_donors=0 | self_exclusion_ids=true | "
        "runtime_only=true | available=%d | requested=%s | selected=%d | "
        "subset_seed=%d | selected_ids_sha256=%s | dims_l/a/v=%d/%d/%d",
        expected_count,
        "full" if args.retrieval_reference_bank_size == 0 else str(
            args.retrieval_reference_bank_size
        ),
        actual_count,
        args.retrieval_reference_bank_seed,
        selected_ids_sha256,
        banks['l'].size(1),
        banks['a'].size(1),
        banks['v'].size(1),
    )
    return {
        'source': 'complete_training_split_only',
        'available_count': expected_count,
        'requested_size': int(args.retrieval_reference_bank_size),
        'requested_size_label': (
            'full' if args.retrieval_reference_bank_size == 0
            else str(args.retrieval_reference_bank_size)
        ),
        'actual_size': actual_count,
        'subset_seed': int(args.retrieval_reference_bank_seed),
        'selection': 'sha256_seeded_sample_id_nested_prefix',
        'selected_ids_sha256': selected_ids_sha256,
        'validation_donors': 0,
        'test_donors': 0,
        'self_exclusion_ids': True,
        'runtime_only': True,
    }


def adjust_learning_rate(optimizer, epoch, args):
    """Decay the learning rate based on schedule"""
    lr = args.learning_rate
    if args.cos: 
        lr *= 0.5 * (1. + math.cos(math.pi * epoch / args.n_epochs))
    else: 
        for milestone in args.schedule:
            lr *= 0.1 if epoch >= milestone else 1.
    for param_group in optimizer.param_groups:
        param_group['lr'] = lr * param_group.get('lr_multiplier', 1.0)

parser = argparse.ArgumentParser(description='IIEModel')
parser.add_argument('-f', default='', type=str)
parser.add_argument("--dataset", type=str,
                    choices=["mosi", "mosei"], default="mosei")
parser.add_argument("--alignment", type=str, choices=["align", "unalign"],
                    default="align",
                    help="feature alignment mode (the released datasets are aligned)")
parser.add_argument("--max_seq_length", type=int, default=50)
parser.add_argument("--train_batch_size", type=int, default=256)
parser.add_argument("--dev_batch_size", type=int, default=128)
parser.add_argument("--test_batch_size", type=int, default=128)
parser.add_argument("--n_epochs", type=int, default=100)
parser.add_argument('--out_dropout', type=float, default=0.1,
                    help='output layer dropout')
parser.add_argument('--dropout', type=float, default=0.1,
                    help='classifier dropout')
parser.add_argument('--similarity_threshold', type=float, default=0.6,
                    help='threshold of the similarity')# for 3 modalities, shoud be [0.0, 0.7]
parser.add_argument('--retrieval_top_k', type=int, default=2,
                    help='number of observed same-modality neighbours')
parser.add_argument('--retrieval_mode', type=str, default='missing_aware',
                    choices=['legacy', 'missing_aware'],
                    help='legacy IIE retrieval or the proposed missing-aware retrieval')
parser.add_argument('--retrieval_queue_size', type=int, default=0,
                    help='FIFO memory size per modality; 0 means batch-only retrieval')
parser.add_argument(
    '--retrieval_candidate_source',
    type=str,
    default='batch',
    choices=['batch', 'train_bank'],
    help='current batch/queue or a strict complete-training donor bank',
)
parser.add_argument(
    '--retrieval_candidate_filter',
    type=str,
    default='observed_only',
    choices=['observed_only', 'all'],
    help='E12 control: exclude missing placeholders or allow all candidates',
)
parser.add_argument(
    '--retrieval_composition',
    type=str,
    default='prototype_neighbours',
    choices=['prototype_only', 'neighbours_only', 'prototype_neighbours'],
    help='E12 control for the retrieved prototype/neighbour slots',
)
parser.add_argument(
    '--retrieval_selection',
    type=str,
    default='similarity',
    choices=['similarity', 'random'],
    help='E12 similarity retrieval or deterministic random-donor control',
)
parser.add_argument(
    '--retrieval_random_seed',
    type=int,
    default=3407,
    help='stateless E12 random-donor seed',
)
parser.add_argument(
    '--retrieval_bank_batch_size',
    type=int,
    default=256,
    help='batch size used to rebuild strict complete-training banks',
)
parser.add_argument(
    '--retrieval_bank_refresh_epochs',
    type=int,
    default=1,
    help='refresh strict train banks after this many training epochs',
)
parser.add_argument(
    '--retrieval_reference_bank_size',
    type=int,
    default=0,
    help='strict donor-bank size; 0 uses the complete training split',
)
parser.add_argument(
    '--retrieval_reference_bank_seed',
    type=int,
    default=3407,
    help='fixed sample-id ranking seed for finite strict donor banks',
)
parser.add_argument('--retrieval_temperature', type=float, default=0.1,
                    help='softmax temperature for neighbour similarity weights')
parser.add_argument('--retrieval_metric_mode', type=str, default='raw',
                    choices=['raw', 'sentiment_guided'],
                    help='raw cosine similarity or a label-supervised retrieval space')
parser.add_argument('--retrieval_projection_dim', type=int, default=64,
                    help='dimension of each sentiment-guided retrieval projection')
parser.add_argument('--retrieval_missing_query', type=str, default='center',
                    choices=['center', 'sample'],
                    help='q0 modality centre or an eh_sample-specific missing query')
parser.add_argument('--retrieval_label_temperature', type=float, default=0.5,
                    help='temperature of continuous-label soft retrieval targets')
parser.add_argument('--retrieval_loss_weight', type=float, default=0.1,
                    help='weight of the sentiment-guided retrieval KL objective')
parser.add_argument('--cross_modal_retrieval_mode', type=str, default='none',
                    choices=['none', 'agcqr', 'scbr'],
                    help='improvement-11 AGCQR or improvement-12 same-sample '
                         'bundle retrieval')
parser.add_argument('--cross_modal_retrieval_hidden_dim', type=int, default=128,
                    help='hidden dimension of each AGCQR source-to-target mapper')
parser.add_argument('--cross_modal_retrieval_temperature', type=float, default=0.1,
                    help='temperature for AGCQR train-bank neighbour weighting')
parser.add_argument('--cross_modal_match_temperature', type=float, default=0.1,
                    help='temperature of the AGCQR paired matching objective')
parser.add_argument('--cross_modal_match_loss_weight', type=float, default=0.05,
                    help='weight of the AGCQR in-batch matching objective')
parser.add_argument('--cross_modal_retrieval_learning_rate', type=float, default=1e-3,
                    help='learning rate for isolated AGCQR parameters')
parser.add_argument('--cross_modal_reference_bank_size', type=int, default=4096,
                    help='maximum complete training representations per modality')
parser.add_argument('--cross_modal_reference_seed', type=int, default=3407,
                    help='deterministic seed used to subsample the train-only bank')
parser.add_argument('--bundle_retrieval_temperature', type=float, default=0.1,
                    help='softmax temperature for SCBR donor slots')
parser.add_argument('--bundle_sentiment_weight', type=float, default=0.25,
                    help='weight of the frozen-prediction sentiment penalty')
parser.add_argument('--bundle_sentiment_temperature', type=float, default=0.5,
                    help='scale of continuous donor-label differences')
parser.add_argument('--bundle_injection_scales', type=str,
                    default='0,0.1,0.25,0.5,1.0',
                    help='comma-separated SCBR scales selected by dev MAE')
parser.add_argument('--training_prior_mode', type=str, default='none',
                    choices=['none', 'tspe'],
                    help='improvement-13 training-only similar-prior enhancement')
parser.add_argument('--training_prior_mix_ratio', type=float, default=0.1,
                    help='TSPE neighbour mixture ratio')
parser.add_argument('--training_prior_top_k', type=int, default=2,
                    help='number of qualifying TSPE neighbours required')
parser.add_argument('--training_prior_similarity_min', type=float, default=0.90,
                    help='lower cosine bound for TSPE candidates')
parser.add_argument('--training_prior_similarity_max', type=float, default=0.95,
                    help='upper cosine bound for TSPE candidates')
parser.add_argument('--training_prior_score_temperature', type=float, default=0.1,
                    help='TSPE donor softmax temperature')
parser.add_argument('--training_prior_label_weight', type=float, default=0.25,
                    help='continuous-label penalty in TSPE donor ranking')
parser.add_argument('--training_prior_label_temperature', type=float, default=0.5,
                    help='scale of TSPE continuous-label differences')
parser.add_argument('--hybrid_expert_mode', type=str, default='none',
                    choices=['none', 'acher'],
                    help='improvement-14 availability-constrained hybrid '
                         'expert residual')
parser.add_argument('--hybrid_expert_hidden_dim', type=int, default=64,
                    help='hidden dimension of ACHER experts and routers')
parser.add_argument('--hybrid_expert_private_count', type=int, default=3,
                    help='number of private experts per modality')
parser.add_argument('--hybrid_expert_shared_count', type=int, default=3,
                    help='number of parameter-shared experts')
parser.add_argument('--hybrid_expert_dropout', type=float, default=0.1,
                    help='dropout inside ACHER experts and residual head')
parser.add_argument('--hybrid_expert_initial_temperature', type=float,
                    default=None,
                    help='initial positive routing temperature; default is '
                         '1/(private+shared experts)')
parser.add_argument('--hybrid_expert_orthogonality_weight', type=float,
                    default=0.01,
                    help='weight of squared-cosine private/shared separation')
parser.add_argument('--hybrid_expert_learning_rate', type=float, default=1e-3,
                    help='learning rate for the isolated ACHER branch')
parser.add_argument('--protocol_consistency_mode', type=str, default='none',
                    choices=['none', 'pcmc'],
                    help='improvement-15 protocol-conditioned complete-to-'
                         'missing polarity consistency')
parser.add_argument('--protocol_consistency_weight', type=float, default=0.01,
                    help='weight of the confidence-gated polarity KL loss')
parser.add_argument('--protocol_consistency_temperature', type=float,
                    default=0.5,
                    help='temperature for converting regression predictions '
                         'to two-class polarity probabilities')
parser.add_argument('--protocol_consistency_confidence', type=float,
                    default=0.95,
                    help='minimum complete-view teacher polarity confidence')
parser.add_argument('--protocol_consistency_learning_rate', type=float,
                    default=1e-4,
                    help='learning rate for isolated fusion_all re-adaptation')
parser.add_argument('--protocol_fusion_readaptation', action='store_true',
                    help='retained improvement-15: second-stage fixed-protocol '
                         'fusion_all re-adaptation without a teacher branch')
parser.add_argument('--protocol_fusion_learning_rate', type=float, default=1e-4,
                    help='learning rate for retained fixed-protocol fusion_all '
                         're-adaptation')
parser.add_argument('--protocol_adaptation_scope', type=str,
                    default='fusion_all',
                    choices=['last_layer', 'fusion_all',
                             'late_transformer_fusion'],
                    help='E13 trainable scope for fixed-protocol adaptation')
parser.add_argument('--protocol_transformer_learning_rate', type=float,
                    default=2e-5,
                    help='E13 learning rate for transformer_encoder_all when '
                         'late fusion is unfrozen')
parser.add_argument('--relation_distill_mode', type=str, default='none',
                    choices=['none', 'tag_mrd'],
                    help='improvement-16 teacher-advantage-gated modality '
                         'relation distillation')
parser.add_argument('--relation_distill_weight', type=float, default=0.01,
                    help='weight of the enhanced-modality cosine graph loss')
parser.add_argument('--relation_distill_advantage_margin', type=float,
                    default=0.0,
                    help='minimum teacher MAE advantage required per sample')
parser.add_argument('--relation_distill_transformer_learning_rate', type=float,
                    default=2e-5,
                    help='TAG-MRD learning rate for transformer_encoder_all')
parser.add_argument('--relation_distill_fusion_learning_rate', type=float,
                    default=1e-4,
                    help='TAG-MRD learning rate for fusion_all')
parser.add_argument('--missing_text_contrast_mode', type=str, default='none',
                    choices=['none', 'feature', 'label'],
                    help='improvement-17 missing-text residual with ordinary '
                         'or label-semantic in-batch contrast')
parser.add_argument('--missing_text_contrast_hidden_dim', type=int, default=128,
                    help='hidden dimension of the isolated missing-text adapter')
parser.add_argument('--missing_text_contrast_max_scale', type=float, default=1.0,
                    help='absolute bound of the missing-text residual scale')
parser.add_argument('--missing_text_contrast_temperature', type=float,
                    default=0.5,
                    help='InfoNCE temperature for missing-text candidates')
parser.add_argument('--missing_text_pair_loss_weight', type=float, default=0.1,
                    help='weight of paired complete-text reconstruction')
parser.add_argument('--missing_text_contrast_loss_weight', type=float,
                    default=0.01,
                    help='weight of ordinary or label-semantic InfoNCE')
parser.add_argument('--missing_text_contrast_learning_rate', type=float,
                    default=1e-3,
                    help='learning rate for the isolated improvement-17 adapter')
parser.add_argument('--privileged_purification_mode', type=str, default='none',
                    choices=['none', 'task_only', 'full'],
                    help='improvement-18 PDRP matched task-only control or '
                         'full privileged disentanglement')
parser.add_argument('--privileged_purification_hidden_dim', type=int,
                    default=128,
                    help='hidden dimension of the isolated PDRP adapter')
parser.add_argument('--privileged_purification_subspace_dim', type=int,
                    default=64,
                    help='shared and complementary PDRP subspace dimension')
parser.add_argument('--privileged_purification_max_scale', type=float,
                    default=1.0,
                    help='absolute bound for each missing-token residual scale')
parser.add_argument('--privileged_purification_shared_weight', type=float,
                    default=0.05,
                    help='complete-view shared-consensus alignment weight')
parser.add_argument('--privileged_purification_orthogonality_weight',
                    type=float, default=0.01,
                    help='shared/complementary squared-cosine loss weight')
parser.add_argument('--privileged_purification_separation_weight', type=float,
                    default=0.01,
                    help='complementary modality margin loss weight')
parser.add_argument('--privileged_purification_separation_margin', type=float,
                    default=1.0,
                    help='minimum pairwise complementary subspace distance')
parser.add_argument('--privileged_purification_learning_rate', type=float,
                    default=1e-3,
                    help='learning rate for the isolated PDRP adapter')
parser.add_argument('--language_hyper_mode', type=str, default='none',
                    choices=['none', 'availability_only', 'language_query'],
                    help='improvement-19 availability-only control or '
                         'language-query hyper residual')
parser.add_argument('--language_hyper_hidden_dim', type=int, default=128,
                    help='hidden dimension of the isolated AT-LDHR adapter')
parser.add_argument('--language_hyper_max_scale', type=float, default=0.5,
                    help='absolute bound of the language residual scale')
parser.add_argument('--language_hyper_learning_rate', type=float, default=1e-3,
                    help='learning rate for the isolated AT-LDHR adapter')
parser.add_argument('--coupled_prompt_mode', type=str, default='none',
                    choices=['none', 'lcmpr'],
                    help='improvement-20 layerwise coupled missing prompt')
parser.add_argument('--coupled_prompt_depth', type=int, default=2,
                    help='number of frozen fusion layers receiving prompts')
parser.add_argument('--coupled_prompt_length', type=int, default=2,
                    help='prompt-bank entries per layer and modality')
parser.add_argument('--coupled_prompt_hidden_dim', type=int, default=64,
                    help='context encoder width for LCMPR')
parser.add_argument('--coupled_prompt_max_scale', type=float, default=0.5,
                    help='absolute bound for each LCMPR residual scale')
parser.add_argument('--coupled_prompt_init_std', type=float, default=0.02,
                    help='Gaussian initialization standard deviation')
parser.add_argument('--coupled_prompt_learning_rate', type=float, default=1e-3,
                    help='learning rate for the isolated LCMPR adapter')
parser.add_argument('--consistency_mode', type=str, default='mixed',
                    choices=['mixed', 'status_separated', 'observed_only', 'none'],
                    help='MMD consistency objective: original mixed batch, '
                         'availability-separated, observed-only, or disabled')
parser.add_argument('--consistency_min_group_size', type=int, default=2,
                    help='minimum samples required for a masked MMD subgroup')
parser.add_argument('--consistency_log_interval', type=int, default=0,
                    help='log per-batch MMD diagnostics every N batches; '
                         '0 keeps epoch summaries only')
parser.add_argument('--distill_mode', type=str, default='none',
                    choices=['none', 'paired_hierarchical'],
                    help='frozen complete-to-incomplete distillation ablation')
parser.add_argument('--distill_sample_weight', type=float, default=0.05,
                    help='weight of paired eh_sample representation alignment')
parser.add_argument('--distill_fusion_weight', type=float, default=0.05,
                    help='weight of paired final fusion representation alignment')
parser.add_argument('--pns_audit', action='store_true',
                    help='run a read-only PNS audit on a frozen q0 checkpoint')
parser.add_argument('--pns_threshold', type=float, default=1.0,
                    help='absolute-error correctness threshold for PNS events')
parser.add_argument('--fusion_mode', type=str, default='flat',
                    choices=['flat', 'availability_multistage'],
                    help='active flat q0 fusion or the frozen failed sixth '
                         'availability-guided multi-stage ablation')
parser.add_argument('--prompt_mode', type=str, default='none',
                    choices=['none', 'missing_dynamic'],
                    help='optional missing-only dynamic prompt adapter on a '
                         'frozen q0 checkpoint')
parser.add_argument('--prompt_finetune_scope', type=str, default='prompt_head',
                    choices=['prompt_head', 'head_only'],
                    help='seventh-improvement ablation: tune both the dynamic '
                         'prompt and fusion head, or bypass the prompt and tune '
                         'only fusion_all')
parser.add_argument('--prompt_hidden_dim', type=int, default=32,
                    help='hidden size of the shared prompt weighting network')
parser.add_argument('--prompt_modality_embedding_dim', type=int, default=8,
                    help='modality identity embedding size for dynamic prompts')
parser.add_argument('--prompt_max_scale', type=float, default=1.0,
                    help='absolute bound of each learnable prompt residual scale')
parser.add_argument('--prompt_init_std', type=float, default=0.02,
                    help='initial standard deviation of absent prompt vectors')
parser.add_argument('--prompt_learning_rate', type=float, default=1e-3,
                    help='learning rate for the dynamic prompt adapter')
parser.add_argument('--reconstruction_mode', type=str, default='none',
                    choices=['none', 'text_guided_nonverbal'],
                    help='frozen failed improvement-8 text-guided '
                         'reconstruction ablation; explicit reproduction only')
parser.add_argument('--reconstruction_hidden_dim', type=int, default=128,
                    help='hidden dimension of each audio/video reconstructor')
parser.add_argument('--reconstruction_max_scale', type=float, default=1.0,
                    help='absolute bound of reconstruction injection scales')
parser.add_argument('--reconstruction_learning_rate', type=float, default=1e-3,
                    help='learning rate for the isolated reconstruction adapter')
parser.add_argument('--reconstruction_loss_weight', type=float, default=0.1,
                    help='weight of missing-only Smooth L1 reconstruction loss')
parser.add_argument('--consensus_mode', type=str, default='none',
                    choices=['none', 'amucr'],
                    help='frozen failed improvement-9 availability-masked '
                         'unified consensus residual; reproduction only')
parser.add_argument('--consensus_num_heads', type=int, default=4,
                    help='attention heads used by the AMUCR consensus token')
parser.add_argument('--consensus_num_layers', type=int, default=2,
                    help='number of consensus cross-attention layers')
parser.add_argument('--consensus_hidden_dim', type=int, default=96,
                    help='hidden size of the AMUCR sentiment residual head')
parser.add_argument('--consensus_dropout', type=float, default=0.1,
                    help='dropout inside the AMUCR branch')
parser.add_argument('--consensus_learning_rate', type=float, default=1e-3,
                    help='learning rate for the isolated AMUCR branch')
parser.add_argument('--tag_mode', type=str, default='none',
                    choices=['none', 'amtfb'],
                    help='frozen failed improvement-10 additive missing-tag '
                         'fusion bias; reproduction only')
parser.add_argument('--tag_learning_rate', type=float, default=1e-3,
                    help='learning rate for the isolated AMTFB projection')
parser.add_argument('--gate_mode', type=str, default='none',
                    choices=['none', 'reliability', 'reliability_v1',
                             'quality_reliability',
                             'quality_reliability_v22',
                             'counterfactual_harm_v23',
                             'counterfactual_scale_v24',
                             'fixed_scale_ablation'],
                    help='optional enhanced-feature calibration before fusion')
parser.add_argument('--gate_hidden_dim', type=int, default=32,
                    help='hidden dimension of the reliability gate')
parser.add_argument('--gate_dropout', type=float, default=0.0,
                    help='V1 gate dropout; V2 is deterministic and does not use dropout')
parser.add_argument('--gate_max_adjustment', type=float, default=0.5,
                    help='V1 maximum residual adjustment; must be in [0, 1)')
parser.add_argument('--gate_min_scale', type=float, default=0.7,
                    help='minimum V2 enhanced-feature multiplier')
parser.add_argument('--gate_fixed_scale', type=float, default=0.85,
                    help='uniform enhanced-feature scale for the parameter-free ablation')
parser.add_argument('--gate_init_bias', type=float, default=4.0,
                    help='V2.1 reliability-head bias for near-identity initialization')
parser.add_argument('--gate_init_scale', type=float, default=0.98,
                    help='V2.2 initial enhanced-feature multiplier')
parser.add_argument('--gate_init_harm_probability', type=float, default=0.02,
                    help='V2.3 initial probability that an enhancement is harmful')
parser.add_argument('--gate_teacher_mid_scale', type=float, default=0.85,
                    help='V2.4 middle executable scale used by the counterfactual teacher')
parser.add_argument('--gate_scale_loss_beta', type=float, default=0.05,
                    help='V2.4 Smooth-L1 transition point in scale units')
parser.add_argument('--gate_max_residual_logit', type=float, default=8.0,
                    help='V2.4 bound on the sample-quality residual logit')
parser.add_argument('--gate_init_seed', type=int, default=3407,
                    help='isolated initialization seed for the V2 gate')
parser.add_argument('--gate_lr_multiplier', type=float, default=10.0,
                    help='quality-gate learning-rate multiplier over the backbone')
parser.add_argument('--gate_cf_loss_weight', type=float, default=0.2,
                    help='V2.3 counterfactual harm-supervision loss weight')
parser.add_argument('--gate_cf_warmup_epochs', type=int, default=5,
                    help='epochs before enabling V2.3 counterfactual supervision')
parser.add_argument('--gate_scale_loss_weight', type=float, default=1.0,
                    help='V2.4 counterfactual scale-regression loss weight')
parser.add_argument('--gate_scale_warmup_epochs', type=int, default=5,
                    help='epochs before enabling V2.4 scale supervision')
parser.add_argument(
    "--model",
    type=str,
    choices=["bert-base-uncased"],
    default="bert-base-uncased",
)
parser.add_argument("--learning_rate", type=float, default=2e-5)
parser.add_argument("--gradient_accumulation_step", type=int, default=1)
parser.add_argument("--d_l", type=int, default=96)
parser.add_argument("--seed", type=int, default=5576)
parser.add_argument("--missing_rate", type=float, default=0.3) #from 0.1 to 0.7
parser.add_argument("--attn_dropout", type=float, default=0.5)
parser.add_argument("--num_heads", type=int, default=16)
parser.add_argument("--relu_dropout", type=float, default=0.3)
parser.add_argument("--res_dropout", type=float, default=0.3)
parser.add_argument("--attn_dropout_v", type=float, default=0.0)
parser.add_argument("--alpha", type=float, default=0.1)
parser.add_argument("--embed_dropout", type=float, default=0.2)
parser.add_argument('--wd', '--weight-decay', default=1e-4, type=float,
                    metavar='W', help='weight decay (default: 1e-4)',
                    dest='weight_decay')
parser.add_argument('--schedule', default=[180, 200], nargs='*', type=int,
                    help='learning rate schedule (when to drop lr by 10x)')# needs to adjust based on n_epochs []
parser.add_argument("--adam_epsilon", default=1e-8, type=float, help="Epsilon for Adam optimizer.")
parser.add_argument('--fixed_protocol', type=str, default='0',choices=['0', '1', '2', '3', '4', '5', '6'],
                    help='fixed missing modalities')
parser.add_argument('--fixed_missing', action="store_true",default=True,
                    help='fixed missing strategy')
parser.add_argument("--load", type=int, default=0)
parser.add_argument("--test", type=int, default=0)
parser.add_argument("--model_path", type=str, default='bert_tm.pth')
parser.add_argument('--cos', action='store_true',
                    help='use cosine lr schedule')
parser.add_argument('--layers', type=int, default=3,
                    help='layers of the transformer encoders')
parser.add_argument('--hyper_depth', type=int, default=2,
                    help='number of layers in the latent transformers')
parser.add_argument('--latent_layers', type=int, default=2,
                    help='layers of the latent transformer')
parser.add_argument('--num_latents', type=int, default=5,
                    help='number of learnable latents')
parser.add_argument('--latent_dim', type=int, default=96,
                    help='hidden_dimensions of the learnable units')
parser.add_argument('--weights_threshold', type=float, default=0.2,
                    help='weight of the threshold')
parser.add_argument('--clip', type=float, default=0.8,
                    help='gradient clip value (default: 0.8)')
parser.add_argument('--lr_decrease', type=str, default='cos', help='the methods of learning rate decay')
parser.add_argument('--lr_warmup', type=int, default=1)
parser.add_argument('--weight_decay', type=float, default=5e-4)
parser.add_argument('--early_stopping_patience', type=int, default=0,
                    help='stop after this many epochs without dev-loss improvement; '
                         '0 disables early stopping')
parser.add_argument('--early_stopping_min_delta', type=float, default=0.0,
                    help='minimum dev-loss decrease required to count as improvement')
parser.add_argument('--best_model_dir', type=str, default='best_modules',
                    help='directory used to save the best model for each run')
parser.add_argument('--log_dir', type=str, default='train_logs',
                    help='directory used to save training logs')
parser.add_argument('--paper_experiment', action='store_true',
                    help='enable isolated publication-quality run recording')
parser.add_argument('--paper_run_id', type=str, default='',
                    help='unique immutable identifier for a formal paper run')
parser.add_argument('--paper_method_id', type=str, default='',
                    help='formal method identifier, for example M0 or M1')
parser.add_argument('--paper_stage_id', type=str, default='',
                    help='formal experiment stage identifier, for example E04')
parser.add_argument(
    '--paper_parent_run_id',
    type=str,
    default='',
    help='formal parent run required by staged methods M2 and M3',
)
parser.add_argument(
    '--paper_manifest_dir',
    type=str,
    default='paper_experiments/manifests',
    help='directory for immutable per-run paper manifests',
)
parser.add_argument(
    '--paper_e19_prediction_output',
    type=str,
    default='',
    help='E19 post-hoc path for immutable fixed-protocol test predictions',
)
parser.add_argument(
    '--paper_e19_source_run_id',
    type=str,
    default='',
    help='frozen E06R1 source run recorded in an E19 prediction export',
)


args = parser.parse_args()
torch.manual_seed(args.seed)
dataset = str.lower(args.dataset.strip())
if args.paper_experiment:
    if not args.paper_run_id:
        parser.error('--paper_run_id is required with --paper_experiment')
    if not args.paper_method_id:
        parser.error('--paper_method_id is required with --paper_experiment')
    if not args.paper_stage_id:
        parser.error('--paper_stage_id is required with --paper_experiment')
    if args.dataset not in ('mosei', 'mosi'):
        parser.error('formal experiments support only mosei and mosi')
    if args.seed not in (1111, 2222, 3407, 5576, 7777):
        parser.error(
            'formal experiment seed must be one of '
            '1111, 2222, 3407, 5576, or 7777'
        )
    if not args.fixed_missing:
        parser.error('formal experiments require fixed missing protocols')
    if args.best_model_dir == 'best_modules':
        args.best_model_dir = 'paper_checkpoints'
    if args.log_dir == 'train_logs':
        args.log_dir = 'paper_logs'
if args.paper_e19_prediction_output:
    if args.paper_experiment:
        parser.error('E19 prediction export is post-hoc and not a training run')
    if not args.paper_e19_source_run_id:
        parser.error('--paper_e19_source_run_id is required for E19 export')
    if not args.load:
        parser.error('E19 prediction export requires --load=1')
    if not args.fixed_missing:
        parser.error('E19 source exports require one fixed protocol')
if args.retrieval_metric_mode == 'sentiment_guided' and args.retrieval_mode != 'missing_aware':
    parser.error('sentiment-guided metrics require --retrieval_mode=missing_aware')
if args.retrieval_missing_query == 'sample' and args.retrieval_metric_mode != 'sentiment_guided':
    parser.error('sample missing queries require --retrieval_metric_mode=sentiment_guided')
if args.retrieval_projection_dim < 1:
    parser.error('--retrieval_projection_dim must be positive')
if args.retrieval_label_temperature <= 0:
    parser.error('--retrieval_label_temperature must be positive')
if args.retrieval_temperature <= 0:
    parser.error('--retrieval_temperature must be positive')
if args.retrieval_loss_weight < 0:
    parser.error('--retrieval_loss_weight cannot be negative')
if args.retrieval_bank_batch_size < 1:
    parser.error('--retrieval_bank_batch_size must be positive')
if args.retrieval_bank_refresh_epochs < 1:
    parser.error('--retrieval_bank_refresh_epochs must be positive')
if args.retrieval_reference_bank_size < 0:
    parser.error('--retrieval_reference_bank_size cannot be negative')
if args.retrieval_reference_bank_seed < 0:
    parser.error('--retrieval_reference_bank_seed cannot be negative')
if (
    args.retrieval_reference_bank_size > 0
    and args.retrieval_reference_bank_size <= args.retrieval_top_k
):
    parser.error('--retrieval_reference_bank_size must exceed retrieval_top_k')
if args.retrieval_candidate_source == 'train_bank':
    if args.retrieval_mode != 'missing_aware':
        parser.error(
            'train-bank candidates require --retrieval_mode=missing_aware'
        )
    if args.retrieval_queue_size != 0:
        parser.error(
            'train-bank candidates require --retrieval_queue_size=0'
        )
    if args.retrieval_metric_mode != 'raw':
        parser.error(
            'E01 train-bank candidates require --retrieval_metric_mode=raw'
        )
if args.cross_modal_retrieval_hidden_dim < 1:
    parser.error('--cross_modal_retrieval_hidden_dim must be positive')
if args.cross_modal_retrieval_temperature <= 0:
    parser.error('--cross_modal_retrieval_temperature must be positive')
if args.cross_modal_match_temperature <= 0:
    parser.error('--cross_modal_match_temperature must be positive')
if args.cross_modal_match_loss_weight < 0:
    parser.error('--cross_modal_match_loss_weight cannot be negative')
if args.cross_modal_retrieval_learning_rate <= 0:
    parser.error('--cross_modal_retrieval_learning_rate must be positive')
if args.cross_modal_reference_bank_size < args.retrieval_top_k + 1:
    parser.error(
        '--cross_modal_reference_bank_size must exceed retrieval_top_k '
        'so training can exclude the paired item'
    )
if args.bundle_retrieval_temperature <= 0:
    parser.error('--bundle_retrieval_temperature must be positive')
if args.bundle_sentiment_weight < 0:
    parser.error('--bundle_sentiment_weight cannot be negative')
if args.bundle_sentiment_temperature <= 0:
    parser.error('--bundle_sentiment_temperature must be positive')
try:
    args.bundle_injection_scale_values = [
        float(value.strip())
        for value in args.bundle_injection_scales.split(',')
        if value.strip()
    ]
except ValueError:
    parser.error('--bundle_injection_scales must be comma-separated numbers')
if not args.bundle_injection_scale_values:
    parser.error('--bundle_injection_scales cannot be empty')
if any(
    scale < 0.0 or scale > 1.0
    for scale in args.bundle_injection_scale_values
):
    parser.error('--bundle_injection_scales values must be in [0, 1]')
args.bundle_injection_scale_values = list(dict.fromkeys(
    [0.0] + args.bundle_injection_scale_values
))
if not 0.0 < args.training_prior_mix_ratio < 1.0:
    parser.error('--training_prior_mix_ratio must be in (0, 1)')
if args.training_prior_top_k < 1:
    parser.error('--training_prior_top_k must be positive')
if not (
    -1.0 <= args.training_prior_similarity_min
    < args.training_prior_similarity_max <= 1.0
):
    parser.error(
        '--training_prior_similarity_min/max must define an increasing '
        'interval inside [-1, 1]'
    )
if args.training_prior_score_temperature <= 0:
    parser.error('--training_prior_score_temperature must be positive')
if args.training_prior_label_weight < 0:
    parser.error('--training_prior_label_weight cannot be negative')
if args.training_prior_label_temperature <= 0:
    parser.error('--training_prior_label_temperature must be positive')
if args.hybrid_expert_hidden_dim < 1:
    parser.error('--hybrid_expert_hidden_dim must be positive')
if args.hybrid_expert_private_count < 1:
    parser.error('--hybrid_expert_private_count must be positive')
if args.hybrid_expert_shared_count < 1:
    parser.error('--hybrid_expert_shared_count must be positive')
if not 0.0 <= args.hybrid_expert_dropout < 1.0:
    parser.error('--hybrid_expert_dropout must be in [0, 1)')
if (
    args.hybrid_expert_initial_temperature is not None
    and args.hybrid_expert_initial_temperature <= 0
):
    parser.error('--hybrid_expert_initial_temperature must be positive')
if args.hybrid_expert_orthogonality_weight < 0:
    parser.error('--hybrid_expert_orthogonality_weight cannot be negative')
if args.hybrid_expert_learning_rate <= 0:
    parser.error('--hybrid_expert_learning_rate must be positive')
if args.protocol_consistency_weight < 0:
    parser.error('--protocol_consistency_weight cannot be negative')
if args.protocol_consistency_temperature <= 0:
    parser.error('--protocol_consistency_temperature must be positive')
if not 0.5 <= args.protocol_consistency_confidence <= 1.0:
    parser.error('--protocol_consistency_confidence must be in [0.5, 1]')
if args.protocol_consistency_learning_rate <= 0:
    parser.error('--protocol_consistency_learning_rate must be positive')
if args.protocol_fusion_learning_rate <= 0:
    parser.error('--protocol_fusion_learning_rate must be positive')
if args.protocol_transformer_learning_rate <= 0:
    parser.error('--protocol_transformer_learning_rate must be positive')
if args.relation_distill_weight < 0:
    parser.error('--relation_distill_weight cannot be negative')
if args.relation_distill_advantage_margin < 0:
    parser.error('--relation_distill_advantage_margin cannot be negative')
if args.relation_distill_transformer_learning_rate <= 0:
    parser.error(
        '--relation_distill_transformer_learning_rate must be positive'
    )
if args.relation_distill_fusion_learning_rate <= 0:
    parser.error('--relation_distill_fusion_learning_rate must be positive')
if args.missing_text_contrast_hidden_dim < 1:
    parser.error('--missing_text_contrast_hidden_dim must be positive')
if args.missing_text_contrast_max_scale <= 0:
    parser.error('--missing_text_contrast_max_scale must be positive')
if args.missing_text_contrast_temperature <= 0:
    parser.error('--missing_text_contrast_temperature must be positive')
if args.missing_text_pair_loss_weight < 0:
    parser.error('--missing_text_pair_loss_weight cannot be negative')
if args.missing_text_contrast_loss_weight < 0:
    parser.error('--missing_text_contrast_loss_weight cannot be negative')
if args.missing_text_contrast_learning_rate <= 0:
    parser.error('--missing_text_contrast_learning_rate must be positive')
if (
    args.missing_text_contrast_mode != 'none'
    and args.missing_text_pair_loss_weight == 0
    and args.missing_text_contrast_loss_weight == 0
):
    parser.error(
        'improvement 17 requires a positive paired or contrastive loss weight'
    )
if args.privileged_purification_hidden_dim < 1:
    parser.error('--privileged_purification_hidden_dim must be positive')
if args.privileged_purification_subspace_dim < 1:
    parser.error('--privileged_purification_subspace_dim must be positive')
if args.privileged_purification_max_scale <= 0:
    parser.error('--privileged_purification_max_scale must be positive')
if args.privileged_purification_shared_weight < 0:
    parser.error('--privileged_purification_shared_weight cannot be negative')
if args.privileged_purification_orthogonality_weight < 0:
    parser.error(
        '--privileged_purification_orthogonality_weight cannot be negative'
    )
if args.privileged_purification_separation_weight < 0:
    parser.error('--privileged_purification_separation_weight cannot be negative')
if args.privileged_purification_separation_margin < 0:
    parser.error('--privileged_purification_separation_margin cannot be negative')
if args.privileged_purification_learning_rate <= 0:
    parser.error('--privileged_purification_learning_rate must be positive')
if args.language_hyper_hidden_dim < 1:
    parser.error('--language_hyper_hidden_dim must be positive')
if args.language_hyper_max_scale <= 0:
    parser.error('--language_hyper_max_scale must be positive')
if args.language_hyper_learning_rate <= 0:
    parser.error('--language_hyper_learning_rate must be positive')
if args.coupled_prompt_depth not in (1, 2):
    parser.error('--coupled_prompt_depth must be 1 or 2')
if args.coupled_prompt_length < 1:
    parser.error('--coupled_prompt_length must be positive')
if args.coupled_prompt_hidden_dim < 1:
    parser.error('--coupled_prompt_hidden_dim must be positive')
if args.coupled_prompt_max_scale <= 0:
    parser.error('--coupled_prompt_max_scale must be positive')
if args.coupled_prompt_init_std <= 0:
    parser.error('--coupled_prompt_init_std must be positive')
if args.coupled_prompt_learning_rate <= 0:
    parser.error('--coupled_prompt_learning_rate must be positive')
if args.distill_sample_weight < 0:
    parser.error('--distill_sample_weight cannot be negative')
if args.distill_fusion_weight < 0:
    parser.error('--distill_fusion_weight cannot be negative')
if args.pns_threshold <= 0:
    parser.error('--pns_threshold must be positive')
if args.prompt_hidden_dim < 1:
    parser.error('--prompt_hidden_dim must be positive')
if args.prompt_modality_embedding_dim < 1:
    parser.error('--prompt_modality_embedding_dim must be positive')
if args.prompt_max_scale <= 0:
    parser.error('--prompt_max_scale must be positive')
if args.prompt_init_std <= 0:
    parser.error('--prompt_init_std must be positive')
if args.prompt_learning_rate <= 0:
    parser.error('--prompt_learning_rate must be positive')
if args.reconstruction_hidden_dim < 1:
    parser.error('--reconstruction_hidden_dim must be positive')
if args.reconstruction_max_scale <= 0:
    parser.error('--reconstruction_max_scale must be positive')
if args.reconstruction_learning_rate <= 0:
    parser.error('--reconstruction_learning_rate must be positive')
if args.reconstruction_loss_weight <= 0:
    parser.error('--reconstruction_loss_weight must be positive')
if args.consensus_num_heads < 1:
    parser.error('--consensus_num_heads must be positive')
if args.consensus_num_layers < 1:
    parser.error('--consensus_num_layers must be positive')
if args.consensus_hidden_dim < 1:
    parser.error('--consensus_hidden_dim must be positive')
if not 0.0 <= args.consensus_dropout < 1.0:
    parser.error('--consensus_dropout must be in [0, 1)')
if args.consensus_learning_rate <= 0:
    parser.error('--consensus_learning_rate must be positive')
if args.tag_learning_rate <= 0:
    parser.error('--tag_learning_rate must be positive')
if (
    args.tag_mode != 'none'
    and (
        args.prompt_mode != 'none'
        or args.reconstruction_mode != 'none'
        or args.consensus_mode != 'none'
    )
):
    parser.error('improvement 10 cannot be combined with improvements 7, 8, or 9')
if args.cross_modal_retrieval_mode == 'agcqr':
    agcqr_baseline = (
        args.retrieval_mode == 'missing_aware'
        and args.retrieval_queue_size == 0
        and args.retrieval_metric_mode == 'raw'
        and args.retrieval_missing_query == 'center'
        and args.gate_mode == 'none'
        and args.consistency_mode == 'mixed'
        and args.distill_mode == 'none'
        and args.fusion_mode == 'flat'
        and args.prompt_mode == 'none'
        and args.reconstruction_mode == 'none'
        and args.consensus_mode == 'none'
        and args.tag_mode == 'none'
        and not args.pns_audit
        and bool(args.load)
    )
    if not agcqr_baseline:
        parser.error(
            'AGCQR requires --load=1 and the clean first+seventh foundation '
            'configuration'
        )
if args.cross_modal_retrieval_mode == 'scbr':
    scbr_baseline = (
        args.retrieval_mode == 'missing_aware'
        and args.retrieval_queue_size == 0
        and args.retrieval_metric_mode == 'raw'
        and args.retrieval_missing_query == 'center'
        and args.gate_mode == 'none'
        and args.consistency_mode == 'mixed'
        and args.distill_mode == 'none'
        and args.fusion_mode == 'flat'
        and args.prompt_mode == 'none'
        and args.reconstruction_mode == 'none'
        and args.consensus_mode == 'none'
        and args.tag_mode == 'none'
        and not args.pns_audit
        and bool(args.load)
    )
    if not scbr_baseline:
        parser.error(
            'SCBR requires --load=1 and the clean first+seventh foundation '
            'configuration'
        )
if args.training_prior_mode == 'tspe':
    tspe_baseline = (
        args.retrieval_mode == 'missing_aware'
        and args.retrieval_queue_size == 0
        and args.retrieval_metric_mode == 'raw'
        and args.retrieval_missing_query == 'center'
        and args.gate_mode == 'none'
        and args.consistency_mode == 'mixed'
        and args.distill_mode == 'none'
        and args.fusion_mode == 'flat'
        and args.prompt_mode == 'none'
        and args.reconstruction_mode == 'none'
        and args.consensus_mode == 'none'
        and args.tag_mode == 'none'
        and args.cross_modal_retrieval_mode == 'none'
        and not args.pns_audit
        and bool(args.load)
    )
    if not tspe_baseline:
        parser.error(
            'TSPE requires --load=1 and the clean first+seventh foundation '
            'configuration'
        )
if args.hybrid_expert_mode == 'acher':
    acher_baseline = (
        args.retrieval_mode == 'missing_aware'
        and args.retrieval_queue_size == 0
        and args.retrieval_metric_mode == 'raw'
        and args.retrieval_missing_query == 'center'
        and args.gate_mode == 'none'
        and args.consistency_mode == 'mixed'
        and args.distill_mode == 'none'
        and args.fusion_mode == 'flat'
        and args.prompt_mode == 'none'
        and args.reconstruction_mode == 'none'
        and args.consensus_mode == 'none'
        and args.tag_mode == 'none'
        and args.cross_modal_retrieval_mode == 'none'
        and args.training_prior_mode == 'none'
        and not args.pns_audit
        and bool(args.load)
    )
    if not acher_baseline:
        parser.error(
            'ACHER requires --load=1 and the clean first+seventh foundation '
            'configuration'
        )
if (
    args.protocol_consistency_mode == 'pcmc'
    or args.protocol_fusion_readaptation
):
    protocol_fusion_baseline = (
        args.retrieval_mode == 'missing_aware'
        and args.retrieval_queue_size == 0
        and args.retrieval_metric_mode == 'raw'
        and args.retrieval_missing_query == 'center'
        and args.gate_mode == 'none'
        and args.consistency_mode == 'mixed'
        and args.distill_mode == 'none'
        and args.fusion_mode == 'flat'
        and args.prompt_mode == 'none'
        and args.reconstruction_mode == 'none'
        and args.consensus_mode == 'none'
        and args.tag_mode == 'none'
        and args.cross_modal_retrieval_mode == 'none'
        and args.training_prior_mode == 'none'
        and args.hybrid_expert_mode == 'none'
        and not args.pns_audit
        and bool(args.load)
        and args.fixed_missing
    )
    if not protocol_fusion_baseline:
        parser.error(
            'protocol fusion adaptation requires --load=1, '
            '--fixed_missing=1, and the clean '
            'first+seventh foundation configuration'
        )
if (
    args.protocol_fusion_readaptation
    and args.protocol_consistency_mode != 'none'
):
    parser.error(
        '--protocol_fusion_readaptation cannot be combined with PCMC'
    )
if args.missing_text_contrast_mode in ('feature', 'label'):
    missing_text_contrast_baseline = (
        args.retrieval_mode == 'missing_aware'
        and args.retrieval_queue_size == 0
        and args.retrieval_metric_mode == 'raw'
        and args.retrieval_missing_query == 'center'
        and args.gate_mode == 'none'
        and args.consistency_mode == 'mixed'
        and args.distill_mode == 'none'
        and args.fusion_mode == 'flat'
        and args.prompt_mode == 'none'
        and args.reconstruction_mode == 'none'
        and args.consensus_mode == 'none'
        and args.tag_mode == 'none'
        and args.cross_modal_retrieval_mode == 'none'
        and args.training_prior_mode == 'none'
        and args.hybrid_expert_mode == 'none'
        and args.protocol_consistency_mode == 'none'
        and not args.protocol_fusion_readaptation
        and args.relation_distill_mode == 'none'
        and not args.pns_audit
        and bool(args.load)
        and args.fixed_missing
        and args.fixed_protocol in ('1', '2', '5')
    )
    if not missing_text_contrast_baseline:
        parser.error(
            'improvement 17 requires --load=1, a text-missing fixed protocol '
            '(1, 2, or 5), and the clean first+seventh+FPFR configuration'
        )
if args.privileged_purification_mode in ('task_only', 'full'):
    privileged_purification_baseline = (
        args.retrieval_mode == 'missing_aware'
        and args.retrieval_queue_size == 0
        and args.retrieval_metric_mode == 'raw'
        and args.retrieval_missing_query == 'center'
        and args.gate_mode == 'none'
        and args.consistency_mode == 'mixed'
        and args.distill_mode == 'none'
        and args.fusion_mode == 'flat'
        and args.prompt_mode == 'none'
        and args.reconstruction_mode == 'none'
        and args.consensus_mode == 'none'
        and args.tag_mode == 'none'
        and args.cross_modal_retrieval_mode == 'none'
        and args.training_prior_mode == 'none'
        and args.hybrid_expert_mode == 'none'
        and args.protocol_consistency_mode == 'none'
        and not args.protocol_fusion_readaptation
        and args.relation_distill_mode == 'none'
        and args.missing_text_contrast_mode == 'none'
        and args.language_hyper_mode == 'none'
        and not args.pns_audit
        and bool(args.load)
        and args.fixed_missing
        and args.fixed_protocol == '5'
    )
    if not privileged_purification_baseline:
        parser.error(
            'improvement 18 pilot requires --load=1, fixed protocol 5, and '
            'the clean first+seventh+FPFR configuration'
        )
if args.language_hyper_mode in ('availability_only', 'language_query'):
    language_hyper_baseline = (
        args.retrieval_mode == 'missing_aware'
        and args.retrieval_queue_size == 0
        and args.retrieval_metric_mode == 'raw'
        and args.retrieval_missing_query == 'center'
        and args.gate_mode == 'none'
        and args.consistency_mode == 'mixed'
        and args.distill_mode == 'none'
        and args.fusion_mode == 'flat'
        and args.prompt_mode == 'none'
        and args.reconstruction_mode == 'none'
        and args.consensus_mode == 'none'
        and args.tag_mode == 'none'
        and args.cross_modal_retrieval_mode == 'none'
        and args.training_prior_mode == 'none'
        and args.hybrid_expert_mode == 'none'
        and args.protocol_consistency_mode == 'none'
        and not args.protocol_fusion_readaptation
        and args.relation_distill_mode == 'none'
        and args.missing_text_contrast_mode == 'none'
        and args.privileged_purification_mode == 'none'
        and not args.pns_audit
        and bool(args.load)
        and args.fixed_missing
        and args.fixed_protocol == '3'
    )
    if not language_hyper_baseline:
        parser.error(
            'improvement 19 pilot requires --load=1, fixed protocol 3, and '
            'the clean first+seventh+FPFR configuration'
        )
if args.coupled_prompt_mode == 'lcmpr':
    coupled_prompt_baseline = (
        args.retrieval_mode == 'missing_aware'
        and args.retrieval_queue_size == 0
        and args.retrieval_metric_mode == 'raw'
        and args.retrieval_missing_query == 'center'
        and args.gate_mode == 'none'
        and args.consistency_mode == 'mixed'
        and args.distill_mode == 'none'
        and args.fusion_mode == 'flat'
        and args.prompt_mode == 'none'
        and args.reconstruction_mode == 'none'
        and args.consensus_mode == 'none'
        and args.tag_mode == 'none'
        and args.cross_modal_retrieval_mode == 'none'
        and args.training_prior_mode == 'none'
        and args.hybrid_expert_mode == 'none'
        and args.protocol_consistency_mode == 'none'
        and not args.protocol_fusion_readaptation
        and args.relation_distill_mode == 'none'
        and args.missing_text_contrast_mode == 'none'
        and args.privileged_purification_mode == 'none'
        and args.language_hyper_mode == 'none'
        and not args.pns_audit
        and bool(args.load)
        and args.fixed_missing
        and args.fixed_protocol in ('0', '3', '4')
    )
    if not coupled_prompt_baseline:
        parser.error(
            'improvement 20 pilot requires --load=1, a text-observed fixed '
            'protocol (0, 3, or 4), and the clean first+seventh+FPFR '
            'configuration'
        )
if args.relation_distill_mode == 'tag_mrd':
    relation_distill_baseline = (
        args.retrieval_mode == 'missing_aware'
        and args.retrieval_queue_size == 0
        and args.retrieval_metric_mode == 'raw'
        and args.retrieval_missing_query == 'center'
        and args.gate_mode == 'none'
        and args.consistency_mode == 'mixed'
        and args.distill_mode == 'none'
        and args.fusion_mode == 'flat'
        and args.prompt_mode == 'none'
        and args.reconstruction_mode == 'none'
        and args.consensus_mode == 'none'
        and args.tag_mode == 'none'
        and args.cross_modal_retrieval_mode == 'none'
        and args.training_prior_mode == 'none'
        and args.hybrid_expert_mode == 'none'
        and args.protocol_consistency_mode == 'none'
        and not args.protocol_fusion_readaptation
        and not args.pns_audit
        and bool(args.load)
        and args.fixed_missing
    )
    if not relation_distill_baseline:
        parser.error(
            'TAG-MRD requires --load=1, --fixed_missing=1, and the clean '
            'first+seventh+FPFR foundation configuration'
        )
if (
    args.consensus_mode != 'none'
    and (
        args.reconstruction_mode != 'none'
        or args.prompt_mode != 'none'
    )
):
    parser.error('improvement 9 cannot be combined with improvements 7 or 8')
if (
    args.reconstruction_mode != 'none'
    and args.prompt_mode != 'none'
):
    parser.error('improvement 8 cannot be combined with the frozen prompt branch')
if args.reconstruction_mode == 'text_guided_nonverbal':
    reconstruction_baseline = (
        args.retrieval_mode == 'missing_aware'
        and args.retrieval_queue_size == 0
        and args.retrieval_metric_mode == 'raw'
        and args.retrieval_missing_query == 'center'
        and args.gate_mode == 'none'
        and args.consistency_mode == 'mixed'
        and args.distill_mode == 'none'
        and args.fusion_mode == 'flat'
        and args.prompt_mode == 'none'
        and not args.pns_audit
        and bool(args.load)
    )
    if not reconstruction_baseline:
        parser.error(
            'text-guided reconstruction requires --load=1 and the clean '
            'first+seventh foundation configuration'
        )
if args.prompt_mode == 'none' and args.prompt_finetune_scope != 'prompt_head':
    parser.error('--prompt_finetune_scope requires --prompt_mode=missing_dynamic')
if args.prompt_mode == 'missing_dynamic':
    prompt_baseline = (
        args.retrieval_mode == 'missing_aware'
        and args.retrieval_queue_size == 0
        and args.retrieval_metric_mode == 'raw'
        and args.retrieval_missing_query == 'center'
        and args.gate_mode == 'none'
        and args.consistency_mode == 'mixed'
        and args.distill_mode == 'none'
        and args.fusion_mode == 'flat'
        and not args.pns_audit
        and bool(args.load)
    )
    if not prompt_baseline:
        parser.error(
            'missing dynamic prompt requires --load=1 and the frozen q0 '
            'baseline configuration'
        )
if args.fusion_mode == 'availability_multistage':
    multistage_baseline = (
        args.retrieval_mode == 'missing_aware'
        and args.retrieval_queue_size == 0
        and args.retrieval_metric_mode == 'raw'
        and args.retrieval_missing_query == 'center'
        and args.gate_mode == 'none'
        and args.consistency_mode == 'mixed'
        and args.distill_mode == 'none'
        and args.prompt_mode == 'none'
        and not args.pns_audit
    )
    if not multistage_baseline:
        parser.error(
            'availability multi-stage fusion is isolated to the frozen q0 baseline'
        )
if args.distill_mode == 'paired_hierarchical':
    if args.distill_sample_weight == 0 and args.distill_fusion_weight == 0:
        parser.error(
            'paired hierarchical distillation requires at least one positive '
            'distillation weight'
        )
    paired_distillation_baseline = (
        args.retrieval_mode == 'missing_aware'
        and args.retrieval_queue_size == 0
        and args.retrieval_metric_mode == 'raw'
        and args.retrieval_missing_query == 'center'
        and args.gate_mode == 'none'
        and args.consistency_mode == 'mixed'
        and args.prompt_mode == 'none'
    )
    if not paired_distillation_baseline:
        parser.error(
            'paired hierarchical distillation is isolated to the frozen '
            'missing-aware q0 baseline'
        )
if args.pns_audit:
    pns_audit_baseline = (
        args.retrieval_mode == 'missing_aware'
        and args.retrieval_queue_size == 0
        and args.retrieval_metric_mode == 'raw'
        and args.retrieval_missing_query == 'center'
        and args.gate_mode == 'none'
        and args.consistency_mode == 'mixed'
        and args.distill_mode == 'none'
        and args.fusion_mode == 'flat'
        and args.prompt_mode == 'none'
    )
    if not pns_audit_baseline:
        parser.error('PNS audit is restricted to the frozen q0 baseline')
    if not args.load:
        parser.error('--pns_audit requires --load=1 and a q0 --model_path')
if args.consensus_mode == 'amucr':
    consensus_baseline = (
        args.retrieval_mode == 'missing_aware'
        and args.retrieval_queue_size == 0
        and args.retrieval_metric_mode == 'raw'
        and args.retrieval_missing_query == 'center'
        and args.gate_mode == 'none'
        and args.consistency_mode == 'mixed'
        and args.distill_mode == 'none'
        and args.fusion_mode == 'flat'
        and args.prompt_mode == 'none'
        and args.reconstruction_mode == 'none'
        and args.tag_mode == 'none'
        and not args.pns_audit
        and bool(args.load)
    )
    if not consensus_baseline:
        parser.error(
            'AMUCR requires --load=1 and the clean first+seventh foundation '
            'configuration'
        )
    if args.d_l % args.consensus_num_heads:
        parser.error('--consensus_num_heads must evenly divide --d_l')
if args.tag_mode == 'amtfb':
    tag_baseline = (
        args.retrieval_mode == 'missing_aware'
        and args.retrieval_queue_size == 0
        and args.retrieval_metric_mode == 'raw'
        and args.retrieval_missing_query == 'center'
        and args.gate_mode == 'none'
        and args.consistency_mode == 'mixed'
        and args.distill_mode == 'none'
        and args.fusion_mode == 'flat'
        and args.prompt_mode == 'none'
        and args.reconstruction_mode == 'none'
        and args.consensus_mode == 'none'
        and not args.pns_audit
        and bool(args.load)
    )
    if not tag_baseline:
        parser.error(
            'AMTFB requires --load=1 and the clean first+seventh foundation '
            'configuration'
        )
if args.dataset == 'mosi':
    args.TEXT_DIM = 768
    args.ACOUSTIC_DIM = 5 # 74
    args.VISUAL_DIM = 20 # 47
    args.train_nums = 1284
    args.dev_nums = 229
    args.test_nums = 686
    args.attn_dropout_a = 0.2
    
elif args.dataset == 'mosei':
    args.TEXT_DIM = 768
    args.ACOUSTIC_DIM = 74
    args.VISUAL_DIM = 35
    args.train_nums = 16326
    args.dev_nums = 1871
    args.test_nums = 4659
    args.attn_dropout_a = 0.0

else:
    print('wrong dataset')

if args.alignment == 'align':
    args.text_length = args.max_seq_length
    args.visual_length = args.max_seq_length
    args.acoustic_length = args.max_seq_length
else:
    args.text_length = args.max_seq_length
    args.visual_length = 500
    args.acoustic_length = 375


args.output_dim = 1


def setup_run_outputs():
    os.makedirs(args.best_model_dir, exist_ok=True)
    os.makedirs(args.log_dir, exist_ok=True)

    if args.retrieval_mode == "legacy":
        retrieval_tag = "legacy"
    else:
        retrieval_tag = "missing_aware_q{}".format(
            args.retrieval_queue_size
        )
        if args.retrieval_candidate_source == 'train_bank':
            retrieval_tag = "missing_aware_trainbank_q{}".format(
                args.retrieval_queue_size
            )
        if args.retrieval_metric_mode == 'sentiment_guided':
            retrieval_tag = "{}_sg_{}q".format(
                retrieval_tag, args.retrieval_missing_query
            )
    gate_tags = {
        "reliability": "gate_rg_v1",
        "reliability_v1": "gate_rg_v1",
        "quality_reliability": "gate_qrg_v21",
        "quality_reliability_v22": "gate_qrg_v22",
        "counterfactual_harm_v23": "gate_cfhg_v23",
        "counterfactual_scale_v24": "gate_cfsg_v24",
    }
    if args.gate_mode == 'none':
        gate_tag = None
    elif args.gate_mode == 'fixed_scale_ablation':
        fixed_scale_tag = (
            "{:.3f}".format(args.gate_fixed_scale)
            .rstrip('0')
            .rstrip('.')
            .replace('.', '')
        )
        gate_tag = "gate_fixed_s{}".format(fixed_scale_tag)
    else:
        gate_tag = gate_tags[args.gate_mode]
    if gate_tag is None:
        run_name = "iie_{}_protocol_{}_{}".format(
            args.dataset,
            args.fixed_protocol,
            retrieval_tag,
        )
    else:
        run_name = "iie_{}_protocol_{}_{}_{}".format(
            args.dataset,
            args.fixed_protocol,
            retrieval_tag,
            gate_tag,
        )
    if args.consistency_mode != 'mixed':
        run_name = "{}_mmd_{}".format(run_name, args.consistency_mode)
    if args.distill_mode == 'paired_hierarchical':
        run_name = "{}_distill_phd".format(run_name)
    if args.pns_audit:
        run_name = "{}_audit_pns".format(run_name)
    if args.fusion_mode == 'availability_multistage':
        run_name = "{}_fusion_amsf".format(run_name)
    if args.prompt_mode == 'missing_dynamic':
        if args.prompt_finetune_scope == 'head_only':
            run_name = "{}_ablation_head_only".format(run_name)
        else:
            run_name = "{}_ablation_prompt_head".format(run_name)
    if args.reconstruction_mode == 'text_guided_nonverbal':
        run_name = "{}_recon_tgnv_frozen".format(run_name)
    if args.consensus_mode == 'amucr':
        run_name = "{}_consensus_amucr_frozen".format(run_name)
    if args.tag_mode == 'amtfb':
        run_name = "{}_tag_amtfb_frozen".format(run_name)
    if args.cross_modal_retrieval_mode == 'agcqr':
        run_name = "{}_retrieval_agcqr".format(run_name)
    elif args.cross_modal_retrieval_mode == 'scbr':
        run_name = "{}_retrieval_scbr".format(run_name)
    if args.training_prior_mode == 'tspe':
        run_name = "{}_prior_tspe".format(run_name)
    if args.hybrid_expert_mode == 'acher':
        run_name = "{}_expert_acher".format(run_name)
    if args.coupled_prompt_mode == 'lcmpr':
        if args.coupled_prompt_depth == 1:
            run_name = "{}_ablation_lcmpr_single_layer".format(run_name)
        else:
            run_name = "{}_fusion_lcmpr".format(run_name)
    elif args.language_hyper_mode == 'availability_only':
        run_name = "{}_ablation_availability_hyper".format(run_name)
    elif args.language_hyper_mode == 'language_query':
        run_name = "{}_fusion_at_ldhr".format(run_name)
    elif args.privileged_purification_mode == 'task_only':
        run_name = "{}_ablation_pdrp_task_only".format(run_name)
    elif args.privileged_purification_mode == 'full':
        run_name = "{}_purify_pdrp".format(run_name)
    elif args.missing_text_contrast_mode == 'feature':
        run_name = "{}_ablation_text_feature_contrast".format(run_name)
    elif args.missing_text_contrast_mode == 'label':
        run_name = "{}_contrast_lscmr".format(run_name)
    elif args.relation_distill_mode == 'tag_mrd':
        if args.relation_distill_weight == 0.0:
            run_name = "{}_ablation_late_fusion".format(run_name)
        else:
            run_name = "{}_distill_tag_mrd".format(run_name)
    elif args.protocol_fusion_readaptation:
        run_name = "{}_fusion_fpfr".format(run_name)
    elif args.protocol_consistency_mode == 'pcmc':
        if args.protocol_consistency_weight == 0.0:
            run_name = "{}_ablation_fusion_head".format(run_name)
        else:
            run_name = "{}_consistency_pcmc".format(run_name)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    if args.paper_experiment:
        # A formal run id is immutable and unique.  Use it for both outputs so
        # later seeds cannot overwrite a selected checkpoint or matching log.
        run_name = args.paper_run_id
        log_path = os.path.join(args.log_dir, "{}.log".format(run_name))
    else:
        log_path = os.path.join(
            args.log_dir, "{}_{}.log".format(run_name, timestamp)
        )
    best_model_path = os.path.join(
        args.best_model_dir, "{}_best.pt".format(run_name)
    )
    if args.paper_experiment:
        manifest_path = os.path.join(
            args.paper_manifest_dir, "{}.json".format(args.paper_run_id)
        )
        existing_outputs = [
            path
            for path in (log_path, best_model_path, manifest_path)
            if os.path.exists(path)
        ]
        if existing_outputs:
            raise FileExistsError(
                "Formal run outputs already exist and will not be "
                "overwritten: {}".format(", ".join(existing_outputs))
            )

    logger.setLevel(logging.INFO)
    logger.propagate = False
    for handler in list(logger.handlers):
        logger.removeHandler(handler)
        handler.close()

    formatter = logging.Formatter(
        "%(asctime)s | %(levelname)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )
    stream_handler = logging.StreamHandler(sys.stdout)
    stream_handler.setFormatter(formatter)
    file_handler = logging.FileHandler(log_path, mode="w", encoding="utf-8")
    file_handler.setFormatter(formatter)
    logger.addHandler(stream_handler)
    logger.addHandler(file_handler)

    return log_path, best_model_path


def build_optimizer(model: nn.Module):
    no_decay = [
        'bias', 'LayerNorm.weight', 'mix_parameters', 'raw_temperature'
    ]
    named_parameters = [
        (name, parameter)
        for name, parameter in model.named_parameters()
        if parameter.requires_grad
    ]

    if args.coupled_prompt_mode == 'lcmpr':
        if args.learning_rate <= 0:
            raise ValueError("learning_rate must be positive")
        group_lr = args.coupled_prompt_learning_rate
        multiplier = group_lr / args.learning_rate
        optimizer_grouped_parameters = []
        for group_name, is_no_decay, weight_decay in (
            ('lcmpr_decay', False, args.weight_decay),
            ('lcmpr_no_decay', True, 0.0),
        ):
            parameters = [
                parameter
                for name, parameter in named_parameters
                if any(item in name for item in no_decay) == is_no_decay
            ]
            if parameters:
                optimizer_grouped_parameters.append({
                    'params': parameters,
                    'weight_decay': weight_decay,
                    'lr': group_lr,
                    'lr_multiplier': multiplier,
                    'group_name': group_name,
                })
        logger.info(
            "Improvement-20 optimizer | adapter_lr=%.8g | groups=%d",
            group_lr,
            len(optimizer_grouped_parameters),
        )
    elif args.language_hyper_mode in (
        'availability_only', 'language_query'
    ):
        if args.learning_rate <= 0:
            raise ValueError("learning_rate must be positive")
        group_lr = args.language_hyper_learning_rate
        multiplier = group_lr / args.learning_rate
        optimizer_grouped_parameters = []
        for group_name, is_no_decay, weight_decay in (
            ('at_ldhr_decay', False, args.weight_decay),
            ('at_ldhr_no_decay', True, 0.0),
        ):
            parameters = [
                parameter
                for name, parameter in named_parameters
                if any(item in name for item in no_decay) == is_no_decay
            ]
            if parameters:
                optimizer_grouped_parameters.append({
                    'params': parameters,
                    'weight_decay': weight_decay,
                    'lr': group_lr,
                    'lr_multiplier': multiplier,
                    'group_name': group_name,
                })
        logger.info(
            "Improvement-19 optimizer | adapter_lr=%.8g | groups=%d",
            group_lr,
            len(optimizer_grouped_parameters),
        )
    elif args.privileged_purification_mode in ('task_only', 'full'):
        if args.learning_rate <= 0:
            raise ValueError("learning_rate must be positive")
        group_lr = args.privileged_purification_learning_rate
        multiplier = group_lr / args.learning_rate
        optimizer_grouped_parameters = []
        for group_name, is_no_decay, weight_decay in (
            ('pdrp_decay', False, args.weight_decay),
            ('pdrp_no_decay', True, 0.0),
        ):
            parameters = [
                parameter
                for name, parameter in named_parameters
                if any(item in name for item in no_decay) == is_no_decay
            ]
            if parameters:
                optimizer_grouped_parameters.append({
                    'params': parameters,
                    'weight_decay': weight_decay,
                    'lr': group_lr,
                    'lr_multiplier': multiplier,
                    'group_name': group_name,
                })
        logger.info(
            "Improvement-18 optimizer | adapter_lr=%.8g | groups=%d",
            group_lr,
            len(optimizer_grouped_parameters),
        )
    elif args.missing_text_contrast_mode in ('feature', 'label'):
        if args.learning_rate <= 0:
            raise ValueError("learning_rate must be positive")
        multiplier = args.missing_text_contrast_learning_rate / args.learning_rate
        optimizer_grouped_parameters = []
        for group_name, is_no_decay, weight_decay in (
            ('lscmr_decay', False, args.weight_decay),
            ('lscmr_no_decay', True, 0.0),
        ):
            parameters = [
                parameter
                for name, parameter in named_parameters
                if any(item in name for item in no_decay) == is_no_decay
            ]
            if parameters:
                optimizer_grouped_parameters.append({
                    'params': parameters,
                    'weight_decay': weight_decay,
                    'lr': args.missing_text_contrast_learning_rate,
                    'lr_multiplier': multiplier,
                    'group_name': group_name,
                })
        logger.info(
            "Improvement-17 optimizer | adapter_lr=%.8g | groups=%d",
            args.missing_text_contrast_learning_rate,
            len(optimizer_grouped_parameters),
        )
    elif args.relation_distill_mode == 'tag_mrd':
        if args.learning_rate <= 0:
            raise ValueError("learning_rate must be positive")
        optimizer_grouped_parameters = []
        module_specs = (
            (
                'tag_mrd_transformer',
                'transformer_encoder_all.',
                args.relation_distill_transformer_learning_rate,
            ),
            (
                'tag_mrd_fusion',
                'fusion_all.',
                args.relation_distill_fusion_learning_rate,
            ),
        )
        for module_name, prefix, group_lr in module_specs:
            multiplier = group_lr / args.learning_rate
            for decay_name, is_no_decay, weight_decay in (
                ('decay', False, args.weight_decay),
                ('no_decay', True, 0.0),
            ):
                parameters = [
                    parameter
                    for name, parameter in named_parameters
                    if name.startswith(prefix)
                    and any(item in name for item in no_decay) == is_no_decay
                ]
                if parameters:
                    optimizer_grouped_parameters.append({
                        'params': parameters,
                        'weight_decay': weight_decay,
                        'lr': group_lr,
                        'lr_multiplier': multiplier,
                        'group_name': '{}_{}'.format(
                            module_name, decay_name
                        ),
                    })
        logger.info(
            "Improvement-16 optimizer | transformer_lr=%.8g | "
            "fusion_lr=%.8g | groups=%d",
            args.relation_distill_transformer_learning_rate,
            args.relation_distill_fusion_learning_rate,
            len(optimizer_grouped_parameters),
        )
    elif args.protocol_fusion_readaptation:
        if args.learning_rate <= 0:
            raise ValueError("learning_rate must be positive")
        optimizer_grouped_parameters = []
        module_specs = []
        if args.protocol_adaptation_scope == 'late_transformer_fusion':
            module_specs.append((
                'e13_late_transformer', 'transformer_encoder_all.',
                args.protocol_transformer_learning_rate,
            ))
        fusion_prefix = (
            'fusion_all.fusion_layer_all_all.'
            if args.protocol_adaptation_scope == 'last_layer'
            else 'fusion_all.'
        )
        module_specs.append((
            'protocol_fusion', fusion_prefix,
            args.protocol_fusion_learning_rate,
        ))
        for module_name, prefix, group_lr in module_specs:
            multiplier = group_lr / args.learning_rate
            for decay_name, is_no_decay, weight_decay in (
                ('decay', False, args.weight_decay),
                ('no_decay', True, 0.0),
            ):
                parameters = [
                    parameter
                    for name, parameter in named_parameters
                    if name.startswith(prefix)
                    and any(item in name for item in no_decay) == is_no_decay
                ]
                if parameters:
                    optimizer_grouped_parameters.append({
                        'params': parameters,
                        'weight_decay': weight_decay,
                        'lr': group_lr,
                        'lr_multiplier': multiplier,
                        'group_name': '{}_{}'.format(
                            module_name, decay_name
                        ),
                    })
        logger.info(
            "Protocol adaptation optimizer | scope=%s | "
            "fusion_lr=%.8g | transformer_lr=%.8g | groups=%d",
            args.protocol_adaptation_scope,
            args.protocol_fusion_learning_rate,
            args.protocol_transformer_learning_rate,
            len(optimizer_grouped_parameters),
        )
    elif args.protocol_consistency_mode == 'pcmc':
        if args.learning_rate <= 0:
            raise ValueError("learning_rate must be positive")
        multiplier = (
            args.protocol_consistency_learning_rate / args.learning_rate
        )
        optimizer_grouped_parameters = []
        for group_name, is_no_decay, weight_decay in (
            ('pcmc_fusion_decay', False, args.weight_decay),
            ('pcmc_fusion_no_decay', True, 0.0),
        ):
            parameters = [
                parameter
                for name, parameter in named_parameters
                if any(item in name for item in no_decay) == is_no_decay
            ]
            if parameters:
                optimizer_grouped_parameters.append({
                    'params': parameters,
                    'weight_decay': weight_decay,
                    'lr': args.protocol_consistency_learning_rate,
                    'lr_multiplier': multiplier,
                    'group_name': group_name,
                })
        logger.info(
            "Improvement-15 optimizer | fusion_all_lr=%.8g | groups=%d",
            args.protocol_consistency_learning_rate,
            len(optimizer_grouped_parameters),
        )
    elif args.hybrid_expert_mode == 'acher':
        if args.learning_rate <= 0:
            raise ValueError("learning_rate must be positive")
        multiplier = args.hybrid_expert_learning_rate / args.learning_rate
        optimizer_grouped_parameters = []
        for group_name, is_no_decay, weight_decay in (
            ('acher_decay', False, args.weight_decay),
            ('acher_no_decay', True, 0.0),
        ):
            parameters = [
                parameter
                for name, parameter in named_parameters
                if any(item in name for item in no_decay) == is_no_decay
            ]
            if parameters:
                optimizer_grouped_parameters.append({
                    'params': parameters,
                    'weight_decay': weight_decay,
                    'lr': args.hybrid_expert_learning_rate,
                    'lr_multiplier': multiplier,
                    'group_name': group_name,
                })
        logger.info(
            "Improvement-14 optimizer | acher_lr=%.8g | groups=%d",
            args.hybrid_expert_learning_rate,
            len(optimizer_grouped_parameters),
        )
    elif args.training_prior_mode == 'tspe':
        optimizer_grouped_parameters = []
        for group_name, is_no_decay, weight_decay in (
            ('tspe_head_decay', False, args.weight_decay),
            ('tspe_head_no_decay', True, 0.0),
        ):
            parameters = [
                parameter
                for name, parameter in named_parameters
                if any(item in name for item in no_decay) == is_no_decay
            ]
            if parameters:
                optimizer_grouped_parameters.append({
                    'params': parameters,
                    'weight_decay': weight_decay,
                    'lr': args.learning_rate,
                    'lr_multiplier': 1.0,
                    'group_name': group_name,
                })
        logger.info(
            "Improvement-13 optimizer | fusion_head_lr=%.8g | groups=%d",
            args.learning_rate,
            len(optimizer_grouped_parameters),
        )
    elif args.cross_modal_retrieval_mode == 'agcqr':
        if args.learning_rate <= 0:
            raise ValueError("learning_rate must be positive")
        multiplier = (
            args.cross_modal_retrieval_learning_rate / args.learning_rate
        )
        optimizer_grouped_parameters = []
        for group_name, is_no_decay, weight_decay in (
            ('agcqr_decay', False, args.weight_decay),
            ('agcqr_no_decay', True, 0.0),
        ):
            parameters = [
                parameter
                for name, parameter in named_parameters
                if any(item in name for item in no_decay) == is_no_decay
            ]
            if parameters:
                optimizer_grouped_parameters.append({
                    'params': parameters,
                    'weight_decay': weight_decay,
                    'lr': args.cross_modal_retrieval_learning_rate,
                    'lr_multiplier': multiplier,
                    'group_name': group_name,
                })
        logger.info(
            "Improvement-11 optimizer | agcqr_lr=%.8g | groups=%d",
            args.cross_modal_retrieval_learning_rate,
            len(optimizer_grouped_parameters),
        )
    elif args.tag_mode == 'amtfb':
        if args.learning_rate <= 0:
            raise ValueError("learning_rate must be positive")
        multiplier = args.tag_learning_rate / args.learning_rate
        optimizer_grouped_parameters = [{
            'params': [parameter for _, parameter in named_parameters],
            'weight_decay': 0.0,
            'lr': args.tag_learning_rate,
            'lr_multiplier': multiplier,
            'group_name': 'missing_tag_projection',
        }]
        logger.info(
            "Improvement-10 optimizer | tag_lr=%.8g | groups=1 | "
            "weight_decay=0",
            args.tag_learning_rate,
        )
    elif args.consensus_mode == 'amucr':
        if args.learning_rate <= 0:
            raise ValueError("learning_rate must be positive")
        multiplier = args.consensus_learning_rate / args.learning_rate
        optimizer_grouped_parameters = []
        for group_name, is_no_decay, weight_decay in (
            ('consensus_decay', False, args.weight_decay),
            ('consensus_no_decay', True, 0.0),
        ):
            parameters = [
                parameter
                for name, parameter in named_parameters
                if any(item in name for item in no_decay) == is_no_decay
            ]
            if parameters:
                optimizer_grouped_parameters.append({
                    'params': parameters,
                    'weight_decay': weight_decay,
                    'lr': args.consensus_learning_rate,
                    'lr_multiplier': multiplier,
                    'group_name': group_name,
                })
        logger.info(
            "Improvement-9 optimizer | consensus_lr=%.8g | groups=%d",
            args.consensus_learning_rate,
            len(optimizer_grouped_parameters),
        )
    elif args.reconstruction_mode == 'text_guided_nonverbal':
        if args.learning_rate <= 0:
            raise ValueError("learning_rate must be positive")
        multiplier = args.reconstruction_learning_rate / args.learning_rate
        optimizer_grouped_parameters = []
        for group_name, is_no_decay, weight_decay in (
            ('reconstruction_decay', False, args.weight_decay),
            ('reconstruction_no_decay', True, 0.0),
        ):
            parameters = [
                parameter
                for name, parameter in named_parameters
                if any(item in name for item in no_decay) == is_no_decay
            ]
            if parameters:
                optimizer_grouped_parameters.append({
                    'params': parameters,
                    'weight_decay': weight_decay,
                    'lr': args.reconstruction_learning_rate,
                    'lr_multiplier': multiplier,
                    'group_name': group_name,
                })
        logger.info(
            "Improvement-8 optimizer | reconstruction_lr=%.8g | "
            "groups=%d",
            args.reconstruction_learning_rate,
            len(optimizer_grouped_parameters),
        )
    elif args.prompt_mode == 'missing_dynamic':
        if args.learning_rate <= 0:
            raise ValueError("learning_rate must be positive")
        prompt_multiplier = args.prompt_learning_rate / args.learning_rate
        optimizer_grouped_parameters = []
        group_specs = (
            ('prompt_decay', True, False, args.weight_decay, prompt_multiplier),
            ('prompt_no_decay', True, True, 0.0, prompt_multiplier),
            ('head_decay', False, False, args.weight_decay, 1.0),
            ('head_no_decay', False, True, 0.0, 1.0),
        )
        for group_name, prompt_group, no_decay_group, weight_decay, multiplier in group_specs:
            parameters = [
                parameter
                for name, parameter in named_parameters
                if name.startswith('dynamic_prompt_adapter.') == prompt_group
                and any(item in name for item in no_decay) == no_decay_group
            ]
            if parameters:
                optimizer_grouped_parameters.append({
                    'params': parameters,
                    'weight_decay': weight_decay,
                    'lr': args.learning_rate * multiplier,
                    'lr_multiplier': multiplier,
                    'group_name': group_name,
                })
        logger.info(
            "Seventh-improvement optimizer | scope=%s | prompt_lr=%s | "
            "fusion_head_lr=%.8g | groups=%d",
            args.prompt_finetune_scope,
            (
                "{:.8g}".format(args.prompt_learning_rate)
                if args.prompt_finetune_scope == 'prompt_head'
                else "disabled"
            ),
            args.learning_rate,
            len(optimizer_grouped_parameters),
        )
    elif args.gate_mode in (
        'quality_reliability_v22',
        'counterfactual_harm_v23',
        'counterfactual_scale_v24',
    ):
        if args.gate_lr_multiplier <= 0.0:
            raise ValueError("gate_lr_multiplier must be positive")
        optimizer_grouped_parameters = []
        group_specs = (
            ('backbone_decay', False, False, args.weight_decay, 1.0),
            ('backbone_no_decay', False, True, 0.0, 1.0),
            (
                'gate_decay', True, False, args.weight_decay,
                args.gate_lr_multiplier,
            ),
            ('gate_no_decay', True, True, 0.0, args.gate_lr_multiplier),
        )
        for group_name, gate_group, no_decay_group, weight_decay, multiplier in group_specs:
            parameters = [
                parameter
                for name, parameter in named_parameters
                if name.startswith('reliability_gate.') == gate_group
                and any(item in name for item in no_decay) == no_decay_group
            ]
            if parameters:
                optimizer_grouped_parameters.append({
                    'params': parameters,
                    'weight_decay': weight_decay,
                    'lr': args.learning_rate * multiplier,
                    'lr_multiplier': multiplier,
                    'group_name': group_name,
                })
        gate_versions = {
            'quality_reliability_v22': "Gate-V2.2",
            'counterfactual_harm_v23': "Gate-V2.3",
            'counterfactual_scale_v24': "Gate-V2.4",
        }
        gate_version = gate_versions[args.gate_mode]
        logger.info(
            "%s optimizer | backbone_lr=%.8g | gate_lr=%.8g | "
            "gate_lr_multiplier=%.3f",
            gate_version,
            args.learning_rate,
            args.learning_rate * args.gate_lr_multiplier,
            args.gate_lr_multiplier,
        )
    else:
        optimizer_grouped_parameters = [
            {
                'params': [
                    parameter
                    for name, parameter in named_parameters
                    if not any(item in name for item in no_decay)
                ],
                'weight_decay': args.weight_decay,
                'lr_multiplier': 1.0,
            },
            {
                'params': [
                    parameter
                    for name, parameter in named_parameters
                    if any(item in name for item in no_decay)
                ],
                'weight_decay': 0.0,
                'lr_multiplier': 1.0,
            },
        ]
    return AdamW(
        optimizer_grouped_parameters,
        lr=args.learning_rate,
        eps=args.adam_epsilon,
    )


def new_v24_supervision_totals():
    return {
        'loss': 0.0,
        'scale_mae': 0.0,
        'target_scale_mean': 0.0,
        'predicted_scale_mean': 0.0,
        'oracle_gain_mean': 0.0,
        'target_by_modality': torch.zeros(3, dtype=torch.float64),
        'prediction_by_modality': torch.zeros(3, dtype=torch.float64),
        'selection_fraction': torch.zeros((3, 3), dtype=torch.float64),
        'group_statistics': torch.zeros((3, 2, 6), dtype=torch.float64),
        'teacher_scales': None,
        'count': 0,
    }


def update_v24_supervision_totals(totals, diagnostics):
    for name in (
        'loss',
        'scale_mae',
        'target_scale_mean',
        'predicted_scale_mean',
        'oracle_gain_mean',
    ):
        totals[name] += diagnostics[name].item()
    for name in (
        'target_by_modality',
        'prediction_by_modality',
        'selection_fraction',
        'group_statistics',
    ):
        totals[name] += diagnostics[name].detach().cpu().double()
    totals['teacher_scales'] = (
        diagnostics['teacher_scales'].detach().cpu().double()
    )
    totals['count'] += 1


def log_v24_supervision(totals, split, epoch):
    count = totals['count']
    if not count:
        logger.info(
            "Gate-V2.4 supervision | split=%s | epoch=%d | warmup=true",
            split,
            epoch + 1,
        )
        return

    target_by_modality = totals['target_by_modality'] / count
    prediction_by_modality = totals['prediction_by_modality'] / count
    selection = totals['selection_fraction'] / count
    teacher_scales = totals['teacher_scales']
    logger.info(
        "Gate-V2.4 supervision | split=%s | epoch=%d | loss=%.6f | "
        "scale_mae=%.6f | target=%.6f | prediction=%.6f | "
        "oracle_gain=%.6f | target_l/a/v=%.6f/%.6f/%.6f | "
        "prediction_l/a/v=%.6f/%.6f/%.6f",
        split,
        epoch + 1,
        totals['loss'] / count,
        totals['scale_mae'] / count,
        totals['target_scale_mean'] / count,
        totals['predicted_scale_mean'] / count,
        totals['oracle_gain_mean'] / count,
        target_by_modality[0].item(),
        target_by_modality[1].item(),
        target_by_modality[2].item(),
        prediction_by_modality[0].item(),
        prediction_by_modality[1].item(),
        prediction_by_modality[2].item(),
    )
    for modality_index, modality in enumerate(('l', 'a', 'v')):
        logger.info(
            "Gate-V2.4 teacher choices | split=%s | epoch=%d | %s | "
            "scale_%.2f/%.2f/%.2f=%.4f/%.4f/%.4f",
            split,
            epoch + 1,
            modality,
            teacher_scales[0].item(),
            teacher_scales[1].item(),
            teacher_scales[2].item(),
            selection[modality_index, 0].item(),
            selection[modality_index, 1].item(),
            selection[modality_index, 2].item(),
        )

    for modality_index, modality in enumerate(('l', 'a', 'v')):
        for status_index, status in enumerate(('missing', 'observed')):
            statistics = totals['group_statistics'][
                modality_index, status_index
            ]
            sample_count = statistics[0].item()
            if sample_count == 0:
                continue
            target_mean = statistics[1].item() / sample_count
            prediction_mean = statistics[3].item() / sample_count
            target_variance = max(
                0.0,
                statistics[2].item() / sample_count - target_mean ** 2,
            )
            prediction_variance = max(
                0.0,
                statistics[4].item() / sample_count
                - prediction_mean ** 2,
            )
            denominator = math.sqrt(
                target_variance * prediction_variance
            )
            correlation = float('nan')
            if denominator > 1e-12:
                covariance = (
                    statistics[5].item() / sample_count
                    - target_mean * prediction_mean
                )
                correlation = max(
                    -1.0, min(1.0, covariance / denominator)
                )
            logger.info(
                "Gate-V2.4 group fit | split=%s | epoch=%d | %s.%s | "
                "n=%d | target=%.6f+/-%.6f | prediction=%.6f+/-%.6f | "
                "corr=%.4f",
                split,
                epoch + 1,
                modality,
                status,
                int(sample_count),
                target_mean,
                math.sqrt(target_variance),
                prediction_mean,
                math.sqrt(prediction_variance),
                correlation,
            )


def train_epoch(
    model: nn.Module,
    train_dataloader: DataLoader,
    optimizer: torch.optim.Optimizer,
    epoch=None,
    relation_teacher=None,
):
    adjust_learning_rate(optimizer, epoch, args)  
 
    model.train()
    if args.prompt_mode == 'missing_dynamic':
        model.enforce_missing_prompt_finetune_mode()
    if args.reconstruction_mode == 'text_guided_nonverbal':
        model.enforce_text_guided_reconstruction_finetune_mode()
    if args.consensus_mode == 'amucr':
        model.enforce_unified_consensus_finetune_mode()
    if args.tag_mode == 'amtfb':
        model.enforce_missing_tag_finetune_mode()
    if args.cross_modal_retrieval_mode == 'agcqr':
        model.enforce_cross_modal_retrieval_finetune_mode()
    if args.training_prior_mode == 'tspe':
        model.enforce_training_prior_finetune_mode()
    if args.hybrid_expert_mode == 'acher':
        model.enforce_availability_hybrid_expert_finetune_mode()
    if (
        args.protocol_consistency_mode == 'pcmc'
        or args.protocol_fusion_readaptation
    ):
        model.enforce_protocol_consistency_finetune_mode()
    if args.relation_distill_mode == 'tag_mrd':
        model.enforce_relation_distillation_finetune_mode()
    if args.missing_text_contrast_mode in ('feature', 'label'):
        model.enforce_missing_text_contrast_finetune_mode()
    if args.privileged_purification_mode in ('task_only', 'full'):
        model.enforce_privileged_purification_finetune_mode()
    if args.language_hyper_mode in (
        'availability_only', 'language_query'
    ):
        model.enforce_language_hyper_finetune_mode()
    if args.coupled_prompt_mode == 'lcmpr':
        model.enforce_coupled_prompt_finetune_mode()
    tr_loss = 0
    nb_tr_steps = 0
    prompt_epoch_totals = {
        'weights': torch.zeros(3, dtype=torch.float64),
        'residual_norms': torch.zeros(3, dtype=torch.float64),
        'missing_fraction': torch.zeros(3, dtype=torch.float64),
        'scales': torch.zeros(3, dtype=torch.float64),
        'count': 0,
    }
    reconstruction_epoch_totals = {
        'prediction_loss': 0.0,
        'filled_loss': 0.0,
        'eligible_count': torch.zeros(2, dtype=torch.float64),
        'scales': torch.zeros(2, dtype=torch.float64),
        'prediction_norm': torch.zeros(2, dtype=torch.float64),
        'injected_norm': torch.zeros(2, dtype=torch.float64),
        'count': 0,
    }
    consensus_epoch_totals = {
        'residual_abs_mean': 0.0,
        'attention_mean': torch.zeros(7, dtype=torch.float64),
        'raw_masked_fraction': 0.0,
        'count': 0,
    }
    tag_epoch_totals = {
        'tag_mean': torch.zeros(4, dtype=torch.float64),
        'shift_abs_mean': 0.0,
        'shift_norm_mean': 0.0,
        'column_norms': torch.zeros(4, dtype=torch.float64),
        'count': 0,
    }
    cross_modal_epoch_totals = {
        'query_loss': 0.0,
        'mix_scales': torch.zeros(3, dtype=torch.float64),
        'eligible_count': torch.zeros(3, dtype=torch.float64),
        'top1_similarity': torch.zeros(3, dtype=torch.float64),
        'count': 0,
    }
    training_prior_epoch_totals = {
        'eligible_count': torch.zeros(3, dtype=torch.float64),
        'observed_count': torch.zeros(3, dtype=torch.float64),
        'mean_similarity': torch.zeros(3, dtype=torch.float64),
        'mean_label_gap': torch.zeros(3, dtype=torch.float64),
        'mean_delta_norm': torch.zeros(3, dtype=torch.float64),
        'count': 0,
    }
    hybrid_expert_epoch_totals = {
        'residual_abs_mean': 0.0,
        'residual_norm_mean': 0.0,
        'orthogonality_loss': 0.0,
        'temperature': 0.0,
        'routing_weights': torch.zeros(
            3,
            args.hybrid_expert_private_count
            + args.hybrid_expert_shared_count,
            dtype=torch.float64,
        ),
        'routing_entropy': torch.zeros(3, dtype=torch.float64),
        'private_mass': torch.zeros(3, dtype=torch.float64),
        'shared_mass': torch.zeros(3, dtype=torch.float64),
        'count': 0,
    }
    protocol_consistency_totals = {
        'loss': 0.0,
        'coverage': 0.0,
        'eligible_count': 0.0,
        'teacher_confidence': 0.0,
        'teacher_abs_prediction': 0.0,
        'student_teacher_abs_gap': 0.0,
        'polarity_disagreement': 0.0,
        'eligible_polarity_disagreement': 0.0,
        'count': 0,
    }
    relation_distill_totals = {
        'loss': 0.0,
        'coverage': 0.0,
        'eligible_count': 0.0,
        'teacher_mae': 0.0,
        'student_mae': 0.0,
        'teacher_advantage': 0.0,
        'relation_gap': 0.0,
        'count': 0,
    }
    missing_text_contrast_totals = {
        'pair_loss': 0.0,
        'contrastive_loss': 0.0,
        'eligible_count': 0.0,
        'positive_similarity': 0.0,
        'negative_similarity': 0.0,
        'semantic_weight': 0.0,
        'candidate_target_gap': 0.0,
        'scale': 0.0,
        'prediction_norm': 0.0,
        'injected_norm': 0.0,
        'count': 0,
    }
    privileged_purification_totals = {
        'shared_loss': 0.0,
        'orthogonality_loss': 0.0,
        'separation_loss': 0.0,
        'eligible_count': 0.0,
        'shared_cosine': 0.0,
        'orthogonality': 0.0,
        'separation': 0.0,
        'residual_norm': 0.0,
        'injected_norm': 0.0,
        'scales': torch.zeros(3, dtype=torch.float64),
        'count': 0,
    }
    language_hyper_totals = {
        'attention': torch.zeros(4, dtype=torch.float64),
        'attention_entropy': 0.0,
        'eligible_count': 0.0,
        'scale': 0.0,
        'residual_norm': 0.0,
        'injected_norm': 0.0,
        'count': 0,
    }
    coupled_prompt_totals = {
        'attention': torch.zeros(
            args.coupled_prompt_depth,
            3,
            args.coupled_prompt_length,
            dtype=torch.float64,
        ),
        'residual_norms': torch.zeros(
            args.coupled_prompt_depth, 3, dtype=torch.float64
        ),
        'scales': torch.zeros(
            args.coupled_prompt_depth, 3, dtype=torch.float64
        ),
        'missing_count': torch.zeros(3, dtype=torch.float64),
        'count': 0,
    }
    retrieval_loss_total = 0.0
    distillation_totals = {
        'sample': 0.0,
        'fusion': 0.0,
    }
    gate_supervision_totals = {
        'loss': 0.0,
        'harm_target_mean': 0.0,
        'harmful_fraction': 0.0,
        'absolute_margin_mean': 0.0,
        'target_by_modality': torch.zeros(3, dtype=torch.float64),
        'count': 0,
    }
    v24_supervision_totals = new_v24_supervision_totals()
    mmd_epoch_totals = {
        modality: {
            'loss': 0.0,
            'observed': 0,
            'missing': 0,
            'observed_fraction': 0.0,
            'min_observed_fraction': 1.0,
            'max_observed_fraction': 0.0,
            'observed_skipped': 0,
            'missing_skipped': 0,
        }
        for modality in ('l', 'a', 'v')
    }
    use_gate_supervision = (
        (
            args.gate_mode == 'counterfactual_harm_v23'
            and epoch >= args.gate_cf_warmup_epochs
        )
        or (
            args.gate_mode == 'counterfactual_scale_v24'
            and epoch >= args.gate_scale_warmup_epochs
        )
    )
    use_retrieval_supervision = (
        args.retrieval_metric_mode == 'sentiment_guided'
    )
    use_paired_distillation = (
        args.distill_mode == 'paired_hierarchical'
    )
    use_protocol_consistency = (
        args.protocol_consistency_mode == 'pcmc'
    )
    use_protocol_fusion_readaptation = bool(
        args.protocol_fusion_readaptation
    )
    use_relation_distillation = (
        args.relation_distill_mode == 'tag_mrd'
    )
    use_missing_text_contrast = (
        args.missing_text_contrast_mode in ('feature', 'label')
    )
    use_privileged_purification = (
        args.privileged_purification_mode in ('task_only', 'full')
    )
    use_language_hyper = (
        args.language_hyper_mode in (
            'availability_only', 'language_query'
        )
    )
    use_coupled_prompt = args.coupled_prompt_mode == 'lcmpr'
    if use_relation_distillation and relation_teacher is None:
        raise RuntimeError("TAG-MRD requires a frozen late-fusion teacher")
    if args.gate_cf_loss_weight < 0.0:
        raise ValueError("gate_cf_loss_weight must be non-negative")
    if args.gate_cf_warmup_epochs < 0:
        raise ValueError("gate_cf_warmup_epochs must be non-negative")
    if args.gate_scale_loss_weight < 0.0:
        raise ValueError("gate_scale_loss_weight must be non-negative")
    if args.gate_scale_warmup_epochs < 0:
        raise ValueError("gate_scale_warmup_epochs must be non-negative")
    nums = args.train_nums
    if (
        args.paper_experiment
        or use_protocol_consistency
        or use_protocol_fusion_readaptation
        or use_relation_distillation
        or use_missing_text_contrast
        or use_privileged_purification
        or use_language_hyper
        or use_coupled_prompt
    ):
        # Formal E03 provenance fingerprints a fixed protocol for every split;
        # the training path must consume that same pre-registered mask.
        ps = generate_fixed_missing_matrix(
            nums, fixed_protocol=args.fixed_protocol
        )
    else:
        ps = generate_missing_matrix(nums, 3, missing_rate=args.missing_rate)

    for batch_idx, batch in enumerate(tqdm(train_dataloader, desc="Iteration")):
        batch = tuple(t.to(DEVICE) for t in batch)
        (
            input_ids,
            visual,
            acoustic,
            input_mask,
            segment_ids,
            label_ids,
            sample_ids,
        ) = unpack_dataset_batch(batch)
        visual = torch.squeeze(visual, 1)
        acoustic = torch.squeeze(acoustic, 1)
        batch_size = visual.shape[0]
     
        
        batch_ps = ps[batch_idx * batch_size : (batch_idx + 1) * batch_size]
        batch_ps = torch.from_numpy(batch_ps).to(DEVICE)

        teacher_outputs = None
        if (
            use_paired_distillation
            or use_protocol_consistency
            or use_relation_distillation
            or use_missing_text_contrast
            or use_privileged_purification
        ):
            # Forking restores the RNG after the complete-view pass, so the
            # student consumes exactly the same dropout stream as q0. Because
            # teacher and student have identical shapes, they also receive
            # paired dropout masks instead of distilling unrelated noise.
            rng_devices = (
                [torch.cuda.current_device()]
                if input_ids.is_cuda
                else []
            )
            with torch.random.fork_rng(devices=rng_devices):
                with torch.no_grad():
                    teacher_outputs = model(
                        input_ids,
                        visual,
                        acoustic,
                        torch.ones_like(batch_ps),
                        token_type_ids=segment_ids,
                        attention_mask=input_mask,
                        labels=None,
                        retrieval_labels=None,
                        retrieval_query_ids=sample_ids,
                    )
        
        outputs = model(
            input_ids,
            visual,
            acoustic,
            batch_ps,
            token_type_ids=segment_ids,
            attention_mask=input_mask,
            labels=(
                label_ids
                if use_gate_supervision or args.training_prior_mode == 'tspe'
                else None
            ),
            retrieval_labels=(
                label_ids if use_retrieval_supervision else None
            ),
            retrieval_query_ids=sample_ids,
            compute_reconstruction_targets=(
                args.reconstruction_mode == 'text_guided_nonverbal'
            ),
            compute_cross_modal_targets=(
                args.cross_modal_retrieval_mode == 'agcqr'
            ),
        )
        language_hyper_info = outputs.get('language_hyper_diagnostics', {})
        if language_hyper_info.get('enabled', False):
            language_hyper_totals['attention'] += (
                language_hyper_info['attention'].mean(dim=0).cpu().double()
            )
            for name in (
                'attention_entropy', 'eligible_count', 'scale',
                'residual_norm', 'injected_norm',
            ):
                language_hyper_totals[name] += (
                    language_hyper_info[name].item()
                )
            language_hyper_totals['count'] += 1
        coupled_prompt_info = outputs.get('coupled_prompt_diagnostics', {})
        if coupled_prompt_info.get('enabled', False):
            coupled_prompt_totals['attention'] += (
                coupled_prompt_info['attention']
                .mean(dim=0).cpu().double()
            )
            coupled_prompt_totals['residual_norms'] += (
                coupled_prompt_info['residual_norms']
                .mean(dim=0).cpu().double()
            )
            coupled_prompt_totals['scales'] += (
                coupled_prompt_info['scales'].cpu().double()
            )
            coupled_prompt_totals['missing_count'] += (
                coupled_prompt_info['missing_count'].cpu().double()
            )
            coupled_prompt_totals['count'] += 1
        cross_modal_info = outputs.get(
            'cross_modal_query_diagnostics', {}
        )
        if cross_modal_info.get('enabled', False):
            cross_modal_epoch_totals['query_loss'] += (
                cross_modal_info['query_loss'].item()
            )
            for name in (
                'mix_scales', 'eligible_count', 'top1_similarity'
            ):
                cross_modal_epoch_totals[name] += (
                    cross_modal_info[name].cpu().double()
                )
            cross_modal_epoch_totals['count'] += 1
        training_prior_info = outputs.get(
            'prior_enhancement_diagnostics', {}
        )
        if training_prior_info.get('enabled', False):
            for name in (
                'eligible_count',
                'observed_count',
                'mean_similarity',
                'mean_label_gap',
                'mean_delta_norm',
            ):
                training_prior_epoch_totals[name] += (
                    training_prior_info[name].cpu().double()
                )
            training_prior_epoch_totals['count'] += 1
        hybrid_expert_info = outputs.get('hybrid_expert_diagnostics', {})
        if hybrid_expert_info.get('enabled', False):
            for name in (
                'residual_abs_mean',
                'residual_norm_mean',
                'orthogonality_loss',
                'temperature',
            ):
                hybrid_expert_epoch_totals[name] += (
                    hybrid_expert_info[name].item()
                )
            for name in (
                'routing_weights',
                'routing_entropy',
                'private_mass',
                'shared_mass',
            ):
                hybrid_expert_epoch_totals[name] += (
                    hybrid_expert_info[name].cpu().double()
                )
            hybrid_expert_epoch_totals['count'] += 1
        consensus_info = outputs.get('consensus_diagnostics', {})
        if consensus_info.get('enabled', False):
            consensus_epoch_totals['residual_abs_mean'] += (
                consensus_info['residual_abs_mean'].item()
            )
            consensus_epoch_totals['attention_mean'] += (
                consensus_info['attention_mean'].cpu().double()
            )
            consensus_epoch_totals['raw_masked_fraction'] += (
                consensus_info['raw_masked_fraction'].item()
            )
            consensus_epoch_totals['count'] += 1
        tag_info = outputs.get('tag_diagnostics', {})
        if tag_info.get('enabled', False):
            for name in ('tag_mean', 'column_norms'):
                tag_epoch_totals[name] += tag_info[name].cpu().double()
            for name in ('shift_abs_mean', 'shift_norm_mean'):
                tag_epoch_totals[name] += tag_info[name].item()
            tag_epoch_totals['count'] += 1
        prompt_info = outputs.get('prompt_diagnostics', {})
        if prompt_info.get('enabled', False):
            prompt_epoch_totals['weights'] += (
                prompt_info['weights'].mean(dim=0).cpu().double()
            )
            prompt_epoch_totals['residual_norms'] += (
                prompt_info['residual_norms'].mean(dim=0).cpu().double()
            )
            prompt_epoch_totals['missing_fraction'] += (
                prompt_info['missing_fraction'].cpu().double()
            )
            prompt_epoch_totals['scales'] += (
                prompt_info['scales'].cpu().double()
            )
            prompt_epoch_totals['count'] += 1
        reconstruction_info = outputs.get('reconstruction_diagnostics', {})
        if reconstruction_info.get('enabled', False):
            reconstruction_epoch_totals['prediction_loss'] += (
                reconstruction_info['prediction_loss'].item()
            )
            reconstruction_epoch_totals['filled_loss'] += (
                reconstruction_info['filled_loss'].item()
            )
            for name in (
                'eligible_count', 'scales', 'prediction_norm', 'injected_norm'
            ):
                reconstruction_epoch_totals[name] += (
                    reconstruction_info[name].cpu().double()
                )
            reconstruction_epoch_totals['count'] += 1
        mmd_losses = outputs['mmd_losses']
        if args.consistency_mode != 'mixed':
            mmd_diagnostics = outputs['mmd_diagnostics']
            for modality in ('l', 'a', 'v'):
                modality_mmd = mmd_diagnostics[modality]
                totals = mmd_epoch_totals[modality]
                totals['loss'] += modality_mmd['loss'].item()
                totals['observed'] += modality_mmd['observed_count']
                totals['missing'] += modality_mmd['missing_count']
                observed_fraction = (
                    modality_mmd['observed_count']
                    / modality_mmd['batch_size']
                )
                totals['observed_fraction'] += observed_fraction
                totals['min_observed_fraction'] = min(
                    totals['min_observed_fraction'], observed_fraction
                )
                totals['max_observed_fraction'] = max(
                    totals['max_observed_fraction'], observed_fraction
                )
                totals['observed_skipped'] += int(
                    args.consistency_mode
                    in ('status_separated', 'observed_only')
                    and not modality_mmd['observed_used']
                    and modality_mmd['observed_count'] > 0
                )
                totals['missing_skipped'] += int(
                    args.consistency_mode == 'status_separated'
                    and not modality_mmd['missing_used']
                    and modality_mmd['missing_count'] > 0
                )
            if (
                args.consistency_log_interval > 0
                and batch_idx % args.consistency_log_interval == 0
            ):
                logger.info(
                    "MMD batch | epoch=%d | batch=%d | mode=%s | "
                    "obs_l/a/v=%d/%d/%d | miss_l/a/v=%d/%d/%d | "
                    "loss_l/a/v=%.6f/%.6f/%.6f",
                    epoch + 1,
                    batch_idx + 1,
                    mmd_diagnostics['mode'],
                    mmd_diagnostics['l']['observed_count'],
                    mmd_diagnostics['a']['observed_count'],
                    mmd_diagnostics['v']['observed_count'],
                    mmd_diagnostics['l']['missing_count'],
                    mmd_diagnostics['a']['missing_count'],
                    mmd_diagnostics['v']['missing_count'],
                    mmd_diagnostics['l']['loss'].item(),
                    mmd_diagnostics['a']['loss'].item(),
                    mmd_diagnostics['v']['loss'].item(),
                )
        predictions = outputs['predictions']
        loss_fct = L1Loss()
        loss_task = loss_fct(predictions.view(-1), label_ids.view(-1))
        # AGCQR deliberately avoids adding another distribution-alignment
        # pressure: the frozen third-improvement MMD direction was not useful.
        loss_all = (
            loss_task
            if args.cross_modal_retrieval_mode == 'agcqr'
            else loss_task + mmd_losses
        )
        if args.cross_modal_retrieval_mode == 'agcqr':
            loss_all = (
                loss_all
                + args.cross_modal_match_loss_weight
                * outputs['cross_modal_query_loss']
            )
        reconstruction_loss = outputs.get('reconstruction_loss')
        if reconstruction_loss is not None:
            loss_all = (
                loss_all
                + args.reconstruction_loss_weight * reconstruction_loss
            )
        if use_missing_text_contrast:
            if teacher_outputs is None:
                raise RuntimeError(
                    "improvement 17 requires complete-view training targets"
                )
            missing_text_info = outputs.get(
                'missing_text_contrast_diagnostics', {}
            )
            pair_loss, contrastive_loss, contrast_info = (
                label_semantic_missing_text_objective(
                    missing_text_info,
                    teacher_outputs['fusion_representations'][1],
                    label_ids,
                    temperature=args.missing_text_contrast_temperature,
                    semantic_weighting=(
                        args.missing_text_contrast_mode == 'label'
                    ),
                )
            )
            loss_all = (
                loss_all
                + args.missing_text_pair_loss_weight * pair_loss
                + args.missing_text_contrast_loss_weight * contrastive_loss
            )
            missing_text_contrast_totals['pair_loss'] += pair_loss.item()
            missing_text_contrast_totals[
                'contrastive_loss'
            ] += contrastive_loss.item()
            for name in (
                'eligible_count',
                'positive_similarity',
                'negative_similarity',
                'semantic_weight',
                'candidate_target_gap',
            ):
                missing_text_contrast_totals[name] += (
                    contrast_info[name].item()
                )
            for name in ('scale', 'prediction_norm', 'injected_norm'):
                missing_text_contrast_totals[name] += (
                    missing_text_info[name].item()
                )
            missing_text_contrast_totals['count'] += 1
        if use_privileged_purification:
            purification_info = outputs.get(
                'privileged_purification_diagnostics', {}
            )
            if not purification_info.get('enabled', False):
                raise RuntimeError("PDRP did not return enabled diagnostics")
            zero = outputs['predictions'].sum() * 0.0
            shared_loss = zero
            orthogonality_loss = zero
            separation_loss = zero
            objective_info = {
                'eligible_count': purification_info['eligible_count'],
                'shared_cosine': zero.detach(),
                'orthogonality': zero.detach(),
                'separation': zero.detach(),
            }
            if args.privileged_purification_mode == 'full':
                if teacher_outputs is None:
                    raise RuntimeError(
                        "full PDRP requires complete-view training targets"
                    )
                (
                    shared_loss,
                    orthogonality_loss,
                    separation_loss,
                    objective_info,
                ) = privileged_disentangled_objective(
                    purification_info,
                    teacher_outputs[
                        'privileged_purification_diagnostics'
                    ],
                    separation_margin=(
                        args.privileged_purification_separation_margin
                    ),
                )
                loss_all = (
                    loss_all
                    + args.privileged_purification_shared_weight
                    * shared_loss
                    + args.privileged_purification_orthogonality_weight
                    * orthogonality_loss
                    + args.privileged_purification_separation_weight
                    * separation_loss
                )
            privileged_purification_totals['shared_loss'] += (
                shared_loss.item()
            )
            privileged_purification_totals['orthogonality_loss'] += (
                orthogonality_loss.item()
            )
            privileged_purification_totals['separation_loss'] += (
                separation_loss.item()
            )
            for name in (
                'eligible_count', 'shared_cosine', 'orthogonality',
                'separation',
            ):
                privileged_purification_totals[name] += (
                    objective_info[name].item()
                )
            privileged_purification_totals['residual_norm'] += (
                purification_info['residual_norm'].item()
            )
            privileged_purification_totals['injected_norm'] += (
                purification_info['injected_norm'].item()
            )
            privileged_purification_totals['scales'] += (
                purification_info['scales'].cpu().double()
            )
            privileged_purification_totals['count'] += 1
        hybrid_expert_loss = outputs.get('hybrid_expert_orthogonality_loss')
        if args.hybrid_expert_mode == 'acher':
            if hybrid_expert_loss is None:
                raise RuntimeError("ACHER did not return its auxiliary loss")
            loss_all = (
                loss_all
                + args.hybrid_expert_orthogonality_weight
                * hybrid_expert_loss
            )
        if use_protocol_consistency:
            protocol_consistency_loss, protocol_consistency_info = (
                confidence_gated_polarity_consistency(
                    outputs['predictions'],
                    teacher_outputs['predictions'],
                    temperature=args.protocol_consistency_temperature,
                    confidence_threshold=(
                        args.protocol_consistency_confidence
                    ),
                )
            )
            loss_all = (
                loss_all
                + args.protocol_consistency_weight
                * protocol_consistency_loss
            )
            for name in protocol_consistency_totals:
                if name == 'count':
                    continue
                protocol_consistency_totals[name] += (
                    protocol_consistency_info[name].item()
                )
            protocol_consistency_totals['count'] += 1
        if use_relation_distillation:
            teacher_nodes, teacher_prediction = relation_teacher(
                teacher_outputs['fusion_representations']
            )
            relation_distill_loss, relation_distill_info = (
                teacher_advantage_relation_distillation(
                    outputs['hidden'],
                    teacher_nodes,
                    outputs['predictions'],
                    teacher_prediction,
                    label_ids,
                    advantage_margin=(
                        args.relation_distill_advantage_margin
                    ),
                )
            )
            loss_all = (
                loss_all
                + args.relation_distill_weight * relation_distill_loss
            )
            relation_distill_totals['loss'] += (
                relation_distill_loss.item()
            )
            for name in (
                'coverage',
                'eligible_count',
                'teacher_mae',
                'student_mae',
                'teacher_advantage',
                'relation_gap',
            ):
                relation_distill_totals[name] += (
                    relation_distill_info[name].item()
                )
            relation_distill_totals['count'] += 1
        if use_paired_distillation:
            distillation_losses = paired_hierarchical_distillation(
                outputs['sample_representation'],
                teacher_outputs['sample_representation'],
                outputs['hidden'],
                teacher_outputs['hidden'],
            )
            loss_all = (
                loss_all
                + args.distill_sample_weight * distillation_losses['sample']
                + args.distill_fusion_weight * distillation_losses['fusion']
            )
            distillation_totals['sample'] += (
                distillation_losses['sample'].item()
            )
            distillation_totals['fusion'] += (
                distillation_losses['fusion'].item()
            )
        retrieval_loss = outputs['retrieval_loss']
        if use_retrieval_supervision:
            loss_all = (
                loss_all
                + args.retrieval_loss_weight * retrieval_loss
            )
            retrieval_loss_total += retrieval_loss.item()
        gate_supervision_loss = outputs.get('gate_supervision_loss')
        if gate_supervision_loss is not None:
            gate_loss_weight = (
                args.gate_scale_loss_weight
                if args.gate_mode == 'counterfactual_scale_v24'
                else args.gate_cf_loss_weight
            )
            loss_all = (
                loss_all
                + gate_loss_weight * gate_supervision_loss
            )
            gate_info = outputs['gate_supervision_diagnostics']
            if args.gate_mode == 'counterfactual_scale_v24':
                update_v24_supervision_totals(
                    v24_supervision_totals, gate_info
                )
            else:
                gate_supervision_totals['loss'] += gate_info['loss'].item()
                gate_supervision_totals['harm_target_mean'] += (
                    gate_info['harm_target_mean'].item()
                )
                gate_supervision_totals['harmful_fraction'] += (
                    gate_info['harmful_fraction'].item()
                )
                gate_supervision_totals['absolute_margin_mean'] += (
                    gate_info['absolute_margin_mean'].item()
                )
                gate_supervision_totals['target_by_modality'] += (
                    gate_info['target_by_modality'].detach().cpu().double()
                )
                gate_supervision_totals['count'] += 1
        
        
        optimizer.zero_grad()
        loss_all.backward()
        torch.nn.utils.clip_grad_value_([param for param in model.parameters() if param.requires_grad], args.clip)
        optimizer.step()

        if args.gradient_accumulation_step > 1:
            loss_all = loss_all / args.gradient_accumulation_step

        tr_loss += loss_all.item()
        nb_tr_steps += 1
    train_loss = tr_loss / nb_tr_steps
    if prompt_epoch_totals['count']:
        count = prompt_epoch_totals['count']
        mean_weights = prompt_epoch_totals['weights'] / count
        mean_norms = prompt_epoch_totals['residual_norms'] / count
        mean_missing = prompt_epoch_totals['missing_fraction'] / count
        mean_scales = prompt_epoch_totals['scales'] / count
        logger.info(
            "Dynamic prompt | epoch=%d | scale_l/a/v=%.6f/%.6f/%.6f | "
            "weight_l/a/v=%.6f/%.6f/%.6f | "
            "residual_norm_l/a/v=%.6f/%.6f/%.6f | "
            "missing_rate_l/a/v=%.3f/%.3f/%.3f",
            epoch + 1,
            *mean_scales.tolist(),
            *mean_weights.tolist(),
            *mean_norms.tolist(),
            *mean_missing.tolist(),
        )
    if reconstruction_epoch_totals['count']:
        count = reconstruction_epoch_totals['count']
        mean_eligible = reconstruction_epoch_totals['eligible_count'] / count
        mean_scales = reconstruction_epoch_totals['scales'] / count
        mean_prediction_norm = (
            reconstruction_epoch_totals['prediction_norm'] / count
        )
        mean_injected_norm = (
            reconstruction_epoch_totals['injected_norm'] / count
        )
        logger.info(
            "Text-guided reconstruction | epoch=%d | "
            "prediction_loss=%.6f | filled_loss=%.6f | "
            "scale_a/v=%.6f/%.6f | eligible_a/v=%.2f/%.2f | "
            "prediction_norm_a/v=%.6f/%.6f | "
            "injected_norm_a/v=%.6f/%.6f",
            epoch + 1,
            reconstruction_epoch_totals['prediction_loss'] / count,
            reconstruction_epoch_totals['filled_loss'] / count,
            *mean_scales.tolist(),
            *mean_eligible.tolist(),
            *mean_prediction_norm.tolist(),
            *mean_injected_norm.tolist(),
        )
    if consensus_epoch_totals['count']:
        count = consensus_epoch_totals['count']
        mean_attention = consensus_epoch_totals['attention_mean'] / count
        logger.info(
            "AMUCR consensus | epoch=%d | residual_abs_mean=%.6f | "
            "attention_sample/eh_l/eh_a/eh_v/raw_l/raw_a/raw_v="
            "%.4f/%.4f/%.4f/%.4f/%.4f/%.4f/%.4f | "
            "raw_masked_fraction=%.4f",
            epoch + 1,
            consensus_epoch_totals['residual_abs_mean'] / count,
            *mean_attention.tolist(),
            consensus_epoch_totals['raw_masked_fraction'] / count,
        )
    if tag_epoch_totals['count']:
        count = tag_epoch_totals['count']
        mean_tag = tag_epoch_totals['tag_mean'] / count
        column_norms = tag_epoch_totals['column_norms'] / count
        logger.info(
            "AMTFB tag | epoch=%d | "
            "tag_rate_complete/miss_l/miss_a/miss_v="
            "%.4f/%.4f/%.4f/%.4f | "
            "shift_abs_mean=%.6f | shift_norm_mean=%.6f | "
            "column_norm_complete/miss_l/miss_a/miss_v="
            "%.6f/%.6f/%.6f/%.6f",
            epoch + 1,
            *mean_tag.tolist(),
            tag_epoch_totals['shift_abs_mean'] / count,
            tag_epoch_totals['shift_norm_mean'] / count,
            *column_norms.tolist(),
        )
    if cross_modal_epoch_totals['count']:
        count = cross_modal_epoch_totals['count']
        mean_mix = cross_modal_epoch_totals['mix_scales'] / count
        mean_eligible = cross_modal_epoch_totals['eligible_count'] / count
        mean_similarity = (
            cross_modal_epoch_totals['top1_similarity'] / count
        )
        mean_query_loss = cross_modal_epoch_totals['query_loss'] / count
        logger.info(
            "AGCQR retrieval | epoch=%d | query_loss=%.6f | weighted=%.6f | "
            "mix_l/a/v=%.6f/%.6f/%.6f | "
            "eligible_l/a/v=%.2f/%.2f/%.2f | "
            "top1_similarity_l/a/v=%.6f/%.6f/%.6f",
            epoch + 1,
            mean_query_loss,
            args.cross_modal_match_loss_weight * mean_query_loss,
            *mean_mix.tolist(),
            *mean_eligible.tolist(),
            *mean_similarity.tolist(),
        )
    if training_prior_epoch_totals['count']:
        count = training_prior_epoch_totals['count']
        mean_eligible = training_prior_epoch_totals['eligible_count'] / count
        mean_observed = training_prior_epoch_totals['observed_count'] / count
        mean_similarity = (
            training_prior_epoch_totals['mean_similarity'] / count
        )
        mean_label_gap = training_prior_epoch_totals['mean_label_gap'] / count
        mean_delta_norm = (
            training_prior_epoch_totals['mean_delta_norm'] / count
        )
        logger.info(
            "TSPE prior | epoch=%d | mix_ratio=%.6f | "
            "eligible_l/a/v=%.2f/%.2f/%.2f | "
            "observed_l/a/v=%.2f/%.2f/%.2f | "
            "similarity_l/a/v=%.6f/%.6f/%.6f | "
            "label_gap_l/a/v=%.6f/%.6f/%.6f | "
            "delta_norm_l/a/v=%.6f/%.6f/%.6f",
            epoch + 1,
            args.training_prior_mix_ratio,
            *mean_eligible.tolist(),
            *mean_observed.tolist(),
            *mean_similarity.tolist(),
            *mean_label_gap.tolist(),
            *mean_delta_norm.tolist(),
        )
    if hybrid_expert_epoch_totals['count']:
        count = hybrid_expert_epoch_totals['count']
        mean_weights = hybrid_expert_epoch_totals['routing_weights'] / count
        mean_entropy = hybrid_expert_epoch_totals['routing_entropy'] / count
        mean_private = hybrid_expert_epoch_totals['private_mass'] / count
        mean_shared = hybrid_expert_epoch_totals['shared_mass'] / count
        mean_orthogonality = (
            hybrid_expert_epoch_totals['orthogonality_loss'] / count
        )
        weight_strings = [
            ','.join('{:.4f}'.format(value) for value in row.tolist())
            for row in mean_weights
        ]
        logger.info(
            "ACHER experts | epoch=%d | residual_abs=%.6f | "
            "residual_norm=%.6f | orthogonality=%.6f | weighted=%.6f | "
            "temperature=%.6f | entropy_l/a/v=%.4f/%.4f/%.4f | "
            "private_mass_l/a/v=%.4f/%.4f/%.4f | "
            "shared_mass_l/a/v=%.4f/%.4f/%.4f | "
            "usage_l=[%s] | usage_a=[%s] | usage_v=[%s]",
            epoch + 1,
            hybrid_expert_epoch_totals['residual_abs_mean'] / count,
            hybrid_expert_epoch_totals['residual_norm_mean'] / count,
            mean_orthogonality,
            args.hybrid_expert_orthogonality_weight * mean_orthogonality,
            hybrid_expert_epoch_totals['temperature'] / count,
            *mean_entropy.tolist(),
            *mean_private.tolist(),
            *mean_shared.tolist(),
            *weight_strings,
        )
    if protocol_consistency_totals['count']:
        count = protocol_consistency_totals['count']
        mean_loss = protocol_consistency_totals['loss'] / count
        logger.info(
            "PCMC consistency | epoch=%d | protocol=%s | loss=%.6f | "
            "weighted=%.6f | coverage=%.4f | eligible_per_batch=%.2f | "
            "teacher_confidence=%.4f | teacher_abs_prediction=%.4f | "
            "student_teacher_abs_gap=%.4f | disagreement=%.4f | "
            "eligible_disagreement=%.4f",
            epoch + 1,
            args.fixed_protocol,
            mean_loss,
            args.protocol_consistency_weight * mean_loss,
            protocol_consistency_totals['coverage'] / count,
            protocol_consistency_totals['eligible_count'] / count,
            protocol_consistency_totals['teacher_confidence'] / count,
            protocol_consistency_totals['teacher_abs_prediction'] / count,
            protocol_consistency_totals['student_teacher_abs_gap'] / count,
            protocol_consistency_totals['polarity_disagreement'] / count,
            (
                protocol_consistency_totals[
                    'eligible_polarity_disagreement'
                ] / count
            ),
        )
    if relation_distill_totals['count']:
        count = relation_distill_totals['count']
        mean_loss = relation_distill_totals['loss'] / count
        logger.info(
            "TAG-MRD relation | epoch=%d | protocol=%s | loss=%.6f | "
            "weighted=%.6f | coverage=%.4f | eligible_per_batch=%.2f | "
            "teacher_mae=%.6f | student_mae=%.6f | "
            "teacher_advantage=%.6f | relation_gap=%.6f",
            epoch + 1,
            args.fixed_protocol,
            mean_loss,
            args.relation_distill_weight * mean_loss,
            relation_distill_totals['coverage'] / count,
            relation_distill_totals['eligible_count'] / count,
            relation_distill_totals['teacher_mae'] / count,
            relation_distill_totals['student_mae'] / count,
            relation_distill_totals['teacher_advantage'] / count,
            relation_distill_totals['relation_gap'] / count,
        )
    if missing_text_contrast_totals['count']:
        count = missing_text_contrast_totals['count']
        mean_pair = missing_text_contrast_totals['pair_loss'] / count
        mean_contrast = (
            missing_text_contrast_totals['contrastive_loss'] / count
        )
        logger.info(
            "LSCMR missing text | epoch=%d | protocol=%s | mode=%s | "
            "pair_loss=%.6f | pair_weighted=%.6f | contrast_loss=%.6f | "
            "contrast_weighted=%.6f | eligible_per_batch=%.2f | "
            "positive_similarity=%.6f | negative_similarity=%.6f | "
            "semantic_weight=%.6f | candidate_target_gap=%.6f | "
            "scale=%.6f | prediction_norm=%.6f | injected_norm=%.6f",
            epoch + 1,
            args.fixed_protocol,
            args.missing_text_contrast_mode,
            mean_pair,
            args.missing_text_pair_loss_weight * mean_pair,
            mean_contrast,
            args.missing_text_contrast_loss_weight * mean_contrast,
            missing_text_contrast_totals['eligible_count'] / count,
            missing_text_contrast_totals['positive_similarity'] / count,
            missing_text_contrast_totals['negative_similarity'] / count,
            missing_text_contrast_totals['semantic_weight'] / count,
            missing_text_contrast_totals['candidate_target_gap'] / count,
            missing_text_contrast_totals['scale'] / count,
            missing_text_contrast_totals['prediction_norm'] / count,
            missing_text_contrast_totals['injected_norm'] / count,
        )
    if privileged_purification_totals['count']:
        count = privileged_purification_totals['count']
        scales = privileged_purification_totals['scales'] / count
        logger.info(
            "PDRP purification | epoch=%d | protocol=%s | mode=%s | "
            "shared_loss=%.6f | orthogonality_loss=%.6f | "
            "separation_loss=%.6f | eligible_per_batch=%.2f | "
            "shared_cosine=%.6f | scales_l/a/v=%.6f/%.6f/%.6f | "
            "residual_norm=%.6f | injected_norm=%.6f",
            epoch + 1,
            args.fixed_protocol,
            args.privileged_purification_mode,
            privileged_purification_totals['shared_loss'] / count,
            privileged_purification_totals['orthogonality_loss'] / count,
            privileged_purification_totals['separation_loss'] / count,
            privileged_purification_totals['eligible_count'] / count,
            privileged_purification_totals['shared_cosine'] / count,
            scales[0].item(),
            scales[1].item(),
            scales[2].item(),
            privileged_purification_totals['residual_norm'] / count,
            privileged_purification_totals['injected_norm'] / count,
        )
    if language_hyper_totals['count']:
        count = language_hyper_totals['count']
        attention = language_hyper_totals['attention'] / count
        logger.info(
            "AT-LDHR language hyper residual | epoch=%d | protocol=%s | "
            "mode=%s | attention_ea/ev/ra/rv=%.6f/%.6f/%.6f/%.6f | "
            "entropy=%.6f | eligible_per_batch=%.2f | scale=%.6f | "
            "residual_norm=%.6f | injected_norm=%.6f",
            epoch + 1,
            args.fixed_protocol,
            args.language_hyper_mode,
            attention[0].item(),
            attention[1].item(),
            attention[2].item(),
            attention[3].item(),
            language_hyper_totals['attention_entropy'] / count,
            language_hyper_totals['eligible_count'] / count,
            language_hyper_totals['scale'] / count,
            language_hyper_totals['residual_norm'] / count,
            language_hyper_totals['injected_norm'] / count,
        )
    if coupled_prompt_totals['count']:
        count = coupled_prompt_totals['count']
        attention = coupled_prompt_totals['attention'] / count
        residual_norms = coupled_prompt_totals['residual_norms'] / count
        scales = coupled_prompt_totals['scales'] / count
        missing_count = coupled_prompt_totals['missing_count'] / count
        logger.info(
            "LCMPR layerwise prompt | epoch=%d | protocol=%s | depth=%d | "
            "length=%d | scales=%s | residual_norms=%s | "
            "attention_slot0=%s | missing_per_batch=%s",
            epoch + 1,
            args.fixed_protocol,
            args.coupled_prompt_depth,
            args.coupled_prompt_length,
            scales.tolist(),
            residual_norms.tolist(),
            attention[..., 0].tolist(),
            missing_count.tolist(),
        )
    if args.consistency_mode != 'mixed':
        logger.info(
            "MMD epoch | epoch=%d | mode=%s | "
            "loss_l/a/v=%.6f/%.6f/%.6f | "
            "mean_obs_rate_l/a/v=%.3f/%.3f/%.3f | "
            "obs_rate_range_l/a/v=%.3f-%.3f/%.3f-%.3f/%.3f-%.3f | "
            "skipped_obs_l/a/v=%d/%d/%d | skipped_miss_l/a/v=%d/%d/%d",
            epoch + 1,
            args.consistency_mode,
            mmd_epoch_totals['l']['loss'] / nb_tr_steps,
            mmd_epoch_totals['a']['loss'] / nb_tr_steps,
            mmd_epoch_totals['v']['loss'] / nb_tr_steps,
            mmd_epoch_totals['l']['observed_fraction'] / nb_tr_steps,
            mmd_epoch_totals['a']['observed_fraction'] / nb_tr_steps,
            mmd_epoch_totals['v']['observed_fraction'] / nb_tr_steps,
            mmd_epoch_totals['l']['min_observed_fraction'],
            mmd_epoch_totals['l']['max_observed_fraction'],
            mmd_epoch_totals['a']['min_observed_fraction'],
            mmd_epoch_totals['a']['max_observed_fraction'],
            mmd_epoch_totals['v']['min_observed_fraction'],
            mmd_epoch_totals['v']['max_observed_fraction'],
            mmd_epoch_totals['l']['observed_skipped'],
            mmd_epoch_totals['a']['observed_skipped'],
            mmd_epoch_totals['v']['observed_skipped'],
            mmd_epoch_totals['l']['missing_skipped'],
            mmd_epoch_totals['a']['missing_skipped'],
            mmd_epoch_totals['v']['missing_skipped'],
        )
    if args.gate_mode == 'counterfactual_harm_v23':
        count = gate_supervision_totals['count']
        if count:
            target_by_modality = (
                gate_supervision_totals['target_by_modality'] / count
            )
            logger.info(
                "Gate-V2.3 supervision | epoch=%d | loss=%.6f | "
                "harm_target=%.6f | harmful_fraction=%.6f | "
                "abs_margin=%.6f | target_l/a/v=%.6f/%.6f/%.6f",
                epoch + 1,
                gate_supervision_totals['loss'] / count,
                gate_supervision_totals['harm_target_mean'] / count,
                gate_supervision_totals['harmful_fraction'] / count,
                gate_supervision_totals['absolute_margin_mean'] / count,
                target_by_modality[0].item(),
                target_by_modality[1].item(),
                target_by_modality[2].item(),
            )
        else:
            logger.info(
                "Gate-V2.3 supervision | epoch=%d | warmup=true",
                epoch + 1,
            )
    elif args.gate_mode == 'counterfactual_scale_v24':
        log_v24_supervision(v24_supervision_totals, 'train', epoch)
    if use_retrieval_supervision:
        logger.info(
            "Retrieval supervision | epoch=%d | mode=%s | missing_query=%s | "
            "kl=%.6f | weighted=%.6f",
            epoch + 1,
            args.retrieval_metric_mode,
            args.retrieval_missing_query,
            retrieval_loss_total / nb_tr_steps,
            args.retrieval_loss_weight * retrieval_loss_total / nb_tr_steps,
        )
    if use_paired_distillation:
        mean_sample = distillation_totals['sample'] / nb_tr_steps
        mean_fusion = distillation_totals['fusion'] / nb_tr_steps
        logger.info(
            "Paired distillation | epoch=%d | sample=%.6f | fusion=%.6f | "
            "weighted=%.6f",
            epoch + 1,
            mean_sample,
            mean_fusion,
            args.distill_sample_weight * mean_sample
            + args.distill_fusion_weight * mean_fusion,
        )
    
    return tr_loss / nb_tr_steps

def eval_epoch(model: nn.Module, dev_dataloader: DataLoader, epoch=None):
    model.eval()
    dev_loss = 0
    nb_dev_steps = 0
    dev_absolute_error = 0.0
    dev_example_count = 0
    v24_supervision_totals = new_v24_supervision_totals()
    bundle_totals = {
        'eligible_count': torch.zeros(3, dtype=torch.float64),
        'top1_similarity': 0.0,
        'top1_sentiment_gap': 0.0,
        'observed_modalities': 0.0,
        'count': 0,
    }
    nums = args.dev_nums
    if args.fixed_missing:
        ps = generate_fixed_missing_matrix(nums, fixed_protocol=args.fixed_protocol)
    else:
        ps = generate_missing_matrix(nums, 3, missing_rate=args.missing_rate)

    with torch.no_grad():
        for batch_idx, batch in enumerate(tqdm(dev_dataloader, desc="Iteration")):
            batch = tuple(t.to(DEVICE) for t in batch)
            (
                input_ids,
                visual,
                acoustic,
                input_mask,
                segment_ids,
                label_ids,
                sample_ids,
            ) = unpack_dataset_batch(batch)
            visual = torch.squeeze(visual, 1)
            acoustic = torch.squeeze(acoustic, 1)
            batch_size = visual.shape[0]
            batch_ps = ps[batch_idx * batch_size : (batch_idx + 1) * batch_size]
            batch_ps = torch.from_numpy(batch_ps).to(DEVICE)
    
            visual = torch.squeeze(visual, 1)
            acoustic = torch.squeeze(acoustic, 1)
            outputs = model.test(
                input_ids,
                 visual,
                 acoustic,
                 batch_ps,
                token_type_ids=segment_ids,
                attention_mask=input_mask,
                labels=(
                    label_ids
                    if args.gate_mode == 'counterfactual_scale_v24'
                    else None
                ),
            )

            bundle_info = outputs.get('bundle_retrieval_diagnostics', {})
            if bundle_info.get('enabled', False):
                bundle_totals['eligible_count'] += (
                    bundle_info['eligible_count'].cpu().double()
                )
                for name in (
                    'top1_similarity',
                    'top1_sentiment_gap',
                    'observed_modalities',
                ):
                    bundle_totals[name] += bundle_info[name].item()
                bundle_totals['count'] += 1

            gate_info = outputs.get('gate_supervision_diagnostics')
            if gate_info is not None:
                update_v24_supervision_totals(
                    v24_supervision_totals, gate_info
                )

            predictions = outputs['predictions']

            loss_fct = L1Loss()
            loss_task = loss_fct(predictions.view(-1), label_ids.view(-1))
            loss = loss_task
            if args.paper_experiment:
                dev_absolute_error += torch.abs(
                    predictions.view(-1) - label_ids.view(-1)
                ).sum().item()
                dev_example_count += label_ids.numel()
            
            if args.gradient_accumulation_step > 1:
                loss = loss / args.gradient_accumulation_step

            dev_loss += loss.item()
            nb_dev_steps += 1
    if args.gate_mode == 'counterfactual_scale_v24':
        log_v24_supervision(v24_supervision_totals, 'dev', epoch)
    if bundle_totals['count']:
        count = bundle_totals['count']
        scale = model.same_sample_bundle_retrieval.injection_scale.item()
        logger.info(
            "SCBR dev diagnostics | scale=%.6f | "
            "eligible_l/a/v=%.2f/%.2f/%.2f | top1_similarity=%.6f | "
            "top1_sentiment_gap=%.6f | observed_modalities=%.3f",
            scale,
            *(bundle_totals['eligible_count'] / count).tolist(),
            bundle_totals['top1_similarity'] / count,
            bundle_totals['top1_sentiment_gap'] / count,
            bundle_totals['observed_modalities'] / count,
        )
    if args.paper_experiment:
        if dev_example_count == 0:
            raise RuntimeError("Development split is empty")
        return dev_absolute_error / dev_example_count
    return dev_loss / nb_dev_steps


def update_gate_statistics(statistics, diagnostics):
    if not diagnostics.get("enabled", False):
        return

    for modality in ('l', 'a', 'v'):
        for branch, branch_diagnostics in diagnostics[modality].items():
            reliability = branch_diagnostics["reliability"].double()
            multiplier = branch_diagnostics["multiplier"].double()
            observed = branch_diagnostics["observed"].bool()
            groups = {'observed': observed}
            if branch == 'enhanced':
                groups['missing'] = ~observed

            for group, selection in groups.items():
                key = (modality, branch, group)
                selection_float = selection.to(reliability.dtype)
                if key not in statistics:
                    statistics[key] = {
                        'reliability_sum': reliability.new_zeros(()),
                        'reliability_square_sum': reliability.new_zeros(()),
                        'multiplier_sum': multiplier.new_zeros(()),
                        'multiplier_square_sum': multiplier.new_zeros(()),
                        'multiplier_min': multiplier.new_full((), float('inf')),
                        'multiplier_max': multiplier.new_full((), float('-inf')),
                        'count': reliability.new_zeros(()),
                        'quality': {},
                        'extra': {},
                    }
                entry = statistics[key]
                entry['reliability_sum'] += (
                    reliability * selection_float
                ).sum()
                entry['reliability_square_sum'] += (
                    reliability.square() * selection_float
                ).sum()
                entry['multiplier_sum'] += (
                    multiplier * selection_float
                ).sum()
                entry['multiplier_square_sum'] += (
                    multiplier.square() * selection_float
                ).sum()
                entry['multiplier_min'] = torch.minimum(
                    entry['multiplier_min'],
                    multiplier.masked_fill(~selection, float('inf')).min(),
                )
                entry['multiplier_max'] = torch.maximum(
                    entry['multiplier_max'],
                    multiplier.masked_fill(~selection, float('-inf')).max(),
                )
                entry['count'] += selection_float.sum()

                for diagnostic_name in ('prior_scale', 'residual_logit'):
                    if diagnostic_name not in branch_diagnostics:
                        continue
                    diagnostic_value = branch_diagnostics[
                        diagnostic_name
                    ].double()
                    if diagnostic_name not in entry['extra']:
                        entry['extra'][diagnostic_name] = {
                            'sum': diagnostic_value.new_zeros(()),
                            'square_sum': diagnostic_value.new_zeros(()),
                        }
                    extra_entry = entry['extra'][diagnostic_name]
                    extra_entry['sum'] += (
                        diagnostic_value * selection_float
                    ).sum()
                    extra_entry['square_sum'] += (
                        diagnostic_value.square() * selection_float
                    ).sum()

                for quality_name, quality_value in branch_diagnostics.get(
                    'quality', {}
                ).items():
                    quality_value = quality_value.double()
                    if quality_name not in entry['quality']:
                        entry['quality'][quality_name] = {
                            'sum': quality_value.new_zeros(()),
                            'square_sum': quality_value.new_zeros(()),
                            'reliability_product_sum': quality_value.new_zeros(()),
                        }
                    quality_entry = entry['quality'][quality_name]
                    quality_entry['sum'] += (
                        quality_value * selection_float
                    ).sum()
                    quality_entry['square_sum'] += (
                        quality_value.square() * selection_float
                    ).sum()
                    quality_entry['reliability_product_sum'] += (
                        quality_value * reliability * selection_float
                    ).sum()


def log_gate_statistics(statistics):
    if not statistics:
        return

    for key in sorted(statistics):
        modality, branch, group = key
        entry = statistics[key]
        count = entry['count'].item()
        if count == 0:
            continue
        reliability_mean = entry['reliability_sum'].item() / count
        reliability_variance = max(
            0.0,
            entry['reliability_square_sum'].item() / count
            - reliability_mean ** 2,
        )
        multiplier_mean = entry['multiplier_sum'].item() / count
        multiplier_variance = max(
            0.0,
            entry['multiplier_square_sum'].item() / count
            - multiplier_mean ** 2,
        )

        correlations = []
        for quality_name in sorted(entry['quality']):
            quality_entry = entry['quality'][quality_name]
            quality_mean = quality_entry['sum'].item() / count
            quality_variance = max(
                0.0,
                quality_entry['square_sum'].item() / count
                - quality_mean ** 2,
            )
            denominator = math.sqrt(
                reliability_variance * quality_variance
            )
            if denominator > 1e-12:
                covariance = (
                    quality_entry['reliability_product_sum'].item() / count
                    - reliability_mean * quality_mean
                )
                correlation = max(
                    -1.0, min(1.0, covariance / denominator)
                )
                correlations.append(
                    "{}:{:.3f}".format(quality_name, correlation)
                )

        extra_diagnostics = []
        for diagnostic_name in sorted(entry.get('extra', {})):
            extra_entry = entry['extra'][diagnostic_name]
            diagnostic_mean = extra_entry['sum'].item() / count
            diagnostic_variance = max(
                0.0,
                extra_entry['square_sum'].item() / count
                - diagnostic_mean ** 2,
            )
            extra_diagnostics.append(
                "{}={:.6f}+/-{:.6f}".format(
                    diagnostic_name,
                    diagnostic_mean,
                    math.sqrt(diagnostic_variance),
                )
            )

        logger.info(
            "Gate diagnostics | %s.%s.%s | r=%.6f+/-%.6f | "
            "scale=%.6f+/-%.6f[%.6f,%.6f] | corr={%s} | %s",
            modality,
            branch,
            group,
            reliability_mean,
            math.sqrt(reliability_variance),
            multiplier_mean,
            math.sqrt(multiplier_variance),
            entry['multiplier_min'].item(),
            entry['multiplier_max'].item(),
            ",".join(correlations),
            " | ".join(extra_diagnostics) or "extra={}",
        )


def new_retrieval_mechanism_totals():
    return {
        modality: {'distance_sum': 0.0, 'same_polarity_sum': 0.0, 'count': 0}
        for modality in ('l', 'a', 'v')
    }


def update_retrieval_mechanism_totals(totals, diagnostics, labels):
    """Measure selected neighbours after retrieval; never affect selection."""
    labels = labels.view(-1)
    batch_size = labels.numel()
    for modality in ('l', 'a', 'v'):
        modality_diagnostics = diagnostics[modality]
        indices = modality_diagnostics['topk_indices']
        valid = modality_diagnostics['topk_valid'].bool()
        in_batch = valid & (indices >= 0) & (indices < batch_size)
        if not bool(in_batch.any()):
            continue
        safe_indices = indices.clamp(min=0, max=max(0, batch_size - 1))
        neighbour_labels = labels[safe_indices]
        query_labels = labels.unsqueeze(1).expand_as(neighbour_labels)
        entry = totals[modality]
        entry['distance_sum'] += torch.abs(
            query_labels[in_batch] - neighbour_labels[in_batch]
        ).sum().item()
        entry['same_polarity_sum'] += (
            (query_labels[in_batch] >= 0)
            == (neighbour_labels[in_batch] >= 0)
        ).sum().item()
        entry['count'] += int(in_batch.sum().item())


def log_retrieval_mechanism_totals(totals, split):
    distances = []
    polarities = []
    counts = []
    for modality in ('l', 'a', 'v'):
        entry = totals[modality]
        count = entry['count']
        counts.append(count)
        if count:
            distances.append(entry['distance_sum'] / count)
            polarities.append(entry['same_polarity_sum'] / count)
        else:
            distances.append(float('nan'))
            polarities.append(float('nan'))
    logger.info(
        "Retrieval mechanism | split=%s | "
        "mean_label_distance_l/a/v=%.6f/%.6f/%.6f | "
        "same_polarity_l/a/v=%.6f/%.6f/%.6f | pairs_l/a/v=%d/%d/%d | "
        "polarity_rule=label>=0",
        split,
        *distances,
        *polarities,
        *counts,
    )


def test_epoch(model: nn.Module, test_dataloader: DataLoader):
    model.eval()
    preds = []
    labels = []
    gate_statistics = {}
    retrieval_mechanism_totals = new_retrieval_mechanism_totals()
    nums = args.test_nums
    if args.fixed_missing:
        ps = generate_fixed_missing_matrix(nums, fixed_protocol=args.fixed_protocol)
    else:
        ps = generate_missing_matrix(nums, 3, missing_rate=args.missing_rate)
    
    with torch.no_grad():
        for batch_idx, batch in enumerate(tqdm(test_dataloader, desc="Iteration")):
            batch = tuple(t.to(DEVICE) for t in batch)
            (
                input_ids,
                visual,
                acoustic,
                input_mask,
                segment_ids,
                label_ids,
                sample_ids,
            ) = unpack_dataset_batch(batch)
            visual = torch.squeeze(visual, 1)
            acoustic = torch.squeeze(acoustic, 1)
            batch_size = visual.shape[0]
            batch_ps = ps[batch_idx * batch_size : (batch_idx + 1) * batch_size]
            batch_ps = torch.from_numpy(batch_ps).to(DEVICE)
            
            outputs = model.test(
                input_ids,
                 visual,
                 acoustic,
                batch_ps,
                token_type_ids=segment_ids,
                attention_mask=input_mask,
                labels=None,
            )

            predictions = outputs['predictions']
            update_gate_statistics(
                gate_statistics, outputs.get('gate_diagnostics', {})
            )
            if args.retrieval_metric_mode == 'sentiment_guided':
                update_retrieval_mechanism_totals(
                    retrieval_mechanism_totals,
                    outputs['retrieval_diagnostics'],
                    label_ids,
                )
            logits = predictions.detach().cpu().numpy()
            label_ids = label_ids.detach().cpu().numpy()
            logits = np.squeeze(logits).tolist()
            label_ids = np.squeeze(label_ids).tolist()
            preds.extend(logits)
            labels.extend(label_ids)

    preds = np.array(preds)
    labels = np.array(labels)
    log_gate_statistics(gate_statistics)
    if args.retrieval_metric_mode == 'sentiment_guided':
        log_retrieval_mechanism_totals(
            retrieval_mechanism_totals, 'test_posthoc'
        )

    return preds, labels


def export_e19_fixed_protocol_predictions(model, test_dataloader):
    """Export one frozen specialist's predictions for later E19 routing."""
    output = os.path.abspath(args.paper_e19_prediction_output)
    if os.path.exists(output):
        raise FileExistsError(
            "E19 prediction export already exists and is immutable: {}".format(
                output
            )
        )
    predictions, labels = test_epoch(model, test_dataloader)
    predictions = np.asarray(predictions, dtype=np.float64).reshape(-1)
    labels = np.asarray(labels, dtype=np.float64).reshape(-1)
    if predictions.shape != labels.shape:
        raise RuntimeError("E19 prediction/label shape mismatch")
    if predictions.size != int(args.test_nums):
        raise RuntimeError(
            "E19 export expected {} test samples, received {}".format(
                args.test_nums, predictions.size
            )
        )
    sample_ids = np.arange(predictions.size, dtype=np.int64)
    output_dir = os.path.dirname(output)
    if output_dir:
        os.makedirs(output_dir, exist_ok=True)
    temporary = output + ".tmp.npz"
    if os.path.exists(temporary):
        raise FileExistsError(
            "Stale E19 temporary export requires manual audit: {}".format(
                temporary
            )
        )
    np.savez_compressed(
        temporary,
        sample_ids=sample_ids,
        predictions=predictions,
        labels=labels,
        source_run_id=np.asarray(args.paper_e19_source_run_id),
        protocol=np.asarray(args.fixed_protocol),
        seed=np.asarray(int(args.seed), dtype=np.int64),
        checkpoint_sha256=np.asarray(sha256_file(args.model_path)),
        dataset_sha256=np.asarray(
            sha256_file(resolve_dataset_path(os.getcwd(), args.dataset))
        ),
    )
    os.replace(temporary, output)
    logger.info(
        "E19 fixed-protocol predictions exported | source_run=%s | "
        "protocol=%s | samples=%d | checkpoint_sha256=%s | output=%s",
        args.paper_e19_source_run_id,
        args.fixed_protocol,
        predictions.size,
        sha256_file(args.model_path),
        output,
    )
    return output


def audit_pns_epoch(model: nn.Module, test_dataloader: DataLoader):
    """Run branch counterfactuals without changing model parameters."""
    model.eval()
    accumulator = PNSAuditAccumulator()
    nums = args.test_nums
    if args.fixed_missing:
        ps = generate_fixed_missing_matrix(
            nums, fixed_protocol=args.fixed_protocol
        )
    else:
        ps = generate_missing_matrix(
            nums, 3, missing_rate=args.missing_rate
        )

    with torch.no_grad():
        for batch_idx, batch in enumerate(
            tqdm(test_dataloader, desc="PNS audit")
        ):
            batch = tuple(t.to(DEVICE) for t in batch)
            (
                input_ids,
                visual,
                acoustic,
                input_mask,
                segment_ids,
                label_ids,
                sample_ids,
            ) = unpack_dataset_batch(batch)
            visual = torch.squeeze(visual, 1)
            acoustic = torch.squeeze(acoustic, 1)
            batch_size = visual.shape[0]
            batch_ps = ps[
                batch_idx * batch_size : (batch_idx + 1) * batch_size
            ]
            batch_ps = torch.from_numpy(batch_ps).to(DEVICE)

            outputs = model.test(
                input_ids,
                visual,
                acoustic,
                batch_ps,
                token_type_ids=segment_ids,
                attention_mask=input_mask,
                labels=None,
            )
            diagnostics = evaluate_enhanced_branch_counterfactuals(
                model.fuse_representations,
                outputs['fusion_representations'],
                label_ids,
                batch_ps,
                threshold=args.pns_threshold,
                factual_prediction=outputs['predictions'],
            )
            accumulator.update(diagnostics)

    summaries = accumulator.summaries()
    for modality in ('l', 'a', 'v'):
        summary = summaries[modality]
        logger.info(
            "PNS audit | protocol=%s | modality=%s | samples=%d | "
            "observed_rate=%.6f | factual_mae=%.6f | removed_mae=%.6f | "
            "branch_only_mae=%.6f | null_mae=%.6f | "
            "necessity_margin=%.6f | sufficiency_margin=%.6f | "
            "necessary_rate=%.6f | sufficient_rate=%.6f | "
            "necessity_positive_rate=%.6f | "
            "sufficiency_positive_rate=%.6f | "
            "harmful_rate=%.6f | pns_event_score=%.6f",
            args.fixed_protocol,
            modality,
            summary['count'],
            summary['observed_rate'],
            summary['factual_error'],
            summary['removed_error'],
            summary['branch_only_error'],
            summary['null_error'],
            summary['necessity_margin'],
            summary['sufficiency_margin'],
            summary['necessity_event_rate'],
            summary['sufficiency_event_rate'],
            summary['necessity_positive_rate'],
            summary['sufficiency_positive_rate'],
            summary['harmful_rate'],
            summary['pns_event_score'],
        )
    return summaries


def multiclass_acc(preds, truths):
    """
    Compute the multiclass accuracy w.r.t. groundtruth

    :param preds: Float array representing the predictions, dimension (N,)
    :param truths: Float/int array representing the groundtruth classes, dimension (N,)
    :return: Classification accuracy
    """
    return np.sum(np.round(preds) == np.round(truths)) / float(len(truths))

def test_score_model(model: nn.Module, test_dataloader: DataLoader, use_zero=False):
    if FINAL_TEST_GATE is not None:
        FINAL_TEST_GATE.record_access()
    test_preds, test_truth = test_epoch(model, test_dataloader)
    mae = np.mean(np.absolute(test_preds - test_truth))
    corr = np.corrcoef(test_preds, test_truth)[0][1]
    
    non_zeros = np.array(
        [i for i, e in enumerate(test_truth) if e != 0 or use_zero])

    test_preds_a7 = np.clip(test_preds, a_min=-3., a_max=3.)
    test_truth_a7 = np.clip(test_truth, a_min=-3., a_max=3.)
    mult_a7 = multiclass_acc(test_preds_a7, test_truth_a7)
    
    test_preds_a5 = np.clip(test_preds, a_min=-2., a_max=2.)
    test_truth_a5 = np.clip(test_truth, a_min=-2., a_max=2.)
    mult_a5 = multiclass_acc(test_preds_a5, test_truth_a5)
    binary_truth_o = (test_truth[non_zeros] > 0)
    binary_preds_o = (test_preds[non_zeros] > 0)
    acc2_non_zero = accuracy_score(binary_truth_o, binary_preds_o)
    f_score_non_zero = f1_score(binary_truth_o, binary_preds_o,  average='weighted')
    binary_truth = (test_truth >= 0)
    binary_preds = (test_preds >= 0)
    acc2 = accuracy_score(binary_truth, binary_preds)
    f_score = f1_score(binary_truth, binary_preds, average='weighted')
    f_score_bias = f1_score((test_preds > 0), (test_truth >= 0), average='weighted')

    return mae, corr, mult_a7, mult_a5, acc2_non_zero, f_score_non_zero, acc2, f_score


TEST_METRIC_NAMES = (
    "test_mae",
    "test_corr",
    "test_acc7",
    "test_acc5",
    "test_acc2_non_zero",
    "test_f1_non_zero",
    "test_acc2",
    "test_f1",
)


def named_test_metrics(metrics):
    if len(metrics) != len(TEST_METRIC_NAMES):
        raise ValueError("Unexpected number of final test metrics")
    return {
        name: float(value)
        for name, value in zip(TEST_METRIC_NAMES, metrics)
    }


def evaluate_scbr_scale_grid(
    model,
    validation_dataloader,
    test_data_loader,
    best_model_path,
):
    """Select a fixed SCBR injection scale using development MAE only."""
    model.eval()
    best_scale = None
    best_loss = float("inf")
    scale_losses = []
    logger.info(
        "SCBR scale search started | scales=%s | optimizer=none | "
        "selection_metric=dev_mae",
        args.bundle_injection_scale_values,
    )
    for scale in args.bundle_injection_scale_values:
        model.set_bundle_injection_scale(scale)
        dev_loss = eval_epoch(model, validation_dataloader, epoch=None)
        scale_losses.append((scale, dev_loss))
        logger.info(
            "SCBR scale result | scale=%.6f | dev_loss=%.6f",
            scale,
            dev_loss,
        )
        if dev_loss < best_loss:
            best_loss = dev_loss
            best_scale = scale

    model.set_bundle_injection_scale(best_scale)
    torch.save(
        {
            name: tensor.detach().cpu()
            for name, tensor in model.state_dict().items()
        },
        best_model_path,
    )
    best_metrics = None
    if not args.paper_experiment:
        best_metrics = test_score_model(model, test_data_loader)
        logger.info(
            "Improvement-12 selected | scale=%.6f | dev_loss=%.6f | "
            "mae=%.6f | corr=%.6f | acc7=%.6f | acc5=%.6f | "
            "acc2_non_zero=%.6f | f1_non_zero=%.6f | "
            "acc2=%.6f | f1=%.6f",
            best_scale,
            best_loss,
            *best_metrics,
        )
    else:
        logger.info(
            "SCBR selection completed without test access | "
            "scale=%.6f | dev_loss=%.6f",
            best_scale,
            best_loss,
        )
    logger.info(
        "SCBR checkpoint saved | path=%s | selected_scale=%.6f",
        os.path.abspath(best_model_path),
        best_scale,
    )
    return {
        "best_epoch": 0,
        "best_loss": best_loss,
        "best_metrics": best_metrics,
        "best_scale": best_scale,
        "scale_losses": scale_losses,
        "completed_epochs": 0,
    }


def train(
    model,
    train_dataloader,
    train_bank_dataloader,
    validation_dataloader,
    test_data_loader,
    best_model_path,
):
    if args.cross_modal_retrieval_mode == 'scbr':
        return evaluate_scbr_scale_grid(
            model,
            validation_dataloader,
            test_data_loader,
            best_model_path,
        )
    valid_losses = []
    test_accuracies = []
    f1_scores = []
    best_loss = float("inf")
    best_epoch = -1
    best_metrics = None
    baseline_loss = None
    epochs_without_improvement = 0
    relation_teacher = None
    if args.relation_distill_mode == 'tag_mrd':
        relation_teacher = FrozenLateFusionTeacher(
            model.transformer_encoder_all,
            model.fusion_all,
        ).to(DEVICE)
        teacher_parameters = sum(
            parameter.numel() for parameter in relation_teacher.parameters()
        )
        logger.info(
            "TAG-MRD frozen teacher snapshot created | parameters=%d | "
            "serialized=false | inference_branch=none",
            teacher_parameters,
        )
    optimizer = build_optimizer(model)

    def frozen_ablation_state_dict():
        state_dict = {
            name: tensor.detach().cpu()
            for name, tensor in model.state_dict().items()
        }
        if (
            args.prompt_mode == 'missing_dynamic'
            and args.prompt_finetune_scope == 'head_only'
            and not args.paper_experiment
        ):
            state_dict = {
                name: tensor
                for name, tensor in state_dict.items()
                if not name.startswith('dynamic_prompt_adapter.')
            }
        return state_dict

    logger.info(
        "Training started | dataset=%s | protocol=%s | max_epochs=%s | patience=%s | min_delta=%s",
        args.dataset,
        args.fixed_protocol,
        args.n_epochs,
        args.early_stopping_patience,
        args.early_stopping_min_delta,
    )
    logger.info("Best model path: %s", os.path.abspath(best_model_path))

    if (
        args.prompt_mode == 'missing_dynamic'
        or args.reconstruction_mode == 'text_guided_nonverbal'
        or args.consensus_mode == 'amucr'
        or args.tag_mode == 'amtfb'
        or args.cross_modal_retrieval_mode == 'agcqr'
        or args.training_prior_mode == 'tspe'
        or args.hybrid_expert_mode == 'acher'
        or args.protocol_consistency_mode == 'pcmc'
        or args.protocol_fusion_readaptation
        or args.relation_distill_mode == 'tag_mrd'
        or args.missing_text_contrast_mode in ('feature', 'label')
        or args.privileged_purification_mode in ('task_only', 'full')
        or args.language_hyper_mode in (
            'availability_only', 'language_query'
        )
        or args.coupled_prompt_mode == 'lcmpr'
    ):
        baseline_loss = eval_epoch(model, validation_dataloader, epoch=-1)
        baseline_metrics = None
        if not args.paper_experiment:
            baseline_metrics = test_score_model(model, test_data_loader)
        best_loss = baseline_loss
        best_epoch = 0
        best_metrics = baseline_metrics
        torch.save(frozen_ablation_state_dict(), best_model_path)
        if args.paper_experiment:
            logger.info(
                "Formal epoch-0 candidate | selection_split=development | "
                "dev_loss=%.6f | test_access=false",
                baseline_loss,
            )
        elif args.coupled_prompt_mode == 'lcmpr':
            logger.info(
                "Improvement-20 epoch 000 first+seventh+FPFR baseline | "
                "depth=%d | prompt_length=%d | residual_scales=0 | "
                "student_protocol=%s | evaluation_path=exact_foundation | "
                "dev_loss=%.6f | mae=%.6f | corr=%.6f | acc7=%.6f | "
                "acc5=%.6f | acc2_non_zero=%.6f | f1_non_zero=%.6f | "
                "acc2=%.6f | f1=%.6f",
                args.coupled_prompt_depth,
                args.coupled_prompt_length,
                args.fixed_protocol,
                baseline_loss,
                *baseline_metrics,
            )
        elif args.language_hyper_mode in (
            'availability_only', 'language_query'
        ):
            logger.info(
                "Improvement-19 epoch 000 first+seventh+FPFR baseline | "
                "mode=%s | residual_scale=0 | student_protocol=%s | "
                "evaluation_path=exact_foundation | dev_loss=%.6f | "
                "mae=%.6f | corr=%.6f | acc7=%.6f | acc5=%.6f | "
                "acc2_non_zero=%.6f | f1_non_zero=%.6f | "
                "acc2=%.6f | f1=%.6f",
                args.language_hyper_mode,
                args.fixed_protocol,
                baseline_loss,
                *baseline_metrics,
            )
        elif args.privileged_purification_mode in ('task_only', 'full'):
            logger.info(
                "Improvement-18 epoch 000 first+seventh+FPFR baseline | "
                "mode=%s | residual_scales=0/0/0 | student_protocol=%s | "
                "evaluation_path=exact_foundation | dev_loss=%.6f | "
                "mae=%.6f | corr=%.6f | acc7=%.6f | acc5=%.6f | "
                "acc2_non_zero=%.6f | f1_non_zero=%.6f | "
                "acc2=%.6f | f1=%.6f",
                args.privileged_purification_mode,
                args.fixed_protocol,
                baseline_loss,
                *baseline_metrics,
            )
        elif args.missing_text_contrast_mode in ('feature', 'label'):
            logger.info(
                "Improvement-17 epoch 000 first+seventh+FPFR baseline | "
                "mode=%s | residual_scale=0 | student_protocol=%s | "
                "evaluation_path=exact_foundation | dev_loss=%.6f | "
                "mae=%.6f | corr=%.6f | acc7=%.6f | acc5=%.6f | "
                "acc2_non_zero=%.6f | f1_non_zero=%.6f | "
                "acc2=%.6f | f1=%.6f",
                args.missing_text_contrast_mode,
                args.fixed_protocol,
                baseline_loss,
                *baseline_metrics,
            )
        elif args.relation_distill_mode == 'tag_mrd':
            logger.info(
                "Improvement-16 epoch 000 first+seventh+FPFR baseline | "
                "relation_training=off | student_protocol=%s | "
                "evaluation_path=exact_foundation | dev_loss=%.6f | "
                "mae=%.6f | corr=%.6f | acc7=%.6f | acc5=%.6f | "
                "acc2_non_zero=%.6f | f1_non_zero=%.6f | "
                "acc2=%.6f | f1=%.6f",
                args.fixed_protocol,
                baseline_loss,
                *baseline_metrics,
            )
        elif args.protocol_fusion_readaptation:
            logger.info(
                "Improvement-15 epoch 000 first+seventh baseline | "
                "strategy=fixed_protocol_fusion_readaptation | "
                "adaptation_training=off | student_protocol=%s | "
                "evaluation_path=exact_first+seventh | dev_loss=%.6f | "
                "mae=%.6f | corr=%.6f | acc7=%.6f | acc5=%.6f | "
                "acc2_non_zero=%.6f | f1_non_zero=%.6f | "
                "acc2=%.6f | f1=%.6f",
                args.fixed_protocol,
                baseline_loss,
                *baseline_metrics,
            )
        elif args.protocol_consistency_mode == 'pcmc':
            logger.info(
                "Improvement-15 epoch 000 first+seventh baseline | "
                "consistency_training=off | student_protocol=%s | "
                "evaluation_path=exact_first+seventh | dev_loss=%.6f | "
                "mae=%.6f | corr=%.6f | acc7=%.6f | acc5=%.6f | "
                "acc2_non_zero=%.6f | f1_non_zero=%.6f | "
                "acc2=%.6f | f1=%.6f",
                args.fixed_protocol,
                baseline_loss,
                *baseline_metrics,
            )
        elif args.hybrid_expert_mode == 'acher':
            logger.info(
                "Improvement-14 epoch 000 first+seventh baseline | "
                "expert_residual=exact_zero | dev_loss=%.6f | "
                "mae=%.6f | corr=%.6f | acc7=%.6f | acc5=%.6f | "
                "acc2_non_zero=%.6f | f1_non_zero=%.6f | "
                "acc2=%.6f | f1=%.6f",
                baseline_loss,
                *baseline_metrics,
            )
        elif args.training_prior_mode == 'tspe':
            logger.info(
                "Improvement-13 epoch 000 first+seventh baseline | "
                "training_prior=off | evaluation_path=exact_identity | "
                "dev_loss=%.6f | mae=%.6f | corr=%.6f | "
                "acc7=%.6f | acc5=%.6f | "
                "acc2_non_zero=%.6f | f1_non_zero=%.6f | "
                "acc2=%.6f | f1=%.6f",
                baseline_loss,
                *baseline_metrics,
            )
        elif args.cross_modal_retrieval_mode == 'agcqr':
            logger.info(
                "Improvement-11 epoch 000 first+seventh baseline | "
                "mix_l/a/v=0/0/0 | dev_loss=%.6f | mae=%.6f | corr=%.6f | "
                "acc7=%.6f | acc5=%.6f | "
                "acc2_non_zero=%.6f | f1_non_zero=%.6f | "
                "acc2=%.6f | f1=%.6f",
                baseline_loss,
                *baseline_metrics,
            )
        elif args.tag_mode == 'amtfb':
            logger.info(
                "Improvement-10 epoch 000 first+seventh baseline | "
                "dev_loss=%.6f | mae=%.6f | corr=%.6f | "
                "acc7=%.6f | acc5=%.6f | "
                "acc2_non_zero=%.6f | f1_non_zero=%.6f | "
                "acc2=%.6f | f1=%.6f",
                baseline_loss,
                *baseline_metrics,
            )
        elif args.consensus_mode == 'amucr':
            logger.info(
                "Improvement-9 epoch 000 first+seventh baseline | "
                "dev_loss=%.6f | mae=%.6f | corr=%.6f | "
                "acc7=%.6f | acc5=%.6f | "
                "acc2_non_zero=%.6f | f1_non_zero=%.6f | "
                "acc2=%.6f | f1=%.6f",
                baseline_loss,
                *baseline_metrics,
            )
        elif args.reconstruction_mode == 'text_guided_nonverbal':
            logger.info(
                "Improvement-8 epoch 000 first+seventh baseline | "
                "dev_loss=%.6f | mae=%.6f | corr=%.6f | "
                "acc7=%.6f | acc5=%.6f | "
                "acc2_non_zero=%.6f | f1_non_zero=%.6f | "
                "acc2=%.6f | f1=%.6f",
                baseline_loss,
                *baseline_metrics,
            )
        else:
            logger.info(
                "Ablation epoch 000 q0 baseline | scope=%s | "
                "dev_loss=%.6f | mae=%.6f | "
                "corr=%.6f | acc7=%.6f | acc5=%.6f | "
                "acc2_non_zero=%.6f | f1_non_zero=%.6f | "
                "acc2=%.6f | f1=%.6f",
                args.prompt_finetune_scope,
                baseline_loss,
                *baseline_metrics,
            )
        logger.info(
            "Frozen epoch-0 baseline saved before isolated tuning | path=%s",
            os.path.abspath(best_model_path),
        )

    for epoch_i in range(int(args.n_epochs)):
        train_loss = train_epoch(
            model,
            train_dataloader,
            optimizer,
            epoch_i,
            relation_teacher=relation_teacher,
        )
        if (
            args.retrieval_candidate_source == 'train_bank'
            and (epoch_i + 1) % args.retrieval_bank_refresh_epochs == 0
        ):
            build_strict_retrieval_reference_banks(
                model, train_bank_dataloader
            )
        valid_loss = eval_epoch(model, validation_dataloader, epoch_i)
        current_test_metrics = None
        if not args.paper_experiment:
            current_test_metrics = test_score_model(model, test_data_loader)

        logger.info(
            "Epoch %03d | train_loss=%.6f | dev_loss=%.6f | "
            "test_evaluated=%s",
            epoch_i + 1,
            train_loss,
            valid_loss,
            current_test_metrics is not None,
        )
        if current_test_metrics is not None:
            logger.info(
                "Current metrics | mae=%.6f | corr=%.6f | acc7=%.6f | "
                "acc5=%.6f | acc2_non_zero=%.6f | f1_non_zero=%.6f | "
                "acc2=%.6f | f1=%.6f",
                *current_test_metrics,
            )

        valid_losses.append(valid_loss)
        if current_test_metrics is not None:
            test_accuracies.append(current_test_metrics[6])
            f1_scores.append(current_test_metrics[5])

        improved = valid_loss < (best_loss - args.early_stopping_min_delta)
        if improved:
            best_loss = valid_loss
            best_epoch = epoch_i + 1
            best_metrics = current_test_metrics
            epochs_without_improvement = 0
            torch.save(frozen_ablation_state_dict(), best_model_path)
            logger.info(
                "New best model saved | epoch=%d | dev_loss=%.6f",
                best_epoch,
                best_loss,
            )
        else:
            epochs_without_improvement += 1
            logger.info(
                "No dev-loss improvement | patience=%d/%d",
                epochs_without_improvement,
                args.early_stopping_patience,
            )

        if best_metrics is not None:
            logger.info(
                "Best so far | epoch=%d | dev_loss=%.6f | mae=%.6f | corr=%.6f | "
                "acc7=%.6f | acc5=%.6f | acc2_non_zero=%.6f | "
                "f1_non_zero=%.6f | acc2=%.6f | f1=%.6f",
                best_epoch,
                best_loss,
                *best_metrics,
            )

        if (
            args.early_stopping_patience > 0
            and epochs_without_improvement >= args.early_stopping_patience
        ):
            logger.info(
                "Early stopping triggered at epoch %d; best epoch was %d.",
                epoch_i + 1,
                best_epoch,
            )
            break

    logger.info(
        "Training finished | completed_epochs=%d | best_epoch=%d | best_dev_loss=%.6f",
        len(valid_losses),
        best_epoch,
        best_loss,
    )
    return {
        "best_epoch": best_epoch,
        "best_loss": best_loss,
        "best_metrics": best_metrics,
        "completed_epochs": len(valid_losses),
        "development_mae_history": valid_losses,
        "baseline_dev_mae": baseline_loss,
    }


def main():
    global FINAL_TEST_GATE
    FINAL_TEST_GATE = FinalTestGate(enabled=args.paper_experiment)
    if args.paper_experiment:
        args.paper_lineage = validate_formal_lineage(args)
    log_path, best_model_path = setup_run_outputs()
    manifest_path = None
    if args.paper_experiment:
        manifest_path = start_paper_manifest(
            args,
            log_path,
            best_model_path,
            workspace=os.getcwd(),
        )
    set_random_seed(args.seed)
    start_time = time.time()
    logger.info("Arguments: %s", args)
    logger.info("Log path: %s", os.path.abspath(log_path))
    if manifest_path is not None:
        logger.info("Paper manifest: %s", manifest_path)

    try:
        (
            train_data_loader,
            dev_data_loader,
            test_data_loader,
            train_bank_data_loader,
            num_train_optimization_steps,
            data_provenance,
        ) = set_up_data_loader()

        model = prep_for_training(
            num_train_optimization_steps)#

        retrieval_bank_record = None
        if args.retrieval_candidate_source == 'train_bank':
            retrieval_bank_record = build_strict_retrieval_reference_banks(
                model, train_bank_data_loader
            )

        if args.cross_modal_retrieval_mode in ('agcqr', 'scbr'):
            build_cross_modal_reference_banks(model, train_data_loader)

        if args.paper_e19_prediction_output:
            export_e19_fixed_protocol_predictions(model, test_data_loader)
            logger.info(
                "E19 post-hoc export completed without training | source_run=%s",
                args.paper_e19_source_run_id,
            )
            return

        if args.pns_audit:
            audit_pns_epoch(model, test_data_loader)
            logger.info(
                "PNS audit completed | protocol=%s | checkpoint=%s",
                args.fixed_protocol,
                os.path.abspath(args.model_path),
            )
            if manifest_path is not None:
                finalize_paper_manifest(
                    manifest_path,
                    "complete",
                    result={"audit": "pns", "elapsed_seconds": time.time() - start_time},
                )
            return

        result = train(
            model,
            train_data_loader,
            train_bank_data_loader,
            dev_data_loader,
            test_data_loader,
            best_model_path,
        )
        if args.paper_experiment:
            if not os.path.isfile(best_model_path):
                raise RuntimeError(
                    "Development selection did not produce a checkpoint"
                )
            selected_checkpoint_sha256 = sha256_file(best_model_path)
            selected_state = torch.load(best_model_path, map_location="cpu")
            selected_state_sha256 = state_dict_content_sha256(selected_state)
            model.load_state_dict(selected_state, strict=True)
            model.to(DEVICE)

            # The staged-adaptation gate is decided before the single test
            # access, using development loss and model-state identity only.
            if args.paper_method_id in ("M2", "M3", "E13L", "E13T"):
                result["adaptation_gate"] = evaluate_staged_adaptation(
                    method_id=args.paper_method_id,
                    best_epoch=result["best_epoch"],
                    baseline_dev_mae=result["baseline_dev_mae"],
                    best_dev_mae=result["best_loss"],
                    selected_state_sha256=selected_state_sha256,
                    lineage=args.paper_lineage,
                )

            # Runtime-only donor banks must correspond to the selected
            # checkpoint, not merely the final training epoch.
            if args.retrieval_candidate_source == 'train_bank':
                retrieval_bank_record = build_strict_retrieval_reference_banks(
                    model, train_bank_data_loader
                )
            if args.cross_modal_retrieval_mode in ('agcqr', 'scbr'):
                build_cross_modal_reference_banks(model, train_data_loader)

            FINAL_TEST_GATE.arm()
            final_test_metrics = test_score_model(model, test_data_loader)
            if data_provenance is not None and retrieval_bank_record is not None:
                data_provenance["strict_retrieval_bank"] = retrieval_bank_record
            result.update(named_test_metrics(final_test_metrics))
            result.update({
                "selection_split": "development",
                "selection_metric": "mae",
                "selected_checkpoint_sha256": selected_checkpoint_sha256,
                "selected_state_sha256": selected_state_sha256,
                "test_policy": "evaluate_once_after_checkpoint_selection",
                "test_evaluation_count": FINAL_TEST_GATE.evaluation_count,
                "data_provenance": data_provenance,
                "reproducibility": {
                    "seed": int(args.seed),
                    "train_loader_seed": int(args.seed),
                    "train_loader_rng": "isolated_torch_generator",
                    "deterministic_algorithms": True,
                    "cudnn_benchmark": False,
                    "cudnn_enabled": False,
                    "cublas_workspace_config": ":4096:8",
                },
            })
            # Preserve the legacy field while making it contain only the
            # selected-checkpoint test result in formal runs.
            result["best_metrics"] = final_test_metrics
            logger.info(
                "Formal final test completed | checkpoint_sha256=%s | "
                "state_sha256=%s | "
                "evaluation_count=%d | mae=%.6f | corr=%.6f | "
                "acc7=%.6f | acc5=%.6f | acc2_non_zero=%.6f | "
                "f1_non_zero=%.6f | acc2=%.6f | f1=%.6f",
                selected_checkpoint_sha256,
                selected_state_sha256,
                FINAL_TEST_GATE.evaluation_count,
                *final_test_metrics,
            )
        end_time = time.time()
        result["elapsed_seconds"] = end_time - start_time
        logger.info(
            "Run completed | protocol=%s | epochs=%d | elapsed_seconds=%.2f | best_model=%s",
            args.fixed_protocol,
            result["completed_epochs"],
            result["elapsed_seconds"],
            os.path.abspath(best_model_path),
        )
        if manifest_path is not None:
            finalize_paper_manifest(
                manifest_path,
                "complete",
                result=result,
            )
    except BaseException as error:
        if manifest_path is not None:
            finalize_paper_manifest(
                manifest_path,
                "failed",
                error=error,
            )
        raise


if __name__ == "__main__":
    main()
