set -e

SEVENTH_CHECKPOINT_DIR="${SEVENTH_CHECKPOINT_DIR:-best_modules}"
PROTOCOLS="${PROTOCOLS:-0 3 4}"
REFERENCE_BANK_SIZE="${REFERENCE_BANK_SIZE:-4096}"
SCBR_SCALES="${SCBR_SCALES:-0,0.1,0.25,0.5,1.0}"
SENTIMENT_WEIGHT="${SENTIMENT_WEIGHT:-0.25}"

SCBR_ARGS=(
  --retrieval_mode=missing_aware
  --retrieval_queue_size=0
  --retrieval_metric_mode=raw
  --retrieval_missing_query=center
  --gate_mode=none
  --consistency_mode=mixed
  --distill_mode=none
  --fusion_mode=flat
  --prompt_mode=none
  --reconstruction_mode=none
  --consensus_mode=none
  --tag_mode=none
  --cross_modal_retrieval_mode=scbr
  --cross_modal_reference_bank_size="${REFERENCE_BANK_SIZE}"
  --cross_modal_reference_seed=3407
  --bundle_retrieval_temperature=0.1
  --bundle_sentiment_weight="${SENTIMENT_WEIGHT}"
  --bundle_sentiment_temperature=0.5
  --bundle_injection_scales="${SCBR_SCALES}"
  --load=1
  --n_epochs=0
)

echo "Improvement 12: sentiment-consistent same-sample bundle retrieval (SCBR)"
echo "Foundation: frozen first-improvement q0 + seventh fusion head"
echo "Reference source: complete views and labels from the training split only"
echo "Protocols: ${PROTOCOLS}"
echo "Reference bank size: ${REFERENCE_BANK_SIZE}"
echo "Dev-selected injection scales: ${SCBR_SCALES}"
echo "Sentiment weight: ${SENTIMENT_WEIGHT}"

run_protocol() {
  local protocol="$1"
  local train_batch_size="$2"
  local representation_dim="$3"
  local description="$4"
  shift 4

  local checkpoint="${SEVENTH_CHECKPOINT_DIR}/iie_mosei_protocol_${protocol}_missing_aware_q0_seventh_head_best.pt"
  if [ ! -s "${checkpoint}" ]; then
    echo "Missing clean first+seventh checkpoint: ${checkpoint}" >&2
    echo "Run freeze_seventh_checkpoints.py before improvement 12." >&2
    exit 1
  fi

  echo "SCBR: protocol ${protocol} (${description})"
  python3 main.py "${SCBR_ARGS[@]}" \
    --fixed_protocol="${protocol}" \
    --model_path="${checkpoint}" \
    --learning_rate=1e-4 \
    --d_l="${representation_dim}" \
    --latent_dim="${representation_dim}" \
    --train_batch_size="${train_batch_size}" \
    --dataset=mosei \
    "$@"
}

for protocol in ${PROTOCOLS}; do
  case "${protocol}" in
    0) run_protocol 0 128 192 "L observed; retrieve paired A+V" ;;
    3) run_protocol 3 256 96  "L+A observed; retrieve V" ;;
    4) run_protocol 4 256 96  "L+V observed; retrieve A" ;;
    *)
      echo "The first SCBR pilot supports protocols 0, 3, and 4; received ${protocol}" >&2
      exit 1
      ;;
  esac
done
