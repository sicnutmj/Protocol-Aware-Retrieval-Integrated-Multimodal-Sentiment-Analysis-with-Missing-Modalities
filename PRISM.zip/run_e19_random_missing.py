"""Export frozen specialists and audit E19 random-missing robustness."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import statistics
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path

import numpy as np
from sklearn.metrics import accuracy_score, f1_score

from paper_experiment import code_fingerprints, resolve_dataset_path, sha256_file
from run_e06_mosei_primary import PROTOCOL_SETTINGS, write_immutable_json


DATASET = "mosei"
METHODS = ("M0", "M1", "M2")
PROTOCOLS = tuple(str(value) for value in range(7))
SEEDS = (1111, 3407, 7777)
MISSING_RATES = (0.1, 0.3, 0.5, 0.7, 0.9)
MASK_SEED = 3407
TEST_SIZE = 4659
PROTOCOL_MASKS = {
    0: (1, 0, 0),
    1: (0, 1, 0),
    2: (0, 0, 1),
    3: (1, 1, 0),
    4: (1, 0, 1),
    5: (0, 1, 1),
    6: (1, 1, 1),
}
METRICS = (
    "test_mae", "test_corr", "test_acc7", "test_acc5",
    "test_acc2_non_zero", "test_f1_non_zero", "test_acc2", "test_f1",
)
LOWER_IS_BETTER = frozenset(("test_mae",))
COMPATIBILITY_FILES = (
    "IIE_model.py", "utils.py", "latent_transformer.py",
    "modules/missing_aware_retrieval.py",
)


@dataclass(frozen=True)
class ExportSpec:
    method: str
    protocol: str
    seed: int
    source_run_id: str
    export_id: str


def build_export_matrix(
    methods=METHODS, protocols=PROTOCOLS, seeds=SEEDS,
):
    methods = tuple(str(value) for value in methods)
    protocols = tuple(str(value) for value in protocols)
    seeds = tuple(int(value) for value in seeds)
    unknown_methods = sorted(set(methods) - set(METHODS))
    unknown_protocols = sorted(set(protocols) - set(PROTOCOLS))
    unknown_seeds = sorted(set(seeds) - set(SEEDS))
    if unknown_methods or unknown_protocols or unknown_seeds:
        raise ValueError(
            "Unknown E19 selection | methods={} | protocols={} | seeds={}"
            .format(unknown_methods, unknown_protocols, unknown_seeds)
        )
    ordered_methods = tuple(value for value in METHODS if value in methods)
    return [
        ExportSpec(
            method=method,
            protocol=protocol,
            seed=seed,
            source_run_id="E06R1_{}_mosei_p{}_s{}".format(
                method, protocol, seed
            ),
            export_id="E19P_{}_mosei_p{}_s{}".format(
                method, protocol, seed
            ),
        )
        for seed in seeds
        for protocol in protocols
        for method in ordered_methods
    ]


def _read_json(path):
    with open(path, "r", encoding="utf-8") as stream:
        return json.load(stream)


def _source_manifest_path(workspace, spec):
    return (
        workspace / "paper_experiments" / "manifests"
        / (spec.source_run_id + ".json")
    )


def _prediction_paths(workspace, spec):
    configured = os.environ.get("E19_PREDICTION_DIR", "").strip()
    root = Path(configured) if configured else Path(
        "paper_results/E19_predictions"
    )
    if not root.is_absolute():
        root = workspace / root
    return root / (spec.export_id + ".npz"), root / (spec.export_id + ".json")


def _expected_source_arguments(method):
    expected = {
        "retrieval_queue_size": 0,
        "retrieval_metric_mode": "raw",
        "retrieval_missing_query": "center",
    }
    if method == "M0":
        expected.update({
            "retrieval_mode": "legacy",
            "retrieval_candidate_source": "batch",
            "protocol_fusion_readaptation": False,
        })
    else:
        expected.update({
            "retrieval_mode": "missing_aware",
            "retrieval_candidate_source": "train_bank",
            "protocol_fusion_readaptation": method == "M2",
        })
    return expected


def validate_source_manifest(workspace, spec, dataset_sha=None):
    path = _source_manifest_path(workspace, spec)
    if not path.is_file():
        raise FileNotFoundError("E19 source manifest is missing: {}".format(path))
    manifest = _read_json(path)
    expected = {
        "status": "complete", "run_id": spec.source_run_id,
        "method_id": spec.method, "stage_id": "E06", "dataset": DATASET,
        "protocol": spec.protocol, "seed": spec.seed,
    }
    mismatches = {
        key: (value, manifest.get(key)) for key, value in expected.items()
        if manifest.get(key) != value
    }
    if mismatches:
        raise RuntimeError("E19 source identity mismatch: {}".format(mismatches))
    lineage = manifest.get("lineage")
    if spec.method in ("M0", "M1"):
        if lineage is not None:
            raise RuntimeError("E19 root source unexpectedly declares lineage")
    else:
        expected_parent = "E06R1_M1_mosei_p{}_s{}".format(
            spec.protocol, spec.seed
        )
        if not lineage or lineage.get("parent_method_id") != "M1":
            raise RuntimeError("E19 M2 source parent method mismatch")
        if lineage.get("parent_run_id") != expected_parent:
            raise RuntimeError("E19 M2 source parent run mismatch")
    arguments = manifest.get("arguments") or {}
    argument_mismatches = {
        key: (value, arguments.get(key))
        for key, value in _expected_source_arguments(spec.method).items()
        if arguments.get(key) != value
    }
    if argument_mismatches:
        raise RuntimeError(
            "E19 source argument mismatch: {}".format(argument_mismatches)
        )
    result = manifest.get("result") or {}
    if result.get("test_evaluation_count") != 1:
        raise RuntimeError("E19 source must have one formal final test")
    provenance = result.get("data_provenance") or {}
    current_dataset_sha = provenance.get("dataset_sha256")
    if not current_dataset_sha:
        raise RuntimeError("E19 source lacks dataset SHA256")
    if dataset_sha is not None and current_dataset_sha != dataset_sha:
        raise RuntimeError("E19 source uses another MOSEI dataset")
    for metric in METRICS:
        value = result.get(metric)
        if not isinstance(value, (int, float)) or not math.isfinite(value):
            raise RuntimeError("E19 source lacks finite {}".format(metric))
    outputs = manifest.get("outputs") or {}
    checkpoint = Path(outputs.get("best_model_path", ""))
    if not checkpoint.is_file():
        raise FileNotFoundError("E19 source checkpoint is missing: {}".format(checkpoint))
    if sha256_file(checkpoint) != outputs.get("best_model_sha256"):
        raise RuntimeError("E19 source checkpoint SHA256 mismatch")
    return manifest


def _validate_frozen_e17(workspace, dataset_sha):
    path = workspace / "paper_results" / "E17_fusion_learning_rate_audit.json"
    if not path.is_file():
        raise FileNotFoundError("E19 requires the frozen E17 audit: {}".format(path))
    audit = _read_json(path)
    expected = {
        "stage_id": "E17", "completed_new_run_count": 36,
        "completed_reused_reference_count": 12,
        "completed_total_sensitivity_cells": 48,
        "reference_learning_rate": 1e-4,
        "test_metrics_consulted_for_training_or_selection": False,
    }
    mismatches = {
        key: (value, audit.get(key)) for key, value in expected.items()
        if audit.get(key) != value
    }
    if mismatches or audit.get("missing_new_run_ids") or audit.get("missing_reference_run_ids"):
        raise RuntimeError("E19 frozen E17 audit mismatch: {}".format(mismatches))
    if audit.get("dataset_sha256") != dataset_sha:
        raise RuntimeError("E19 frozen E17 audit uses another MOSEI dataset")
    frozen_code = audit.get("new_run_code_sha256") or {}
    current_code = {
        name: sha256_file(workspace / name) for name in COMPATIBILITY_FILES
    }
    mismatched_code = {
        name: (frozen_code.get(name), current_code[name])
        for name in COMPATIBILITY_FILES
        if frozen_code.get(name) != current_code[name]
    }
    if mismatched_code:
        raise RuntimeError(
            "E19 model/retrieval computation drifted after E17: {}".format(
                mismatched_code
            )
        )
    return {
        "path": str(path.resolve()), "sha256": sha256_file(path),
        "compatible_code_sha256": current_code,
    }


def preflight_sources(workspace, specs):
    dataset_sha = sha256_file(resolve_dataset_path(workspace, DATASET))
    e17 = _validate_frozen_e17(workspace, dataset_sha)
    checked = []
    for spec in specs:
        checked.append(validate_source_manifest(
            workspace, spec, dataset_sha
        )["run_id"])
    print("E19 source preflight verified | records={}".format(len(checked)))
    return {
        "source_count": len(checked), "dataset_sha256": dataset_sha,
        "frozen_E17_audit": e17,
    }


def command_for_spec(workspace, spec):
    manifest = validate_source_manifest(workspace, spec)
    checkpoint = Path(manifest["outputs"]["best_model_path"]).resolve()
    prediction_path, _ = _prediction_paths(workspace, spec)
    settings = PROTOCOL_SETTINGS[spec.protocol]
    command = [
        sys.executable, "main.py",
        "--paper_e19_prediction_output={}".format(prediction_path.resolve()),
        "--paper_e19_source_run_id={}".format(spec.source_run_id),
        "--model_path={}".format(checkpoint), "--load=1",
        "--best_model_dir=tmp/e19_unused_checkpoints",
        "--log_dir=paper_logs/E19_exports",
        "--dataset=mosei", "--fixed_protocol={}".format(spec.protocol),
        "--seed={}".format(spec.seed),
        "--train_batch_size={}".format(settings["train_batch_size"]),
        "--dev_batch_size=128", "--test_batch_size=128",
        "--d_l={}".format(settings["representation_dim"]),
        "--latent_dim={}".format(settings["representation_dim"]),
        "--layers={}".format(settings["layers"]),
        "--latent_layers={}".format(settings["latent_layers"]),
        "--missing_rate={}".format(settings["missing_rate"]),
        "--weight_decay=1e-4",
        "--retrieval_queue_size=0", "--retrieval_metric_mode=raw",
        "--retrieval_missing_query=center", "--retrieval_bank_batch_size=256",
        "--retrieval_bank_refresh_epochs=1",
        "--retrieval_reference_bank_size=0",
        "--retrieval_reference_bank_seed=3407",
        "--retrieval_top_k=2", "--retrieval_temperature=0.1",
        "--retrieval_candidate_filter=observed_only",
        "--retrieval_composition=prototype_neighbours",
        "--retrieval_selection=similarity", "--retrieval_random_seed=3407",
        "--gate_mode=none", "--consistency_mode=mixed", "--distill_mode=none",
        "--fusion_mode=flat", "--prompt_mode=none",
        "--reconstruction_mode=none", "--consensus_mode=none",
        "--tag_mode=none", "--cross_modal_retrieval_mode=none",
        "--training_prior_mode=none", "--hybrid_expert_mode=none",
        "--protocol_consistency_mode=none", "--relation_distill_mode=none",
        "--missing_text_contrast_mode=none",
        "--privileged_purification_mode=none", "--language_hyper_mode=none",
        "--coupled_prompt_mode=none", "--n_epochs=0",
    ]
    if spec.method == "M0":
        command.extend(("--retrieval_mode=legacy", "--retrieval_candidate_source=batch"))
    else:
        command.extend((
            "--retrieval_mode=missing_aware",
            "--retrieval_candidate_source=train_bank",
        ))
    if spec.method == "M2":
        command.extend((
            "--protocol_fusion_readaptation",
            "--protocol_adaptation_scope=fusion_all",
            "--protocol_fusion_learning_rate=1e-4",
            "--protocol_transformer_learning_rate=2e-5",
            "--learning_rate=1e-4",
        ))
    else:
        command.append("--learning_rate=2e-5")
    return command


def compute_metrics(predictions, labels):
    predictions = np.asarray(predictions, dtype=np.float64).reshape(-1)
    labels = np.asarray(labels, dtype=np.float64).reshape(-1)
    if predictions.shape != labels.shape or predictions.size == 0:
        raise ValueError("predictions and labels must be non-empty matched vectors")
    nonzero = labels != 0
    clipped7_predictions = np.clip(predictions, -3.0, 3.0)
    clipped7_labels = np.clip(labels, -3.0, 3.0)
    clipped5_predictions = np.clip(predictions, -2.0, 2.0)
    clipped5_labels = np.clip(labels, -2.0, 2.0)
    output = {
        "test_mae": float(np.mean(np.abs(predictions - labels))),
        "test_corr": float(np.corrcoef(predictions, labels)[0, 1]),
        "test_acc7": float(np.mean(np.round(clipped7_predictions) == np.round(clipped7_labels))),
        "test_acc5": float(np.mean(np.round(clipped5_predictions) == np.round(clipped5_labels))),
        "test_acc2_non_zero": float(accuracy_score(labels[nonzero] > 0, predictions[nonzero] > 0)),
        "test_f1_non_zero": float(f1_score(labels[nonzero] > 0, predictions[nonzero] > 0, average="weighted")),
        "test_acc2": float(accuracy_score(labels >= 0, predictions >= 0)),
        "test_f1": float(f1_score(labels >= 0, predictions >= 0, average="weighted")),
    }
    if any(not math.isfinite(value) for value in output.values()):
        raise RuntimeError("E19 produced a non-finite metric")
    return output


def _load_prediction(path):
    with np.load(path, allow_pickle=False) as payload:
        return {
            "sample_ids": payload["sample_ids"].astype(np.int64),
            "predictions": payload["predictions"].astype(np.float64),
            "labels": payload["labels"].astype(np.float64),
            "source_run_id": str(payload["source_run_id"].item()),
            "protocol": str(payload["protocol"].item()),
            "seed": int(payload["seed"].item()),
            "checkpoint_sha256": str(payload["checkpoint_sha256"].item()),
            "dataset_sha256": str(payload["dataset_sha256"].item()),
        }


def _validate_prediction_arrays(payload, spec, manifest, dataset_sha):
    expected_ids = np.arange(TEST_SIZE, dtype=np.int64)
    if not np.array_equal(payload["sample_ids"], expected_ids):
        raise RuntimeError("E19 prediction sample ids are not canonical")
    if payload["predictions"].shape != (TEST_SIZE,):
        raise RuntimeError("E19 prediction vector has the wrong size")
    if payload["labels"].shape != (TEST_SIZE,):
        raise RuntimeError("E19 label vector has the wrong size")
    expected = {
        "source_run_id": spec.source_run_id,
        "protocol": spec.protocol,
        "seed": spec.seed,
        "checkpoint_sha256": manifest["outputs"]["best_model_sha256"],
        "dataset_sha256": dataset_sha,
    }
    mismatches = {
        key: (value, payload[key]) for key, value in expected.items()
        if payload[key] != value
    }
    if mismatches:
        raise RuntimeError("E19 prediction metadata mismatch: {}".format(mismatches))
    metrics = compute_metrics(payload["predictions"], payload["labels"])
    source_result = manifest["result"]
    metric_mismatches = {
        metric: (float(source_result[metric]), metrics[metric])
        for metric in METRICS
        if not math.isclose(
            float(source_result[metric]), metrics[metric],
            rel_tol=1e-7, abs_tol=1e-8,
        )
    }
    if metric_mismatches:
        raise RuntimeError(
            "E19 fixed-protocol replay differs from frozen source: {}".format(
                metric_mismatches
            )
        )
    return metrics


def validate_prediction_export(workspace, spec, require_current_code=True):
    prediction_path, record_path = _prediction_paths(workspace, spec)
    if not prediction_path.is_file() and not record_path.is_file():
        return None
    if not prediction_path.is_file() or not record_path.is_file():
        raise RuntimeError("E19 prediction export is only partially present")
    record = _read_json(record_path)
    expected = {
        "schema_version": 1, "stage_id": "E19",
        "export_id": spec.export_id, "source_run_id": spec.source_run_id,
        "method_id": spec.method, "protocol": spec.protocol, "seed": spec.seed,
        "prediction_sha256": sha256_file(prediction_path),
    }
    mismatches = {
        key: (value, record.get(key)) for key, value in expected.items()
        if record.get(key) != value
    }
    if mismatches:
        raise RuntimeError("E19 export record mismatch: {}".format(mismatches))
    if require_current_code and record.get("code_sha256") != code_fingerprints(workspace):
        raise RuntimeError("E19 resume refused because code changed")
    manifest = validate_source_manifest(workspace, spec)
    if record.get("source_manifest_sha256") != sha256_file(
        _source_manifest_path(workspace, spec)
    ):
        raise RuntimeError("E19 source manifest changed after export")
    payload = _load_prediction(prediction_path)
    dataset_sha = manifest["result"]["data_provenance"]["dataset_sha256"]
    metrics = _validate_prediction_arrays(
        payload, spec, manifest, dataset_sha
    )
    if record.get("fixed_protocol_metrics") != metrics:
        raise RuntimeError("E19 recorded replay metrics changed")
    return {"record": record, "payload": payload, "metrics": metrics}


def finalize_prediction_export(workspace, spec, command):
    prediction_path, record_path = _prediction_paths(workspace, spec)
    if record_path.exists():
        raise FileExistsError("E19 export record already exists: {}".format(record_path))
    manifest = validate_source_manifest(workspace, spec)
    payload = _load_prediction(prediction_path)
    dataset_sha = manifest["result"]["data_provenance"]["dataset_sha256"]
    metrics = _validate_prediction_arrays(payload, spec, manifest, dataset_sha)
    record = {
        "schema_version": 1, "stage_id": "E19",
        "export_id": spec.export_id, "source_run_id": spec.source_run_id,
        "method_id": spec.method, "protocol": spec.protocol, "seed": spec.seed,
        "prediction_path": str(prediction_path.resolve()),
        "prediction_sha256": sha256_file(prediction_path),
        "source_manifest_path": str(_source_manifest_path(workspace, spec).resolve()),
        "source_manifest_sha256": sha256_file(_source_manifest_path(workspace, spec)),
        "checkpoint_sha256": manifest["outputs"]["best_model_sha256"],
        "dataset_sha256": dataset_sha,
        "sample_count": TEST_SIZE,
        "fixed_protocol_metrics": metrics,
        "code_sha256": code_fingerprints(workspace),
        "command": command,
        "training_performed": False,
        "test_metrics_used_for_selection": False,
    }
    write_immutable_json(record_path, record)
    return validate_prediction_export(workspace, spec)


def _uniform_hash(sample_id, missing_rate, mask_seed=MASK_SEED):
    payload = "E19|{}|{:.1f}|{}".format(mask_seed, missing_rate, sample_id)
    digest = hashlib.sha256(payload.encode("utf-8")).digest()
    return int.from_bytes(digest[:8], "big") / float(1 << 64)


def deterministic_protocol_assignments(
    sample_count, missing_rate, mask_seed=MASK_SEED,
):
    missing_rate = float(missing_rate)
    if not 0.0 <= missing_rate < 1.0:
        raise ValueError("missing_rate must be in [0, 1)")
    observed_rate = 1.0 - missing_rate
    raw_weights = []
    for protocol in range(7):
        observed = sum(PROTOCOL_MASKS[protocol])
        missing = 3 - observed
        raw_weights.append(
            (observed_rate ** observed) * (missing_rate ** missing)
        )
    total = sum(raw_weights)
    weights = [value / total for value in raw_weights]
    cumulative = np.cumsum(weights)
    assignments = np.empty(int(sample_count), dtype=np.uint8)
    for sample_id in range(int(sample_count)):
        value = _uniform_hash(sample_id, missing_rate, mask_seed)
        protocol = int(np.searchsorted(cumulative, value, side="right"))
        assignments[sample_id] = min(protocol, 6)
    counts = {
        str(protocol): int(np.sum(assignments == protocol))
        for protocol in range(7)
    }
    missing_entries = sum(
        counts[str(protocol)] * (3 - sum(PROTOCOL_MASKS[protocol]))
        for protocol in range(7)
    )
    return assignments, {
        "nominal_independent_missing_probability": missing_rate,
        "conditioning": "at_least_one_modality_observed",
        "mask_seed": int(mask_seed),
        "sample_count": int(sample_count),
        "protocol_counts": counts,
        "realized_missing_entry_rate": missing_entries / float(sample_count * 3),
        "protocol_assignment_sha256_uint8": hashlib.sha256(
            assignments.tobytes(order="C")
        ).hexdigest(),
    }


def compose_routed_predictions(protocol_predictions, assignments):
    assignments = np.asarray(assignments, dtype=np.uint8).reshape(-1)
    missing = sorted(set(range(7)) - set(protocol_predictions))
    if missing:
        raise ValueError("Missing protocol predictions: {}".format(missing))
    output = np.empty(assignments.size, dtype=np.float64)
    for protocol in range(7):
        values = np.asarray(protocol_predictions[protocol], dtype=np.float64).reshape(-1)
        if values.size != assignments.size:
            raise ValueError("Protocol prediction length mismatch")
        selected = assignments == protocol
        output[selected] = values[selected]
    return output


def _metric_summary(values):
    return {
        "count": len(values),
        "mean": statistics.mean(values) if values else None,
        "sample_std": statistics.stdev(values) if len(values) > 1 else 0.0,
    }


def _gain(metric, baseline, candidate):
    if metric in LOWER_IS_BETTER:
        return float(baseline) - float(candidate)
    return float(candidate) - float(baseline)


def normalized_curve_area(x_values, y_values):
    if len(x_values) != len(y_values) or len(x_values) < 2:
        raise ValueError("AUILC requires matched curves with at least two points")
    pairs = sorted(zip(map(float, x_values), map(float, y_values)))
    area = sum(
        (x1 - x0) * (y0 + y1) / 2.0
        for (x0, y0), (x1, y1) in zip(pairs, pairs[1:])
    )
    width = pairs[-1][0] - pairs[0][0]
    if width <= 0:
        raise ValueError("AUILC x values must span a positive interval")
    return area / width


def compose_audit(workspace, specs, require_complete=True):
    expected_keys = {
        (method, protocol, seed)
        for method in METHODS for protocol in PROTOCOLS for seed in SEEDS
    }
    actual_keys = {(spec.method, spec.protocol, spec.seed) for spec in specs}
    if actual_keys != expected_keys:
        raise ValueError("E19 final audit requires the full 63-export matrix")
    exports, missing = {}, []
    code_hashes = None
    labels = None
    dataset_sha = None
    for spec in specs:
        validated = validate_prediction_export(workspace, spec)
        if validated is None:
            missing.append(spec.export_id)
            continue
        record, payload = validated["record"], validated["payload"]
        if code_hashes is None:
            code_hashes = record["code_sha256"]
        elif record["code_sha256"] != code_hashes:
            raise RuntimeError("E19 exports mix code fingerprints")
        if dataset_sha is None:
            dataset_sha = record["dataset_sha256"]
        elif record["dataset_sha256"] != dataset_sha:
            raise RuntimeError("E19 exports mix datasets")
        if labels is None:
            labels = payload["labels"]
        elif not np.array_equal(labels, payload["labels"]):
            raise RuntimeError("E19 exports disagree on test labels")
        exports[(spec.method, spec.protocol, spec.seed)] = payload["predictions"]
    if require_complete and missing:
        raise RuntimeError(
            "Incomplete E19 exports | missing={} first={}".format(
                len(missing), missing[:5]
            )
        )

    mask_records = {}
    assignments_by_rate = {}
    for missing_rate in MISSING_RATES:
        assignments, mask_record = deterministic_protocol_assignments(
            TEST_SIZE, missing_rate
        )
        label = str(missing_rate)
        assignments_by_rate[missing_rate] = assignments
        mask_records[label] = mask_record

    records = []
    for seed in SEEDS:
        for method in METHODS:
            protocol_predictions = {
                int(protocol): exports[(method, protocol, seed)]
                for protocol in PROTOCOLS
            }
            for missing_rate in MISSING_RATES:
                routed = compose_routed_predictions(
                    protocol_predictions, assignments_by_rate[missing_rate]
                )
                record = {
                    "method_id": method, "seed": seed,
                    "nominal_missing_rate": missing_rate,
                    "realized_missing_entry_rate": mask_records[
                        str(missing_rate)
                    ]["realized_missing_entry_rate"],
                }
                record.update(compute_metrics(routed, labels))
                records.append(record)

    summary = {}
    for method in METHODS:
        summary[method] = {}
        for missing_rate in MISSING_RATES:
            selected = [
                item for item in records
                if item["method_id"] == method
                and item["nominal_missing_rate"] == missing_rate
            ]
            summary[method][str(missing_rate)] = {
                metric: _metric_summary([item[metric] for item in selected])
                for metric in METRICS
            }

    comparisons = {}
    for label, baseline_method, candidate_method in (
        ("M1_minus_M0", "M0", "M1"),
        ("M2_minus_M1", "M1", "M2"),
        ("M2_minus_M0", "M0", "M2"),
    ):
        comparisons[label] = {}
        for missing_rate in MISSING_RATES:
            pairs = []
            for seed in SEEDS:
                baseline = next(
                    item for item in records
                    if item["method_id"] == baseline_method
                    and item["seed"] == seed
                    and item["nominal_missing_rate"] == missing_rate
                )
                candidate = next(
                    item for item in records
                    if item["method_id"] == candidate_method
                    and item["seed"] == seed
                    and item["nominal_missing_rate"] == missing_rate
                )
                pairs.append({
                    "seed": seed,
                    "gains": {
                        metric: _gain(metric, baseline[metric], candidate[metric])
                        for metric in METRICS
                    },
                })
            comparisons[label][str(missing_rate)] = {
                metric: {
                    "count": len(pairs),
                    "mean_gain": statistics.mean(
                        pair["gains"][metric] for pair in pairs
                    ),
                    "wins": sum(pair["gains"][metric] > 1e-12 for pair in pairs),
                    "ties": sum(abs(pair["gains"][metric]) <= 1e-12 for pair in pairs),
                    "losses": sum(pair["gains"][metric] < -1e-12 for pair in pairs),
                }
                for metric in METRICS
            }

    auilc_by_method_seed = {}
    auilc_summary = {}
    for method in METHODS:
        auilc_by_method_seed[method] = {}
        for seed in SEEDS:
            curve = sorted(
                (
                    item for item in records
                    if item["method_id"] == method and item["seed"] == seed
                ),
                key=lambda item: item["nominal_missing_rate"],
            )
            auilc_by_method_seed[method][str(seed)] = {
                metric: normalized_curve_area(
                    [item["nominal_missing_rate"] for item in curve],
                    [item[metric] for item in curve],
                )
                for metric in METRICS
            }
        auilc_summary[method] = {
            metric: _metric_summary([
                auilc_by_method_seed[method][str(seed)][metric]
                for seed in SEEDS
            ])
            for metric in METRICS
        }

    return {
        "schema_version": 1, "stage_id": "E19", "dataset": DATASET,
        "purpose": "post-hoc random-missing robustness with availability routing",
        "methods": list(METHODS), "protocols": list(PROTOCOLS),
        "seeds": list(SEEDS), "missing_rates": list(MISSING_RATES),
        "mask_seed": MASK_SEED,
        "mask_distribution": "independent modality missingness conditioned on at least one observed modality",
        "routing_policy": "known availability mask to matching frozen protocol specialist",
        "expected_prediction_export_count": 63,
        "completed_prediction_export_count": 63 - len(missing),
        "missing_prediction_export_ids": missing,
        "composite_evaluation_count": len(records),
        "training_performed": False,
        "checkpoint_or_hyperparameter_selection_performed": False,
        "test_metrics_used_for_selection": False,
        "source_formal_test_replayed_for_prediction_export": True,
        "dataset_sha256": dataset_sha,
        "prediction_code_sha256": code_hashes,
        "mask_records": mask_records,
        "summary_by_method_and_missing_rate": summary,
        "paired_effects": comparisons,
        "normalized_auilc_by_method_seed": auilc_by_method_seed,
        "normalized_auilc_summary": auilc_summary,
        "records": records,
    }


def execute_exports(workspace, specs):
    preflight_sources(workspace, specs)
    completed = skipped = 0
    environment = os.environ.copy()
    environment["CUBLAS_WORKSPACE_CONFIG"] = ":4096:8"
    for index, spec in enumerate(specs, start=1):
        if validate_prediction_export(workspace, spec) is not None:
            skipped += 1
            print("[{}/{}] SKIP complete {}".format(index, len(specs), spec.export_id))
            continue
        prediction_path, record_path = _prediction_paths(workspace, spec)
        if prediction_path.exists() or record_path.exists():
            raise RuntimeError("E19 refuses to overwrite a partial export")
        command = command_for_spec(workspace, spec)
        print("[{}/{}] EXPORT {}".format(index, len(specs), spec.export_id), flush=True)
        subprocess.check_call(command, cwd=str(workspace), env=environment)
        finalize_prediction_export(workspace, spec, command)
        completed += 1
    print("E19 export finished | new={} | skipped={}".format(completed, skipped))


def _csv_values(value, cast):
    return tuple(cast(item.strip()) for item in value.split(",") if item.strip())


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--workspace", type=Path, default=Path("."))
    parser.add_argument("--methods", default=",".join(METHODS))
    parser.add_argument("--protocols", default=",".join(PROTOCOLS))
    parser.add_argument("--seeds", default=",".join(str(seed) for seed in SEEDS))
    parser.add_argument("--execute", action="store_true")
    parser.add_argument("--audit", action="store_true")
    parser.add_argument(
        "--audit_output", type=Path,
        default=Path("paper_results/E19_random_missing_audit.json"),
    )
    return parser.parse_args()


def main():
    args = parse_args()
    workspace = args.workspace.resolve()
    specs = build_export_matrix(
        _csv_values(args.methods, str),
        _csv_values(args.protocols, str),
        _csv_values(args.seeds, int),
    )
    if not args.execute and not args.audit:
        print(
            "E19 dry-run plan | prediction_exports={} | full_composite_cells={}"
            .format(len(specs), len(METHODS) * len(SEEDS) * len(MISSING_RATES))
        )
        for spec in specs:
            print("{} | source={} | {}".format(
                spec.export_id, spec.source_run_id,
                " ".join(command_for_spec(workspace, spec)),
            ))
        return
    if args.execute:
        if os.environ.get("E19_EXECUTE") != "1":
            raise RuntimeError("Set E19_EXECUTE=1 to authorize prediction exports")
        execute_exports(workspace, specs)
    if args.audit:
        full_specs = build_export_matrix()
        summary = compose_audit(workspace, full_specs, require_complete=True)
        output = args.audit_output
        if not output.is_absolute():
            output = workspace / output
        write_immutable_json(output, summary)
        print("E19 audit verified: {}".format(output))


if __name__ == "__main__":
    main()
