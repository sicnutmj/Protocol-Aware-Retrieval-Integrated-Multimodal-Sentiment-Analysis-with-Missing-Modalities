set -euo pipefail

python3 -m py_compile \
  main.py \
  IIE_model.py \
  paper_experiment.py \
  run_e19_random_missing.py \
  tests/test_e19_random_missing.py

python3 -m pytest \
  tests/test_paper_experiment.py \
  tests/test_missing_aware_retrieval.py \
  tests/test_deterministic_pooling.py \
  tests/test_e05_fpfr_gate.py \
  tests/test_e06_mosei_primary.py \
  tests/test_e07_mosi_external.py \
  tests/test_e08_protocol3_clean.py \
  tests/test_e11_component_ablation.py \
  tests/test_e12_retrieval_ablation.py \
  tests/test_e13_adaptation_scope.py \
  tests/test_e13_fusion_adaptation.py \
  tests/test_e14_retrieval_topk.py \
  tests/test_e14_topk_shape.py \
  tests/test_e15_bank_sampling.py \
  tests/test_e15_retrieval_bank_size.py \
  tests/test_e16_retrieval_temperature.py \
  tests/test_e16_temperature_effect.py \
  tests/test_e17_fusion_learning_rate.py \
  tests/test_e19_random_missing.py \
  -q

python3 - <<'PY'
import json
from pathlib import Path

from paper_experiment import resolve_dataset_path
from run_e19_random_missing import build_export_matrix, preflight_sources

path = Path("paper_experiments/configs/E19_random_missing.json")
with path.open(encoding="utf-8") as stream:
    config = json.load(stream)
assert config["dataset"] == "mosei"
assert config["methods"] == ["M0", "M1", "M2"]
assert config["protocols"] == ["0", "1", "2", "3", "4", "5", "6"]
assert config["seeds"] == [1111, 3407, 7777]
assert config["missing_rates"] == [0.1, 0.3, 0.5, 0.7, 0.9]
assert config["mask_seed"] == 3407
assert config["design"]["training"] is False
assert config["design"]["prediction_exports"] == 63
assert config["design"]["composite_evaluation_cells"] == 45
assert config["reporting_policy"]["test_metrics_used_for_training_or_selection"] is False
assert config["resume_policy"]["overwrite"] == "forbidden"
print("E19 dataset resolved:", resolve_dataset_path(Path("."), "mosei"))
specs = build_export_matrix(methods=("M0", "M1", "M2"), protocols=("0",), seeds=(1111,))
preflight = preflight_sources(Path(".").resolve(), specs)
assert preflight["source_count"] == 3
print("E19 random-missing configuration and source preflight verified")
PY

PLAN_FILE="$(mktemp)"
trap 'rm -f "${PLAN_FILE}"' EXIT
python3 run_e19_random_missing.py \
  --methods=M0,M1,M2 \
  --protocols=0 \
  --seeds=1111 \
  > "${PLAN_FILE}"
grep -q 'E19 dry-run plan | prediction_exports=3 | full_composite_cells=45' "${PLAN_FILE}"
grep -q 'E19P_M0_mosei_p0_s1111' "${PLAN_FILE}"
grep -q 'E19P_M1_mosei_p0_s1111' "${PLAN_FILE}"
grep -q 'E19P_M2_mosei_p0_s1111' "${PLAN_FILE}"
grep -q -- '--paper_e19_source_run_id=E06R1_M0_mosei_p0_s1111' "${PLAN_FILE}"
grep -q -- '--paper_e19_source_run_id=E06R1_M1_mosei_p0_s1111' "${PLAN_FILE}"
grep -q -- '--paper_e19_source_run_id=E06R1_M2_mosei_p0_s1111' "${PLAN_FILE}"
grep -q -- '--n_epochs=0' "${PLAN_FILE}"
echo "E19 63-export plan and 45-cell random-missing composition verified"

if [ "${E19_GPU_SMOKE:-0}" != "1" ]; then
  echo "Set E19_GPU_SMOKE=1 to replay one protocol for all three methods."
  exit 0
fi

SMOKE_ROOT="${SMOKE_ROOT:-tmp/e19_random_missing_smoke}"
STAMP="$(date +%Y%m%d_%H%M%S)"
PREDICTION_DIR="${SMOKE_ROOT}/${STAMP}/predictions"
mkdir -p "${PREDICTION_DIR}"

E19_PREDICTION_DIR="${PREDICTION_DIR}" E19_EXECUTE=1 \
python3 run_e19_random_missing.py \
  --execute \
  --methods=M0,M1,M2 \
  --protocols=0 \
  --seeds=1111

E19_PREDICTION_DIR="${PREDICTION_DIR}" python3 - <<'PY'
from pathlib import Path
import os

from run_e19_random_missing import build_export_matrix, validate_prediction_export

workspace = Path(".").resolve()
root = Path(os.environ["E19_PREDICTION_DIR"])
assert len(list(root.glob("*.npz"))) == 3
assert len(list(root.glob("*.json"))) == 3
for spec in build_export_matrix(methods=("M0", "M1", "M2"), protocols=("0",), seeds=(1111,)):
    validated = validate_prediction_export(workspace, spec)
    assert validated["record"]["training_performed"] is False
    assert validated["record"]["test_metrics_used_for_selection"] is False
    assert validated["record"]["sample_count"] == 4659
print("E19 three-method prediction-export GPU smoke verified")
PY
