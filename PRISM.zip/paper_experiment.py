"""Reproducibility records and evaluation guards for formal experiments."""

from __future__ import annotations

import hashlib
import json
import os
import platform
import re
import socket
import sys
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Iterable, Optional, Union

MANIFEST_SCHEMA_VERSION = 1
SAFE_IDENTIFIER = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]*$")
DEFAULT_CODE_FILES = (
    "main.py",
    "IIE_model.py",
    "paper_experiment.py",
    "utils.py",
    "latent_transformer.py",
    "modules/missing_aware_retrieval.py",
    "modules/retrieval_bank_sampling.py",
    "evaluate_e05_fpfr_gate.py",
    "run_e06_mosei_primary.py",
    "run_e07_mosi_external.py",
    "run_e08_protocol3_clean.py",
    "run_e11_component_ablation.py",
    "run_e12_retrieval_ablation.py",
    "run_e13_fusion_adaptation.py",
    "run_e14_retrieval_topk.py",
    "run_e15_retrieval_bank_size.py",
    "run_e16_retrieval_temperature.py",
    "run_e17_fusion_learning_rate.py",
    "run_e19_random_missing.py",
    "paper_experiments/configs/E00_protocol.json",
    "paper_experiments/configs/E01_train_bank.json",
    "paper_experiments/configs/E02_evaluation_protocol.json",
    "paper_experiments/configs/E03_reproducibility.json",
    "paper_experiments/configs/E04_method_contracts.json",
    "paper_experiments/configs/E05_fpfr_gate.json",
    "paper_experiments/configs/E06_mosei_primary_matrix.json",
    "paper_experiments/configs/E07_mosi_external_validation.json",
    "paper_experiments/configs/E08_protocol3_clean_replication.json",
    "paper_experiments/configs/E11_component_ablation.json",
    "paper_experiments/configs/E12_retrieval_ablation.json",
    "paper_experiments/configs/E13_fusion_adaptation.json",
    "paper_experiments/configs/E14_retrieval_topk.json",
    "paper_experiments/configs/E15_retrieval_bank_size.json",
    "paper_experiments/configs/E16_retrieval_temperature.json",
    "paper_experiments/configs/E17_fusion_learning_rate.json",
    "paper_experiments/configs/E19_random_missing.json",
)

FIXED_PROTOCOL_MODALITIES = {
    "0": (1, 0, 0),
    "1": (0, 1, 0),
    "2": (0, 0, 1),
    "3": (1, 1, 0),
    "4": (1, 0, 1),
    "5": (0, 1, 1),
    "6": (1, 1, 1),
}

FORMAL_METHOD_PARENTS = {
    "M0": None,
    # E11-only ablation arm: missing-aware retrieval while retaining
    # in-batch candidates.  It is a root run, not a staged checkpoint.
    "A1": None,
    "E12U": None,
    "E12P": None,
    "E12N": None,
    "E12R": None,
    "M1": None,
    "M2": "M1",
    "M3": "M2",
    "E13L": "M1",
    "E13T": "M1",
}

FORMAL_DORMANT_ARGUMENTS = {
    "gate_mode": "none",
    "consistency_mode": "mixed",
    "distill_mode": "none",
    "fusion_mode": "flat",
    "prompt_mode": "none",
    "reconstruction_mode": "none",
    "consensus_mode": "none",
    "tag_mode": "none",
    "cross_modal_retrieval_mode": "none",
    "training_prior_mode": "none",
    "hybrid_expert_mode": "none",
    "protocol_consistency_mode": "none",
    "relation_distill_mode": "none",
    "missing_text_contrast_mode": "none",
    "privileged_purification_mode": "none",
    "language_hyper_mode": "none",
    "coupled_prompt_mode": "none",
    "pns_audit": False,
}


class FinalTestGate:
    """Fail closed unless a formal run explicitly enters final evaluation.

    Formal training keeps this gate locked while selecting a checkpoint on the
    development split, arms it only after reloading that checkpoint, and
    permits exactly one test-set evaluation.
    """

    def __init__(self, enabled: bool) -> None:
        self.enabled = bool(enabled)
        self._armed = False
        self.evaluation_count = 0

    def arm(self) -> None:
        if not self.enabled:
            return
        if self._armed or self.evaluation_count:
            raise RuntimeError("Formal final-test gate cannot be re-armed")
        self._armed = True

    def record_access(self) -> None:
        if not self.enabled:
            return
        if self.evaluation_count:
            raise RuntimeError("Formal test set may be evaluated only once")
        if not self._armed:
            raise RuntimeError(
                "Formal test access is forbidden before checkpoint selection"
            )
        self._armed = False
        self.evaluation_count += 1


def fixed_protocol_mask_record(sample_count: int, protocol: str) -> Dict[str, Any]:
    """Return a canonical fingerprint for a fixed missingness mask."""
    if sample_count < 0:
        raise ValueError("sample_count cannot be negative")
    try:
        pattern = FIXED_PROTOCOL_MODALITIES[str(protocol)]
    except KeyError:
        raise ValueError("Unknown fixed protocol: {}".format(protocol))
    payload = bytes(pattern) * int(sample_count)
    return {
        "sample_count": int(sample_count),
        "modalities": list(pattern),
        "available_entries": [
            int(sample_count) * value for value in pattern
        ],
        "sha256_uint8_row_major": hashlib.sha256(payload).hexdigest(),
    }


def build_data_provenance(
    dataset_path: Union[os.PathLike, str],
    split_sizes: Dict[str, int],
    protocol: str,
) -> Dict[str, Any]:
    """Fingerprint the source dataset and every fixed-protocol split mask."""
    path = Path(dataset_path).resolve()
    if not path.is_file():
        raise FileNotFoundError("Dataset file not found: {}".format(path))
    required_splits = ("train", "dev", "test")
    missing = [name for name in required_splits if name not in split_sizes]
    if missing:
        raise ValueError("Missing split sizes: {}".format(", ".join(missing)))
    return {
        "dataset_path": str(path),
        "dataset_sha256": sha256_file(path),
        "split_sizes": {
            name: int(split_sizes[name]) for name in required_splits
        },
        "fixed_protocol": str(protocol),
        "mask_records": {
            name: fixed_protocol_mask_record(split_sizes[name], protocol)
            for name in required_splits
        },
    }


def _require_argument(args: Any, name: str, expected: Any) -> None:
    actual = getattr(args, name, None)
    if actual != expected:
        raise ValueError(
            "Formal method {} requires {}={!r}; received {!r}".format(
                args.paper_method_id, name, expected, actual
            )
        )


def _require_argument_with_parser_default(
    args: Any, name: str, expected: Any
) -> None:
    """Validate a newly introduced flag for legacy Namespace callers.

    argparse always supplies these fields in real runs.  Older unit-test and
    audit Namespace objects may predate the flags; absence therefore has the
    same meaning as the parser default.  An explicitly supplied non-default
    value is still rejected.
    """
    actual = getattr(args, name, expected)
    if actual != expected:
        raise ValueError(
            "Formal method {} requires {}={!r}; received {!r}".format(
                args.paper_method_id, name, expected, actual
            )
        )


def validate_formal_method_identity(args: Any) -> None:
    """Fail closed when a formal method id does not match its active path."""
    method_id = args.paper_method_id
    if method_id not in FORMAL_METHOD_PARENTS:
        raise ValueError(
            "Unknown formal method id: {!r}".format(method_id)
        )
    for name, expected in FORMAL_DORMANT_ARGUMENTS.items():
        _require_argument(args, name, expected)
    _require_argument(args, "retrieval_queue_size", 0)
    _require_argument(args, "retrieval_metric_mode", "raw")
    _require_argument(args, "retrieval_missing_query", "center")

    e12_contracts = {
        "E12U": {
            "retrieval_candidate_source": "batch",
            "retrieval_candidate_filter": "all",
            "retrieval_composition": "prototype_neighbours",
            "retrieval_selection": "similarity",
        },
        "E12P": {
            "retrieval_candidate_source": "train_bank",
            "retrieval_candidate_filter": "observed_only",
            "retrieval_composition": "prototype_only",
            "retrieval_selection": "similarity",
        },
        "E12N": {
            "retrieval_candidate_source": "train_bank",
            "retrieval_candidate_filter": "observed_only",
            "retrieval_composition": "neighbours_only",
            "retrieval_selection": "similarity",
        },
        "E12R": {
            "retrieval_candidate_source": "train_bank",
            "retrieval_candidate_filter": "observed_only",
            "retrieval_composition": "prototype_neighbours",
            "retrieval_selection": "random",
        },
    }
    if method_id in e12_contracts:
        _require_argument(args, "retrieval_mode", "missing_aware")
        for name, expected in e12_contracts[method_id].items():
            _require_argument(args, name, expected)
        if method_id == "E12R":
            _require_argument(args, "retrieval_random_seed", int(args.seed))
    elif method_id == "M0":
        _require_argument(args, "retrieval_mode", "legacy")
        _require_argument(args, "retrieval_candidate_source", "batch")
    elif method_id == "A1":
        _require_argument(args, "retrieval_mode", "missing_aware")
        _require_argument(args, "retrieval_candidate_source", "batch")
    else:
        _require_argument(args, "retrieval_mode", "missing_aware")
        _require_argument(args, "retrieval_candidate_source", "train_bank")

    if method_id not in e12_contracts:
        _require_argument_with_parser_default(
            args, "retrieval_candidate_filter", "observed_only"
        )
        _require_argument_with_parser_default(
            args, "retrieval_composition", "prototype_neighbours"
        )
        _require_argument_with_parser_default(
            args, "retrieval_selection", "similarity"
        )
        _require_argument_with_parser_default(
            args, "retrieval_random_seed", 3407
        )

    reference_bank_size = getattr(args, "retrieval_reference_bank_size", 0)
    reference_bank_seed = getattr(args, "retrieval_reference_bank_seed", 3407)
    paper_stage_id = getattr(args, "paper_stage_id", "")
    if paper_stage_id == "E15":
        if method_id != "M1":
            raise ValueError("E15 reference-bank sensitivity requires M1")
        if reference_bank_size not in (512, 1024, 2048, 4096):
            raise ValueError(
                "E15 finite reference-bank size must be 512, 1024, 2048, or 4096"
            )
        if reference_bank_seed != 3407:
            raise ValueError("E15 requires retrieval_reference_bank_seed=3407")
        _require_argument(args, "retrieval_top_k", 2)
    elif paper_stage_id == "E16":
        if reference_bank_size != 0:
            raise ValueError("E16 requires the complete retrieval reference bank")
        if reference_bank_seed != 3407:
            raise ValueError("E16 requires retrieval_reference_bank_seed=3407")
    else:
        if reference_bank_size != 0:
            raise ValueError(
                "Finite retrieval_reference_bank_size is reserved for E15"
            )
        if reference_bank_seed != 3407:
            raise ValueError("Formal full banks require reference-bank seed 3407")

    retrieval_temperature = getattr(args, "retrieval_temperature", 0.1)
    if paper_stage_id == "E16":
        if method_id != "M1":
            raise ValueError("E16 retrieval-temperature sensitivity requires M1")
        if retrieval_temperature not in (0.05, 0.2, 0.5, 1.0):
            raise ValueError(
                "E16 new-run temperature must be 0.05, 0.2, 0.5, or 1.0"
            )
        _require_argument(args, "retrieval_top_k", 2)
        if reference_bank_size != 0:
            raise ValueError("E16 requires the complete retrieval reference bank")
    elif retrieval_temperature != 0.1:
        raise ValueError(
            "Nondefault retrieval_temperature is reserved for E16"
        )

    is_adaptation = method_id in ("M2", "M3", "E13L", "E13T")
    _require_argument(args, "protocol_fusion_readaptation", is_adaptation)
    _require_argument(args, "load", 1 if is_adaptation else 0)
    expected_scope = {
        "E13L": "last_layer",
        "E13T": "late_transformer_fusion",
    }.get(method_id, "fusion_all")
    fusion_learning_rate = getattr(
        args, "protocol_fusion_learning_rate", 1e-4
    )
    if paper_stage_id == "E17":
        if method_id != "M2":
            raise ValueError("E17 fusion learning-rate sensitivity requires M2")
        if fusion_learning_rate not in (1e-5, 5e-5, 5e-4):
            raise ValueError(
                "E17 new-run fusion learning rate must be 1e-5, 5e-5, or 5e-4"
            )
        _require_argument(args, "protocol_adaptation_scope", "fusion_all")
        _require_argument(args, "protocol_transformer_learning_rate", 2e-5)
        _require_argument(args, "learning_rate", fusion_learning_rate)
        _require_argument(args, "retrieval_top_k", 2)
    elif method_id in ("E13L", "E13T"):
        _require_argument(args, "protocol_adaptation_scope", expected_scope)
        _require_argument(args, "protocol_fusion_learning_rate", 1e-4)
        _require_argument(args, "protocol_transformer_learning_rate", 2e-5)
    else:
        _require_argument_with_parser_default(
            args, "protocol_adaptation_scope", expected_scope
        )
        _require_argument_with_parser_default(
            args, "protocol_transformer_learning_rate", 2e-5
        )
        if is_adaptation:
            _require_argument_with_parser_default(
                args, "protocol_fusion_learning_rate", 1e-4
            )

    parent_run_id = getattr(args, "paper_parent_run_id", "")
    if is_adaptation and not parent_run_id:
        raise ValueError(
            "{} requires --paper_parent_run_id".format(method_id)
        )
    if not is_adaptation and parent_run_id:
        raise ValueError(
            "{} must not declare a parent run".format(method_id)
        )


def validate_formal_lineage(args: Any) -> Optional[Dict[str, Any]]:
    """Validate and fingerprint the selected parent checkpoint."""
    validate_formal_method_identity(args)
    expected_parent_method = FORMAL_METHOD_PARENTS[args.paper_method_id]
    if expected_parent_method is None:
        return None

    validate_identifier(args.paper_parent_run_id, "paper_parent_run_id")
    manifest_path = (
        Path(args.paper_manifest_dir).resolve()
        / "{}.json".format(args.paper_parent_run_id)
    )
    if not manifest_path.is_file():
        raise FileNotFoundError(
            "Parent manifest not found: {}".format(manifest_path)
        )
    with open(manifest_path, "r", encoding="utf-8") as stream:
        parent = json.load(stream)
    expected_fields = {
        "status": "complete",
        "method_id": expected_parent_method,
        "dataset": args.dataset,
        "protocol": str(args.fixed_protocol),
        "seed": int(args.seed),
    }
    mismatches = {
        name: {"expected": expected, "actual": parent.get(name)}
        for name, expected in expected_fields.items()
        if parent.get(name) != expected
    }
    if mismatches:
        raise ValueError(
            "Parent manifest lineage mismatch: {}".format(mismatches)
        )

    outputs = parent.get("outputs") or {}
    checkpoint_path = Path(
        outputs.get("best_model_path", "")
    ).resolve()
    requested_path = Path(args.model_path).resolve()
    if checkpoint_path != requested_path:
        raise ValueError(
            "model_path does not match parent checkpoint: {} != {}".format(
                requested_path, checkpoint_path
            )
        )
    if not checkpoint_path.is_file():
        raise FileNotFoundError(
            "Parent checkpoint not found: {}".format(checkpoint_path)
        )
    actual_sha256 = sha256_file(checkpoint_path)
    recorded_sha256 = outputs.get("best_model_sha256")
    if not recorded_sha256 or recorded_sha256 != actual_sha256:
        raise ValueError(
            "Parent checkpoint SHA256 does not match its manifest"
        )
    parent_result = parent.get("result") or {}
    parent_best_dev_mae = parent_result.get("best_loss")
    parent_state_sha256 = parent_result.get("selected_state_sha256")
    if parent_best_dev_mae is None or not parent_state_sha256:
        raise ValueError(
            "Parent manifest lacks best development MAE or model-state hash"
        )
    return {
        "parent_run_id": parent["run_id"],
        "parent_method_id": parent["method_id"],
        "parent_manifest_path": str(manifest_path),
        "parent_checkpoint_path": str(checkpoint_path),
        "parent_checkpoint_sha256": actual_sha256,
        "parent_best_dev_mae": float(parent_best_dev_mae),
        "parent_state_sha256": parent_state_sha256,
    }


def evaluate_staged_adaptation(
    method_id: str,
    best_epoch: int,
    baseline_dev_mae: float,
    best_dev_mae: float,
    selected_state_sha256: str,
    lineage: Dict[str, Any],
    tolerance: float = 1e-8,
) -> Dict[str, Any]:
    """Enforce exact parent fallback or a genuine development improvement."""
    if method_id not in ("M2", "M3", "E13L", "E13T"):
        raise ValueError(
            "Staged adaptation gate applies only to a formal adaptation method"
        )
    parent_dev = float(lineage["parent_best_dev_mae"])
    baseline_dev = float(baseline_dev_mae)
    selected_dev = float(best_dev_mae)
    if abs(parent_dev - baseline_dev) > tolerance:
        raise RuntimeError(
            "Loaded parent development MAE mismatch: parent={} baseline={}"
            .format(parent_dev, baseline_dev)
        )
    dev_gain = baseline_dev - selected_dev
    if dev_gain < -tolerance:
        raise RuntimeError("Selected adaptation is worse than its parent")

    if int(best_epoch) == 0:
        if abs(dev_gain) > tolerance:
            raise RuntimeError("Epoch-0 fallback changed development MAE")
        if selected_state_sha256 != lineage["parent_state_sha256"]:
            raise RuntimeError(
                "Epoch-0 fallback does not match the parent model state"
            )
        outcome = "fallback_parent"
    else:
        if dev_gain <= 0.0:
            raise RuntimeError(
                "Nonzero adaptation epoch lacks development improvement"
            )
        outcome = "improved"
    return {
        "outcome": outcome,
        "parent_best_dev_mae": parent_dev,
        "baseline_dev_mae": baseline_dev,
        "selected_dev_mae": selected_dev,
        "dev_mae_gain": dev_gain,
        "parent_state_sha256": lineage["parent_state_sha256"],
        "selected_state_sha256": selected_state_sha256,
        "test_metrics_consulted": False,
    }


def _timestamp() -> str:
    return datetime.now().astimezone().isoformat(timespec="seconds")


def _json_value(value: Any) -> Any:
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, dict):
        return {str(key): _json_value(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_value(item) for item in value]
    if hasattr(value, "item"):
        try:
            return value.item()
        except (TypeError, ValueError):
            pass
    return str(value)


def sha256_file(path: Union[os.PathLike, str]) -> str:
    digest = hashlib.sha256()
    with open(path, "rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def resolve_dataset_path(
    workspace: Union[os.PathLike, str], dataset: str
) -> Path:
    """Resolve the supported flat or HME dataset layout deterministically."""
    workspace = Path(workspace).resolve()
    filename = "aligned_{}.pkl".format(str(dataset))
    candidates = (
        workspace / "datasets" / filename,
        workspace / "datasets" / "HME_NeurIPS_25" / filename,
    )
    for candidate in candidates:
        if candidate.is_file():
            return candidate.resolve()
    raise FileNotFoundError(
        "Dataset {!r} was not found; checked: {}".format(
            dataset, ", ".join(str(path) for path in candidates)
        )
    )


def state_dict_content_sha256(state_dict: Dict[str, Any]) -> str:
    """Hash tensor content independently of torch checkpoint container bytes."""
    digest = hashlib.sha256()
    for name in sorted(state_dict):
        tensor = state_dict[name]
        if not hasattr(tensor, "detach"):
            raise TypeError(
                "State entry is not tensor-like: {}".format(name)
            )
        value = tensor.detach().cpu().contiguous()
        metadata = "{}\n{}\n{}\n".format(
            name,
            value.dtype,
            tuple(value.shape),
        ).encode("utf-8")
        digest.update(len(metadata).to_bytes(8, byteorder="big"))
        digest.update(metadata)
        payload = value.numpy().tobytes(order="C")
        digest.update(len(payload).to_bytes(8, byteorder="big"))
        digest.update(payload)
    return digest.hexdigest()


def code_fingerprints(
    workspace: Union[os.PathLike, str],
    relative_paths: Iterable[str] = DEFAULT_CODE_FILES,
) -> Dict[str, Optional[str]]:
    root = Path(workspace).resolve()
    fingerprints: Dict[str, Optional[str]] = {}
    for relative_path in relative_paths:
        path = root / relative_path
        fingerprints[relative_path] = (
            sha256_file(path) if path.is_file() else None
        )
    return fingerprints


def _write_json_atomic(path: Path, payload: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary_path = path.with_suffix(path.suffix + ".tmp")
    with open(temporary_path, "w", encoding="utf-8", newline="\n") as stream:
        json.dump(
            _json_value(payload),
            stream,
            ensure_ascii=False,
            indent=2,
            sort_keys=True,
        )
        stream.write("\n")
    os.replace(temporary_path, path)


def validate_identifier(value: str, field_name: str) -> None:
    if not value or SAFE_IDENTIFIER.fullmatch(value) is None:
        raise ValueError(
            "{} must match {} (received {!r})".format(
                field_name, SAFE_IDENTIFIER.pattern, value
            )
        )


def _torch_environment() -> Dict[str, Any]:
    try:
        import torch
    except ImportError:
        return {
            "torch": None,
            "cuda_available": False,
            "cuda_version": None,
            "gpu": None,
        }
    cuda_available = torch.cuda.is_available()
    return {
        "torch": torch.__version__,
        "cuda_available": cuda_available,
        "cuda_version": torch.version.cuda,
        "gpu": torch.cuda.get_device_name(0) if cuda_available else None,
    }


def start_paper_manifest(
    args: Any,
    log_path: Union[os.PathLike, str],
    best_model_path: Union[os.PathLike, str],
    workspace: Union[os.PathLike, str] = ".",
) -> Path:
    """Create a new formal-run manifest and refuse identifier reuse."""
    validate_identifier(args.paper_run_id, "paper_run_id")
    validate_identifier(args.paper_method_id, "paper_method_id")
    validate_identifier(args.paper_stage_id, "paper_stage_id")

    manifest_dir = Path(args.paper_manifest_dir).resolve()
    manifest_path = manifest_dir / "{}.json".format(args.paper_run_id)
    if manifest_path.exists():
        raise FileExistsError(
            "Formal run id already exists and will not be overwritten: {}".format(
                manifest_path
            )
        )

    workspace_path = Path(workspace).resolve()
    torch_environment = _torch_environment()
    manifest = {
        "schema_version": MANIFEST_SCHEMA_VERSION,
        "run_id": args.paper_run_id,
        "method_id": args.paper_method_id,
        "stage_id": args.paper_stage_id,
        "status": "running",
        "started_at": _timestamp(),
        "finished_at": None,
        "dataset": args.dataset,
        "protocol": str(args.fixed_protocol),
        "seed": int(args.seed),
        "command": [sys.executable] + sys.argv,
        "working_directory": str(workspace_path),
        "arguments": vars(args).copy(),
        "outputs": {
            "log_path": str(Path(log_path).resolve()),
            "best_model_path": str(Path(best_model_path).resolve()),
            "best_model_sha256": None,
        },
        "environment": {
            "hostname": socket.gethostname(),
            "platform": platform.platform(),
            "python": sys.version,
            **torch_environment,
        },
        "code_sha256": code_fingerprints(workspace_path),
        "lineage": getattr(args, "paper_lineage", None),
        "result": None,
        "error": None,
    }
    _write_json_atomic(manifest_path, manifest)
    return manifest_path


def finalize_paper_manifest(
    manifest_path: Union[os.PathLike, str],
    status: str,
    result: Optional[Dict[str, Any]] = None,
    error: Optional[BaseException] = None,
) -> None:
    """Atomically mark a formal run complete or failed."""
    if status not in ("complete", "failed"):
        raise ValueError("status must be 'complete' or 'failed'")

    path = Path(manifest_path).resolve()
    with open(path, "r", encoding="utf-8") as stream:
        manifest = json.load(stream)
    if manifest.get("status") != "running":
        raise RuntimeError(
            "Finalized paper manifest cannot be modified: {}".format(path)
        )

    manifest["status"] = status
    manifest["finished_at"] = _timestamp()
    manifest["result"] = _json_value(result)
    if error is None:
        manifest["error"] = None
    else:
        manifest["error"] = {
            "type": type(error).__name__,
            "message": str(error),
        }

    checkpoint_path = Path(manifest["outputs"]["best_model_path"])
    if checkpoint_path.is_file():
        manifest["outputs"]["best_model_sha256"] = sha256_file(
            checkpoint_path
        )

    _write_json_atomic(path, manifest)
