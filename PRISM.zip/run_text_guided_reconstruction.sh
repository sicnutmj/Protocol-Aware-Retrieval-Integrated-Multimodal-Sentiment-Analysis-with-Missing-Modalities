set -e

SEVENTH_CHECKPOINT_DIR="${SEVENTH_CHECKPOINT_DIR:-best_modules}"
PROTOCOLS="${PROTOCOLS:-0 1 2 3 4 5 6}"
ALLOW_FROZEN_EIGHTH="${ALLOW_FROZEN_EIGHTH:-0}"

if [ "${ALLOW_FROZEN_EIGHTH}" != "1" ]; then
  echo "Improvement 8 is frozen after an unsuccessful ablation." >&2
  echo "Set ALLOW_FROZEN_EIGHTH=1 only for exact reproduction." >&2
  exit 1
fi

RECONSTRUCTION_ARGS=(
  --retrieval_mode=missing_aware
  --retrieval_queue_size=0
  --retrieval_metric_mode=raw
  --retrieval_missing_query=center
  --gate_mode=none
  --consistency_mode=mixed
  --distill_mode=none
  --fusion_mode=flat
  --prompt_mode=none
  --reconstruction_mode=text_guided_nonverbal
  --reconstruction_hidden_dim=128
  --reconstruction_max_scale=1.0
  --reconstruction_learning_rate=1e-3
  --reconstruction_loss_weight=0.1
  --load=1
  --n_epochs=40
  --early_stopping_patience=12
  --early_stopping_min_delta=0.0
)

echo "Frozen failed improvement 8: text-guided nonverbal reconstruction"
echo "Foundation: first-improvement q0 + frozen seventh fusion head"
echo "Checkpoint directory: ${SEVENTH_CHECKPOINT_DIR}"
echo "Protocols: ${PROTOCOLS}"

run_protocol() {
  local protocol="$1"
  local train_batch_size="$2"
  local representation_dim="$3"
  local description="$4"
  shift 4

  local checkpoint="${SEVENTH_CHECKPOINT_DIR}/iie_mosei_protocol_${protocol}_missing_aware_q0_seventh_head_best.pt"
  if [ ! -s "${checkpoint}" ]; then
    echo "Missing clean first+seventh checkpoint: ${checkpoint}" >&2
    echo "Run freeze_seventh_checkpoints.py before improvement 8." >&2
    exit 1
  fi

  echo "text-guided reconstruction: protocol ${protocol} (${description})"
  python3 main.py "${RECONSTRUCTION_ARGS[@]}" \
    --fixed_protocol="${protocol}" \
    --model_path="${checkpoint}" \
    --learning_rate=1e-4 \
    --d_l="${representation_dim}" \
    --latent_dim="${representation_dim}" \
    --train_batch_size="${train_batch_size}" \
    --dataset=mosei \
    "$@"
}

for protocol in ${PROTOCOLS}; do
  case "${protocol}" in
    0) run_protocol 0 128 192 "L observed; reconstruct A+V" ;;
    1) run_protocol 1 128 192 "A observed; preserve foundation" \
         --missing_rate=0.05 \
         --layers=2 \
         --latent_layers=3 ;;
    2) run_protocol 2 256 192 "V observed; preserve foundation" ;;
    3) run_protocol 3 256 96  "L+A observed; reconstruct V" ;;
    4) run_protocol 4 256 96  "L+V observed; reconstruct A" ;;
    5) run_protocol 5 256 192 "A+V observed; preserve foundation" ;;
    6) run_protocol 6 128 192 "L+A+V observed; preserve foundation" ;;
    *)
      echo "Unknown protocol: ${protocol}; expected values from 0 to 6" >&2
      exit 1
      ;;
  esac
done
