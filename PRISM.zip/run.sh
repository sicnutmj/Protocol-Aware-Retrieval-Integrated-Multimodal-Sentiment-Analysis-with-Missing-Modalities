set -e
Q0_ARGS=(
  --retrieval_mode=missing_aware
  --retrieval_queue_size=0
  --retrieval_metric_mode=raw
  --retrieval_missing_query=center
  --gate_mode=none
  --consistency_mode=mixed
  --fusion_mode=flat
  --prompt_mode=none
  --early_stopping_patience=0
)
echo "Frozen first-improvement baseline: missing-aware q0, queue_size=0"

run_protocol() {
  local protocol="$1"
  local train_batch_size="$2"
  local representation_dim="$3"
  local description="$4"
  shift 4

  echo "q0 baseline: protocol ${protocol} (${description})"
  python3 main.py "${Q0_ARGS[@]}" \
    --fixed_protocol="${protocol}" \
    --learning_rate=2e-5 \
    --d_l="${representation_dim}" \
    --latent_dim="${representation_dim}" \
    --train_batch_size="${train_batch_size}" \
    --dataset=mosei \
    "$@"
}

# Preserve the protocol-specific settings of the frozen q0 experiment.
run_protocol 0 128 192 "L observed"
run_protocol 1 128 192 "A observed" \
  --missing_rate=0.05 \
  --layers=2 \
  --latent_layers=3
run_protocol 2 256 192 "V observed"
run_protocol 3 256 96  "L+A observed"
run_protocol 4 256 96  "L+V observed"
run_protocol 5 256 192 "A+V observed"
run_protocol 6 128 192 "L+A+V observed"
