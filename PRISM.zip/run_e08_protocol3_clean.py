"""Plan, execute, and audit the formal E08 protocol-3 clean replication."""

from __future__ import annotations

import argparse
import json
import math
import os
import subprocess
import sys
from collections import Counter
from dataclasses import dataclass
from pathlib import Path

from paper_experiment import (
    code_fingerprints,
    resolve_dataset_path,
    sha256_file,
)
from run_e06_mosei_primary import (
    METRICS,
    PROTOCOL_SETTINGS,
    SEEDS,
    write_immutable_json,
)


DATASETS = ("mosei", "mosi")
METHODS = ("M0", "M1", "M2")
PROTOCOL = "3"
PARENTS = {"M0": None, "M1": None, "M2": "M1"}
SPLIT_SIZES = {
    "mosei": {"train": 16326, "dev": 1871, "test": 4659},
    "mosi": {"train": 1284, "dev": 229, "test": 686},
}


@dataclass(frozen=True)
class RunSpec:
    dataset: str
    method: str
    seed: int
    run_id: str
    parent_run_id: str = ""


def build_matrix(datasets=DATASETS, seeds=SEEDS, methods=METHODS):
    """Return the frozen 30-run clean-replication order."""
    datasets = tuple(str(value) for value in datasets)
    seeds = tuple(int(value) for value in seeds)
    methods = tuple(methods)
    unknown_datasets = sorted(set(datasets) - set(DATASETS))
    unknown_seeds = sorted(set(seeds) - set(SEEDS))
    unknown_methods = sorted(set(methods) - set(METHODS))
    if unknown_datasets or unknown_seeds or unknown_methods:
        raise ValueError(
            "Unknown E08 selection | datasets={} | seeds={} | methods={}"
            .format(unknown_datasets, unknown_seeds, unknown_methods)
        )
    ordered_methods = tuple(method for method in METHODS if method in methods)
    specs = []
    for dataset in datasets:
        for seed in seeds:
            for method in ordered_methods:
                run_id = "E08_{}_{}_p3_s{}".format(method, dataset, seed)
                parent_method = PARENTS[method]
                parent_run_id = (
                    "E08_{}_{}_p3_s{}".format(
                        parent_method, dataset, seed
                    )
                    if parent_method else ""
                )
                specs.append(RunSpec(
                    dataset=dataset,
                    method=method,
                    seed=seed,
                    run_id=run_id,
                    parent_run_id=parent_run_id,
                ))
    return specs


def _read_manifest(path):
    with open(path, "r", encoding="utf-8") as stream:
        return json.load(stream)


def _manifest_path(workspace, run_id):
    return (
        workspace / "paper_experiments" / "manifests"
        / "{}.json".format(run_id)
    )


def _parent_checkpoint(workspace, spec):
    parent_path = _manifest_path(workspace, spec.parent_run_id)
    if not parent_path.is_file():
        raise FileNotFoundError(
            "E08 parent manifest is missing: {}".format(parent_path)
        )
    parent = _read_manifest(parent_path)
    expected = {
        "status": "complete",
        "run_id": spec.parent_run_id,
        "method_id": PARENTS[spec.method],
        "stage_id": "E08",
        "dataset": spec.dataset,
        "protocol": PROTOCOL,
        "seed": spec.seed,
    }
    mismatches = {
        key: (value, parent.get(key))
        for key, value in expected.items()
        if parent.get(key) != value
    }
    if mismatches:
        raise RuntimeError(
            "E08 parent manifest mismatch: {}".format(mismatches)
        )
    outputs = parent.get("outputs") or {}
    checkpoint = Path(outputs.get("best_model_path", ""))
    if not checkpoint.is_file():
        raise FileNotFoundError(
            "E08 parent checkpoint is missing: {}".format(checkpoint)
        )
    if sha256_file(checkpoint) != outputs.get("best_model_sha256"):
        raise RuntimeError("E08 parent checkpoint SHA256 mismatch")
    return checkpoint.resolve()


def command_for_spec(workspace, spec, resolve_parent=True):
    """Build one explicit clean-replication command."""
    settings = PROTOCOL_SETTINGS[PROTOCOL]
    adaptation = spec.method == "M2"
    command = [
        sys.executable,
        "main.py",
        "--paper_experiment",
        "--paper_run_id={}".format(spec.run_id),
        "--paper_method_id={}".format(spec.method),
        "--paper_stage_id=E08",
        "--paper_manifest_dir=paper_experiments/manifests",
        "--dataset={}".format(spec.dataset),
        "--fixed_protocol={}".format(PROTOCOL),
        "--seed={}".format(spec.seed),
        "--train_batch_size={}".format(settings["train_batch_size"]),
        "--dev_batch_size=128",
        "--test_batch_size=128",
        "--d_l={}".format(settings["representation_dim"]),
        "--latent_dim={}".format(settings["representation_dim"]),
        "--layers={}".format(settings["layers"]),
        "--latent_layers={}".format(settings["latent_layers"]),
        "--missing_rate={}".format(settings["missing_rate"]),
        "--weight_decay=1e-4",
        "--retrieval_queue_size=0",
        "--retrieval_metric_mode=raw",
        "--retrieval_missing_query=center",
        "--retrieval_bank_batch_size=256",
        "--retrieval_bank_refresh_epochs=1",
        "--gate_mode=none",
        "--consistency_mode=mixed",
        "--distill_mode=none",
        "--fusion_mode=flat",
        "--prompt_mode=none",
        "--reconstruction_mode=none",
        "--consensus_mode=none",
        "--tag_mode=none",
        "--cross_modal_retrieval_mode=none",
        "--training_prior_mode=none",
        "--hybrid_expert_mode=none",
        "--protocol_consistency_mode=none",
        "--relation_distill_mode=none",
        "--missing_text_contrast_mode=none",
        "--privileged_purification_mode=none",
        "--language_hyper_mode=none",
        "--coupled_prompt_mode=none",
        "--early_stopping_min_delta=0.0",
    ]
    if spec.method == "M0":
        command.extend((
            "--retrieval_mode=legacy",
            "--retrieval_candidate_source=batch",
        ))
    else:
        command.extend((
            "--retrieval_mode=missing_aware",
            "--retrieval_candidate_source=train_bank",
        ))
    if adaptation:
        checkpoint = (
            _parent_checkpoint(workspace, spec)
            if resolve_parent else Path("<PARENT_CHECKPOINT>")
        )
        command.extend((
            "--paper_parent_run_id={}".format(spec.parent_run_id),
            "--model_path={}".format(checkpoint),
            "--load=1",
            "--protocol_fusion_readaptation",
            "--protocol_fusion_learning_rate=1e-4",
            "--learning_rate=1e-4",
            "--n_epochs=40",
            "--early_stopping_patience=12",
        ))
    else:
        command.extend((
            "--learning_rate=2e-5",
            "--n_epochs=100",
            "--early_stopping_patience=12",
        ))
    return command


def _validate_completed_manifest(workspace, spec):
    manifest_path = _manifest_path(workspace, spec.run_id)
    if not manifest_path.is_file():
        return None
    manifest = _read_manifest(manifest_path)
    if manifest.get("status") != "complete":
        raise RuntimeError(
            "E08 run id already exists with status {!r}; inspect it and do "
            "not overwrite it: {}".format(
                manifest.get("status"), manifest_path
            )
        )
    expected = {
        "run_id": spec.run_id,
        "method_id": spec.method,
        "stage_id": "E08",
        "dataset": spec.dataset,
        "protocol": PROTOCOL,
        "seed": spec.seed,
    }
    mismatches = {
        key: (value, manifest.get(key))
        for key, value in expected.items()
        if manifest.get(key) != value
    }
    if mismatches:
        raise RuntimeError(
            "Completed E08 manifest identity mismatch: {}".format(mismatches)
        )
    lineage = manifest.get("lineage")
    if spec.parent_run_id:
        if not isinstance(lineage, dict):
            raise RuntimeError("E08 M2 run lacks M1 lineage")
        if lineage.get("parent_run_id") != spec.parent_run_id:
            raise RuntimeError("E08 M2 run names the wrong parent")
        if lineage.get("parent_method_id") != "M1":
            raise RuntimeError("E08 M2 parent method is not M1")
    elif lineage is not None:
        raise RuntimeError("E08 root method unexpectedly declares lineage")

    result = manifest.get("result") or {}
    if result.get("test_evaluation_count") != 1:
        raise RuntimeError("E08 formal run must evaluate test exactly once")
    if result.get("selection_split") != "development":
        raise RuntimeError("E08 formal run was not selected on development")
    if result.get("selection_metric") != "mae":
        raise RuntimeError("E08 formal selection metric is not MAE")
    for key in ("best_loss",) + METRICS:
        value = result.get(key)
        if not isinstance(value, (int, float)) or not math.isfinite(value):
            raise RuntimeError("E08 result lacks finite {}".format(key))
    if spec.method == "M2":
        gate = result.get("adaptation_gate") or {}
        if gate.get("outcome") not in ("improved", "fallback_parent"):
            raise RuntimeError("E08 M2 adaptation gate is missing")
        if gate.get("test_metrics_consulted") is not False:
            raise RuntimeError("E08 M2 gate consulted test metrics")

    provenance = result.get("data_provenance") or {}
    if provenance.get("split_sizes") != SPLIT_SIZES[spec.dataset]:
        raise RuntimeError(
            "E08 {} split sizes do not match the protocol".format(
                spec.dataset.upper()
            )
        )
    outputs = manifest.get("outputs") or {}
    checkpoint = Path(outputs.get("best_model_path", ""))
    if not checkpoint.is_file():
        raise FileNotFoundError(
            "E08 completed checkpoint is missing: {}".format(checkpoint)
        )
    if sha256_file(checkpoint) != outputs.get("best_model_sha256"):
        raise RuntimeError("E08 completed checkpoint SHA256 mismatch")
    return manifest


def _reference_run_id(spec):
    if spec.dataset == "mosei":
        return "E06R1_{}_mosei_p3_s{}".format(spec.method, spec.seed)
    return "E07_{}_mosi_p3_s{}".format(spec.method, spec.seed)


def compare_with_primary_reference(workspace, specs, require_reference=False):
    """Compare the clean rerun with its E06/E07 protocol-3 counterpart."""
    comparisons = []
    missing = []
    exact = 0
    comparable_fields = (
        "selected_state_sha256",
        "best_epoch",
        "best_loss",
        "development_mae_history",
    ) + METRICS
    for spec in specs:
        rerun_path = _manifest_path(workspace, spec.run_id)
        if not rerun_path.is_file():
            continue
        reference_run_id = _reference_run_id(spec)
        reference_path = _manifest_path(workspace, reference_run_id)
        if not reference_path.is_file():
            missing.append(reference_run_id)
            continue
        rerun = _read_manifest(rerun_path)
        reference = _read_manifest(reference_path)
        expected_reference = {
            "status": "complete",
            "method_id": spec.method,
            "dataset": spec.dataset,
            "protocol": PROTOCOL,
            "seed": spec.seed,
        }
        identity_errors = [
            key for key, value in expected_reference.items()
            if reference.get(key) != value
        ]
        rerun_result = rerun.get("result") or {}
        reference_result = reference.get("result") or {}
        mismatched_fields = list(identity_errors)
        for field in comparable_fields:
            left = reference_result.get(field)
            right = rerun_result.get(field)
            if isinstance(left, (int, float)) and isinstance(
                right, (int, float)
            ):
                matches = math.isclose(
                    float(left), float(right), rel_tol=0.0, abs_tol=1e-12
                )
            else:
                matches = left == right
            if not matches:
                mismatched_fields.append(field)
        if spec.method == "M2":
            left_gate = reference_result.get("adaptation_gate") or {}
            right_gate = rerun_result.get("adaptation_gate") or {}
            for field in ("outcome", "dev_mae_gain"):
                if left_gate.get(field) != right_gate.get(field):
                    mismatched_fields.append("adaptation_gate.{}".format(field))
        is_exact = not mismatched_fields
        exact += int(is_exact)
        comparisons.append({
            "run_id": spec.run_id,
            "reference_run_id": reference_run_id,
            "exact_replication": is_exact,
            "mismatched_fields": mismatched_fields,
        })
    if require_reference and missing:
        raise RuntimeError(
            "E08 primary references are missing; first={}".format(missing[:5])
        )
    return {
        "expected_comparison_count": len(specs),
        "completed_comparison_count": len(comparisons),
        "exact_replication_count": exact,
        "nonexact_replication_count": len(comparisons) - exact,
        "missing_reference_run_ids": missing,
        "comparison_policy": {
            "floating_absolute_tolerance": 1e-12,
            "checkpoint_container_hash_compared": False,
            "canonical_model_state_hash_compared": True,
            "development_history_compared": True,
            "test_metrics_compared": True,
        },
        "comparisons": comparisons,
    }


def audit_matrix(
    workspace, specs, require_complete=True, require_reference=False
):
    """Audit selected E08 artifacts and return a deterministic summary."""
    records = []
    missing = []
    code_sha256 = None
    dataset_sha256 = {}
    for spec in specs:
        manifest = _validate_completed_manifest(workspace, spec)
        if manifest is None:
            missing.append(spec.run_id)
            continue
        result = manifest["result"]
        provenance = result["data_provenance"]
        current_data_sha = provenance["dataset_sha256"]
        previous_data_sha = dataset_sha256.setdefault(
            spec.dataset, current_data_sha
        )
        if previous_data_sha != current_data_sha:
            raise RuntimeError(
                "E08 matrix mixes different {} datasets".format(spec.dataset)
            )
        if code_sha256 is None:
            code_sha256 = manifest.get("code_sha256")
        elif code_sha256 != manifest.get("code_sha256"):
            raise RuntimeError("E08 matrix mixes different code fingerprints")
        record = {
            "run_id": spec.run_id,
            "dataset": spec.dataset,
            "method_id": spec.method,
            "protocol": PROTOCOL,
            "seed": spec.seed,
            "best_epoch": result["best_epoch"],
            "best_dev_mae": result["best_loss"],
        }
        record.update({key: result[key] for key in METRICS})
        if spec.method == "M2":
            gate = result["adaptation_gate"]
            record["adaptation_outcome"] = gate["outcome"]
            record["development_mae_gain"] = gate["dev_mae_gain"]
        records.append(record)
    if require_complete and missing:
        raise RuntimeError(
            "Incomplete E08 matrix: {} of {} runs are missing; first={}".format(
                len(missing), len(specs), missing[:5]
            )
        )
    summary = {
        "schema_version": 1,
        "stage_id": "E08",
        "purpose": "independent clean replication of protocol 3",
        "datasets": list(DATASETS),
        "protocol": PROTOCOL,
        "methods": list(METHODS),
        "expected_run_count": len(specs),
        "completed_run_count": len(records),
        "missing_run_ids": missing,
        "dataset_sha256": dataset_sha256,
        "code_sha256": code_sha256,
        "test_evaluation_count_per_run": 1,
        "selection_split": "development",
        "selection_metric": "mae",
        "adaptation_outcomes": dict(Counter(
            "{}:{}".format(
                record["dataset"], record.get("adaptation_outcome")
            )
            for record in records if record["method_id"] == "M2"
        )),
        "records": records,
    }
    summary["primary_reference_replication"] = compare_with_primary_reference(
        workspace, specs, require_reference=require_reference
    )
    return summary


def execute_matrix(workspace, specs):
    """Resume missing E08 runs while preserving immutable completed runs."""
    partial = audit_matrix(workspace, specs, require_complete=False)
    if partial["completed_run_count"]:
        if partial["code_sha256"] != code_fingerprints(workspace):
            raise RuntimeError(
                "E08 resume refused because the code fingerprint changed"
            )
        completed_datasets = {spec.dataset for spec in specs if (
            _manifest_path(workspace, spec.run_id).is_file()
        )}
        for dataset in completed_datasets:
            dataset_path = resolve_dataset_path(workspace, dataset)
            if partial["dataset_sha256"].get(dataset) != sha256_file(
                dataset_path
            ):
                raise RuntimeError(
                    "E08 resume refused because {} changed".format(dataset)
                )
    environment = os.environ.copy()
    environment["CUBLAS_WORKSPACE_CONFIG"] = ":4096:8"
    completed = 0
    skipped = 0
    for index, spec in enumerate(specs, start=1):
        manifest = _validate_completed_manifest(workspace, spec)
        if manifest is not None:
            skipped += 1
            print("[{}/{}] SKIP complete {}".format(
                index, len(specs), spec.run_id
            ), flush=True)
            continue
        print("[{}/{}] RUN {}".format(
            index, len(specs), spec.run_id
        ), flush=True)
        subprocess.check_call(
            command_for_spec(workspace, spec, resolve_parent=True),
            cwd=str(workspace),
            env=environment,
        )
        _validate_completed_manifest(workspace, spec)
        subprocess.check_call(
            [sys.executable, "refresh_paper_registry.py", "--workspace", "."],
            cwd=str(workspace),
            env=environment,
        )
        completed += 1
    print("E08 execution finished | new={} | skipped={}".format(
        completed, skipped
    ))


def _csv_values(value, cast):
    return tuple(cast(item.strip()) for item in value.split(",") if item.strip())


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--workspace", type=Path, default=Path("."))
    parser.add_argument("--datasets", default=",".join(DATASETS))
    parser.add_argument("--seeds", default=",".join(str(seed) for seed in SEEDS))
    parser.add_argument("--methods", default=",".join(METHODS))
    parser.add_argument("--execute", action="store_true")
    parser.add_argument("--audit", action="store_true")
    parser.add_argument(
        "--audit_output",
        type=Path,
        default=Path("paper_results/E08_protocol3_clean_audit.json"),
    )
    return parser.parse_args()


def main():
    args = parse_args()
    workspace = args.workspace.resolve()
    specs = build_matrix(
        _csv_values(args.datasets, str),
        _csv_values(args.seeds, int),
        _csv_values(args.methods, str),
    )
    if not args.execute and not args.audit:
        print("E08 dry-run plan | runs={}".format(len(specs)))
        for spec in specs:
            print("{} | parent={} | {}".format(
                spec.run_id,
                spec.parent_run_id or "none",
                " ".join(command_for_spec(
                    workspace, spec, resolve_parent=False
                )),
            ))
        return
    if args.execute:
        if os.environ.get("E08_EXECUTE") != "1":
            raise RuntimeError(
                "Set E08_EXECUTE=1 to authorize the formal 30-run matrix"
            )
        execute_matrix(workspace, specs)
    if args.audit:
        summary = audit_matrix(
            workspace,
            specs,
            require_complete=True,
            require_reference=True,
        )
        output = args.audit_output
        if not output.is_absolute():
            output = workspace / output
        write_immutable_json(output, summary)
        print("E08 audit verified: {}".format(output))


if __name__ == "__main__":
    main()
