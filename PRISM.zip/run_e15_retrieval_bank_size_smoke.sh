set -euo pipefail

python3 -m py_compile \
  main.py \
  paper_experiment.py \
  modules/retrieval_bank_sampling.py \
  run_e15_retrieval_bank_size.py \
  tests/test_e15_bank_sampling.py \
  tests/test_e15_retrieval_bank_size.py

python3 -m pytest \
  tests/test_paper_experiment.py \
  tests/test_missing_aware_retrieval.py \
  tests/test_deterministic_pooling.py \
  tests/test_e05_fpfr_gate.py \
  tests/test_e06_mosei_primary.py \
  tests/test_e07_mosi_external.py \
  tests/test_e08_protocol3_clean.py \
  tests/test_e11_component_ablation.py \
  tests/test_e12_retrieval_ablation.py \
  tests/test_e13_adaptation_scope.py \
  tests/test_e13_fusion_adaptation.py \
  tests/test_e14_retrieval_topk.py \
  tests/test_e14_topk_shape.py \
  tests/test_e15_bank_sampling.py \
  tests/test_e15_retrieval_bank_size.py \
  -q

python3 - <<'PY'
import json
from pathlib import Path

from paper_experiment import resolve_dataset_path

path = Path("paper_experiments/configs/E15_retrieval_bank_size.json")
with path.open(encoding="utf-8") as stream:
    config = json.load(stream)
assert config["dataset"] == "mosei"
assert config["protocols"] == ["0", "3", "5", "6"]
assert config["seeds"] == [1111, 3407, 7777]
assert config["bank_size_values"] == [512, 1024, 2048, 4096, "full"]
assert config["full_bank_size"] == 16326
assert config["subset_seed"] == 3407
assert config["new_required_runs"] == 48
assert config["reused_reference_records"] == 12
assert config["total_sensitivity_cells"] == 60
assert config["resume_policy"]["overwrite"] == "forbidden"
print("E15 dataset resolved:", resolve_dataset_path(Path("."), "mosei"))
print("E15 retrieval-bank-size configuration verified")
PY

PLAN_FILE="$(mktemp)"
trap 'rm -f "${PLAN_FILE}"' EXIT
python3 run_e15_retrieval_bank_size.py \
  --protocols=0 \
  --seeds=1111 \
  > "${PLAN_FILE}"
grep -q 'E15 dry-run plan | new_runs=4 | reused_reference_records=1 | total_sensitivity_cells=5' "${PLAN_FILE}"
for value in 512 1024 2048 4096; do
  grep -q "E15_B${value}_mosei_p0_s1111" "${PLAN_FILE}"
  grep -q -- "--retrieval_reference_bank_size=${value}" "${PLAN_FILE}"
done
grep -q 'E06R1_M1_mosei_p0_s1111' "${PLAN_FILE}"
if grep -q -- '--protocol_fusion_readaptation' "${PLAN_FILE}"; then
  echo "E15 sensitivity unexpectedly enables fusion readaptation" >&2
  exit 1
fi
echo "E15 48-new-run plan and 12-record full-bank reuse mapping verified"

if [ "${E15_GPU_SMOKE:-0}" != "1" ]; then
  echo "Set E15_GPU_SMOKE=1 to run one epoch for all four finite bank sizes."
  exit 0
fi

SMOKE_ROOT="${SMOKE_ROOT:-tmp/e15_retrieval_bank_size_smoke}"
STAMP="$(date +%Y%m%d_%H%M%S)"
mkdir -p \
  "${SMOKE_ROOT}/checkpoints" \
  "${SMOKE_ROOT}/logs" \
  "${SMOKE_ROOT}/manifests"

run_smoke_bank_size() {
  local bank_size="$1"
  local run_id="E15_SMOKE_B${bank_size}_mosei_p0_s1111_${STAMP}"
  python3 main.py \
    --paper_experiment \
    --paper_run_id="${run_id}" \
    --paper_method_id=M1 \
    --paper_stage_id=E15 \
    --paper_manifest_dir="${SMOKE_ROOT}/manifests" \
    --best_model_dir="${SMOKE_ROOT}/checkpoints" \
    --log_dir="${SMOKE_ROOT}/logs" \
    --dataset=mosei \
    --fixed_protocol=0 \
    --seed=1111 \
    --train_batch_size=128 \
    --dev_batch_size=128 \
    --test_batch_size=128 \
    --d_l=192 \
    --latent_dim=192 \
    --layers=3 \
    --latent_layers=2 \
    --missing_rate=0.3 \
    --weight_decay=1e-4 \
    --retrieval_mode=missing_aware \
    --retrieval_candidate_source=train_bank \
    --retrieval_candidate_filter=observed_only \
    --retrieval_composition=prototype_neighbours \
    --retrieval_selection=similarity \
    --retrieval_random_seed=3407 \
    --retrieval_top_k=2 \
    --retrieval_queue_size=0 \
    --retrieval_metric_mode=raw \
    --retrieval_missing_query=center \
    --retrieval_bank_batch_size=256 \
    --retrieval_bank_refresh_epochs=1 \
    --retrieval_reference_bank_size="${bank_size}" \
    --retrieval_reference_bank_seed=3407 \
    --gate_mode=none \
    --consistency_mode=mixed \
    --distill_mode=none \
    --fusion_mode=flat \
    --prompt_mode=none \
    --reconstruction_mode=none \
    --consensus_mode=none \
    --tag_mode=none \
    --cross_modal_retrieval_mode=none \
    --training_prior_mode=none \
    --hybrid_expert_mode=none \
    --protocol_consistency_mode=none \
    --relation_distill_mode=none \
    --missing_text_contrast_mode=none \
    --privileged_purification_mode=none \
    --language_hyper_mode=none \
    --coupled_prompt_mode=none \
    --early_stopping_min_delta=0.0 \
    --learning_rate=2e-5 \
    --n_epochs=1 \
    --early_stopping_patience=0
}

for bank_size in 512 1024 2048 4096; do
  run_smoke_bank_size "${bank_size}"
done

python3 - "${SMOKE_ROOT}" "${STAMP}" <<'PY'
import json
import sys
from pathlib import Path

root = Path(sys.argv[1])
stamp = sys.argv[2]
selected_sets = []
for bank_size in (512, 1024, 2048, 4096):
    run_id = "E15_SMOKE_B{}_mosei_p0_s1111_{}".format(bank_size, stamp)
    path = root / "manifests" / "{}.json".format(run_id)
    with path.open(encoding="utf-8") as stream:
        manifest = json.load(stream)
    result = manifest["result"]
    args = manifest["arguments"]
    bank = result["data_provenance"]["strict_retrieval_bank"]
    assert manifest["status"] == "complete"
    assert manifest["method_id"] == "M1"
    assert manifest["lineage"] is None
    assert args["retrieval_top_k"] == 2
    assert args["retrieval_reference_bank_size"] == bank_size
    assert args["retrieval_reference_bank_seed"] == 3407
    assert bank["available_count"] == 16326
    assert bank["requested_size"] == bank_size
    assert bank["actual_size"] == bank_size
    assert bank["validation_donors"] == 0
    assert bank["test_donors"] == 0
    assert result["completed_epochs"] == 1
    assert result["test_evaluation_count"] == 1
    print("E15 GPU contract verified: bank_size={}".format(bank_size))
print("E15 four-size one-epoch GPU smoke verified")
PY
