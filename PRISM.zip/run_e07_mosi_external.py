"""Plan, execute, and audit the formal E07 MOSI external validation."""

from __future__ import annotations

import argparse
import json
import math
import os
import subprocess
import sys
from collections import Counter
from dataclasses import dataclass
from pathlib import Path

from paper_experiment import (
    code_fingerprints,
    resolve_dataset_path,
    sha256_file,
)
from run_e06_mosei_primary import (
    METRICS,
    PROTOCOL_SETTINGS,
    PROTOCOLS,
    SEEDS,
    write_immutable_json,
)


METHODS = ("M0", "M1", "M2")
PARENTS = {"M0": None, "M1": None, "M2": "M1"}


@dataclass(frozen=True)
class RunSpec:
    method: str
    protocol: str
    seed: int
    run_id: str
    parent_run_id: str = ""


def build_matrix(protocols=PROTOCOLS, seeds=SEEDS, methods=METHODS):
    """Return the frozen 105-run external-validation order."""
    protocols = tuple(str(value) for value in protocols)
    seeds = tuple(int(value) for value in seeds)
    methods = tuple(methods)
    unknown_protocols = sorted(set(protocols) - set(PROTOCOLS))
    unknown_seeds = sorted(set(seeds) - set(SEEDS))
    unknown_methods = sorted(set(methods) - set(METHODS))
    if unknown_protocols or unknown_seeds or unknown_methods:
        raise ValueError(
            "Unknown E07 selection | protocols={} | seeds={} | methods={}"
            .format(unknown_protocols, unknown_seeds, unknown_methods)
        )
    ordered_methods = tuple(method for method in METHODS if method in methods)
    specs = []
    for seed in seeds:
        for protocol in protocols:
            for method in ordered_methods:
                run_id = "E07_{}_mosi_p{}_s{}".format(
                    method, protocol, seed
                )
                parent_method = PARENTS[method]
                parent_run_id = (
                    "E07_{}_mosi_p{}_s{}".format(
                        parent_method, protocol, seed
                    )
                    if parent_method else ""
                )
                specs.append(RunSpec(
                    method=method,
                    protocol=protocol,
                    seed=seed,
                    run_id=run_id,
                    parent_run_id=parent_run_id,
                ))
    return specs


def _read_manifest(path):
    with open(path, "r", encoding="utf-8") as stream:
        return json.load(stream)


def _parent_checkpoint(workspace, spec):
    parent_path = (
        workspace / "paper_experiments" / "manifests"
        / "{}.json".format(spec.parent_run_id)
    )
    if not parent_path.is_file():
        raise FileNotFoundError(
            "E07 parent manifest is missing: {}".format(parent_path)
        )
    parent = _read_manifest(parent_path)
    expected = {
        "status": "complete",
        "run_id": spec.parent_run_id,
        "method_id": PARENTS[spec.method],
        "stage_id": "E07",
        "dataset": "mosi",
        "protocol": spec.protocol,
        "seed": spec.seed,
    }
    mismatches = {
        key: (value, parent.get(key))
        for key, value in expected.items()
        if parent.get(key) != value
    }
    if mismatches:
        raise RuntimeError(
            "E07 parent manifest mismatch: {}".format(mismatches)
        )
    outputs = parent.get("outputs") or {}
    checkpoint = Path(outputs.get("best_model_path", ""))
    if not checkpoint.is_file():
        raise FileNotFoundError(
            "E07 parent checkpoint is missing: {}".format(checkpoint)
        )
    if sha256_file(checkpoint) != outputs.get("best_model_sha256"):
        raise RuntimeError("E07 parent checkpoint SHA256 mismatch")
    return checkpoint.resolve()


def command_for_spec(workspace, spec, resolve_parent=True):
    """Build one explicit command without MOSI-specific retuning."""
    settings = PROTOCOL_SETTINGS[spec.protocol]
    adaptation = spec.method == "M2"
    command = [
        sys.executable,
        "main.py",
        "--paper_experiment",
        "--paper_run_id={}".format(spec.run_id),
        "--paper_method_id={}".format(spec.method),
        "--paper_stage_id=E07",
        "--paper_manifest_dir=paper_experiments/manifests",
        "--dataset=mosi",
        "--fixed_protocol={}".format(spec.protocol),
        "--seed={}".format(spec.seed),
        "--train_batch_size={}".format(settings["train_batch_size"]),
        "--dev_batch_size=128",
        "--test_batch_size=128",
        "--d_l={}".format(settings["representation_dim"]),
        "--latent_dim={}".format(settings["representation_dim"]),
        "--layers={}".format(settings["layers"]),
        "--latent_layers={}".format(settings["latent_layers"]),
        "--missing_rate={}".format(settings["missing_rate"]),
        "--weight_decay=1e-4",
        "--retrieval_queue_size=0",
        "--retrieval_metric_mode=raw",
        "--retrieval_missing_query=center",
        "--retrieval_bank_batch_size=256",
        "--retrieval_bank_refresh_epochs=1",
        "--gate_mode=none",
        "--consistency_mode=mixed",
        "--distill_mode=none",
        "--fusion_mode=flat",
        "--prompt_mode=none",
        "--reconstruction_mode=none",
        "--consensus_mode=none",
        "--tag_mode=none",
        "--cross_modal_retrieval_mode=none",
        "--training_prior_mode=none",
        "--hybrid_expert_mode=none",
        "--protocol_consistency_mode=none",
        "--relation_distill_mode=none",
        "--missing_text_contrast_mode=none",
        "--privileged_purification_mode=none",
        "--language_hyper_mode=none",
        "--coupled_prompt_mode=none",
        "--early_stopping_min_delta=0.0",
    ]
    if spec.method == "M0":
        command.extend((
            "--retrieval_mode=legacy",
            "--retrieval_candidate_source=batch",
        ))
    else:
        command.extend((
            "--retrieval_mode=missing_aware",
            "--retrieval_candidate_source=train_bank",
        ))
    if adaptation:
        checkpoint = (
            _parent_checkpoint(workspace, spec)
            if resolve_parent else Path("<PARENT_CHECKPOINT>")
        )
        command.extend((
            "--paper_parent_run_id={}".format(spec.parent_run_id),
            "--model_path={}".format(checkpoint),
            "--load=1",
            "--protocol_fusion_readaptation",
            "--protocol_fusion_learning_rate=1e-4",
            "--learning_rate=1e-4",
            "--n_epochs=40",
            "--early_stopping_patience=12",
        ))
    else:
        command.extend((
            "--learning_rate=2e-5",
            "--n_epochs=100",
            "--early_stopping_patience=12",
        ))
    return command


def _validate_completed_manifest(workspace, spec):
    manifest_path = (
        workspace / "paper_experiments" / "manifests"
        / "{}.json".format(spec.run_id)
    )
    if not manifest_path.is_file():
        return None
    manifest = _read_manifest(manifest_path)
    if manifest.get("status") != "complete":
        raise RuntimeError(
            "E07 run id already exists with status {!r}; inspect it and do "
            "not overwrite it: {}".format(
                manifest.get("status"), manifest_path
            )
        )
    expected = {
        "run_id": spec.run_id,
        "method_id": spec.method,
        "stage_id": "E07",
        "dataset": "mosi",
        "protocol": spec.protocol,
        "seed": spec.seed,
    }
    mismatches = {
        key: (value, manifest.get(key))
        for key, value in expected.items()
        if manifest.get(key) != value
    }
    if mismatches:
        raise RuntimeError(
            "Completed E07 manifest identity mismatch: {}".format(mismatches)
        )
    lineage = manifest.get("lineage")
    if spec.parent_run_id:
        if not isinstance(lineage, dict):
            raise RuntimeError("E07 M2 run lacks M1 lineage")
        if lineage.get("parent_run_id") != spec.parent_run_id:
            raise RuntimeError("E07 M2 run names the wrong parent")
        if lineage.get("parent_method_id") != "M1":
            raise RuntimeError("E07 M2 parent method is not M1")
    elif lineage is not None:
        raise RuntimeError("E07 root method unexpectedly declares lineage")

    result = manifest.get("result") or {}
    if result.get("test_evaluation_count") != 1:
        raise RuntimeError("E07 formal run must evaluate test exactly once")
    if result.get("selection_split") != "development":
        raise RuntimeError("E07 formal run was not selected on development")
    if result.get("selection_metric") != "mae":
        raise RuntimeError("E07 formal selection metric is not MAE")
    for key in ("best_loss",) + METRICS:
        value = result.get(key)
        if not isinstance(value, (int, float)) or not math.isfinite(value):
            raise RuntimeError("E07 result lacks finite {}".format(key))
    if spec.method == "M2":
        gate = result.get("adaptation_gate") or {}
        if gate.get("outcome") not in ("improved", "fallback_parent"):
            raise RuntimeError("E07 M2 adaptation gate is missing")
        if gate.get("test_metrics_consulted") is not False:
            raise RuntimeError("E07 M2 gate consulted test metrics")

    provenance = result.get("data_provenance") or {}
    if provenance.get("split_sizes") != {
        "train": 1284, "dev": 229, "test": 686
    }:
        raise RuntimeError("E07 MOSI split sizes do not match the protocol")
    outputs = manifest.get("outputs") or {}
    checkpoint = Path(outputs.get("best_model_path", ""))
    if not checkpoint.is_file():
        raise FileNotFoundError(
            "E07 completed checkpoint is missing: {}".format(checkpoint)
        )
    if sha256_file(checkpoint) != outputs.get("best_model_sha256"):
        raise RuntimeError("E07 completed checkpoint SHA256 mismatch")
    return manifest


def audit_matrix(workspace, specs, require_complete=True):
    """Audit all selected E07 artifacts and return a deterministic summary."""
    records = []
    missing = []
    code_sha256 = None
    dataset_sha256 = None
    for spec in specs:
        manifest = _validate_completed_manifest(workspace, spec)
        if manifest is None:
            missing.append(spec.run_id)
            continue
        result = manifest["result"]
        provenance = result["data_provenance"]
        if dataset_sha256 is None:
            dataset_sha256 = provenance["dataset_sha256"]
        elif dataset_sha256 != provenance["dataset_sha256"]:
            raise RuntimeError("E07 matrix mixes different MOSI datasets")
        if code_sha256 is None:
            code_sha256 = manifest.get("code_sha256")
        elif code_sha256 != manifest.get("code_sha256"):
            raise RuntimeError("E07 matrix mixes different code fingerprints")
        record = {
            "run_id": spec.run_id,
            "method_id": spec.method,
            "protocol": spec.protocol,
            "seed": spec.seed,
            "best_epoch": result["best_epoch"],
            "best_dev_mae": result["best_loss"],
        }
        record.update({key: result[key] for key in METRICS})
        if spec.method == "M2":
            gate = result["adaptation_gate"]
            record["adaptation_outcome"] = gate["outcome"]
            record["development_mae_gain"] = gate["dev_mae_gain"]
        records.append(record)
    if require_complete and missing:
        raise RuntimeError(
            "Incomplete E07 matrix: {} of {} runs are missing; first={}".format(
                len(missing), len(specs), missing[:5]
            )
        )
    return {
        "schema_version": 1,
        "stage_id": "E07",
        "dataset": "mosi",
        "methods": list(METHODS),
        "expected_run_count": len(specs),
        "completed_run_count": len(records),
        "missing_run_ids": missing,
        "dataset_sha256": dataset_sha256,
        "code_sha256": code_sha256,
        "test_evaluation_count_per_run": 1,
        "selection_split": "development",
        "selection_metric": "mae",
        "adaptation_outcomes": dict(Counter(
            record.get("adaptation_outcome")
            for record in records
            if record["method_id"] == "M2"
        )),
        "records": records,
    }


def execute_matrix(workspace, specs):
    """Resume missing E07 runs while preserving immutable completed runs."""
    partial = audit_matrix(workspace, specs, require_complete=False)
    if partial["completed_run_count"]:
        if partial["code_sha256"] != code_fingerprints(workspace):
            raise RuntimeError(
                "E07 resume refused because the code fingerprint changed"
            )
        dataset_path = resolve_dataset_path(workspace, "mosi")
        if partial["dataset_sha256"] != sha256_file(dataset_path):
            raise RuntimeError(
                "E07 resume refused because the MOSI dataset changed"
            )
    environment = os.environ.copy()
    environment["CUBLAS_WORKSPACE_CONFIG"] = ":4096:8"
    completed = 0
    skipped = 0
    for index, spec in enumerate(specs, start=1):
        manifest = _validate_completed_manifest(workspace, spec)
        if manifest is not None:
            skipped += 1
            print("[{}/{}] SKIP complete {}".format(
                index, len(specs), spec.run_id
            ), flush=True)
            continue
        print("[{}/{}] RUN {}".format(
            index, len(specs), spec.run_id
        ), flush=True)
        subprocess.check_call(
            command_for_spec(workspace, spec, resolve_parent=True),
            cwd=str(workspace),
            env=environment,
        )
        _validate_completed_manifest(workspace, spec)
        subprocess.check_call(
            [sys.executable, "refresh_paper_registry.py", "--workspace", "."],
            cwd=str(workspace),
            env=environment,
        )
        completed += 1
    print("E07 execution finished | new={} | skipped={}".format(
        completed, skipped
    ))


def _csv_values(value, cast):
    return tuple(cast(item.strip()) for item in value.split(",") if item.strip())


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--workspace", type=Path, default=Path("."))
    parser.add_argument("--protocols", default=",".join(PROTOCOLS))
    parser.add_argument("--seeds", default=",".join(str(seed) for seed in SEEDS))
    parser.add_argument("--methods", default=",".join(METHODS))
    parser.add_argument("--execute", action="store_true")
    parser.add_argument("--audit", action="store_true")
    parser.add_argument(
        "--audit_output",
        type=Path,
        default=Path("paper_results/E07_mosi_external_audit.json"),
    )
    return parser.parse_args()


def main():
    args = parse_args()
    workspace = args.workspace.resolve()
    specs = build_matrix(
        _csv_values(args.protocols, str),
        _csv_values(args.seeds, int),
        _csv_values(args.methods, str),
    )
    if not args.execute and not args.audit:
        print("E07 dry-run plan | runs={}".format(len(specs)))
        for spec in specs:
            print("{} | parent={} | {}".format(
                spec.run_id,
                spec.parent_run_id or "none",
                " ".join(command_for_spec(
                    workspace, spec, resolve_parent=False
                )),
            ))
        return
    if args.execute:
        if os.environ.get("E07_EXECUTE") != "1":
            raise RuntimeError(
                "Set E07_EXECUTE=1 to authorize the formal 105-run matrix"
            )
        execute_matrix(workspace, specs)
    if args.audit:
        summary = audit_matrix(workspace, specs, require_complete=True)
        output = args.audit_output
        if not output.is_absolute():
            output = workspace / output
        write_immutable_json(output, summary)
        print("E07 audit verified: {}".format(output))


if __name__ == "__main__":
    main()
