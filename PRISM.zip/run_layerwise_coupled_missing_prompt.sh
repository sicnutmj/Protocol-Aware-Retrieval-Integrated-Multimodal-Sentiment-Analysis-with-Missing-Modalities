set -e

if [ "${ALLOW_FROZEN_TWENTIETH:-0}" != "1" ]; then
  echo "Improvement 20 (LCMPR) is frozen after an unsuccessful pilot." >&2
  echo "Set ALLOW_FROZEN_TWENTIETH=1 only for explicit reproduction." >&2
  exit 2
fi

FPFR_CHECKPOINT_DIR="${FPFR_CHECKPOINT_DIR:-best_modules}"
PROTOCOLS="${PROTOCOLS:-0 3 4}"
RUN_FULL="${RUN_FULL:-1}"
RUN_SINGLE_LAYER="${RUN_SINGLE_LAYER:-0}"
ADAPTER_LR="${ADAPTER_LR:-1e-3}"
HIDDEN_DIM="${HIDDEN_DIM:-64}"
PROMPT_LENGTH="${PROMPT_LENGTH:-2}"
MAX_SCALE="${MAX_SCALE:-0.5}"

LCMPR_ARGS=(
  --retrieval_mode=missing_aware
  --retrieval_queue_size=0
  --retrieval_metric_mode=raw
  --retrieval_missing_query=center
  --gate_mode=none
  --consistency_mode=mixed
  --distill_mode=none
  --fusion_mode=flat
  --prompt_mode=none
  --reconstruction_mode=none
  --consensus_mode=none
  --tag_mode=none
  --cross_modal_retrieval_mode=none
  --training_prior_mode=none
  --hybrid_expert_mode=none
  --protocol_consistency_mode=none
  --relation_distill_mode=none
  --missing_text_contrast_mode=none
  --privileged_purification_mode=none
  --language_hyper_mode=none
  --coupled_prompt_mode=lcmpr
  --coupled_prompt_length="${PROMPT_LENGTH}"
  --coupled_prompt_hidden_dim="${HIDDEN_DIM}"
  --coupled_prompt_max_scale="${MAX_SCALE}"
  --coupled_prompt_learning_rate="${ADAPTER_LR}"
  --load=1
  --n_epochs=40
  --early_stopping_patience=12
  --early_stopping_min_delta=0.0
)

echo "Improvement 20 pilot: layerwise coupled missing prompt re-adaptation (LCMPR)"
echo "Foundation: first + seventh + FPFR; every foundation parameter frozen"
echo "Checkpoint directory: ${FPFR_CHECKPOINT_DIR}"
echo "Pilot protocols: ${PROTOCOLS} (text-observed protocols 0, 3, and 4 only)"
echo "Runs: full=${RUN_FULL}; single-layer ablation=${RUN_SINGLE_LAYER}"
echo "Adapter LR=${ADAPTER_LR}; hidden dim=${HIDDEN_DIM}; prompt length=${PROMPT_LENGTH}; max scale=${MAX_SCALE}"

run_variant() {
  local protocol="$1"
  local depth="$2"
  local description="$3"
  local checkpoint="${FPFR_CHECKPOINT_DIR}/iie_mosei_protocol_${protocol}_missing_aware_q0_fusion_fpfr_best.pt"
  if [ ! -s "${checkpoint}" ]; then
    echo "Missing first+seventh+FPFR protocol-${protocol} checkpoint: ${checkpoint}" >&2
    exit 1
  fi
  echo "LCMPR ${description}: protocol ${protocol}"
  python3 main.py "${LCMPR_ARGS[@]}" \
    --coupled_prompt_depth="${depth}" \
    --fixed_protocol="${protocol}" \
    --model_path="${checkpoint}" \
    --learning_rate=1e-4 \
    --d_l=96 \
    --latent_dim=96 \
    --train_batch_size=256 \
    --dataset=mosei
}

for protocol in ${PROTOCOLS}; do
  case "${protocol}" in
    0|3|4) ;;
    *)
      echo "Strict LCMPR pilot supports protocols 0, 3, and 4 only; received ${protocol}" >&2
      exit 1
      ;;
  esac
  if [ "${RUN_SINGLE_LAYER}" = "1" ]; then
    run_variant "${protocol}" 1 "single-layer ablation"
  fi
  if [ "${RUN_FULL}" = "1" ]; then
    run_variant "${protocol}" 2 "two-layer coupled prompt"
  fi
done
