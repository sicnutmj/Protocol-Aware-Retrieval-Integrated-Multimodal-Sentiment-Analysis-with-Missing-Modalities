set -euo pipefail

python3 -m py_compile \
  main.py \
  IIE_model.py \
  modules/missing_aware_retrieval.py \
  paper_experiment.py \
  run_e12_retrieval_ablation.py \
  tests/test_e12_retrieval_ablation.py

python3 -m pytest \
  tests/test_paper_experiment.py \
  tests/test_missing_aware_retrieval.py \
  tests/test_deterministic_pooling.py \
  tests/test_e05_fpfr_gate.py \
  tests/test_e06_mosei_primary.py \
  tests/test_e07_mosi_external.py \
  tests/test_e08_protocol3_clean.py \
  tests/test_e11_component_ablation.py \
  tests/test_e12_retrieval_ablation.py \
  -q

python3 - <<'PY'
import json
from pathlib import Path

from paper_experiment import resolve_dataset_path

path = Path("paper_experiments/configs/E12_retrieval_ablation.json")
with path.open(encoding="utf-8") as stream:
    config = json.load(stream)
assert config["dataset"] == "mosei"
assert config["protocols"] == ["0", "3", "5", "6"]
assert config["seeds"] == [1111, 3407, 7777]
assert config["new_required_runs"] == 48
assert config["reused_reference_records"] == 24
assert config["total_ablation_cells"] == 72
assert config["arms"]["B0"]["retrieval_candidate_filter"] == "all"
assert config["arms"]["B2"]["retrieval_composition"] == "prototype_only"
assert config["arms"]["B3"]["retrieval_composition"] == "neighbours_only"
assert config["arms"]["B5"]["retrieval_selection"] == "random"
assert config["resume_policy"]["overwrite"] == "forbidden"
print("E12 dataset resolved:", resolve_dataset_path(Path("."), "mosei"))
print("E12 retrieval-ablation configuration verified")
PY

PLAN_FILE="$(mktemp)"
trap 'rm -f "${PLAN_FILE}"' EXIT
python3 run_e12_retrieval_ablation.py \
  --protocols=0 \
  --seeds=1111 \
  > "${PLAN_FILE}"
grep -q 'E12 dry-run plan | new_runs=4 | reused_reference_records=2 | total_ablation_cells=6' "${PLAN_FILE}"
grep -q 'E12_E12U_mosei_p0_s1111' "${PLAN_FILE}"
grep -q 'E12_E12P_mosei_p0_s1111' "${PLAN_FILE}"
grep -q 'E12_E12N_mosei_p0_s1111' "${PLAN_FILE}"
grep -q 'E12_E12R_mosei_p0_s1111' "${PLAN_FILE}"
grep -q 'E11_A1_mosei_p0_s1111,E06R1_M1_mosei_p0_s1111' "${PLAN_FILE}"
grep -q -- '--retrieval_candidate_filter=all' "${PLAN_FILE}"
grep -q -- '--retrieval_composition=prototype_only' "${PLAN_FILE}"
grep -q -- '--retrieval_composition=neighbours_only' "${PLAN_FILE}"
grep -q -- '--retrieval_selection=random' "${PLAN_FILE}"
grep -q -- '--retrieval_random_seed=1111' "${PLAN_FILE}"
if grep -q -- '--protocol_fusion_readaptation' "${PLAN_FILE}"; then
  echo "E12 root ablation unexpectedly enables fusion readaptation" >&2
  exit 1
fi
echo "E12 48-new-run plan and 24-record reuse mapping verified"

if [ "${E12_GPU_SMOKE:-0}" != "1" ]; then
  echo "Set E12_GPU_SMOKE=1 to run one epoch for all four new E12 arms."
  exit 0
fi

SMOKE_ROOT="${SMOKE_ROOT:-tmp/e12_retrieval_ablation_smoke}"
STAMP="$(date +%Y%m%d_%H%M%S)"
mkdir -p \
  "${SMOKE_ROOT}/checkpoints" \
  "${SMOKE_ROOT}/logs" \
  "${SMOKE_ROOT}/manifests"

run_smoke_arm() {
  local arm="$1"
  local method="$2"
  local source="$3"
  local filter="$4"
  local composition="$5"
  local selection="$6"
  local random_seed="$7"
  local run_id="E12_SMOKE_${method}_mosei_p0_s1111_${STAMP}"
  python3 main.py \
    --paper_experiment \
    --paper_run_id="${run_id}" \
    --paper_method_id="${method}" \
    --paper_stage_id=E12_SMOKE \
    --paper_manifest_dir="${SMOKE_ROOT}/manifests" \
    --best_model_dir="${SMOKE_ROOT}/checkpoints" \
    --log_dir="${SMOKE_ROOT}/logs" \
    --dataset=mosei \
    --fixed_protocol=0 \
    --seed=1111 \
    --train_batch_size=128 \
    --dev_batch_size=128 \
    --test_batch_size=128 \
    --d_l=192 \
    --latent_dim=192 \
    --layers=3 \
    --latent_layers=2 \
    --missing_rate=0.3 \
    --weight_decay=1e-4 \
    --retrieval_mode=missing_aware \
    --retrieval_candidate_source="${source}" \
    --retrieval_candidate_filter="${filter}" \
    --retrieval_composition="${composition}" \
    --retrieval_selection="${selection}" \
    --retrieval_random_seed="${random_seed}" \
    --retrieval_top_k=2 \
    --retrieval_queue_size=0 \
    --retrieval_metric_mode=raw \
    --retrieval_missing_query=center \
    --retrieval_bank_batch_size=256 \
    --retrieval_bank_refresh_epochs=1 \
    --gate_mode=none \
    --consistency_mode=mixed \
    --distill_mode=none \
    --fusion_mode=flat \
    --prompt_mode=none \
    --reconstruction_mode=none \
    --consensus_mode=none \
    --tag_mode=none \
    --cross_modal_retrieval_mode=none \
    --training_prior_mode=none \
    --hybrid_expert_mode=none \
    --protocol_consistency_mode=none \
    --relation_distill_mode=none \
    --missing_text_contrast_mode=none \
    --privileged_purification_mode=none \
    --language_hyper_mode=none \
    --coupled_prompt_mode=none \
    --early_stopping_min_delta=0.0 \
    --learning_rate=2e-5 \
    --n_epochs=1 \
    --early_stopping_patience=0
}

run_smoke_arm B0 E12U batch all prototype_neighbours similarity 3407
run_smoke_arm B2 E12P train_bank observed_only prototype_only similarity 3407
run_smoke_arm B3 E12N train_bank observed_only neighbours_only similarity 3407
run_smoke_arm B5 E12R train_bank observed_only prototype_neighbours random 1111

python3 - "${SMOKE_ROOT}" "${STAMP}" <<'PY'
import json
import sys
from pathlib import Path

root = Path(sys.argv[1])
stamp = sys.argv[2]
arms = {
    "E12U": ("batch", "all", "prototype_neighbours", "similarity", 3407),
    "E12P": ("train_bank", "observed_only", "prototype_only", "similarity", 3407),
    "E12N": ("train_bank", "observed_only", "neighbours_only", "similarity", 3407),
    "E12R": ("train_bank", "observed_only", "prototype_neighbours", "random", 1111),
}
for method, expected in arms.items():
    run_id = "E12_SMOKE_{}_mosei_p0_s1111_{}".format(method, stamp)
    path = root / "manifests" / "{}.json".format(run_id)
    with path.open(encoding="utf-8") as stream:
        manifest = json.load(stream)
    result = manifest["result"]
    args = manifest["arguments"]
    actual = (
        args["retrieval_candidate_source"],
        args["retrieval_candidate_filter"],
        args["retrieval_composition"],
        args["retrieval_selection"],
        args["retrieval_random_seed"],
    )
    assert manifest["status"] == "complete"
    assert manifest["method_id"] == method
    assert manifest["lineage"] is None
    assert actual == expected
    assert args["protocol_fusion_readaptation"] is False
    assert result["completed_epochs"] == 1
    assert result["test_evaluation_count"] == 1
    assert result["data_provenance"]["split_sizes"] == {
        "train": 16326, "dev": 1871, "test": 4659,
    }
    print("E12 GPU contract verified:", method)
print("E12 four-arm one-epoch GPU smoke verified")
PY
