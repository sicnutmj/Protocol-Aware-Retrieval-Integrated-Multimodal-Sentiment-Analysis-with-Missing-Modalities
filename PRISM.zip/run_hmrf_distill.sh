set -e
DISTILL_ARGS=(
  --retrieval_mode=missing_aware
  --retrieval_queue_size=0
  --retrieval_metric_mode=raw
  --retrieval_missing_query=center
  --gate_mode=none
  --consistency_mode=mixed
  --distill_mode=paired_hierarchical
  --distill_sample_weight=0.05
  --distill_fusion_weight=0.05
  --early_stopping_patience=0
)
echo "Frozen failed ablation: HMRF-inspired paired hierarchical distillation"

run_protocol() {
  local protocol="$1"
  local train_batch_size="$2"
  local representation_dim="$3"
  local description="$4"

  echo "paired distillation: protocol ${protocol} (${description})"
  python3 main.py "${DISTILL_ARGS[@]}" \
    --fixed_protocol="${protocol}" \
    --learning_rate=2e-5 \
    --d_l="${representation_dim}" \
    --latent_dim="${representation_dim}" \
    --train_batch_size="${train_batch_size}" \
    --dataset=mosei
}

# Screening protocols selected before any seven-protocol expansion.
run_protocol 0 128 192 "L observed"
run_protocol 2 256 192 "V observed"
run_protocol 5 256 192 "A+V observed"
