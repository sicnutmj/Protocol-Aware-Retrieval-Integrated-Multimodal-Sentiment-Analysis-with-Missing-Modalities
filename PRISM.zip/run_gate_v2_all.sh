set -e
ABLATION_ARGS=(
  --retrieval_mode=missing_aware
  --retrieval_queue_size=0
  --gate_mode=quality_reliability
  --gate_hidden_dim=32
  --gate_dropout=0.0
  --gate_min_scale=0.7
  --gate_init_bias=4.0
  --gate_init_seed=3407
  --early_stopping_patience=0
)
echo "Gate-V2.1 full evaluation on fixed missing scenarios"
echo "tuning on L"
python3 main.py "${ABLATION_ARGS[@]}" --fixed_protocol='0' --learning_rate=2e-5 --d_l=192 --latent_dim=192 --train_batch_size=128 --dataset=mosei
echo "tuning on L & A & V"
python3 main.py "${ABLATION_ARGS[@]}" --fixed_protocol='6' --learning_rate=2e-5 --d_l=192 --latent_dim=192 --train_batch_size=128 --dataset=mosei
echo "tuning on A"
python3 main.py "${ABLATION_ARGS[@]}" --fixed_protocol='1' --learning_rate=2e-5 --d_l=192 --latent_dim=192 --train_batch_size=128 --layers=2 --latent_layers=3 --missing_rate=0.05 --dataset=mosei
echo "tuning on L & A"
python3 main.py "${ABLATION_ARGS[@]}" --fixed_protocol='3' --learning_rate=2e-5 --dataset=mosei
echo "tuning on L & V"
python3 main.py "${ABLATION_ARGS[@]}" --fixed_protocol='4' --learning_rate=2e-5 --dataset=mosei
echo "tuning on V"
python3 main.py "${ABLATION_ARGS[@]}" --fixed_protocol='2' --learning_rate=2e-5 --d_l=192 --latent_dim=192 --dataset=mosei
echo "tuning on A & V"
python3 main.py "${ABLATION_ARGS[@]}" --fixed_protocol='5' --learning_rate=2e-5 --d_l=192 --latent_dim=192 --dataset=mosei
