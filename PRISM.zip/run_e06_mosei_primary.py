"""Plan, execute, and audit the formal E06 MOSEI primary matrix."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path

from paper_experiment import code_fingerprints, sha256_file


PROTOCOLS = tuple(str(value) for value in range(7))
SEEDS = (1111, 2222, 3407, 5576, 7777)
METHODS = ("M0", "M1", "M2", "M3")
PARENTS = {"M0": None, "M1": None, "M2": "M1", "M3": "M2"}
METRICS = (
    "test_mae",
    "test_corr",
    "test_acc7",
    "test_acc5",
    "test_acc2_non_zero",
    "test_f1_non_zero",
    "test_acc2",
    "test_f1",
)
PROTOCOL_SETTINGS = {
    "0": {"train_batch_size": 128, "representation_dim": 192,
          "layers": 3, "latent_layers": 2, "missing_rate": 0.3},
    "1": {"train_batch_size": 128, "representation_dim": 192,
          "layers": 2, "latent_layers": 3, "missing_rate": 0.05},
    "2": {"train_batch_size": 256, "representation_dim": 192,
          "layers": 3, "latent_layers": 2, "missing_rate": 0.3},
    "3": {"train_batch_size": 256, "representation_dim": 96,
          "layers": 3, "latent_layers": 2, "missing_rate": 0.3},
    "4": {"train_batch_size": 256, "representation_dim": 96,
          "layers": 3, "latent_layers": 2, "missing_rate": 0.3},
    "5": {"train_batch_size": 256, "representation_dim": 192,
          "layers": 3, "latent_layers": 2, "missing_rate": 0.3},
    "6": {"train_batch_size": 128, "representation_dim": 192,
          "layers": 3, "latent_layers": 2, "missing_rate": 0.3},
}


@dataclass(frozen=True)
class RunSpec:
    method: str
    protocol: str
    seed: int
    run_id: str
    parent_run_id: str = ""


def build_matrix(protocols=PROTOCOLS, seeds=SEEDS, methods=METHODS):
    """Return the deterministic, lineage-safe execution order."""
    protocols = tuple(str(value) for value in protocols)
    seeds = tuple(int(value) for value in seeds)
    methods = tuple(methods)
    unknown_protocols = sorted(set(protocols) - set(PROTOCOLS))
    unknown_seeds = sorted(set(seeds) - set(SEEDS))
    unknown_methods = sorted(set(methods) - set(METHODS))
    if unknown_protocols or unknown_seeds or unknown_methods:
        raise ValueError(
            "Unknown E06 selection | protocols={} | seeds={} | methods={}"
            .format(unknown_protocols, unknown_seeds, unknown_methods)
        )
    ordered_methods = tuple(method for method in METHODS if method in methods)
    specs = []
    for seed in seeds:
        for protocol in protocols:
            for method in ordered_methods:
                run_id = "E06R1_{}_mosei_p{}_s{}".format(
                    method, protocol, seed
                )
                parent_method = PARENTS[method]
                parent_run_id = (
                    "E06R1_{}_mosei_p{}_s{}".format(
                        parent_method, protocol, seed
                    )
                    if parent_method else ""
                )
                specs.append(RunSpec(
                    method=method,
                    protocol=protocol,
                    seed=seed,
                    run_id=run_id,
                    parent_run_id=parent_run_id,
                ))
    return specs


def _sha256_file(path):
    digest = hashlib.sha256()
    with open(path, "rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _read_manifest(path):
    with open(path, "r", encoding="utf-8") as stream:
        return json.load(stream)


def _parent_checkpoint(workspace, spec):
    parent_path = (
        workspace / "paper_experiments" / "manifests"
        / "{}.json".format(spec.parent_run_id)
    )
    if not parent_path.is_file():
        raise FileNotFoundError(
            "E06 parent manifest is missing: {}".format(parent_path)
        )
    parent = _read_manifest(parent_path)
    expected = {
        "status": "complete",
        "run_id": spec.parent_run_id,
        "method_id": PARENTS[spec.method],
        "dataset": "mosei",
        "protocol": spec.protocol,
        "seed": spec.seed,
    }
    mismatches = {
        key: (value, parent.get(key))
        for key, value in expected.items()
        if parent.get(key) != value
    }
    if mismatches:
        raise RuntimeError(
            "E06 parent manifest mismatch: {}".format(mismatches)
        )
    outputs = parent.get("outputs") or {}
    checkpoint = Path(outputs.get("best_model_path", ""))
    if not checkpoint.is_file():
        raise FileNotFoundError(
            "E06 parent checkpoint is missing: {}".format(checkpoint)
        )
    if _sha256_file(checkpoint) != outputs.get("best_model_sha256"):
        raise RuntimeError("E06 parent checkpoint SHA256 mismatch")
    return checkpoint.resolve()


def command_for_spec(workspace, spec, resolve_parent=True):
    """Build the fully explicit frozen command for one formal run."""
    settings = PROTOCOL_SETTINGS[spec.protocol]
    adaptation = spec.method in ("M2", "M3")
    command = [
        sys.executable,
        "main.py",
        "--paper_experiment",
        "--paper_run_id={}".format(spec.run_id),
        "--paper_method_id={}".format(spec.method),
        "--paper_stage_id=E06",
        "--paper_manifest_dir=paper_experiments/manifests",
        "--dataset=mosei",
        "--fixed_protocol={}".format(spec.protocol),
        "--seed={}".format(spec.seed),
        "--train_batch_size={}".format(settings["train_batch_size"]),
        "--dev_batch_size=128",
        "--test_batch_size=128",
        "--d_l={}".format(settings["representation_dim"]),
        "--latent_dim={}".format(settings["representation_dim"]),
        "--layers={}".format(settings["layers"]),
        "--latent_layers={}".format(settings["latent_layers"]),
        "--missing_rate={}".format(settings["missing_rate"]),
        "--weight_decay=1e-4",
        "--retrieval_queue_size=0",
        "--retrieval_metric_mode=raw",
        "--retrieval_missing_query=center",
        "--retrieval_bank_batch_size=256",
        "--retrieval_bank_refresh_epochs=1",
        "--gate_mode=none",
        "--consistency_mode=mixed",
        "--distill_mode=none",
        "--fusion_mode=flat",
        "--prompt_mode=none",
        "--reconstruction_mode=none",
        "--consensus_mode=none",
        "--tag_mode=none",
        "--cross_modal_retrieval_mode=none",
        "--training_prior_mode=none",
        "--hybrid_expert_mode=none",
        "--protocol_consistency_mode=none",
        "--relation_distill_mode=none",
        "--missing_text_contrast_mode=none",
        "--privileged_purification_mode=none",
        "--language_hyper_mode=none",
        "--coupled_prompt_mode=none",
        "--early_stopping_min_delta=0.0",
    ]
    if spec.method == "M0":
        command.extend((
            "--retrieval_mode=legacy",
            "--retrieval_candidate_source=batch",
        ))
    else:
        command.extend((
            "--retrieval_mode=missing_aware",
            "--retrieval_candidate_source=train_bank",
        ))
    if adaptation:
        checkpoint = (
            _parent_checkpoint(workspace, spec)
            if resolve_parent else Path("<PARENT_CHECKPOINT>")
        )
        command.extend((
            "--paper_parent_run_id={}".format(spec.parent_run_id),
            "--model_path={}".format(checkpoint),
            "--load=1",
            "--protocol_fusion_readaptation",
            "--protocol_fusion_learning_rate=1e-4",
            "--learning_rate=1e-4",
            "--n_epochs=40",
            "--early_stopping_patience=12",
        ))
    else:
        command.extend((
            "--learning_rate=2e-5",
            "--n_epochs=100",
            "--early_stopping_patience=12",
        ))
    return command


def _validate_completed_manifest(workspace, spec):
    manifest_path = (
        workspace / "paper_experiments" / "manifests"
        / "{}.json".format(spec.run_id)
    )
    if not manifest_path.is_file():
        return None
    manifest = _read_manifest(manifest_path)
    if manifest.get("status") != "complete":
        raise RuntimeError(
            "E06 run id already exists with status {!r}; inspect it and do "
            "not overwrite it: {}".format(
                manifest.get("status"), manifest_path
            )
        )
    expected = {
        "run_id": spec.run_id,
        "method_id": spec.method,
        "stage_id": "E06",
        "dataset": "mosei",
        "protocol": spec.protocol,
        "seed": spec.seed,
    }
    mismatches = {
        key: (value, manifest.get(key))
        for key, value in expected.items()
        if manifest.get(key) != value
    }
    if mismatches:
        raise RuntimeError(
            "Completed E06 manifest identity mismatch: {}".format(mismatches)
        )
    lineage = manifest.get("lineage")
    if spec.parent_run_id:
        if not isinstance(lineage, dict):
            raise RuntimeError("E06 staged run lacks lineage")
        if lineage.get("parent_run_id") != spec.parent_run_id:
            raise RuntimeError("E06 staged run names the wrong parent")
        if lineage.get("parent_method_id") != PARENTS[spec.method]:
            raise RuntimeError("E06 staged run has the wrong parent method")
    elif lineage is not None:
        raise RuntimeError("E06 root method unexpectedly declares lineage")

    result = manifest.get("result") or {}
    if result.get("test_evaluation_count") != 1:
        raise RuntimeError("E06 formal run must evaluate test exactly once")
    if result.get("selection_split") != "development":
        raise RuntimeError("E06 formal run was not selected on development")
    if result.get("selection_metric") != "mae":
        raise RuntimeError("E06 formal selection metric is not MAE")
    for key in ("best_loss",) + METRICS:
        value = result.get(key)
        if not isinstance(value, (int, float)) or not math.isfinite(value):
            raise RuntimeError("E06 result lacks finite {}".format(key))
    if spec.method in ("M2", "M3"):
        gate = result.get("adaptation_gate") or {}
        if gate.get("outcome") not in ("improved", "fallback_parent"):
            raise RuntimeError("E06 adaptation gate is missing")
        if gate.get("test_metrics_consulted") is not False:
            raise RuntimeError("E06 adaptation gate consulted test metrics")

    outputs = manifest.get("outputs") or {}
    checkpoint = Path(outputs.get("best_model_path", ""))
    if not checkpoint.is_file():
        raise FileNotFoundError(
            "E06 completed checkpoint is missing: {}".format(checkpoint)
        )
    if _sha256_file(checkpoint) != outputs.get("best_model_sha256"):
        raise RuntimeError("E06 completed checkpoint SHA256 mismatch")
    return manifest


def audit_matrix(workspace, specs, require_complete=True):
    """Audit immutable artifacts and return a deterministic summary."""
    records = []
    missing = []
    code_fingerprints = None
    dataset_sha256 = None
    for spec in specs:
        manifest = _validate_completed_manifest(workspace, spec)
        if manifest is None:
            missing.append(spec.run_id)
            continue
        result = manifest["result"]
        provenance = result.get("data_provenance") or {}
        current_dataset_sha256 = provenance.get("dataset_sha256")
        if not current_dataset_sha256:
            raise RuntimeError("E06 manifest lacks dataset SHA256")
        if dataset_sha256 is None:
            dataset_sha256 = current_dataset_sha256
        elif dataset_sha256 != current_dataset_sha256:
            raise RuntimeError("E06 matrix mixes different dataset files")
        current_code = manifest.get("code_sha256")
        if code_fingerprints is None:
            code_fingerprints = current_code
        elif code_fingerprints != current_code:
            raise RuntimeError("E06 matrix mixes different code fingerprints")
        record = {
            "run_id": spec.run_id,
            "method_id": spec.method,
            "protocol": spec.protocol,
            "seed": spec.seed,
            "best_epoch": result["best_epoch"],
            "best_dev_mae": result["best_loss"],
        }
        record.update({key: result[key] for key in METRICS})
        if spec.method in ("M2", "M3"):
            gate = result["adaptation_gate"]
            record["adaptation_outcome"] = gate["outcome"]
            record["development_mae_gain"] = gate["dev_mae_gain"]
        records.append(record)
    if require_complete and missing:
        raise RuntimeError(
            "Incomplete E06 matrix: {} of {} runs are missing; first={}".format(
                len(missing), len(specs), missing[:5]
            )
        )
    return {
        "schema_version": 1,
        "stage_id": "E06",
        "dataset": "mosei",
        "expected_run_count": len(specs),
        "completed_run_count": len(records),
        "missing_run_ids": missing,
        "dataset_sha256": dataset_sha256,
        "code_sha256": code_fingerprints,
        "test_evaluation_count_per_run": 1,
        "selection_split": "development",
        "selection_metric": "mae",
        "records": records,
    }


def write_immutable_json(path, payload):
    encoded = json.dumps(
        payload, ensure_ascii=False, indent=2, sort_keys=True
    ) + "\n"
    if path.exists():
        if path.read_text(encoding="utf-8") != encoded:
            raise FileExistsError(
                "E06 audit exists with different content: {}".format(path)
            )
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(encoded, encoding="utf-8")
    os.replace(str(temporary), str(path))


def execute_matrix(workspace, specs):
    """Resume at missing run ids while refusing ambiguous partial records."""
    partial = audit_matrix(workspace, specs, require_complete=False)
    if partial["completed_run_count"]:
        current_code = code_fingerprints(workspace)
        if partial["code_sha256"] != current_code:
            raise RuntimeError(
                "E06 resume refused because the code fingerprint changed"
            )
        dataset_path = workspace / "datasets" / "aligned_mosei.pkl"
        if not dataset_path.is_file():
            raise FileNotFoundError(
                "E06 dataset is missing: {}".format(dataset_path)
            )
        if partial["dataset_sha256"] != sha256_file(dataset_path):
            raise RuntimeError(
                "E06 resume refused because the dataset fingerprint changed"
            )
    environment = os.environ.copy()
    environment["CUBLAS_WORKSPACE_CONFIG"] = ":4096:8"
    completed = 0
    skipped = 0
    for index, spec in enumerate(specs, start=1):
        manifest = _validate_completed_manifest(workspace, spec)
        if manifest is not None:
            skipped += 1
            print("[{}/{}] SKIP complete {}".format(
                index, len(specs), spec.run_id
            ), flush=True)
            continue
        command = command_for_spec(workspace, spec, resolve_parent=True)
        print("[{}/{}] RUN {}".format(
            index, len(specs), spec.run_id
        ), flush=True)
        subprocess.check_call(command, cwd=str(workspace), env=environment)
        _validate_completed_manifest(workspace, spec)
        subprocess.check_call(
            [sys.executable, "refresh_paper_registry.py", "--workspace", "."],
            cwd=str(workspace),
            env=environment,
        )
        completed += 1
    print("E06 execution finished | new={} | skipped={}".format(
        completed, skipped
    ))


def _csv_values(value, cast):
    return tuple(cast(item.strip()) for item in value.split(",") if item.strip())


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--workspace", type=Path, default=Path("."))
    parser.add_argument("--protocols", default=",".join(PROTOCOLS))
    parser.add_argument("--seeds", default=",".join(str(seed) for seed in SEEDS))
    parser.add_argument("--methods", default=",".join(METHODS))
    parser.add_argument("--execute", action="store_true")
    parser.add_argument("--audit", action="store_true")
    parser.add_argument(
        "--audit_output",
        type=Path,
        default=Path("paper_results/E06_mosei_primary_audit.json"),
    )
    return parser.parse_args()


def main():
    args = parse_args()
    workspace = args.workspace.resolve()
    protocols = _csv_values(args.protocols, str)
    seeds = _csv_values(args.seeds, int)
    methods = _csv_values(args.methods, str)
    specs = build_matrix(protocols, seeds, methods)
    if not args.execute and not args.audit:
        print("E06 dry-run plan | runs={}".format(len(specs)))
        for spec in specs:
            print("{} | parent={} | {}".format(
                spec.run_id,
                spec.parent_run_id or "none",
                " ".join(command_for_spec(
                    workspace, spec, resolve_parent=False
                )),
            ))
        return
    if args.execute:
        if os.environ.get("E06_EXECUTE") != "1":
            raise RuntimeError(
                "Set E06_EXECUTE=1 to authorize the formal 140-run matrix"
            )
        execute_matrix(workspace, specs)
    if args.audit:
        summary = audit_matrix(workspace, specs, require_complete=True)
        output = args.audit_output
        if not output.is_absolute():
            output = workspace / output
        write_immutable_json(output, summary)
        print("E06 audit verified: {}".format(output))


if __name__ == "__main__":
    main()
