set -e

if [ "${E02_SMOKE:-0}" != "1" ]; then
  echo "Set E02_SMOKE=1 to run the diagnostic E02 GPU smoke test." >&2
  exit 2
fi

SMOKE_ROOT="${SMOKE_ROOT:-tmp/e02_smoke}"
RUN_ID="E02_SMOKE_M1_mosei_p6_s1111_$(date +%Y%m%d_%H%M%S)"
mkdir -p \
  "${SMOKE_ROOT}/checkpoints" \
  "${SMOKE_ROOT}/logs" \
  "${SMOKE_ROOT}/manifests"

echo "E02 smoke test: development-only selection and one final test"
echo "Run id: ${RUN_ID}"
echo "Outputs are diagnostic only and excluded from paper_experiments."

python3 main.py \
  --paper_experiment \
  --paper_run_id="${RUN_ID}" \
  --paper_method_id=M1 \
  --paper_stage_id=E02 \
  --paper_manifest_dir="${SMOKE_ROOT}/manifests" \
  --best_model_dir="${SMOKE_ROOT}/checkpoints" \
  --log_dir="${SMOKE_ROOT}/logs" \
  --retrieval_mode=missing_aware \
  --retrieval_candidate_source=train_bank \
  --retrieval_queue_size=0 \
  --retrieval_metric_mode=raw \
  --retrieval_missing_query=center \
  --retrieval_bank_batch_size=256 \
  --retrieval_bank_refresh_epochs=1 \
  --gate_mode=none \
  --consistency_mode=mixed \
  --fusion_mode=flat \
  --prompt_mode=none \
  --fixed_protocol=6 \
  --learning_rate=2e-5 \
  --d_l=192 \
  --latent_dim=192 \
  --train_batch_size=128 \
  --dev_batch_size=128 \
  --test_batch_size=128 \
  --dataset=mosei \
  --seed=1111 \
  --n_epochs=1 \
  --early_stopping_patience=0

python3 - "${SMOKE_ROOT}/manifests/${RUN_ID}.json" <<'PY'
import json
import sys

with open(sys.argv[1], "r", encoding="utf-8") as stream:
    manifest = json.load(stream)
result = manifest["result"]
assert manifest["status"] == "complete"
assert result["selection_split"] == "development"
assert result["selection_metric"] == "mae"
assert result["test_evaluation_count"] == 1
assert result["test_policy"] == "evaluate_once_after_checkpoint_selection"
assert result["selected_checkpoint_sha256"]
assert result["test_mae"] >= 0.0
print("E02 manifest verification passed:", sys.argv[1])
PY

if grep -q "test_evaluated=True" "${SMOKE_ROOT}/logs/${RUN_ID}.log"; then
  echo "E02 failure: test metrics were evaluated during training." >&2
  exit 1
fi

grep -E \
  "test_evaluated=False|Formal final test completed|Run completed" \
  "${SMOKE_ROOT}/logs/${RUN_ID}.log"
