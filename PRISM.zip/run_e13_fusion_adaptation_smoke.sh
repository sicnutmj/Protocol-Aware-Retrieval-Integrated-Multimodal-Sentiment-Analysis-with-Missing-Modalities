set -euo pipefail

python3 -m py_compile \
  main.py \
  IIE_model.py \
  paper_experiment.py \
  run_e13_fusion_adaptation.py \
  tests/test_e13_fusion_adaptation.py \
  tests/test_e13_adaptation_scope.py

python3 -m pytest \
  tests/test_paper_experiment.py \
  tests/test_missing_aware_retrieval.py \
  tests/test_deterministic_pooling.py \
  tests/test_e05_fpfr_gate.py \
  tests/test_e06_mosei_primary.py \
  tests/test_e07_mosi_external.py \
  tests/test_e08_protocol3_clean.py \
  tests/test_e11_component_ablation.py \
  tests/test_e12_retrieval_ablation.py \
  tests/test_e13_fusion_adaptation.py \
  tests/test_e13_adaptation_scope.py \
  -q

python3 - <<'PY'
import json
from pathlib import Path

from paper_experiment import resolve_dataset_path
from run_e13_fusion_adaptation import preflight_references

path = Path("paper_experiments/configs/E13_fusion_adaptation.json")
with path.open(encoding="utf-8") as stream:
    config = json.load(stream)
assert config["dataset"] == "mosei"
assert config["protocols"] == [str(value) for value in range(7)]
assert config["seeds"] == [1111, 2222, 3407, 5576, 7777]
assert config["new_required_runs"] == 70
assert config["reused_reference_records"] == 105
assert config["total_ablation_cells"] == 175
assert config["checklist_aliases"]["一阶段适配"] == "D2"
assert config["checklist_aliases"]["每协议独立适配"] == "D2"
assert config["deferred_shared_model_control"]["included_in_E13"] is False
assert config["resume_policy"]["overwrite"] == "forbidden"
print("E13 dataset resolved:", resolve_dataset_path(Path("."), "mosei"))
preflight = preflight_references(Path(".").resolve(), ("0",), (1111,))
assert preflight["reference_count"] == 3
print("E13 fusion-adaptation configuration verified")
PY

PLAN_FILE="$(mktemp)"
trap 'rm -f "${PLAN_FILE}"' EXIT
python3 run_e13_fusion_adaptation.py \
  --protocols=0 \
  --seeds=1111 \
  > "${PLAN_FILE}"
grep -q 'E13 dry-run plan | new_runs=2 | reused_reference_records=3 | total_ablation_cells=5' "${PLAN_FILE}"
grep -q 'E13_E13L_mosei_p0_s1111' "${PLAN_FILE}"
grep -q 'E13_E13T_mosei_p0_s1111' "${PLAN_FILE}"
grep -q 'E06R1_M1_mosei_p0_s1111,E06R1_M2_mosei_p0_s1111,E06R1_M3_mosei_p0_s1111' "${PLAN_FILE}"
grep -q -- '--protocol_adaptation_scope=last_layer' "${PLAN_FILE}"
grep -q -- '--protocol_adaptation_scope=late_transformer_fusion' "${PLAN_FILE}"
grep -q -- '--protocol_fusion_learning_rate=1e-4' "${PLAN_FILE}"
grep -q -- '--protocol_transformer_learning_rate=2e-5' "${PLAN_FILE}"
echo "E13 70-new-run plan and 105-record reuse mapping verified"

if [ "${E13_GPU_SMOKE:-0}" != "1" ]; then
  echo "Set E13_GPU_SMOKE=1 to run one epoch for both new E13 scopes."
  exit 0
fi

SMOKE_ROOT="${SMOKE_ROOT:-tmp/e13_fusion_adaptation_smoke}"
STAMP="$(date +%Y%m%d_%H%M%S)"
mkdir -p \
  "${SMOKE_ROOT}/checkpoints" \
  "${SMOKE_ROOT}/logs" \
  "${SMOKE_ROOT}/manifests"

# Formal lineage lookup is intentionally rooted at paper_manifest_dir.  The
# smoke outputs stay isolated under tmp/, so provide a read-only copy of the
# frozen parent manifest beside the smoke manifests.  Its recorded checkpoint
# path and SHA256 are still validated against the formal E06 artifact.
cp \
  paper_experiments/manifests/E06R1_M1_mosei_p0_s1111.json \
  "${SMOKE_ROOT}/manifests/E06R1_M1_mosei_p0_s1111.json"

run_smoke_scope() {
  local method="$1"
  local scope="$2"
  local run_id="E13_SMOKE_${method}_mosei_p0_s1111_${STAMP}"
  python3 main.py \
    --paper_experiment \
    --paper_run_id="${run_id}" \
    --paper_method_id="${method}" \
    --paper_stage_id=E13_SMOKE \
    --paper_parent_run_id=E06R1_M1_mosei_p0_s1111 \
    --paper_manifest_dir="${SMOKE_ROOT}/manifests" \
    --best_model_dir="${SMOKE_ROOT}/checkpoints" \
    --log_dir="${SMOKE_ROOT}/logs" \
    --model_path=paper_checkpoints/E06R1_M1_mosei_p0_s1111_best.pt \
    --load=1 \
    --dataset=mosei \
    --fixed_protocol=0 \
    --seed=1111 \
    --train_batch_size=128 \
    --dev_batch_size=128 \
    --test_batch_size=128 \
    --d_l=192 \
    --latent_dim=192 \
    --layers=3 \
    --latent_layers=2 \
    --missing_rate=0.3 \
    --weight_decay=1e-4 \
    --retrieval_mode=missing_aware \
    --retrieval_candidate_source=train_bank \
    --retrieval_candidate_filter=observed_only \
    --retrieval_composition=prototype_neighbours \
    --retrieval_selection=similarity \
    --retrieval_random_seed=3407 \
    --retrieval_queue_size=0 \
    --retrieval_metric_mode=raw \
    --retrieval_missing_query=center \
    --retrieval_bank_batch_size=256 \
    --retrieval_bank_refresh_epochs=1 \
    --gate_mode=none \
    --consistency_mode=mixed \
    --distill_mode=none \
    --fusion_mode=flat \
    --prompt_mode=none \
    --reconstruction_mode=none \
    --consensus_mode=none \
    --tag_mode=none \
    --cross_modal_retrieval_mode=none \
    --training_prior_mode=none \
    --hybrid_expert_mode=none \
    --protocol_consistency_mode=none \
    --relation_distill_mode=none \
    --missing_text_contrast_mode=none \
    --privileged_purification_mode=none \
    --language_hyper_mode=none \
    --coupled_prompt_mode=none \
    --early_stopping_min_delta=0.0 \
    --protocol_fusion_readaptation \
    --protocol_adaptation_scope="${scope}" \
    --protocol_fusion_learning_rate=1e-4 \
    --protocol_transformer_learning_rate=2e-5 \
    --learning_rate=1e-4 \
    --n_epochs=1 \
    --early_stopping_patience=0
}

run_smoke_scope E13L last_layer
run_smoke_scope E13T late_transformer_fusion

python3 - "${SMOKE_ROOT}" "${STAMP}" <<'PY'
import json
import sys
from pathlib import Path

root = Path(sys.argv[1])
stamp = sys.argv[2]
expected = {
    "E13L": "last_layer",
    "E13T": "late_transformer_fusion",
}
for method, scope in expected.items():
    run_id = "E13_SMOKE_{}_mosei_p0_s1111_{}".format(method, stamp)
    path = root / "manifests" / "{}.json".format(run_id)
    with path.open(encoding="utf-8") as stream:
        manifest = json.load(stream)
    result = manifest["result"]
    args = manifest["arguments"]
    assert manifest["status"] == "complete"
    assert manifest["method_id"] == method
    assert manifest["lineage"]["parent_method_id"] == "M1"
    assert manifest["lineage"]["parent_run_id"] == "E06R1_M1_mosei_p0_s1111"
    assert args["protocol_fusion_readaptation"] is True
    assert args["protocol_adaptation_scope"] == scope
    assert result["completed_epochs"] == 1
    assert result["test_evaluation_count"] == 1
    assert result["adaptation_gate"]["outcome"] in (
        "improved", "fallback_parent"
    )
    assert result["adaptation_gate"]["test_metrics_consulted"] is False
    print("E13 GPU contract verified:", method, scope)
print("E13 two-scope one-epoch GPU smoke verified")
PY
