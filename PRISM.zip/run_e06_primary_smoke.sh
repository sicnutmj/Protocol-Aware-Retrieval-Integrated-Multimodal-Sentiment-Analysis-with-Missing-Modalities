set -e

python3 -m py_compile \
  main.py \
  paper_experiment.py \
  run_e06_mosei_primary.py \
  tests/test_e06_mosei_primary.py

python3 -m pytest \
  tests/test_paper_experiment.py \
  tests/test_missing_aware_retrieval.py \
  tests/test_e05_fpfr_gate.py \
  tests/test_e06_mosei_primary.py \
  -q

python3 - <<'PY'
import json

with open(
    "paper_experiments/configs/E06_mosei_primary_matrix.json",
    "r",
    encoding="utf-8",
) as stream:
    config = json.load(stream)
assert config["required_runs"] == 140
assert config["methods"] == ["M0", "M1", "M2", "M3"]
assert config["run_id_template"].startswith("E06R1_")
assert config["preflight_failure_record"]["artifact_policy"].startswith(
    "preserve failed manifest"
)
assert config["root_training"]["early_stopping_patience"] == 12
assert config["fusion_adaptation"]["early_stopping_patience"] == 12
assert config["resume_policy"]["overwrite"] == "forbidden"
print("E06 formal MOSEI matrix configuration verified")
PY

PLAN_FILE="$(mktemp)"
trap 'rm -f "${PLAN_FILE}"' EXIT
python3 run_e06_mosei_primary.py \
  --protocols=6 \
  --seeds=1111 \
  > "${PLAN_FILE}"
grep -q 'E06 dry-run plan | runs=4' "${PLAN_FILE}"
grep -q 'E06R1_M0_mosei_p6_s1111' "${PLAN_FILE}"
grep -q 'E06R1_M3_mosei_p6_s1111' "${PLAN_FILE}"
grep -q -- '--model_path=<PARENT_CHECKPOINT>' "${PLAN_FILE}"
echo "E06 four-stage dry-run lineage verified"

if [ "${E06_GPU_SMOKE:-0}" != "1" ]; then
  echo "Set E06_GPU_SMOKE=1 to run the corrected one-epoch M0 GPU path."
  exit 0
fi

SMOKE_ROOT="${SMOKE_ROOT:-tmp/e06_m0_smoke}"
RUN_ID="E06_PATCH_SMOKE_M0_mosei_p0_s1111_$(date +%Y%m%d_%H%M%S)"
mkdir -p \
  "${SMOKE_ROOT}/checkpoints" \
  "${SMOKE_ROOT}/logs" \
  "${SMOKE_ROOT}/manifests"

python3 main.py \
  --paper_experiment \
  --paper_run_id="${RUN_ID}" \
  --paper_method_id=M0 \
  --paper_stage_id=E06_PATCH_SMOKE \
  --paper_manifest_dir="${SMOKE_ROOT}/manifests" \
  --best_model_dir="${SMOKE_ROOT}/checkpoints" \
  --log_dir="${SMOKE_ROOT}/logs" \
  --dataset=mosei \
  --fixed_protocol=0 \
  --seed=1111 \
  --train_batch_size=128 \
  --dev_batch_size=128 \
  --test_batch_size=128 \
  --d_l=192 \
  --latent_dim=192 \
  --layers=3 \
  --latent_layers=2 \
  --weight_decay=1e-4 \
  --retrieval_mode=legacy \
  --retrieval_candidate_source=batch \
  --retrieval_queue_size=0 \
  --retrieval_metric_mode=raw \
  --retrieval_missing_query=center \
  --gate_mode=none \
  --consistency_mode=mixed \
  --fusion_mode=flat \
  --prompt_mode=none \
  --learning_rate=2e-5 \
  --n_epochs=1 \
  --early_stopping_patience=0

python3 - "${SMOKE_ROOT}/manifests/${RUN_ID}.json" <<'PY'
import json
import sys

with open(sys.argv[1], "r", encoding="utf-8") as stream:
    manifest = json.load(stream)
result = manifest["result"]
assert manifest["status"] == "complete"
assert manifest["method_id"] == "M0"
assert result["completed_epochs"] == 1
assert result["test_evaluation_count"] == 1
assert result["data_provenance"]["fixed_protocol"] == "0"
print("E06 corrected M0 one-epoch GPU path verified")
print("best_dev_mae:", result["best_loss"])
print("test_mae:", result["test_mae"])
PY
