set -e

FPFR_CHECKPOINT_DIR="${FPFR_CHECKPOINT_DIR:-best_modules}"
PROTOCOLS="${PROTOCOLS:-5}"
RUN_TASK_ONLY="${RUN_TASK_ONLY:-1}"
RUN_FULL="${RUN_FULL:-1}"
ADAPTER_LR="${ADAPTER_LR:-1e-3}"
SHARED_WEIGHT="${SHARED_WEIGHT:-0.05}"
ORTHOGONALITY_WEIGHT="${ORTHOGONALITY_WEIGHT:-0.01}"
SEPARATION_WEIGHT="${SEPARATION_WEIGHT:-0.01}"
SEPARATION_MARGIN="${SEPARATION_MARGIN:-1.0}"
HIDDEN_DIM="${HIDDEN_DIM:-128}"
SUBSPACE_DIM="${SUBSPACE_DIM:-64}"
MAX_SCALE="${MAX_SCALE:-1.0}"

PDRP_ARGS=(
  --retrieval_mode=missing_aware
  --retrieval_queue_size=0
  --retrieval_metric_mode=raw
  --retrieval_missing_query=center
  --gate_mode=none
  --consistency_mode=mixed
  --distill_mode=none
  --fusion_mode=flat
  --prompt_mode=none
  --reconstruction_mode=none
  --consensus_mode=none
  --tag_mode=none
  --cross_modal_retrieval_mode=none
  --training_prior_mode=none
  --hybrid_expert_mode=none
  --protocol_consistency_mode=none
  --relation_distill_mode=none
  --missing_text_contrast_mode=none
  --privileged_purification_hidden_dim="${HIDDEN_DIM}"
  --privileged_purification_subspace_dim="${SUBSPACE_DIM}"
  --privileged_purification_max_scale="${MAX_SCALE}"
  --privileged_purification_shared_weight="${SHARED_WEIGHT}"
  --privileged_purification_orthogonality_weight="${ORTHOGONALITY_WEIGHT}"
  --privileged_purification_separation_weight="${SEPARATION_WEIGHT}"
  --privileged_purification_separation_margin="${SEPARATION_MARGIN}"
  --privileged_purification_learning_rate="${ADAPTER_LR}"
  --load=1
  --n_epochs=40
  --early_stopping_patience=12
  --early_stopping_min_delta=0.0
)

echo "Improvement 18 pilot: privileged disentangled representation purification (PDRP)"
echo "Foundation: first + seventh + FPFR; every foundation parameter frozen"
echo "Checkpoint directory: ${FPFR_CHECKPOINT_DIR}"
echo "Pilot protocols: ${PROTOCOLS} (strict pilot supports protocol 5 only)"
echo "Runs: matched task-only=${RUN_TASK_ONLY}; privileged full=${RUN_FULL}"
echo "Adapter LR=${ADAPTER_LR}; shared/orth/separation=${SHARED_WEIGHT}/${ORTHOGONALITY_WEIGHT}/${SEPARATION_WEIGHT}"

run_variant() {
  local mode="$1"
  local description="$2"
  local checkpoint="${FPFR_CHECKPOINT_DIR}/iie_mosei_protocol_5_missing_aware_q0_fusion_fpfr_best.pt"
  if [ ! -s "${checkpoint}" ]; then
    echo "Missing first+seventh+FPFR protocol-5 checkpoint: ${checkpoint}" >&2
    exit 1
  fi
  echo "PDRP ${description}: protocol 5 (A+V observed; text missing)"
  python3 main.py "${PDRP_ARGS[@]}" \
    --privileged_purification_mode="${mode}" \
    --fixed_protocol=5 \
    --model_path="${checkpoint}" \
    --learning_rate=1e-4 \
    --d_l=192 \
    --latent_dim=192 \
    --train_batch_size=256 \
    --dataset=mosei
}

for protocol in ${PROTOCOLS}; do
  if [ "${protocol}" != "5" ]; then
    echo "Strict PDRP pilot supports protocol 5 only; received ${protocol}" >&2
    exit 1
  fi
done

if [ "${RUN_TASK_ONLY}" = "1" ]; then
  run_variant task_only "matched task-only control"
fi
if [ "${RUN_FULL}" = "1" ]; then
  run_variant full "full privileged disentanglement"
fi
