"""Export clean seventh-improvement checkpoints from completed head-only runs.

The historical head-only ablation instantiated the dynamic-prompt module so it
could share an exact experimental path with prompt+head. The module was bypassed
and frozen, but its unused tensors were still serialized. This one-time utility
removes only those tensors and preserves the tuned q0 + fusion_all parameters.
Original checkpoints are never overwritten.
"""

import argparse
import os
from pathlib import Path

import torch


PROMPT_PREFIX = "dynamic_prompt_adapter."


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--checkpoint_dir", default="best_modules")
    parser.add_argument(
        "--protocols",
        nargs="+",
        type=int,
        default=list(range(7)),
        choices=range(7),
    )
    parser.add_argument(
        "--overwrite",
        action="store_true",
        help="replace an existing clean export; source checkpoints are untouched",
    )
    return parser.parse_args()


def export_protocol(checkpoint_dir, protocol, overwrite=False):
    source = checkpoint_dir / (
        "iie_mosei_protocol_{}_missing_aware_q0_"
        "ablation_head_only_best.pt".format(protocol)
    )
    target = checkpoint_dir / (
        "iie_mosei_protocol_{}_missing_aware_q0_"
        "seventh_head_best.pt".format(protocol)
    )
    if not source.is_file() or source.stat().st_size == 0:
        raise FileNotFoundError("missing head-only checkpoint: {}".format(source))
    if target.exists() and not overwrite:
        raise FileExistsError(
            "clean export already exists (use --overwrite to replace it): {}".format(
                target
            )
        )

    checkpoint = torch.load(str(source), map_location="cpu")
    if not isinstance(checkpoint, dict):
        raise TypeError("checkpoint must contain a state-dict mapping: {}".format(source))

    wrapper_key = "state_dict" if "state_dict" in checkpoint else None
    state_dict = checkpoint[wrapper_key] if wrapper_key else checkpoint
    if not isinstance(state_dict, dict):
        raise TypeError("checkpoint state_dict is not a mapping: {}".format(source))

    removed = [name for name in state_dict if name.startswith(PROMPT_PREFIX)]
    clean_state = {
        name: tensor
        for name, tensor in state_dict.items()
        if not name.startswith(PROMPT_PREFIX)
    }
    if not any(name.startswith("fusion_all.") for name in clean_state):
        raise RuntimeError("fusion_all tensors are missing: {}".format(source))

    clean_checkpoint = dict(checkpoint) if wrapper_key else clean_state
    if wrapper_key:
        clean_checkpoint[wrapper_key] = clean_state

    temporary = target.with_suffix(target.suffix + ".tmp")
    torch.save(clean_checkpoint, str(temporary))
    os.replace(str(temporary), str(target))
    print(
        "protocol={} removed_prompt_tensors={} output={}".format(
            protocol, len(removed), target
        )
    )


def main():
    args = parse_args()
    checkpoint_dir = Path(args.checkpoint_dir)
    for protocol in args.protocols:
        export_protocol(checkpoint_dir, protocol, args.overwrite)


if __name__ == "__main__":
    main()
