"""Execute and audit the formal E11 paired component ablation.

Only A1 is newly trained.  A0, A2, and A3 are immutable read-only views of
the matching E06R1/E07 M0, M1, and M2 runs, respectively.
"""

from __future__ import annotations

import argparse
import json
import math
import os
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path

from paper_experiment import (
    code_fingerprints,
    resolve_dataset_path,
    sha256_file,
)
from run_e06_mosei_primary import (
    METRICS,
    PROTOCOL_SETTINGS,
    PROTOCOLS,
    SEEDS,
    write_immutable_json,
)


DATASETS = ("mosei", "mosi")
ARMS = ("A0", "A1", "A2", "A3")
NEW_ARM = "A1"
REFERENCE_METHODS = {"A0": "M0", "A2": "M1", "A3": "M2"}
EFFECTS = {
    "retrieval_logic": ("A0", "A1"),
    "strict_training_bank": ("A1", "A2"),
    "fusion_readaptation": ("A2", "A3"),
    "full_method": ("A0", "A3"),
}
SPLIT_SIZES = {
    "mosei": {"train": 16326, "dev": 1871, "test": 4659},
    "mosi": {"train": 1284, "dev": 229, "test": 686},
}
ENTRYPOINT_FILE = "main.py"
MODEL_CORE_FILES = (
    "IIE_model.py",
    "utils.py",
    "latent_transformer.py",
    "modules/missing_aware_retrieval.py",
)
# Public union used by tests and audit metadata.  E06 has an older main.py hash
# because dataset-path resolution was added before E07; E08 supplies a strict
# behavioral bridge for that entrypoint-only difference.
CORE_CODE_FILES = (ENTRYPOINT_FILE,) + MODEL_CORE_FILES
REPORT_METRICS = ("best_dev_mae",) + METRICS
LOWER_IS_BETTER = frozenset(("best_dev_mae", "test_mae"))


@dataclass(frozen=True)
class RunSpec:
    dataset: str
    protocol: str
    seed: int
    run_id: str


def build_matrix(datasets=DATASETS, protocols=PROTOCOLS, seeds=SEEDS):
    """Return the deterministic 70-run order for the new A1 arm."""
    datasets = tuple(str(value) for value in datasets)
    protocols = tuple(str(value) for value in protocols)
    seeds = tuple(int(value) for value in seeds)
    unknown_datasets = sorted(set(datasets) - set(DATASETS))
    unknown_protocols = sorted(set(protocols) - set(PROTOCOLS))
    unknown_seeds = sorted(set(seeds) - set(SEEDS))
    if unknown_datasets or unknown_protocols or unknown_seeds:
        raise ValueError(
            "Unknown E11 selection | datasets={} | protocols={} | seeds={}"
            .format(unknown_datasets, unknown_protocols, unknown_seeds)
        )
    return [
        RunSpec(
            dataset=dataset,
            protocol=protocol,
            seed=seed,
            run_id="E11_A1_{}_p{}_s{}".format(dataset, protocol, seed),
        )
        for dataset in datasets
        for seed in seeds
        for protocol in protocols
    ]


def _manifest_path(workspace, run_id):
    return (
        workspace / "paper_experiments" / "manifests"
        / "{}.json".format(run_id)
    )


def _read_manifest(path):
    with open(path, "r", encoding="utf-8") as stream:
        return json.load(stream)


def reference_run_id(dataset, arm, protocol, seed):
    """Map one reused ablation arm to its immutable formal source."""
    method = REFERENCE_METHODS[arm]
    if dataset == "mosei":
        return "E06R1_{}_mosei_p{}_s{}".format(method, protocol, seed)
    if dataset == "mosi":
        return "E07_{}_mosi_p{}_s{}".format(method, protocol, seed)
    raise ValueError("Unknown E11 dataset: {}".format(dataset))


def command_for_spec(workspace, spec):
    """Build the fully explicit missing-aware/in-batch A1 command."""
    settings = PROTOCOL_SETTINGS[spec.protocol]
    return [
        sys.executable,
        "main.py",
        "--paper_experiment",
        "--paper_run_id={}".format(spec.run_id),
        "--paper_method_id=A1",
        "--paper_stage_id=E11",
        "--paper_manifest_dir=paper_experiments/manifests",
        "--dataset={}".format(spec.dataset),
        "--fixed_protocol={}".format(spec.protocol),
        "--seed={}".format(spec.seed),
        "--train_batch_size={}".format(settings["train_batch_size"]),
        "--dev_batch_size=128",
        "--test_batch_size=128",
        "--d_l={}".format(settings["representation_dim"]),
        "--latent_dim={}".format(settings["representation_dim"]),
        "--layers={}".format(settings["layers"]),
        "--latent_layers={}".format(settings["latent_layers"]),
        "--missing_rate={}".format(settings["missing_rate"]),
        "--weight_decay=1e-4",
        "--retrieval_mode=missing_aware",
        "--retrieval_candidate_source=batch",
        "--retrieval_queue_size=0",
        "--retrieval_metric_mode=raw",
        "--retrieval_missing_query=center",
        "--retrieval_bank_batch_size=256",
        "--retrieval_bank_refresh_epochs=1",
        "--gate_mode=none",
        "--consistency_mode=mixed",
        "--distill_mode=none",
        "--fusion_mode=flat",
        "--prompt_mode=none",
        "--reconstruction_mode=none",
        "--consensus_mode=none",
        "--tag_mode=none",
        "--cross_modal_retrieval_mode=none",
        "--training_prior_mode=none",
        "--hybrid_expert_mode=none",
        "--protocol_consistency_mode=none",
        "--relation_distill_mode=none",
        "--missing_text_contrast_mode=none",
        "--privileged_purification_mode=none",
        "--language_hyper_mode=none",
        "--coupled_prompt_mode=none",
        "--early_stopping_min_delta=0.0",
        "--learning_rate=2e-5",
        "--n_epochs=100",
        "--early_stopping_patience=12",
    ]


def _validate_result(manifest, label):
    result = manifest.get("result") or {}
    if result.get("test_evaluation_count") != 1:
        raise RuntimeError("{} must evaluate test exactly once".format(label))
    if result.get("selection_split") != "development":
        raise RuntimeError("{} was not selected on development".format(label))
    if result.get("selection_metric") != "mae":
        raise RuntimeError("{} selection metric is not MAE".format(label))
    for key in ("best_loss",) + METRICS:
        value = result.get(key)
        if not isinstance(value, (int, float)) or not math.isfinite(value):
            raise RuntimeError("{} lacks finite {}".format(label, key))
    return result


def _validate_provenance(manifest, dataset, protocol, expected_dataset_sha=None):
    result = manifest.get("result") or {}
    provenance = result.get("data_provenance") or {}
    if provenance.get("split_sizes") != SPLIT_SIZES[dataset]:
        raise RuntimeError("E11 {} split sizes mismatch".format(dataset))
    if provenance.get("fixed_protocol") != str(protocol):
        raise RuntimeError("E11 fixed-protocol provenance mismatch")
    dataset_sha = provenance.get("dataset_sha256")
    if not dataset_sha:
        raise RuntimeError("E11 manifest lacks dataset SHA256")
    if expected_dataset_sha is not None and dataset_sha != expected_dataset_sha:
        raise RuntimeError("E11 dataset SHA256 mismatch")
    return dataset_sha


def _validate_new_manifest(workspace, spec, verify_checkpoint=True):
    path = _manifest_path(workspace, spec.run_id)
    if not path.is_file():
        return None
    manifest = _read_manifest(path)
    if manifest.get("status") != "complete":
        raise RuntimeError(
            "E11 run id exists with status {!r}; inspect it and do not "
            "overwrite it: {}".format(manifest.get("status"), path)
        )
    expected = {
        "run_id": spec.run_id,
        "method_id": NEW_ARM,
        "stage_id": "E11",
        "dataset": spec.dataset,
        "protocol": spec.protocol,
        "seed": spec.seed,
    }
    mismatches = {
        key: (value, manifest.get(key))
        for key, value in expected.items() if manifest.get(key) != value
    }
    if mismatches:
        raise RuntimeError("E11 A1 identity mismatch: {}".format(mismatches))
    if manifest.get("lineage") is not None:
        raise RuntimeError("E11 A1 must be an independently trained root")
    arguments = manifest.get("arguments") or {}
    required_arguments = {
        "retrieval_mode": "missing_aware",
        "retrieval_candidate_source": "batch",
        "retrieval_queue_size": 0,
        "protocol_fusion_readaptation": False,
        "load": 0,
    }
    for name, expected_value in required_arguments.items():
        if arguments.get(name) != expected_value:
            raise RuntimeError(
                "E11 A1 argument {} mismatch".format(name)
            )
    _validate_result(manifest, spec.run_id)
    _validate_provenance(manifest, spec.dataset, spec.protocol)
    outputs = manifest.get("outputs") or {}
    checkpoint = Path(outputs.get("best_model_path", ""))
    if verify_checkpoint:
        if not checkpoint.is_file():
            raise FileNotFoundError(
                "E11 A1 checkpoint is missing: {}".format(checkpoint)
            )
        if sha256_file(checkpoint) != outputs.get("best_model_sha256"):
            raise RuntimeError("E11 A1 checkpoint SHA256 mismatch")
    elif not outputs.get("best_model_sha256"):
        raise RuntimeError("E11 A1 manifest lacks checkpoint SHA256")
    return manifest


def _expected_reference_parent(dataset, arm, protocol, seed):
    if arm != "A3":
        return None
    if dataset == "mosei":
        return "E06R1_M1_mosei_p{}_s{}".format(protocol, seed)
    return "E07_M1_mosi_p{}_s{}".format(protocol, seed)


def _validate_reference_manifest(
    workspace, dataset, arm, protocol, seed, expected_dataset_sha
):
    run_id = reference_run_id(dataset, arm, protocol, seed)
    path = _manifest_path(workspace, run_id)
    if not path.is_file():
        raise FileNotFoundError("E11 reference manifest is missing: {}".format(path))
    manifest = _read_manifest(path)
    expected = {
        "status": "complete",
        "run_id": run_id,
        "method_id": REFERENCE_METHODS[arm],
        "dataset": dataset,
        "protocol": protocol,
        "seed": seed,
    }
    mismatches = {
        key: (value, manifest.get(key))
        for key, value in expected.items() if manifest.get(key) != value
    }
    if mismatches:
        raise RuntimeError("E11 reference identity mismatch: {}".format(mismatches))
    arguments = manifest.get("arguments") or {}
    expected_mode = "legacy" if arm == "A0" else "missing_aware"
    expected_source = "batch" if arm == "A0" else "train_bank"
    if arguments.get("retrieval_mode") != expected_mode:
        raise RuntimeError("E11 reference retrieval mode mismatch")
    if arguments.get("retrieval_candidate_source") != expected_source:
        raise RuntimeError("E11 reference candidate source mismatch")
    expected_adaptation = arm == "A3"
    if arguments.get("protocol_fusion_readaptation") is not expected_adaptation:
        raise RuntimeError("E11 reference adaptation scope mismatch")
    lineage = manifest.get("lineage")
    if expected_adaptation:
        expected_parent = _expected_reference_parent(
            dataset, arm, protocol, seed
        )
        if not isinstance(lineage, dict) or lineage.get(
            "parent_run_id"
        ) != expected_parent:
            raise RuntimeError("E11 A3 reference lineage mismatch")
        gate = (manifest.get("result") or {}).get("adaptation_gate") or {}
        if gate.get("test_metrics_consulted") is not False:
            raise RuntimeError("E11 A3 reference gate consulted test metrics")
    elif lineage is not None:
        raise RuntimeError("E11 root reference unexpectedly declares lineage")
    _validate_result(manifest, run_id)
    _validate_provenance(
        manifest, dataset, protocol, expected_dataset_sha=expected_dataset_sha
    )
    return manifest


def _model_core_hashes(manifest):
    fingerprints = manifest.get("code_sha256") or {}
    missing = [name for name in MODEL_CORE_FILES if name not in fingerprints]
    if missing:
        raise RuntimeError(
            "E11 manifest lacks model-core hashes: {}".format(missing)
        )
    return {name: fingerprints[name] for name in MODEL_CORE_FILES}


def _entrypoint_hash(manifest):
    fingerprints = manifest.get("code_sha256") or {}
    value = fingerprints.get(ENTRYPOINT_FILE)
    if not value:
        raise RuntimeError("E11 manifest lacks main.py hash")
    return value


def validate_e08_entrypoint_bridge(
    workspace, current_main_sha256, current_model_core_sha256
):
    """Prove that the post-E06 entrypoint reproduces E06 on protocol 3."""
    fields = (
        "selected_state_sha256",
        "best_epoch",
        "best_loss",
        "development_mae_history",
    ) + METRICS
    comparisons = 0
    for seed in SEEDS:
        for method in ("M0", "M1", "M2"):
            old_id = "E06R1_{}_mosei_p3_s{}".format(method, seed)
            new_id = "E08_{}_mosei_p3_s{}".format(method, seed)
            old_path = _manifest_path(workspace, old_id)
            new_path = _manifest_path(workspace, new_id)
            if not old_path.is_file() or not new_path.is_file():
                raise FileNotFoundError(
                    "E11 requires the E08 compatibility bridge: {} / {}"
                    .format(old_path, new_path)
                )
            old = _read_manifest(old_path)
            new = _read_manifest(new_path)
            if old.get("status") != "complete" or new.get("status") != "complete":
                raise RuntimeError("E11 E08 compatibility bridge is incomplete")
            if _entrypoint_hash(new) != current_main_sha256:
                raise RuntimeError("E11 E08 bridge does not use current main.py")
            if _model_core_hashes(old) != current_model_core_sha256:
                raise RuntimeError("E11 E06 bridge model core mismatch")
            if _model_core_hashes(new) != current_model_core_sha256:
                raise RuntimeError("E11 E08 bridge model core mismatch")
            old_result = old.get("result") or {}
            new_result = new.get("result") or {}
            mismatches = []
            for field in fields:
                left = old_result.get(field)
                right = new_result.get(field)
                if isinstance(left, (int, float)) and isinstance(
                    right, (int, float)
                ):
                    matches = math.isclose(
                        float(left), float(right), rel_tol=0.0, abs_tol=1e-12
                    )
                else:
                    matches = left == right
                if not matches:
                    mismatches.append(field)
            if method == "M2":
                old_gate = old_result.get("adaptation_gate") or {}
                new_gate = new_result.get("adaptation_gate") or {}
                for field in ("outcome", "dev_mae_gain"):
                    if old_gate.get(field) != new_gate.get(field):
                        mismatches.append("adaptation_gate.{}".format(field))
            if mismatches:
                raise RuntimeError(
                    "E11 E08 bridge mismatch for {}: {}".format(
                        old_id, mismatches
                    )
                )
            comparisons += 1
    return {
        "comparison_count": comparisons,
        "exact_replication_count": comparisons,
        "protocol": "3",
        "floating_absolute_tolerance": 1e-12,
        "purpose": "validate the post-E06 main.py entrypoint change",
    }


def _record(arm, manifest, source_stage, reused):
    result = manifest["result"]
    item = {
        "arm": arm,
        "dataset": manifest["dataset"],
        "protocol": manifest["protocol"],
        "seed": manifest["seed"],
        "source_stage": source_stage,
        "source_run_id": manifest["run_id"],
        "reused_reference": bool(reused),
        "best_epoch": result["best_epoch"],
        "best_dev_mae": result["best_loss"],
    }
    item.update({metric: result[metric] for metric in METRICS})
    if arm == "A3":
        gate = result["adaptation_gate"]
        item["adaptation_outcome"] = gate["outcome"]
        item["development_mae_gain"] = gate["dev_mae_gain"]
    return item


def _gain(metric, baseline, candidate):
    if metric in LOWER_IS_BETTER:
        return float(baseline) - float(candidate)
    return float(candidate) - float(baseline)


def summarize_effects(records):
    """Return paired, direction-normalized descriptive component gains."""
    indexed = {
        (item["dataset"], item["protocol"], item["seed"], item["arm"]): item
        for item in records
    }
    output = {}
    for effect, (baseline_arm, candidate_arm) in EFFECTS.items():
        pairs = []
        for dataset in DATASETS:
            for protocol in PROTOCOLS:
                for seed in SEEDS:
                    baseline = indexed.get((dataset, protocol, seed, baseline_arm))
                    candidate = indexed.get((dataset, protocol, seed, candidate_arm))
                    if baseline is None or candidate is None:
                        continue
                    gains = {
                        metric: _gain(metric, baseline[metric], candidate[metric])
                        for metric in REPORT_METRICS
                    }
                    pairs.append({
                        "dataset": dataset,
                        "protocol": protocol,
                        "seed": seed,
                        "baseline_arm": baseline_arm,
                        "candidate_arm": candidate_arm,
                        "gains": gains,
                    })
        groups = {}
        for dataset in ("all",) + DATASETS:
            selected = [
                pair for pair in pairs
                if dataset == "all" or pair["dataset"] == dataset
            ]
            metric_summary = {}
            for metric in REPORT_METRICS:
                values = [pair["gains"][metric] for pair in selected]
                tolerance = 1e-12
                metric_summary[metric] = {
                    "count": len(values),
                    "mean_gain": sum(values) / len(values) if values else None,
                    "wins": sum(value > tolerance for value in values),
                    "ties": sum(abs(value) <= tolerance for value in values),
                    "losses": sum(value < -tolerance for value in values),
                }
            groups[dataset] = metric_summary
        output[effect] = {
            "baseline_arm": baseline_arm,
            "candidate_arm": candidate_arm,
            "gain_definition": "positive_always_favors_candidate",
            "summary": groups,
            "pairs": pairs,
        }
    return output


def audit_matrix(
    workspace, specs, require_complete=True, require_entrypoint_bridge=True
):
    """Audit the 70 new runs and the 210 immutable reference records."""
    records = []
    missing_new = []
    missing_reference = []
    new_code_sha256 = None
    new_main_sha256 = None
    canonical_core_sha256 = None
    e06_main_hashes = set()
    dataset_sha256 = {}

    for spec in specs:
        manifest = _validate_new_manifest(workspace, spec)
        if manifest is None:
            missing_new.append(spec.run_id)
            continue
        current_code = manifest.get("code_sha256")
        if new_code_sha256 is None:
            new_code_sha256 = current_code
        elif new_code_sha256 != current_code:
            raise RuntimeError("E11 A1 runs mix different code fingerprints")
        current_core = _model_core_hashes(manifest)
        current_main = _entrypoint_hash(manifest)
        if new_main_sha256 is None:
            new_main_sha256 = current_main
        elif new_main_sha256 != current_main:
            raise RuntimeError("E11 A1 runs mix different main.py hashes")
        if canonical_core_sha256 is None:
            canonical_core_sha256 = current_core
        elif canonical_core_sha256 != current_core:
            raise RuntimeError("E11 A1 runs mix different training-core hashes")
        current_dataset_sha = _validate_provenance(
            manifest, spec.dataset, spec.protocol
        )
        previous = dataset_sha256.setdefault(spec.dataset, current_dataset_sha)
        if previous != current_dataset_sha:
            raise RuntimeError("E11 A1 runs mix different dataset files")
        records.append(_record(NEW_ARM, manifest, "E11", reused=False))

        for arm in ("A0", "A2", "A3"):
            run_id = reference_run_id(
                spec.dataset, arm, spec.protocol, spec.seed
            )
            try:
                reference = _validate_reference_manifest(
                    workspace,
                    spec.dataset,
                    arm,
                    spec.protocol,
                    spec.seed,
                    current_dataset_sha,
                )
            except FileNotFoundError:
                missing_reference.append(run_id)
                continue
            if _model_core_hashes(reference) != canonical_core_sha256:
                raise RuntimeError(
                    "E11 reference {} uses a different model core".format(run_id)
                )
            reference_main = _entrypoint_hash(reference)
            if spec.dataset == "mosi" and reference_main != new_main_sha256:
                raise RuntimeError(
                    "E11 MOSI reference {} uses a different main.py"
                    .format(run_id)
                )
            if spec.dataset == "mosei":
                e06_main_hashes.add(reference_main)
            records.append(_record(
                arm, reference, reference.get("stage_id"), reused=True
            ))

    if require_complete and (missing_new or missing_reference):
        raise RuntimeError(
            "Incomplete E11 ablation | missing_new={} first_new={} | "
            "missing_reference={} first_reference={}".format(
                len(missing_new), missing_new[:5],
                len(missing_reference), missing_reference[:5],
            )
        )
    records.sort(key=lambda item: (
        DATASETS.index(item["dataset"]),
        SEEDS.index(int(item["seed"])),
        PROTOCOLS.index(str(item["protocol"])),
        ARMS.index(item["arm"]),
    ))
    entrypoint_bridge = None
    if require_entrypoint_bridge and any(
        spec.dataset == "mosei" for spec in specs
    ):
        if len(e06_main_hashes) != 1:
            raise RuntimeError("E11 E06 references mix main.py fingerprints")
        entrypoint_bridge = validate_e08_entrypoint_bridge(
            workspace,
            new_main_sha256,
            canonical_core_sha256,
        )
    return {
        "schema_version": 1,
        "stage_id": "E11",
        "purpose": "paired component ablation",
        "datasets": list(DATASETS),
        "protocols": list(PROTOCOLS),
        "seeds": list(SEEDS),
        "arms": list(ARMS),
        "expected_new_run_count": len(specs),
        "completed_new_run_count": len(specs) - len(missing_new),
        "expected_reused_reference_count": len(specs) * 3,
        "completed_reused_reference_count": len(specs) * 3 - len(missing_reference),
        "expected_total_ablation_cells": len(specs) * 4,
        "completed_total_ablation_cells": len(records),
        "missing_new_run_ids": missing_new,
        "missing_reference_run_ids": missing_reference,
        "dataset_sha256": dataset_sha256,
        "new_run_code_sha256": new_code_sha256,
        "model_core_sha256": canonical_core_sha256,
        "new_main_sha256": new_main_sha256,
        "e06_main_sha256": next(iter(e06_main_hashes), None),
        "entrypoint_compatibility_bridge": entrypoint_bridge,
        "test_evaluation_count_per_run": 1,
        "selection_split": "development",
        "selection_metric": "mae",
        "test_metrics_consulted_for_training_or_selection": False,
        "effect_gain_direction": "positive_always_favors_candidate",
        "effects": summarize_effects(records),
        "records": records,
    }


def preflight_references(workspace, specs):
    """Fail before training if any reused record is absent or incompatible."""
    current_model_core = {
        name: sha256_file(workspace / name) for name in MODEL_CORE_FILES
    }
    current_main = sha256_file(workspace / ENTRYPOINT_FILE)
    dataset_sha256 = {
        dataset: sha256_file(resolve_dataset_path(workspace, dataset))
        for dataset in {spec.dataset for spec in specs}
    }
    checked = set()
    e06_main_hashes = set()
    for spec in specs:
        for arm in ("A0", "A2", "A3"):
            run_id = reference_run_id(
                spec.dataset, arm, spec.protocol, spec.seed
            )
            if run_id in checked:
                continue
            reference = _validate_reference_manifest(
                workspace,
                spec.dataset,
                arm,
                spec.protocol,
                spec.seed,
                dataset_sha256[spec.dataset],
            )
            if _model_core_hashes(reference) != current_model_core:
                raise RuntimeError(
                    "E11 reference {} does not match the current model "
                    "core; do not start the matrix".format(run_id)
                )
            reference_main = _entrypoint_hash(reference)
            if spec.dataset == "mosi" and reference_main != current_main:
                raise RuntimeError(
                    "E11 MOSI reference {} does not use current main.py"
                    .format(run_id)
                )
            if spec.dataset == "mosei":
                e06_main_hashes.add(reference_main)
            checked.add(run_id)
    bridge = None
    if any(spec.dataset == "mosei" for spec in specs):
        if len(e06_main_hashes) != 1:
            raise RuntimeError("E11 E06 references mix main.py fingerprints")
        bridge = validate_e08_entrypoint_bridge(
            workspace, current_main, current_model_core
        )
    print("E11 reference preflight verified | records={}".format(len(checked)))
    return {
        "reference_count": len(checked),
        "dataset_sha256": dataset_sha256,
        "model_core_sha256": current_model_core,
        "current_main_sha256": current_main,
        "e06_main_sha256": next(iter(e06_main_hashes), None),
        "entrypoint_compatibility_bridge": bridge,
    }


def execute_matrix(workspace, specs):
    """Resume missing A1 roots while preserving immutable completed runs."""
    preflight_references(workspace, specs)
    completed_manifests = []
    for spec in specs:
        manifest = _validate_new_manifest(workspace, spec)
        if manifest is not None:
            completed_manifests.append(manifest)
    if completed_manifests:
        expected_code = code_fingerprints(workspace)
        for manifest in completed_manifests:
            if manifest.get("code_sha256") != expected_code:
                raise RuntimeError(
                    "E11 resume refused because the code fingerprint changed"
                )
        for dataset in {item["dataset"] for item in completed_manifests}:
            expected_sha = sha256_file(resolve_dataset_path(workspace, dataset))
            for manifest in completed_manifests:
                if manifest["dataset"] != dataset:
                    continue
                actual = manifest["result"]["data_provenance"]["dataset_sha256"]
                if actual != expected_sha:
                    raise RuntimeError(
                        "E11 resume refused because {} changed".format(dataset)
                    )

    environment = os.environ.copy()
    environment["CUBLAS_WORKSPACE_CONFIG"] = ":4096:8"
    completed = 0
    skipped = 0
    for index, spec in enumerate(specs, start=1):
        manifest = _validate_new_manifest(workspace, spec)
        if manifest is not None:
            skipped += 1
            print("[{}/{}] SKIP complete {}".format(
                index, len(specs), spec.run_id
            ), flush=True)
            continue
        print("[{}/{}] RUN {}".format(
            index, len(specs), spec.run_id
        ), flush=True)
        subprocess.check_call(
            command_for_spec(workspace, spec),
            cwd=str(workspace),
            env=environment,
        )
        _validate_new_manifest(workspace, spec)
        subprocess.check_call(
            [sys.executable, "refresh_paper_registry.py", "--workspace", "."],
            cwd=str(workspace),
            env=environment,
        )
        completed += 1
    print("E11 execution finished | new={} | skipped={}".format(
        completed, skipped
    ))


def _csv_values(value, cast):
    return tuple(cast(item.strip()) for item in value.split(",") if item.strip())


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--workspace", type=Path, default=Path("."))
    parser.add_argument("--datasets", default=",".join(DATASETS))
    parser.add_argument("--protocols", default=",".join(PROTOCOLS))
    parser.add_argument("--seeds", default=",".join(str(seed) for seed in SEEDS))
    parser.add_argument("--execute", action="store_true")
    parser.add_argument("--audit", action="store_true")
    parser.add_argument(
        "--audit_output",
        type=Path,
        default=Path("paper_results/E11_component_ablation_audit.json"),
    )
    return parser.parse_args()


def main():
    args = parse_args()
    workspace = args.workspace.resolve()
    specs = build_matrix(
        _csv_values(args.datasets, str),
        _csv_values(args.protocols, str),
        _csv_values(args.seeds, int),
    )
    if not args.execute and not args.audit:
        print(
            "E11 dry-run plan | new_A1_runs={} | reused_reference_records={} | "
            "total_ablation_cells={}".format(
                len(specs), len(specs) * 3, len(specs) * 4
            )
        )
        for spec in specs:
            references = [
                reference_run_id(
                    spec.dataset, arm, spec.protocol, spec.seed
                ) for arm in ("A0", "A2", "A3")
            ]
            print("{} | references={} | {}".format(
                spec.run_id, ",".join(references),
                " ".join(command_for_spec(workspace, spec)),
            ))
        return
    if args.execute:
        if os.environ.get("E11_EXECUTE") != "1":
            raise RuntimeError(
                "Set E11_EXECUTE=1 to authorize the formal 70-run A1 matrix"
            )
        execute_matrix(workspace, specs)
    if args.audit:
        summary = audit_matrix(workspace, specs, require_complete=True)
        output = args.audit_output
        if not output.is_absolute():
            output = workspace / output
        write_immutable_json(output, summary)
        print("E11 audit verified: {}".format(output))


if __name__ == "__main__":
    main()
