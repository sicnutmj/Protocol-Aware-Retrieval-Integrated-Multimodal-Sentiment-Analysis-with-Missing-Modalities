set -e

# Key ablation for improvement 15: keep the same fixed-protocol fusion-head
# re-adaptation path while removing the PCMC term from the optimization loss.
# The teacher pass remains enabled for matched diagnostics and restores RNG
# state before the student pass, so it cannot change the student's dropout.
export CONSISTENCY_WEIGHT=0

echo "Improvement 15 key ablation: fusion-head re-adaptation without PCMC loss"
bash run_protocol_missing_consistency.sh
