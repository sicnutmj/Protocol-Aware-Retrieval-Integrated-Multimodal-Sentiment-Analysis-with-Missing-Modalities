set -e

Q0_CHECKPOINT_DIR="${Q0_CHECKPOINT_DIR:-best_modules}"
REBUILD_Q0_IF_MISSING="${REBUILD_Q0_IF_MISSING:-0}"
PROTOCOLS="${PROTOCOLS:-0 1 2 3 4 5 6}"
RUN_HEAD_ONLY="${RUN_HEAD_ONLY:-1}"
# Frozen failed branch. Set to 1 only when reproducing the completed ablation.
RUN_PROMPT_HEAD="${RUN_PROMPT_HEAD:-0}"
Q0_ARGS=(
  --retrieval_mode=missing_aware
  --retrieval_queue_size=0
  --retrieval_metric_mode=raw
  --retrieval_missing_query=center
  --gate_mode=none
  --consistency_mode=mixed
  --distill_mode=none
  --fusion_mode=flat
  --prompt_mode=none
  --n_epochs=100
  --early_stopping_patience=0
)
FINETUNE_ARGS=(
  --retrieval_mode=missing_aware
  --retrieval_queue_size=0
  --retrieval_metric_mode=raw
  --retrieval_missing_query=center
  --gate_mode=none
  --consistency_mode=mixed
  --distill_mode=none
  --fusion_mode=flat
  --prompt_mode=missing_dynamic
  --prompt_hidden_dim=32
  --prompt_modality_embedding_dim=8
  --prompt_max_scale=1.0
  --prompt_init_std=0.02
  --prompt_learning_rate=1e-3
  --load=1
  --n_epochs=40
  --early_stopping_patience=12
  --early_stopping_min_delta=0.0
)
echo "Frozen seventh improvement: q0 backbone + fusion-head-only adaptation"
echo "Frozen q0 checkpoint directory: ${Q0_CHECKPOINT_DIR}"
echo "Rebuild missing q0 checkpoints: ${REBUILD_Q0_IF_MISSING}"
echo "Protocols: ${PROTOCOLS}"
echo "Runs: q0(epoch 0 baseline), head_only=${RUN_HEAD_ONLY}, frozen_prompt_ablation=${RUN_PROMPT_HEAD}"

run_protocol() {
  local protocol="$1"
  local train_batch_size="$2"
  local representation_dim="$3"
  local description="$4"
  shift 4

  local checkpoint="${Q0_CHECKPOINT_DIR}/iie_mosei_protocol_${protocol}_missing_aware_q0_best.pt"
  if [ ! -s "${checkpoint}" ]; then
    if [ "${REBUILD_Q0_IF_MISSING}" != "1" ]; then
      echo "Missing q0 checkpoint and automatic rebuild is disabled: ${checkpoint}" >&2
      exit 1
    fi

    echo "q0 checkpoint missing; rebuilding protocol ${protocol} (${description})"
    python3 main.py "${Q0_ARGS[@]}" \
      --fixed_protocol="${protocol}" \
      --learning_rate=2e-5 \
      --d_l="${representation_dim}" \
      --latent_dim="${representation_dim}" \
      --train_batch_size="${train_batch_size}" \
      --best_model_dir="${Q0_CHECKPOINT_DIR}" \
      --dataset=mosei \
      "$@"

    if [ ! -s "${checkpoint}" ]; then
      echo "q0 rebuild completed without producing the expected checkpoint: ${checkpoint}" >&2
      exit 1
    fi
    echo "q0 checkpoint rebuilt: ${checkpoint}"
  fi

  if [ "${RUN_HEAD_ONLY}" = "1" ]; then
    echo "head-only ablation: protocol ${protocol} (${description})"
    python3 main.py "${FINETUNE_ARGS[@]}" \
      --prompt_finetune_scope=head_only \
      --fixed_protocol="${protocol}" \
      --model_path="${checkpoint}" \
      --learning_rate=1e-4 \
      --d_l="${representation_dim}" \
      --latent_dim="${representation_dim}" \
      --train_batch_size="${train_batch_size}" \
      --dataset=mosei \
      "$@"
  fi

  if [ "${RUN_PROMPT_HEAD}" = "1" ]; then
    echo "dynamic-prompt + head ablation: protocol ${protocol} (${description})"
    python3 main.py "${FINETUNE_ARGS[@]}" \
      --prompt_finetune_scope=prompt_head \
      --fixed_protocol="${protocol}" \
      --model_path="${checkpoint}" \
      --learning_rate=1e-4 \
      --d_l="${representation_dim}" \
      --latent_dim="${representation_dim}" \
      --train_batch_size="${train_batch_size}" \
      --dataset=mosei \
      "$@"
  fi
}

# Preserve the protocol-specific q0 architecture and training-mask settings.
for protocol in ${PROTOCOLS}; do
  case "${protocol}" in
    0) run_protocol 0 128 192 "L observed" ;;
    1) run_protocol 1 128 192 "A observed" \
         --missing_rate=0.05 \
         --layers=2 \
         --latent_layers=3 ;;
    2) run_protocol 2 256 192 "V observed" ;;
    3) run_protocol 3 256 96  "L+A observed" ;;
    4) run_protocol 4 256 96  "L+V observed" ;;
    5) run_protocol 5 256 192 "A+V observed" ;;
    6) run_protocol 6 128 192 "L+A+V observed" ;;
    *)
      echo "Unknown protocol: ${protocol}; expected values from 0 to 6" >&2
      exit 1
      ;;
  esac
done
