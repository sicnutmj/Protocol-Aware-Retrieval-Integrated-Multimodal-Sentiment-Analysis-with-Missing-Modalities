"""Rebuild the formal experiment registry from immutable run manifests."""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

from prepare_paper_experiments import REGISTRY_FIELDS


def result_value(result, key):
    return "" if not isinstance(result, dict) else result.get(key, "")


def rebuild_registry(workspace: Path) -> Path:
    workspace = workspace.resolve()
    manifest_dir = workspace / "paper_experiments" / "manifests"
    registry_path = workspace / "paper_experiments" / "registry.csv"
    rows = []
    for manifest_path in sorted(manifest_dir.glob("*.json")):
        with open(manifest_path, "r", encoding="utf-8") as stream:
            manifest = json.load(stream)
        result = manifest.get("result") or {}
        outputs = manifest.get("outputs") or {}
        row = {
            "run_id": manifest.get("run_id", ""),
            "method_id": manifest.get("method_id", ""),
            "stage_id": manifest.get("stage_id", ""),
            "dataset": manifest.get("dataset", ""),
            "protocol": manifest.get("protocol", ""),
            "seed": manifest.get("seed", ""),
            "status": manifest.get("status", ""),
            "best_epoch": result_value(result, "best_epoch"),
            "best_dev_mae": result_value(result, "best_loss"),
            "test_mae": result_value(result, "test_mae"),
            "test_corr": result_value(result, "test_corr"),
            "test_acc2": result_value(result, "test_acc2"),
            "test_f1": result_value(result, "test_f1"),
            "checkpoint_path": outputs.get("best_model_path", ""),
            "checkpoint_sha256": outputs.get("best_model_sha256", ""),
            "manifest_path": str(manifest_path),
            "notes": "",
        }
        rows.append(row)

    temporary_path = registry_path.with_suffix(".csv.tmp")
    with open(temporary_path, "w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=REGISTRY_FIELDS)
        writer.writeheader()
        writer.writerows(rows)
    temporary_path.replace(registry_path)
    print("Wrote {} rows to {}".format(len(rows), registry_path))
    return registry_path


def parse_args():
    parser = argparse.ArgumentParser(
        description="Rebuild paper_experiments/registry.csv from manifests"
    )
    parser.add_argument("--workspace", type=Path, default=Path("."))
    return parser.parse_args()


if __name__ == "__main__":
    options = parse_args()
    rebuild_registry(options.workspace)

