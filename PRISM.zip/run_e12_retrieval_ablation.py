"""Execute and audit the formal E12 retrieval-mechanism ablation."""

from __future__ import annotations

import argparse
import json
import math
import os
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path

from paper_experiment import code_fingerprints, resolve_dataset_path, sha256_file
from run_e06_mosei_primary import (
    METRICS,
    PROTOCOL_SETTINGS,
    write_immutable_json,
)


DATASET = "mosei"
PROTOCOLS = ("0", "3", "5", "6")
SEEDS = (1111, 3407, 7777)
ARMS = ("B0", "B1", "B2", "B3", "B4", "B5")
NEW_ARM_SETTINGS = {
    "B0": {
        "method": "E12U", "candidate_source": "batch",
        "candidate_filter": "all", "composition": "prototype_neighbours",
        "selection": "similarity",
    },
    "B2": {
        "method": "E12P", "candidate_source": "train_bank",
        "candidate_filter": "observed_only", "composition": "prototype_only",
        "selection": "similarity",
    },
    "B3": {
        "method": "E12N", "candidate_source": "train_bank",
        "candidate_filter": "observed_only", "composition": "neighbours_only",
        "selection": "similarity",
    },
    "B5": {
        "method": "E12R", "candidate_source": "train_bank",
        "candidate_filter": "observed_only", "composition": "prototype_neighbours",
        "selection": "random",
    },
}
REFERENCE_METHODS = {"B1": "A1", "B4": "M1"}
EFFECTS = {
    "missing_candidate_exclusion": ("B0", "B1"),
    "strict_training_bank": ("B1", "B4"),
    "prototype_contribution": ("B3", "B4"),
    "neighbour_contribution": ("B2", "B4"),
    "similarity_over_random": ("B5", "B4"),
}
SPLIT_SIZES = {"train": 16326, "dev": 1871, "test": 4659}
REPORT_METRICS = ("best_dev_mae",) + METRICS
LOWER_IS_BETTER = frozenset(("best_dev_mae", "test_mae"))
OLD_MODEL_CORE_FILES = (
    "IIE_model.py", "utils.py", "latent_transformer.py",
    "modules/missing_aware_retrieval.py",
)
UNCHANGED_CORE_FILES = ("utils.py", "latent_transformer.py")


@dataclass(frozen=True)
class RunSpec:
    arm: str
    method: str
    protocol: str
    seed: int
    run_id: str


def build_matrix(protocols=PROTOCOLS, seeds=SEEDS, arms=tuple(NEW_ARM_SETTINGS)):
    protocols = tuple(str(value) for value in protocols)
    seeds = tuple(int(value) for value in seeds)
    arms = tuple(arms)
    unknown_protocols = sorted(set(protocols) - set(PROTOCOLS))
    unknown_seeds = sorted(set(seeds) - set(SEEDS))
    unknown_arms = sorted(set(arms) - set(NEW_ARM_SETTINGS))
    if unknown_protocols or unknown_seeds or unknown_arms:
        raise ValueError(
            "Unknown E12 selection | protocols={} | seeds={} | arms={}"
            .format(unknown_protocols, unknown_seeds, unknown_arms)
        )
    ordered_arms = tuple(arm for arm in NEW_ARM_SETTINGS if arm in arms)
    return [
        RunSpec(
            arm=arm,
            method=NEW_ARM_SETTINGS[arm]["method"],
            protocol=protocol,
            seed=seed,
            run_id="E12_{}_mosei_p{}_s{}".format(
                NEW_ARM_SETTINGS[arm]["method"], protocol, seed
            ),
        )
        for seed in seeds for protocol in protocols for arm in ordered_arms
    ]


def _manifest_path(workspace, run_id):
    return workspace / "paper_experiments" / "manifests" / (run_id + ".json")


def _read_json(path):
    with open(path, "r", encoding="utf-8") as stream:
        return json.load(stream)


def reference_run_id(arm, protocol, seed):
    if arm == "B1":
        return "E11_A1_mosei_p{}_s{}".format(protocol, seed)
    if arm == "B4":
        return "E06R1_M1_mosei_p{}_s{}".format(protocol, seed)
    raise ValueError("E12 arm {} is not reused".format(arm))


def command_for_spec(workspace, spec):
    settings = PROTOCOL_SETTINGS[spec.protocol]
    arm = NEW_ARM_SETTINGS[spec.arm]
    return [
        sys.executable, "main.py", "--paper_experiment",
        "--paper_run_id={}".format(spec.run_id),
        "--paper_method_id={}".format(spec.method),
        "--paper_stage_id=E12",
        "--paper_manifest_dir=paper_experiments/manifests",
        "--dataset=mosei", "--fixed_protocol={}".format(spec.protocol),
        "--seed={}".format(spec.seed),
        "--train_batch_size={}".format(settings["train_batch_size"]),
        "--dev_batch_size=128", "--test_batch_size=128",
        "--d_l={}".format(settings["representation_dim"]),
        "--latent_dim={}".format(settings["representation_dim"]),
        "--layers={}".format(settings["layers"]),
        "--latent_layers={}".format(settings["latent_layers"]),
        "--missing_rate={}".format(settings["missing_rate"]),
        "--weight_decay=1e-4", "--retrieval_mode=missing_aware",
        "--retrieval_candidate_source={}".format(arm["candidate_source"]),
        "--retrieval_candidate_filter={}".format(arm["candidate_filter"]),
        "--retrieval_composition={}".format(arm["composition"]),
        "--retrieval_selection={}".format(arm["selection"]),
        "--retrieval_random_seed={}".format(
            spec.seed if spec.arm == "B5" else 3407
        ),
        "--retrieval_top_k=2", "--retrieval_queue_size=0",
        "--retrieval_metric_mode=raw", "--retrieval_missing_query=center",
        "--retrieval_bank_batch_size=256",
        "--retrieval_bank_refresh_epochs=1", "--gate_mode=none",
        "--consistency_mode=mixed", "--distill_mode=none",
        "--fusion_mode=flat", "--prompt_mode=none",
        "--reconstruction_mode=none", "--consensus_mode=none",
        "--tag_mode=none", "--cross_modal_retrieval_mode=none",
        "--training_prior_mode=none", "--hybrid_expert_mode=none",
        "--protocol_consistency_mode=none", "--relation_distill_mode=none",
        "--missing_text_contrast_mode=none",
        "--privileged_purification_mode=none", "--language_hyper_mode=none",
        "--coupled_prompt_mode=none", "--early_stopping_min_delta=0.0",
        "--learning_rate=2e-5", "--n_epochs=100",
        "--early_stopping_patience=12",
    ]


def _validate_result(manifest, label):
    result = manifest.get("result") or {}
    if result.get("test_evaluation_count") != 1:
        raise RuntimeError("{} must evaluate test exactly once".format(label))
    if result.get("selection_split") != "development":
        raise RuntimeError("{} was not selected on development".format(label))
    if result.get("selection_metric") != "mae":
        raise RuntimeError("{} selection metric is not MAE".format(label))
    for key in ("best_loss",) + METRICS:
        value = result.get(key)
        if not isinstance(value, (int, float)) or not math.isfinite(value):
            raise RuntimeError("{} lacks finite {}".format(label, key))
    provenance = result.get("data_provenance") or {}
    if provenance.get("split_sizes") != SPLIT_SIZES:
        raise RuntimeError("{} has wrong MOSEI split sizes".format(label))
    if provenance.get("fixed_protocol") != str(manifest.get("protocol")):
        raise RuntimeError("{} has wrong fixed-protocol provenance".format(label))
    if not provenance.get("dataset_sha256"):
        raise RuntimeError("{} lacks dataset SHA256".format(label))
    return result


def _expected_arguments(spec):
    arm = NEW_ARM_SETTINGS[spec.arm]
    return {
        "retrieval_mode": "missing_aware",
        "retrieval_candidate_source": arm["candidate_source"],
        "retrieval_candidate_filter": arm["candidate_filter"],
        "retrieval_composition": arm["composition"],
        "retrieval_selection": arm["selection"],
        "retrieval_random_seed": spec.seed if spec.arm == "B5" else 3407,
        "retrieval_queue_size": 0,
        "protocol_fusion_readaptation": False,
        "load": 0,
    }


def _validate_new_manifest(workspace, spec, verify_checkpoint=True):
    path = _manifest_path(workspace, spec.run_id)
    if not path.is_file():
        return None
    manifest = _read_json(path)
    if manifest.get("status") != "complete":
        raise RuntimeError(
            "E12 run id exists with status {!r}; inspect it and do not "
            "overwrite it: {}".format(manifest.get("status"), path)
        )
    expected = {
        "run_id": spec.run_id, "method_id": spec.method, "stage_id": "E12",
        "dataset": DATASET, "protocol": spec.protocol, "seed": spec.seed,
    }
    mismatches = {
        key: (value, manifest.get(key)) for key, value in expected.items()
        if manifest.get(key) != value
    }
    if mismatches:
        raise RuntimeError("E12 new-run identity mismatch: {}".format(mismatches))
    if manifest.get("lineage") is not None:
        raise RuntimeError("E12 ablation arms must be independent roots")
    arguments = manifest.get("arguments") or {}
    for name, expected_value in _expected_arguments(spec).items():
        if arguments.get(name) != expected_value:
            raise RuntimeError("E12 {} argument mismatch".format(name))
    _validate_result(manifest, spec.run_id)
    outputs = manifest.get("outputs") or {}
    checkpoint = Path(outputs.get("best_model_path", ""))
    if verify_checkpoint:
        if not checkpoint.is_file():
            raise FileNotFoundError("E12 checkpoint is missing: {}".format(checkpoint))
        if sha256_file(checkpoint) != outputs.get("best_model_sha256"):
            raise RuntimeError("E12 checkpoint SHA256 mismatch")
    elif not outputs.get("best_model_sha256"):
        raise RuntimeError("E12 manifest lacks checkpoint SHA256")
    return manifest


def _reference_defaults(arguments, name, default):
    """Older frozen manifests predate E12 flags, whose defaults are exact."""
    return arguments[name] if name in arguments else default


def _validate_reference_manifest(workspace, arm, protocol, seed, dataset_sha):
    run_id = reference_run_id(arm, protocol, seed)
    path = _manifest_path(workspace, run_id)
    if not path.is_file():
        raise FileNotFoundError("E12 reference manifest is missing: {}".format(path))
    manifest = _read_json(path)
    expected = {
        "status": "complete", "run_id": run_id,
        "method_id": REFERENCE_METHODS[arm], "dataset": DATASET,
        "protocol": protocol, "seed": seed,
    }
    mismatches = {
        key: (value, manifest.get(key)) for key, value in expected.items()
        if manifest.get(key) != value
    }
    if mismatches:
        raise RuntimeError("E12 reference identity mismatch: {}".format(mismatches))
    if manifest.get("lineage") is not None:
        raise RuntimeError("E12 reference root unexpectedly declares lineage")
    args = manifest.get("arguments") or {}
    expected_source = "batch" if arm == "B1" else "train_bank"
    if args.get("retrieval_mode") != "missing_aware":
        raise RuntimeError("E12 reference is not missing-aware")
    if args.get("retrieval_candidate_source") != expected_source:
        raise RuntimeError("E12 reference candidate source mismatch")
    defaults = {
        "retrieval_candidate_filter": "observed_only",
        "retrieval_composition": "prototype_neighbours",
        "retrieval_selection": "similarity",
    }
    for name, expected_value in defaults.items():
        if _reference_defaults(args, name, expected_value) != expected_value:
            raise RuntimeError("E12 reference {} mismatch".format(name))
    result = _validate_result(manifest, run_id)
    if result["data_provenance"]["dataset_sha256"] != dataset_sha:
        raise RuntimeError("E12 reference dataset SHA256 mismatch")
    return manifest


def _manifest_hashes(manifest, names):
    fingerprints = manifest.get("code_sha256") or {}
    missing = [name for name in names if name not in fingerprints]
    if missing:
        raise RuntimeError("E12 manifest lacks code hashes: {}".format(missing))
    return {name: fingerprints[name] for name in names}


def validate_frozen_reference_audit(workspace, dataset_sha):
    path = workspace / "paper_results" / "E11_component_ablation_audit.json"
    if not path.is_file():
        raise FileNotFoundError("E12 requires the frozen E11 audit: {}".format(path))
    audit = _read_json(path)
    expected = {
        "stage_id": "E11", "completed_new_run_count": 70,
        "completed_reused_reference_count": 210,
        "completed_total_ablation_cells": 280,
        "test_metrics_consulted_for_training_or_selection": False,
    }
    mismatches = {
        key: (value, audit.get(key)) for key, value in expected.items()
        if audit.get(key) != value
    }
    if mismatches:
        raise RuntimeError("E12 frozen E11 audit mismatch: {}".format(mismatches))
    bridge = audit.get("entrypoint_compatibility_bridge") or {}
    if bridge.get("comparison_count") != 15 or bridge.get(
        "exact_replication_count"
    ) != 15:
        raise RuntimeError("E12 E06 entrypoint bridge is not exact 15/15")
    if (audit.get("dataset_sha256") or {}).get("mosei") != dataset_sha:
        raise RuntimeError("E12 frozen E11 audit uses another MOSEI file")
    return {
        "path": str(path.resolve()), "sha256": sha256_file(path),
        "entrypoint_exact_replications": 15,
    }


def preflight_references(workspace, protocols, seeds):
    dataset_path = resolve_dataset_path(workspace, DATASET)
    dataset_sha = sha256_file(dataset_path)
    audit_record = validate_frozen_reference_audit(workspace, dataset_sha)
    old_core = None
    checked = []
    current_unchanged = {
        name: sha256_file(workspace / name) for name in UNCHANGED_CORE_FILES
    }
    for seed in seeds:
        for protocol in protocols:
            for arm in ("B1", "B4"):
                manifest = _validate_reference_manifest(
                    workspace, arm, protocol, seed, dataset_sha
                )
                hashes = _manifest_hashes(manifest, OLD_MODEL_CORE_FILES)
                if old_core is None:
                    old_core = hashes
                elif old_core != hashes:
                    raise RuntimeError("E12 references mix old model-core hashes")
                for name in UNCHANGED_CORE_FILES:
                    if hashes[name] != current_unchanged[name]:
                        raise RuntimeError(
                            "E12 unchanged core {} drifted".format(name)
                        )
                checked.append(manifest["run_id"])
    print("E12 reference preflight verified | records={}".format(len(checked)))
    return {
        "reference_count": len(checked), "dataset_sha256": dataset_sha,
        "old_model_core_sha256": old_core,
        "current_unchanged_core_sha256": current_unchanged,
        "frozen_E11_audit": audit_record,
    }


def _record(arm, manifest, reused):
    result = manifest["result"]
    item = {
        "arm": arm, "protocol": manifest["protocol"], "seed": manifest["seed"],
        "source_stage": manifest["stage_id"], "source_run_id": manifest["run_id"],
        "reused_reference": bool(reused), "best_epoch": result["best_epoch"],
        "best_dev_mae": result["best_loss"],
    }
    item.update({metric: result[metric] for metric in METRICS})
    return item


def _gain(metric, baseline, candidate):
    return (
        float(baseline) - float(candidate)
        if metric in LOWER_IS_BETTER
        else float(candidate) - float(baseline)
    )


def summarize_effects(records, protocols, seeds):
    indexed = {
        (item["protocol"], item["seed"], item["arm"]): item
        for item in records
    }
    output = {}
    for effect, (baseline_arm, candidate_arm) in EFFECTS.items():
        pairs = []
        for seed in seeds:
            for protocol in protocols:
                baseline = indexed.get((protocol, seed, baseline_arm))
                candidate = indexed.get((protocol, seed, candidate_arm))
                if baseline is None or candidate is None:
                    continue
                pairs.append({
                    "protocol": protocol, "seed": seed,
                    "baseline_arm": baseline_arm, "candidate_arm": candidate_arm,
                    "gains": {
                        metric: _gain(metric, baseline[metric], candidate[metric])
                        for metric in REPORT_METRICS
                    },
                })
        summary = {}
        for metric in REPORT_METRICS:
            values = [pair["gains"][metric] for pair in pairs]
            tolerance = 1e-12
            summary[metric] = {
                "count": len(values),
                "mean_gain": sum(values) / len(values) if values else None,
                "wins": sum(value > tolerance for value in values),
                "ties": sum(abs(value) <= tolerance for value in values),
                "losses": sum(value < -tolerance for value in values),
            }
        output[effect] = {
            "baseline_arm": baseline_arm, "candidate_arm": candidate_arm,
            "gain_definition": "positive_always_favors_candidate",
            "summary": summary, "pairs": pairs,
        }
    return output


def audit_matrix(
    workspace, specs, require_complete=True, perform_reference_preflight=True
):
    protocols = tuple(dict.fromkeys(spec.protocol for spec in specs))
    seeds = tuple(dict.fromkeys(spec.seed for spec in specs))
    records, missing_new, missing_reference = [], [], []
    new_code, dataset_sha = None, None
    for spec in specs:
        manifest = _validate_new_manifest(workspace, spec)
        if manifest is None:
            missing_new.append(spec.run_id)
            continue
        current_code = manifest.get("code_sha256")
        if new_code is None:
            new_code = current_code
        elif new_code != current_code:
            raise RuntimeError("E12 new runs mix code fingerprints")
        current_data = manifest["result"]["data_provenance"]["dataset_sha256"]
        if dataset_sha is None:
            dataset_sha = current_data
        elif dataset_sha != current_data:
            raise RuntimeError("E12 new runs mix MOSEI files")
        records.append(_record(spec.arm, manifest, reused=False))

    for seed in seeds:
        for protocol in protocols:
            for arm in ("B1", "B4"):
                run_id = reference_run_id(arm, protocol, seed)
                try:
                    manifest = _validate_reference_manifest(
                        workspace, arm, protocol, seed, dataset_sha
                    )
                except FileNotFoundError:
                    missing_reference.append(run_id)
                    continue
                records.append(_record(arm, manifest, reused=True))

    if require_complete and (missing_new or missing_reference):
        raise RuntimeError(
            "Incomplete E12 ablation | missing_new={} first_new={} | "
            "missing_reference={} first_reference={}".format(
                len(missing_new), missing_new[:5],
                len(missing_reference), missing_reference[:5],
            )
        )
    records.sort(key=lambda item: (
        seeds.index(int(item["seed"])), protocols.index(str(item["protocol"])),
        ARMS.index(item["arm"]),
    ))
    reference_preflight = None
    if require_complete and perform_reference_preflight:
        reference_preflight = preflight_references(workspace, protocols, seeds)
    return {
        "schema_version": 1, "stage_id": "E12", "dataset": DATASET,
        "purpose": "retrieval mechanism ablation",
        "protocols": list(protocols), "seeds": list(seeds), "arms": list(ARMS),
        "expected_new_run_count": len(specs),
        "completed_new_run_count": len(specs) - len(missing_new),
        "expected_reused_reference_count": len(protocols) * len(seeds) * 2,
        "completed_reused_reference_count": (
            len(protocols) * len(seeds) * 2 - len(missing_reference)
        ),
        "expected_total_ablation_cells": len(protocols) * len(seeds) * 6,
        "completed_total_ablation_cells": len(records),
        "missing_new_run_ids": missing_new,
        "missing_reference_run_ids": missing_reference,
        "dataset_sha256": dataset_sha, "new_run_code_sha256": new_code,
        "reference_preflight": reference_preflight,
        "selection_split": "development", "selection_metric": "mae",
        "test_evaluation_count_per_run": 1,
        "test_metrics_consulted_for_training_or_selection": False,
        "effects": summarize_effects(records, protocols, seeds),
        "records": records,
    }


def execute_matrix(workspace, specs):
    protocols = tuple(dict.fromkeys(spec.protocol for spec in specs))
    seeds = tuple(dict.fromkeys(spec.seed for spec in specs))
    preflight_references(workspace, protocols, seeds)
    completed_manifests = []
    for spec in specs:
        manifest = _validate_new_manifest(workspace, spec)
        if manifest is not None:
            completed_manifests.append(manifest)
    if completed_manifests:
        expected_code = code_fingerprints(workspace)
        for manifest in completed_manifests:
            if manifest.get("code_sha256") != expected_code:
                raise RuntimeError(
                    "E12 resume refused because the code fingerprint changed"
                )
        expected_data = sha256_file(resolve_dataset_path(workspace, DATASET))
        for manifest in completed_manifests:
            actual = manifest["result"]["data_provenance"]["dataset_sha256"]
            if actual != expected_data:
                raise RuntimeError("E12 resume refused because MOSEI changed")

    environment = os.environ.copy()
    environment["CUBLAS_WORKSPACE_CONFIG"] = ":4096:8"
    completed = skipped = 0
    for index, spec in enumerate(specs, start=1):
        if _validate_new_manifest(workspace, spec) is not None:
            skipped += 1
            print("[{}/{}] SKIP complete {}".format(index, len(specs), spec.run_id))
            continue
        print("[{}/{}] RUN {}".format(index, len(specs), spec.run_id), flush=True)
        subprocess.check_call(
            command_for_spec(workspace, spec), cwd=str(workspace), env=environment
        )
        _validate_new_manifest(workspace, spec)
        subprocess.check_call(
            [sys.executable, "refresh_paper_registry.py", "--workspace", "."],
            cwd=str(workspace), env=environment,
        )
        completed += 1
    print("E12 execution finished | new={} | skipped={}".format(completed, skipped))


def _csv_values(value, cast):
    return tuple(cast(item.strip()) for item in value.split(",") if item.strip())


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--workspace", type=Path, default=Path("."))
    parser.add_argument("--protocols", default=",".join(PROTOCOLS))
    parser.add_argument("--seeds", default=",".join(str(seed) for seed in SEEDS))
    parser.add_argument("--arms", default=",".join(NEW_ARM_SETTINGS))
    parser.add_argument("--execute", action="store_true")
    parser.add_argument("--audit", action="store_true")
    parser.add_argument(
        "--audit_output", type=Path,
        default=Path("paper_results/E12_retrieval_ablation_audit.json"),
    )
    return parser.parse_args()


def main():
    args = parse_args()
    workspace = args.workspace.resolve()
    specs = build_matrix(
        _csv_values(args.protocols, str), _csv_values(args.seeds, int),
        _csv_values(args.arms, str),
    )
    if not args.execute and not args.audit:
        cells = len(set((spec.protocol, spec.seed) for spec in specs))
        print(
            "E12 dry-run plan | new_runs={} | reused_reference_records={} | "
            "total_ablation_cells={}".format(len(specs), cells * 2, cells * 6)
        )
        for spec in specs:
            refs = [
                reference_run_id(arm, spec.protocol, spec.seed)
                for arm in ("B1", "B4")
            ]
            print("{} | arm={} | references={} | {}".format(
                spec.run_id, spec.arm, ",".join(refs),
                " ".join(command_for_spec(workspace, spec)),
            ))
        return
    if args.execute:
        if os.environ.get("E12_EXECUTE") != "1":
            raise RuntimeError(
                "Set E12_EXECUTE=1 to authorize the formal 48-run matrix"
            )
        execute_matrix(workspace, specs)
    if args.audit:
        summary = audit_matrix(workspace, specs, require_complete=True)
        output = args.audit_output
        if not output.is_absolute():
            output = workspace / output
        write_immutable_json(output, summary)
        print("E12 audit verified: {}".format(output))


if __name__ == "__main__":
    main()
