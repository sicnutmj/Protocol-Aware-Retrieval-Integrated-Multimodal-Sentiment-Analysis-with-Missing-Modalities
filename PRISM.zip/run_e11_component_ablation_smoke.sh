set -euo pipefail

python3 -m py_compile \
  main.py \
  paper_experiment.py \
  run_e11_component_ablation.py \
  tests/test_e11_component_ablation.py

python3 -m pytest \
  tests/test_paper_experiment.py \
  tests/test_missing_aware_retrieval.py \
  tests/test_deterministic_pooling.py \
  tests/test_e05_fpfr_gate.py \
  tests/test_e06_mosei_primary.py \
  tests/test_e07_mosi_external.py \
  tests/test_e08_protocol3_clean.py \
  tests/test_e11_component_ablation.py \
  -q

python3 - <<'PY'
import json
from pathlib import Path

from paper_experiment import resolve_dataset_path

path = Path("paper_experiments/configs/E11_component_ablation.json")
with path.open(encoding="utf-8") as stream:
    config = json.load(stream)
assert config["datasets"] == ["mosei", "mosi"]
assert config["protocols"] == [str(value) for value in range(7)]
assert config["new_method_id"] == "A1"
assert config["new_required_runs"] == 70
assert config["reused_reference_records"] == 210
assert config["total_ablation_cells"] == 280
assert config["ablation_arms"]["A1"]["retrieval_candidate_source"] == "batch"
assert config["ablation_arms"]["A2"]["retrieval_candidate_source"] == "train_bank"
assert config["resume_policy"]["overwrite"] == "forbidden"
for dataset in config["datasets"]:
    print("E11 dataset resolved:", dataset, resolve_dataset_path(Path("."), dataset))
print("E11 component-ablation configuration verified")
PY

PLAN_FILE="$(mktemp)"
trap 'rm -f "${PLAN_FILE}"' EXIT
python3 run_e11_component_ablation.py \
  --datasets=mosei,mosi \
  --protocols=0 \
  --seeds=1111 \
  > "${PLAN_FILE}"
grep -q 'E11 dry-run plan | new_A1_runs=2 | reused_reference_records=6 | total_ablation_cells=8' "${PLAN_FILE}"
grep -q 'E11_A1_mosei_p0_s1111' "${PLAN_FILE}"
grep -q 'E11_A1_mosi_p0_s1111' "${PLAN_FILE}"
grep -q 'E06R1_M0_mosei_p0_s1111,E06R1_M1_mosei_p0_s1111,E06R1_M2_mosei_p0_s1111' "${PLAN_FILE}"
grep -q 'E07_M0_mosi_p0_s1111,E07_M1_mosi_p0_s1111,E07_M2_mosi_p0_s1111' "${PLAN_FILE}"
grep -q -- '--paper_method_id=A1' "${PLAN_FILE}"
grep -q -- '--retrieval_mode=missing_aware' "${PLAN_FILE}"
grep -q -- '--retrieval_candidate_source=batch' "${PLAN_FILE}"
if grep -q -- '--retrieval_candidate_source=train_bank' "${PLAN_FILE}"; then
  echo "E11 new A1 dry-run unexpectedly enables the strict training bank" >&2
  exit 1
fi
if grep -q -- '--protocol_fusion_readaptation' "${PLAN_FILE}"; then
  echo "E11 new A1 dry-run unexpectedly enables fusion readaptation" >&2
  exit 1
fi
echo "E11 70-new-run plan and 210-record reuse mapping verified"

if [ "${E11_GPU_SMOKE:-0}" != "1" ]; then
  echo "Set E11_GPU_SMOKE=1 to run one E11 A1 epoch on MOSEI and MOSI."
  exit 0
fi

SMOKE_ROOT="${SMOKE_ROOT:-tmp/e11_component_ablation_smoke}"
STAMP="$(date +%Y%m%d_%H%M%S)"
mkdir -p \
  "${SMOKE_ROOT}/checkpoints" \
  "${SMOKE_ROOT}/logs" \
  "${SMOKE_ROOT}/manifests"

run_smoke_dataset() {
  local dataset="$1"
  local run_id="E11_SMOKE_A1_${dataset}_p0_s1111_${STAMP}"
  python3 main.py \
    --paper_experiment \
    --paper_run_id="${run_id}" \
    --paper_method_id=A1 \
    --paper_stage_id=E11_SMOKE \
    --paper_manifest_dir="${SMOKE_ROOT}/manifests" \
    --best_model_dir="${SMOKE_ROOT}/checkpoints" \
    --log_dir="${SMOKE_ROOT}/logs" \
    --dataset="${dataset}" \
    --fixed_protocol=0 \
    --seed=1111 \
    --train_batch_size=128 \
    --dev_batch_size=128 \
    --test_batch_size=128 \
    --d_l=192 \
    --latent_dim=192 \
    --layers=3 \
    --latent_layers=2 \
    --missing_rate=0.3 \
    --weight_decay=1e-4 \
    --retrieval_mode=missing_aware \
    --retrieval_candidate_source=batch \
    --retrieval_queue_size=0 \
    --retrieval_metric_mode=raw \
    --retrieval_missing_query=center \
    --retrieval_bank_batch_size=256 \
    --retrieval_bank_refresh_epochs=1 \
    --gate_mode=none \
    --consistency_mode=mixed \
    --distill_mode=none \
    --fusion_mode=flat \
    --prompt_mode=none \
    --reconstruction_mode=none \
    --consensus_mode=none \
    --tag_mode=none \
    --cross_modal_retrieval_mode=none \
    --training_prior_mode=none \
    --hybrid_expert_mode=none \
    --protocol_consistency_mode=none \
    --relation_distill_mode=none \
    --missing_text_contrast_mode=none \
    --privileged_purification_mode=none \
    --language_hyper_mode=none \
    --coupled_prompt_mode=none \
    --early_stopping_min_delta=0.0 \
    --learning_rate=2e-5 \
    --n_epochs=1 \
    --early_stopping_patience=0
}

run_smoke_dataset mosei
run_smoke_dataset mosi

python3 - "${SMOKE_ROOT}" "${STAMP}" <<'PY'
import json
import sys
from pathlib import Path

root = Path(sys.argv[1])
stamp = sys.argv[2]
sizes = {
    "mosei": {"train": 16326, "dev": 1871, "test": 4659},
    "mosi": {"train": 1284, "dev": 229, "test": 686},
}
for dataset in ("mosei", "mosi"):
    run_id = "E11_SMOKE_A1_{}_p0_s1111_{}".format(dataset, stamp)
    path = root / "manifests" / "{}.json".format(run_id)
    with path.open(encoding="utf-8") as stream:
        manifest = json.load(stream)
    result = manifest["result"]
    args = manifest["arguments"]
    assert manifest["status"] == "complete"
    assert manifest["method_id"] == "A1"
    assert manifest["lineage"] is None
    assert args["retrieval_mode"] == "missing_aware"
    assert args["retrieval_candidate_source"] == "batch"
    assert args["retrieval_queue_size"] == 0
    assert args["protocol_fusion_readaptation"] is False
    assert result["completed_epochs"] == 1
    assert result["test_evaluation_count"] == 1
    assert result["data_provenance"]["split_sizes"] == sizes[dataset]
    print("E11 A1 GPU contract verified:", dataset)
print("E11 dual-dataset one-epoch smoke verified")
PY
