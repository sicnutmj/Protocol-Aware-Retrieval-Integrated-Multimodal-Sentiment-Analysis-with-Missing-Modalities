import torch
from torch import nn
import torch.nn.functional as F


class TextGuidedMissingNonverbalReconstruction(nn.Module):
    """Frozen failed improvement-8 reconstruction ablation.

    The injected branch starts at exact zero so a newly initialized module is
    functionally identical to the frozen first+seventh foundation. Direct
    prediction supervision trains the reconstructors even while the injection
    scales are still close to zero. Retained only for exact reproduction; it is
    not part of the active first+seventh foundation.
    """

    MODALITIES = 3
    AUDIO_INDEX = 1
    VIDEO_INDEX = 2

    def __init__(self, embedding_dim, hidden_dim=128, max_scale=1.0):
        super().__init__()
        if embedding_dim < 1:
            raise ValueError("embedding_dim must be positive")
        if hidden_dim < 1:
            raise ValueError("hidden_dim must be positive")
        if max_scale <= 0:
            raise ValueError("max_scale must be positive")

        self.embedding_dim = int(embedding_dim)
        self.max_scale = float(max_scale)
        context_dim = 4 * self.embedding_dim + self.MODALITIES
        self.predictors = nn.ModuleDict({
            "a": self._make_predictor(context_dim, hidden_dim),
            "v": self._make_predictor(context_dim, hidden_dim),
        })
        self.injection_scale_logits = nn.Parameter(torch.zeros(2))

    def _make_predictor(self, context_dim, hidden_dim):
        return nn.Sequential(
            nn.LayerNorm(context_dim),
            nn.Linear(context_dim, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, self.embedding_dim),
        )

    def _validate_vector(self, name, value, batch_size):
        expected = (batch_size, self.embedding_dim)
        if value.shape != expected:
            raise ValueError(
                "{} must have shape {}, got {}".format(
                    name, expected, tuple(value.shape)
                )
            )

    def _validate_inputs(
        self, sample_representation, text_feature, raw_features, observed_mask
    ):
        if sample_representation.ndim != 2:
            raise ValueError("sample_representation must be a 2D tensor")
        batch_size = sample_representation.shape[0]
        self._validate_vector(
            "sample_representation", sample_representation, batch_size
        )
        self._validate_vector("text_feature", text_feature, batch_size)
        if len(raw_features) != self.MODALITIES:
            raise ValueError("raw_features must contain exactly three tensors")
        for index, feature in enumerate(raw_features):
            self._validate_vector(
                "raw_features[{}]".format(index), feature, batch_size
            )
        if observed_mask.shape != (batch_size, self.MODALITIES):
            raise ValueError(
                "observed_mask must have shape [{}, 3]".format(batch_size)
            )
        availability = observed_mask.to(
            device=sample_representation.device,
            dtype=sample_representation.dtype,
        )
        if torch.any((availability != 0) & (availability != 1)):
            raise ValueError("observed_mask values must be binary")
        if torch.any(availability.sum(dim=1) == 0):
            raise ValueError("each sample must contain an observed modality")
        return availability

    def forward(
        self,
        sample_representation,
        text_feature,
        raw_features,
        observed_mask,
        complete_targets=None,
    ):
        availability = self._validate_inputs(
            sample_representation,
            text_feature,
            raw_features,
            observed_mask,
        )
        batch_size = sample_representation.shape[0]
        context = torch.cat(
            (
                text_feature,
                sample_representation,
                raw_features[self.AUDIO_INDEX],
                raw_features[self.VIDEO_INDEX],
                availability,
            ),
            dim=1,
        )
        predictions = (
            self.predictors["a"](context),
            self.predictors["v"](context),
        )
        scales = self.max_scale * torch.tanh(self.injection_scale_logits)
        text_observed = availability[:, 0]
        eligible = (
            text_observed * (1.0 - availability[:, self.AUDIO_INDEX]),
            text_observed * (1.0 - availability[:, self.VIDEO_INDEX]),
        )

        filled_raw = list(raw_features)
        injected = []
        for local_index, modality_index in enumerate(
            (self.AUDIO_INDEX, self.VIDEO_INDEX)
        ):
            addition = (
                eligible[local_index].unsqueeze(1)
                * scales[local_index]
                * predictions[local_index]
            )
            filled_raw[modality_index] = raw_features[modality_index] + addition
            injected.append(addition)

        reconstruction_loss = None
        prediction_loss = sample_representation.sum() * 0.0
        filled_loss = sample_representation.sum() * 0.0
        active_modalities = 0
        if complete_targets is not None:
            if len(complete_targets) != 2:
                raise ValueError(
                    "complete_targets must contain audio and video tensors"
                )
            for local_index, target in enumerate(complete_targets):
                self._validate_vector(
                    "complete_targets[{}]".format(local_index),
                    target,
                    batch_size,
                )
                selected = eligible[local_index].bool()
                if selected.any():
                    detached_target = target[selected].detach()
                    modality_index = (
                        self.AUDIO_INDEX, self.VIDEO_INDEX
                    )[local_index]
                    residual_target = (
                        detached_target
                        - raw_features[modality_index][selected].detach()
                    )
                    prediction_loss = prediction_loss + F.smooth_l1_loss(
                        predictions[local_index][selected], residual_target
                    )
                    filled_loss = filled_loss + F.smooth_l1_loss(
                        filled_raw[modality_index][selected],
                        detached_target,
                    )
                    active_modalities += 1
            if active_modalities:
                prediction_loss = prediction_loss / active_modalities
                filled_loss = filled_loss / active_modalities
            reconstruction_loss = prediction_loss + filled_loss

        diagnostics = {
            "enabled": True,
            "scales": scales.detach(),
            "eligible_count": torch.stack(
                [value.sum() for value in eligible]
            ).detach(),
            "prediction_norm": torch.stack(
                [value.norm(dim=1).mean() for value in predictions]
            ).detach(),
            "injected_norm": torch.stack(
                [value.norm(dim=1).mean() for value in injected]
            ).detach(),
            "prediction_loss": prediction_loss.detach(),
            "filled_loss": filled_loss.detach(),
        }
        return tuple(filled_raw), reconstruction_loss, diagnostics
