"""Training-only similar-prior enhancement for improvement thirteen.

Observed pooled modality features are weakly mixed with sentiment-compatible,
high-cosine neighbours from the current training batch.  Missing modalities and
all evaluation calls are exact identity paths.  The module has no parameters;
only the already-proven ``fusion_all`` head is re-adapted.
"""

import torch
from torch import nn
import torch.nn.functional as F


class TrainingSimilarPriorEnhancement(nn.Module):
    def __init__(
        self,
        mix_ratio=0.1,
        top_k=2,
        similarity_min=0.90,
        similarity_max=0.95,
        score_temperature=0.1,
        label_weight=0.25,
        label_temperature=0.5,
    ):
        super().__init__()
        if not 0.0 < mix_ratio < 1.0:
            raise ValueError("mix_ratio must be in (0, 1)")
        if top_k < 1:
            raise ValueError("top_k must be positive")
        if not -1.0 <= similarity_min < similarity_max <= 1.0:
            raise ValueError("invalid similarity interval")
        if score_temperature <= 0 or label_temperature <= 0:
            raise ValueError("temperatures must be positive")
        if label_weight < 0:
            raise ValueError("label_weight must be non-negative")

        self.mix_ratio = mix_ratio
        self.top_k = top_k
        self.similarity_min = similarity_min
        self.similarity_max = similarity_max
        self.score_temperature = score_temperature
        self.label_weight = label_weight
        self.label_temperature = label_temperature

    def _enhance_modality(self, features, observed, labels):
        batch_size = features.size(0)
        if batch_size <= self.top_k:
            zero = features.new_zeros(())
            return features, {
                "eligible_count": torch.zeros(
                    (), device=features.device, dtype=torch.long
                ),
                "observed_count": observed.sum().detach(),
                "mean_similarity": zero,
                "mean_label_gap": zero,
                "mean_delta_norm": zero,
            }

        normalized = F.normalize(features, dim=-1, eps=1e-8)
        similarities = normalized @ normalized.transpose(0, 1)
        label_gap = torch.abs(
            labels.detach().view(-1, 1) - labels.detach().view(1, -1)
        )
        valid = (
            (similarities >= self.similarity_min)
            & (similarities <= self.similarity_max)
            & observed.view(-1, 1)
            & observed.view(1, -1)
        )
        diagonal = torch.arange(batch_size, device=features.device)
        valid[diagonal, diagonal] = False

        scores = similarities - self.label_weight * (
            label_gap / self.label_temperature
        )
        scores = scores.masked_fill(~valid, float("-inf"))
        values, indices = torch.topk(
            scores,
            k=self.top_k,
            dim=1,
            largest=True,
            sorted=True,
        )
        top_valid = torch.isfinite(values)
        eligible = observed & (top_valid.sum(dim=1) == self.top_k)
        safe_logits = torch.where(
            top_valid,
            values / self.score_temperature,
            torch.full_like(values, -1e4),
        )
        weights = F.softmax(safe_logits, dim=1) * top_valid
        weights = weights / weights.sum(dim=1, keepdim=True).clamp_min(1e-8)
        donor = (
            features[indices] * weights.unsqueeze(-1)
        ).sum(dim=1)
        candidate = features + self.mix_ratio * (donor - features)
        enhanced = torch.where(
            eligible.unsqueeze(1), candidate, features
        )

        selected_similarity = similarities.gather(1, indices)
        selected_label_gap = label_gap.gather(1, indices)
        eligible_float = eligible.to(dtype=features.dtype)
        denominator = eligible_float.sum().clamp_min(1.0)
        mean_similarity = (
            selected_similarity.mean(dim=1) * eligible_float
        ).sum() / denominator
        mean_label_gap = (
            selected_label_gap.mean(dim=1) * eligible_float
        ).sum() / denominator
        mean_delta_norm = (
            (enhanced - features).norm(dim=1) * eligible_float
        ).sum() / denominator
        return enhanced, {
            "eligible_count": eligible.sum().detach(),
            "observed_count": observed.sum().detach(),
            "mean_similarity": mean_similarity.detach(),
            "mean_label_gap": mean_label_gap.detach(),
            "mean_delta_norm": mean_delta_norm.detach(),
        }

    def forward(self, features, observed_mask, labels=None):
        if len(features) != 3:
            raise ValueError("TSPE expects three modality features")
        observed_mask = observed_mask.to(dtype=torch.bool)
        if observed_mask.ndim != 2 or observed_mask.size(1) != 3:
            raise ValueError("observed_mask must have shape [batch, 3]")
        if labels is None or not self.training:
            return tuple(features), {"enabled": False}
        labels = labels.to(
            device=features[0].device,
            dtype=features[0].dtype,
        ).view(-1)
        if labels.numel() != observed_mask.size(0):
            raise ValueError("labels must contain one value per sample")

        enhanced = []
        modality_diagnostics = []
        for modality_index, modality_features in enumerate(features):
            result, diagnostics = self._enhance_modality(
                modality_features,
                observed_mask[:, modality_index],
                labels,
            )
            enhanced.append(result)
            modality_diagnostics.append(diagnostics)

        return tuple(enhanced), {
            "enabled": True,
            "mix_ratio": features[0].new_tensor(self.mix_ratio),
            "eligible_count": torch.stack([
                item["eligible_count"] for item in modality_diagnostics
            ]),
            "observed_count": torch.stack([
                item["observed_count"] for item in modality_diagnostics
            ]),
            "mean_similarity": torch.stack([
                item["mean_similarity"] for item in modality_diagnostics
            ]),
            "mean_label_gap": torch.stack([
                item["mean_label_gap"] for item in modality_diagnostics
            ]),
            "mean_delta_norm": torch.stack([
                item["mean_delta_norm"] for item in modality_diagnostics
            ]),
        }
