import torch
from torch import nn
import torch.nn.functional as F


def legacy_batch_retrieval(embeddings, top_k=2):
    """Reproduce IIE's original batch-only hard Top-K retrieval."""
    if embeddings.ndim != 2:
        raise ValueError("embeddings must have shape [batch, embedding_dim]")
    if top_k < 1:
        raise ValueError("top_k must be at least 1")

    batch_size = embeddings.size(0)
    mean_embedding = embeddings.mean(dim=0, keepdim=True)
    available_k = min(top_k, max(0, batch_size - 1))

    if available_k:
        cosine_sim = F.cosine_similarity(
            embeddings.unsqueeze(1),
            embeddings.unsqueeze(0),
            dim=2,
        )
        self_mask = torch.eye(
            batch_size,
            device=embeddings.device,
            dtype=torch.bool,
        )
        cosine_sim.masked_fill_(self_mask, float("-inf"))
        _, top_indices = torch.topk(
            cosine_sim,
            k=available_k,
            dim=1,
            largest=True,
            sorted=False,
        )
        neighbours = embeddings[top_indices]
    else:
        neighbours = embeddings.new_empty(
            batch_size, 0, embeddings.size(1)
        )
        top_indices = torch.empty(
            batch_size, 0, device=embeddings.device, dtype=torch.long
        )

    topk_valid = torch.ones(
        batch_size,
        available_k,
        device=embeddings.device,
        dtype=torch.bool,
    )

    if available_k < top_k:
        neighbours = torch.cat(
            [
                neighbours,
                mean_embedding.view(1, 1, -1).expand(
                    batch_size, top_k - available_k, -1
                ),
            ],
            dim=1,
        )
        missing_slots = top_k - available_k
        top_indices = torch.cat(
            [
                top_indices,
                torch.full(
                    (batch_size, missing_slots),
                    -1,
                    device=embeddings.device,
                    dtype=torch.long,
                ),
            ],
            dim=1,
        )
        topk_valid = torch.cat(
            [
                topk_valid,
                torch.zeros(
                    batch_size,
                    missing_slots,
                    device=embeddings.device,
                    dtype=torch.bool,
                ),
            ],
            dim=1,
        )

    retrieved = torch.cat(
        [
            embeddings.unsqueeze(1),
            neighbours,
            mean_embedding.view(1, 1, -1).expand(batch_size, -1, -1),
        ],
        dim=1,
    )
    diagnostics = {
        "support_count": torch.full(
            (batch_size,),
            max(0, batch_size - 1),
            device=embeddings.device,
            dtype=torch.long,
        ),
        "memory_size": torch.zeros(
            (),
            device=embeddings.device,
            dtype=torch.long,
        ),
        # Legacy hard Top-K has no supervised retrieval objective, but the
        # model-level output contract always exposes a scalar retrieval loss.
        "retrieval_loss": embeddings.new_zeros(()),
        # Post-hoc evaluation consumes these two fields to identify selected
        # in-batch neighbours. They do not alter legacy retrieval itself.
        "topk_indices": top_indices.detach(),
        "topk_valid": topk_valid.detach(),
    }
    return retrieved, diagnostics


class MissingAwareRetrieval(nn.Module):
    """Retrieve same-modality neighbours without missing placeholders."""

    def __init__(
        self,
        embedding_dim,
        top_k=2,
        queue_size=0,
        temperature=0.1,
        metric_mode="raw",
        projection_dim=64,
        missing_query_mode="center",
        sample_embedding_dim=None,
        label_temperature=0.5,
        candidate_source="batch",
        candidate_filter="observed_only",
        composition_mode="prototype_neighbours",
        selection_mode="similarity",
        random_seed=3407,
    ):
        super().__init__()
        if top_k < 1:
            raise ValueError("top_k must be at least 1")
        if queue_size < 0:
            raise ValueError("queue_size cannot be negative")
        if temperature <= 0:
            raise ValueError("temperature must be positive")
        if metric_mode not in ("raw", "sentiment_guided"):
            raise ValueError("metric_mode must be raw or sentiment_guided")
        if missing_query_mode not in ("center", "sample"):
            raise ValueError("missing_query_mode must be center or sample")
        if projection_dim < 1:
            raise ValueError("projection_dim must be at least 1")
        if label_temperature <= 0:
            raise ValueError("label_temperature must be positive")
        if candidate_source not in ("batch", "train_bank"):
            raise ValueError(
                "candidate_source must be batch or train_bank"
            )
        if candidate_filter not in ("observed_only", "all"):
            raise ValueError(
                "candidate_filter must be observed_only or all"
            )
        if composition_mode not in (
            "prototype_only", "neighbours_only", "prototype_neighbours"
        ):
            raise ValueError(
                "composition_mode must be prototype_only, neighbours_only, "
                "or prototype_neighbours"
            )
        if selection_mode not in ("similarity", "random"):
            raise ValueError("selection_mode must be similarity or random")
        if candidate_source == "train_bank" and queue_size != 0:
            raise ValueError(
                "train-bank retrieval requires queue_size=0"
            )
        if candidate_source == "train_bank" and metric_mode != "raw":
            raise ValueError(
                "E01 train-bank retrieval currently requires raw metrics"
            )
        if missing_query_mode == "sample" and metric_mode != "sentiment_guided":
            raise ValueError(
                "sample-specific missing queries require sentiment-guided metrics"
            )

        self.embedding_dim = embedding_dim
        self.top_k = top_k
        self.queue_size = queue_size
        self.temperature = temperature
        self.metric_mode = metric_mode
        self.projection_dim = projection_dim
        self.missing_query_mode = missing_query_mode
        self.label_temperature = label_temperature
        self.candidate_source = candidate_source
        self.candidate_filter = candidate_filter
        self.composition_mode = composition_mode
        self.selection_mode = selection_mode
        self.random_seed = int(random_seed)

        # These heads affect only retrieval similarities. Selected neighbours
        # remain in the original feature space before entering IIE's latent
        # transformer.
        if metric_mode == "sentiment_guided":
            self.key_projection = nn.Linear(
                embedding_dim, projection_dim, bias=False
            )
            if missing_query_mode == "sample":
                if sample_embedding_dim is None:
                    raise ValueError(
                        "sample_embedding_dim is required for sample queries"
                    )
                self.sample_query_projection = nn.Linear(
                    sample_embedding_dim, projection_dim, bias=False
                )
            else:
                self.sample_query_projection = None
        else:
            self.key_projection = None
            self.sample_query_projection = None

        self.fallback_prototype = nn.Parameter(torch.empty(embedding_dim))
        nn.init.normal_(self.fallback_prototype, mean=0.0, std=0.02)

        self.register_buffer(
            "memory",
            torch.zeros(queue_size, embedding_dim),
        )
        self.register_buffer("memory_size", torch.zeros((), dtype=torch.long))
        self.register_buffer("memory_ptr", torch.zeros((), dtype=torch.long))
        # Formal E01 banks are runtime-only. They are rebuilt exclusively from
        # the complete training split and deliberately excluded from model
        # checkpoints so validation/test artifacts can never become donors.
        self.register_buffer(
            "reference_bank",
            torch.zeros(0, embedding_dim),
            persistent=False,
        )
        self.register_buffer(
            "reference_ids",
            torch.zeros(0, dtype=torch.long),
            persistent=False,
        )

    def set_reference_bank(self, embeddings, sample_ids):
        if self.candidate_source != "train_bank":
            raise RuntimeError(
                "reference banks are available only in train_bank mode"
            )
        if embeddings.ndim != 2 or embeddings.size(1) != self.embedding_dim:
            raise ValueError(
                "reference embeddings must have shape [bank, embedding_dim]"
            )
        sample_ids = sample_ids.to(dtype=torch.long).view(-1)
        if sample_ids.numel() != embeddings.size(0):
            raise ValueError("one sample id is required per bank entry")
        if embeddings.size(0) == 0:
            raise ValueError("reference bank cannot be empty")
        if torch.unique(sample_ids).numel() != sample_ids.numel():
            raise ValueError("reference sample ids must be unique")
        self.reference_bank = embeddings.detach().clone()
        self.reference_ids = sample_ids.detach().clone().to(
            device=embeddings.device
        )

    def clear_reference_bank(self):
        self.reference_bank = self.reference_bank.new_zeros(
            (0, self.embedding_dim)
        )
        self.reference_ids = self.reference_ids.new_zeros((0,))

    def reset_memory(self):
        self.memory.zero_()
        self.memory_size.zero_()
        self.memory_ptr.zero_()

    def _active_memory(self):
        return self.memory[:int(self.memory_size.item())]

    @torch.no_grad()
    def _enqueue(self, embeddings):
        if self.queue_size == 0 or embeddings.numel() == 0:
            return

        values = embeddings.detach()
        if values.size(0) >= self.queue_size:
            self.memory.copy_(values[-self.queue_size:])
            self.memory_size.fill_(self.queue_size)
            self.memory_ptr.zero_()
            return

        count = values.size(0)
        ptr = int(self.memory_ptr.item())
        first = min(count, self.queue_size - ptr)
        self.memory[ptr:ptr + first].copy_(values[:first])
        remainder = count - first
        if remainder:
            self.memory[:remainder].copy_(values[first:])

        self.memory_ptr.fill_((ptr + count) % self.queue_size)
        self.memory_size.fill_(
            min(self.queue_size, int(self.memory_size.item()) + count)
        )

    def _project_retrieval_queries(
        self,
        embeddings,
        observed_mask,
        modality_center,
        sample_query,
    ):
        if self.metric_mode == "raw":
            query_embeddings = torch.where(
                observed_mask.unsqueeze(-1),
                embeddings,
                modality_center.unsqueeze(0),
            )
            return F.normalize(query_embeddings, dim=-1, eps=1e-8)

        observed_queries = F.normalize(
            self.key_projection(embeddings), dim=-1, eps=1e-8
        )
        if self.missing_query_mode == "sample":
            if sample_query is None:
                raise ValueError(
                    "sample_query is required for sample-specific missing queries"
                )
            if sample_query.ndim != 2 or sample_query.size(0) != embeddings.size(0):
                raise ValueError("sample_query must have shape [batch, sample_dim]")
            missing_queries = F.normalize(
                self.sample_query_projection(sample_query), dim=-1, eps=1e-8
            )
        else:
            missing_queries = F.normalize(
                self.key_projection(modality_center.unsqueeze(0)),
                dim=-1,
                eps=1e-8,
            ).expand_as(observed_queries)
        return torch.where(
            observed_mask.unsqueeze(-1), observed_queries, missing_queries
        )

    def _sentiment_metric_loss(
        self,
        embeddings,
        observed_mask,
        sample_query,
        labels,
    ):
        if self.metric_mode != "sentiment_guided" or labels is None:
            return embeddings.sum() * 0.0

        labels = labels.to(device=embeddings.device, dtype=embeddings.dtype).view(-1)
        if labels.numel() != embeddings.size(0):
            raise ValueError("labels must contain one value per sample")

        keys = F.normalize(
            self.key_projection(embeddings), dim=-1, eps=1e-8
        )
        if self.missing_query_mode == "sample":
            if sample_query is None:
                raise ValueError(
                    "sample_query is required for sample-specific missing queries"
                )
            missing_queries = F.normalize(
                self.sample_query_projection(sample_query), dim=-1, eps=1e-8
            )
            queries = torch.where(
                observed_mask.unsqueeze(-1), keys, missing_queries
            )
            valid_queries = torch.ones_like(observed_mask)
        else:
            queries = keys
            # Stage A learns the modality projection from genuinely observed
            # queries. The shared centre used by missing samples has no
            # sample-specific information and should not receive contradictory
            # label targets until Stage B supplies eh_sample queries.
            valid_queries = observed_mask

        valid_pairs = observed_mask.unsqueeze(0).expand(
            embeddings.size(0), -1
        ).clone()
        diagonal = torch.arange(embeddings.size(0), device=embeddings.device)
        valid_pairs[diagonal, diagonal] = False
        valid_queries = valid_queries & valid_pairs.any(dim=1)
        if not bool(valid_queries.any()):
            return embeddings.sum() * 0.0

        similarity_logits = (queries @ keys.transpose(0, 1)) / self.temperature
        similarity_logits = similarity_logits.masked_fill(~valid_pairs, -1e4)
        log_probabilities = F.log_softmax(similarity_logits, dim=1)

        label_logits = -torch.abs(
            labels.unsqueeze(1) - labels.unsqueeze(0)
        ) / self.label_temperature
        label_logits = label_logits.masked_fill(~valid_pairs, -1e4)
        targets = F.softmax(label_logits, dim=1) * valid_pairs
        targets = targets / targets.sum(dim=1, keepdim=True).clamp_min(1e-8)
        target_logs = targets.clamp_min(1e-8).log()
        row_kl = (
            targets * (target_logs - log_probabilities)
        ).sum(dim=1)
        return row_kl[valid_queries].mean()

    def _deterministic_random_scores(
        self, batch_size, candidate_count, query_ids, candidate_ids, device
    ):
        """Return stateless pseudo-random donor scores.

        Scores depend only on query/candidate ids and the registered seed, so
        the E12 random-donor control is invariant to batch partition and never
        consumes the model's training RNG stream.
        """
        if query_ids is None:
            query_ids = torch.arange(
                batch_size, device=device, dtype=torch.long
            )
        else:
            query_ids = query_ids.to(device=device, dtype=torch.long).view(-1)
            if query_ids.numel() != batch_size:
                raise ValueError(
                    "query_ids must contain one id per random-control query"
                )
        if candidate_ids is None:
            candidate_ids = torch.arange(
                candidate_count, device=device, dtype=torch.long
            )
        else:
            candidate_ids = candidate_ids.to(
                device=device, dtype=torch.long
            ).view(-1)
            if candidate_ids.numel() != candidate_count:
                raise ValueError(
                    "candidate_ids must contain one id per random donor"
                )
        modulus = 2147483647
        mixed = (
            query_ids.unsqueeze(1) * 1103515245
            + candidate_ids.unsqueeze(0) * 12345
            + self.random_seed * 2654435761
        ) % modulus
        return mixed.to(dtype=torch.float32) / float(modulus)

    def forward(
        self,
        embeddings,
        observed_mask,
        update_memory=None,
        sample_query=None,
        labels=None,
        query_ids=None,
    ):
        if embeddings.ndim != 2:
            raise ValueError("embeddings must have shape [batch, embedding_dim]")
        if embeddings.size(1) != self.embedding_dim:
            raise ValueError(
                "embedding dimension mismatch: expected {}, got {}".format(
                    self.embedding_dim, embeddings.size(1)
                )
            )

        observed_mask = observed_mask.to(
            device=embeddings.device,
            dtype=torch.bool,
        ).view(-1)
        if observed_mask.numel() != embeddings.size(0):
            raise ValueError("observed_mask must contain one value per sample")

        batch_size = embeddings.size(0)
        if self.candidate_source == "train_bank":
            if self.reference_bank.size(0) == 0:
                raise RuntimeError(
                    "strict train reference bank has not been built"
                )
            candidates = self.reference_bank.to(
                device=embeddings.device, dtype=embeddings.dtype
            )
            candidate_observed = torch.ones(
                candidates.size(0),
                device=embeddings.device,
                dtype=torch.bool,
            )
            memory = embeddings.new_zeros((0, self.embedding_dim))
            candidate_ids = self.reference_ids
        else:
            # Clone because the queue is updated before backward; sharing
            # storage with the buffer would invalidate autograd tensors.
            memory = self._active_memory().detach().clone().to(
                dtype=embeddings.dtype
            )
            candidates = torch.cat([embeddings, memory], dim=0)
            current_observed = (
                observed_mask
                if self.candidate_filter == "observed_only"
                else torch.ones_like(observed_mask)
            )
            candidate_observed = torch.cat([
                current_observed,
                torch.ones(
                    memory.size(0),
                    device=embeddings.device,
                    dtype=torch.bool,
                ),
            ], dim=0)
            candidate_ids = None

        prototype = self.fallback_prototype.to(dtype=embeddings.dtype)
        observed_values = candidates[candidate_observed]
        modality_center = (
            observed_values.mean(dim=0)
            if observed_values.numel()
            else prototype
        )
        # Missing raw features are zero placeholders. Stage A retains the q0
        # modality-centre query; Stage B can replace it with a sample-specific
        # query predicted from eh_sample.
        query = self._project_retrieval_queries(
            embeddings,
            observed_mask,
            modality_center,
            sample_query,
        )
        if self.metric_mode == "sentiment_guided":
            candidate_norm = F.normalize(
                self.key_projection(candidates), dim=-1, eps=1e-8
            )
        else:
            candidate_norm = F.normalize(candidates, dim=-1, eps=1e-8)
        similarities = query @ candidate_norm.transpose(0, 1)
        if self.selection_mode == "random":
            similarities = self._deterministic_random_scores(
                batch_size,
                candidates.size(0),
                query_ids,
                candidate_ids,
                embeddings.device,
            ).to(dtype=embeddings.dtype)

        valid_candidates = candidate_observed.unsqueeze(0).expand(
            batch_size, -1
        ).clone()
        if self.candidate_source == "train_bank":
            if query_ids is not None:
                query_ids = query_ids.to(
                    device=embeddings.device, dtype=torch.long
                ).view(-1)
                if query_ids.numel() != batch_size:
                    raise ValueError(
                        "query_ids must contain one id per query"
                    )
                reference_ids = self.reference_ids.to(
                    device=embeddings.device
                )
                valid_candidates &= (
                    query_ids.unsqueeze(1) != reference_ids.unsqueeze(0)
                )
        else:
            batch_indices = torch.arange(
                batch_size, device=embeddings.device
            )
            valid_candidates[batch_indices, batch_indices] = False
        similarities = similarities.masked_fill(
            ~valid_candidates, float("-inf")
        )

        available_k = min(self.top_k, candidates.size(0))
        top_values, top_indices = torch.topk(
            similarities,
            k=available_k,
            dim=1,
            largest=True,
            sorted=True,
        )
        top_valid = torch.isfinite(top_values)
        selected = candidates[top_indices]

        safe_logits = torch.where(
            top_valid,
            top_values / self.temperature,
            torch.full_like(top_values, -1e4),
        )
        weights = torch.softmax(safe_logits, dim=1) * top_valid
        weights = weights / weights.sum(dim=1, keepdim=True).clamp_min(1e-8)

        valid_count_float = top_valid.sum(dim=1).to(embeddings.dtype)
        valid_similarities = torch.where(
            top_valid, top_values, torch.zeros_like(top_values)
        )
        weighted_similarity = (weights * valid_similarities).sum(dim=1)
        neighbour_dispersion = torch.where(
            valid_count_float > 0,
            1.0 - weighted_similarity.clamp(min=-1.0, max=1.0),
            torch.ones_like(weighted_similarity),
        )
        entropy = -(
            weights * weights.clamp_min(1e-8).log()
        ).sum(dim=1)
        maximum_entropy = valid_count_float.clamp_min(2.0).log()
        topk_confidence = torch.where(
            valid_count_float > 1,
            1.0 - entropy / maximum_entropy,
            (valid_count_float == 1).to(embeddings.dtype),
        ).clamp(min=0.0, max=1.0)

        # Preserve the old feature scale for uniform neighbours, while making
        # more similar neighbours proportionally more important.
        valid_count = top_valid.sum(dim=1, keepdim=True).clamp_min(1)
        slot_weights = weights * valid_count
        weighted_neighbours = selected * slot_weights.unsqueeze(-1)

        neighbour_summary = (
            selected * weights.unsqueeze(-1)
        ).sum(dim=1, keepdim=True)
        neighbour_summary = torch.where(
            top_valid.any(dim=1).view(-1, 1, 1),
            neighbour_summary,
            prototype.view(1, 1, -1),
        )

        weighted_neighbours = torch.where(
            top_valid.unsqueeze(-1),
            weighted_neighbours,
            prototype.view(1, 1, -1),
        )

        if available_k < self.top_k:
            missing_slots = self.top_k - available_k
            padding = prototype.view(1, 1, -1).expand(
                batch_size, missing_slots, -1
            )
            weighted_neighbours = torch.cat(
                [weighted_neighbours, padding], dim=1
            )
            top_valid = torch.cat(
                [
                    top_valid,
                    torch.zeros(
                        batch_size,
                        missing_slots,
                        device=embeddings.device,
                        dtype=torch.bool,
                    ),
                ],
                dim=1,
            )
            weights = torch.cat(
                [
                    weights,
                    torch.zeros(
                        batch_size,
                        missing_slots,
                        device=embeddings.device,
                        dtype=embeddings.dtype,
                    ),
                ],
                dim=1,
            )
            top_indices = torch.cat(
                [
                    top_indices,
                    torch.full(
                        (batch_size, missing_slots),
                        -1,
                        device=embeddings.device,
                        dtype=torch.long,
                    ),
                ],
                dim=1,
            )

        modality_mean = modality_center.view(1, 1, -1).expand(
            batch_size, -1, -1
        )
        if self.composition_mode == "prototype_only":
            weighted_neighbours = modality_mean.expand(
                batch_size, self.top_k, -1
            )
            context_slot = modality_mean
        elif self.composition_mode == "neighbours_only":
            context_slot = neighbour_summary
        else:
            context_slot = modality_mean
        retrieved = torch.cat(
            [
                embeddings.unsqueeze(1),
                weighted_neighbours,
                context_slot,
            ],
            dim=1,
        )

        diagnostics = {
            "support_count": valid_candidates.sum(dim=1).detach(),
            "topk_valid": top_valid.detach(),
            "topk_weights": weights.detach(),
            "topk_confidence": topk_confidence.detach(),
            "valid_ratio": top_valid.to(embeddings.dtype).mean(dim=1).detach(),
            "support_ratio": (
                valid_candidates.sum(dim=1).to(embeddings.dtype)
                / max(1, candidates.size(0) - 1)
            ).clamp(max=1.0).detach(),
            "weighted_similarity": weighted_similarity.detach(),
            "neighbour_dispersion": neighbour_dispersion.detach(),
            "memory_size": self.memory_size.detach().clone(),
            "topk_indices": top_indices.detach(),
            "topk_from_memory": (
                (
                    (top_indices >= batch_size) & top_valid
                    if self.candidate_source == "batch"
                    else torch.zeros_like(top_valid)
                )
            ).detach(),
            "topk_from_reference_bank": (
                top_valid
                if self.candidate_source == "train_bank"
                else torch.zeros_like(top_valid)
            ).detach(),
            "candidate_source": self.candidate_source,
            "candidate_filter": self.candidate_filter,
            "composition_mode": self.composition_mode,
            "selection_mode": self.selection_mode,
            "retrieval_loss": self._sentiment_metric_loss(
                embeddings,
                observed_mask,
                sample_query,
                labels,
            ),
        }

        if update_memory is None:
            update_memory = self.training
        if update_memory and self.candidate_source == "batch":
            self._enqueue(embeddings[observed_mask])

        return retrieved, diagnostics
