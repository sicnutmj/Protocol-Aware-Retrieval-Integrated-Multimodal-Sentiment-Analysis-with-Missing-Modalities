import torch.nn.functional as F


def paired_hierarchical_distillation(
    student_sample,
    teacher_sample,
    student_fusion,
    teacher_fusion,
):
    """Frozen ablation aligning paired views at two representation levels.

    Teacher tensors are detached here so callers cannot accidentally send
    gradients through the complete-view branch.
    """
    pairs = (
        ("sample", student_sample, teacher_sample),
        ("fusion", student_fusion, teacher_fusion),
    )
    losses = {}
    for name, student, teacher in pairs:
        if student.shape != teacher.shape:
            raise ValueError(
                "{} representations must have identical shapes, got {} and {}"
                .format(name, tuple(student.shape), tuple(teacher.shape))
            )
        if student.device != teacher.device:
            raise ValueError(
                "{} representations must be on the same device".format(name)
            )
        losses[name] = F.smooth_l1_loss(student, teacher.detach())
    return losses
