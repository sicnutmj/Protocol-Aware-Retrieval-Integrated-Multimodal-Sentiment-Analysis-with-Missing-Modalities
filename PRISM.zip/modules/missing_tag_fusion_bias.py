"""Frozen failed improvement-10 missing-tag fusion bias ablation.

The exact four-bit tag is ``[complete, missing_l, missing_a, missing_v]``.
Its zero-initialized projection shifts only the pre-activation of the proven
first layer in ``fusion_all``; it does not modify or reconstruct any modality.
The branch is retained only for exact reproduction.
"""

import torch
from torch import nn


class AdditiveMissingTagFusionBias(nn.Module):
    """Project a deterministic missing-pattern tag into fusion hidden space."""

    TAG_DIMENSION = 4

    def __init__(self, fusion_hidden_dim):
        super().__init__()
        if fusion_hidden_dim < 1:
            raise ValueError("fusion_hidden_dim must be positive")
        self.fusion_hidden_dim = fusion_hidden_dim
        self.projection = nn.Linear(
            self.TAG_DIMENSION,
            fusion_hidden_dim,
            bias=False,
        )
        self.reset_identity()

    def reset_identity(self):
        """Make the tag branch an exact identity at epoch 0."""
        nn.init.zeros_(self.projection.weight)

    @staticmethod
    def build_tag(observed_mask):
        if observed_mask.dim() != 2 or observed_mask.size(1) != 3:
            raise ValueError("observed_mask must have shape [batch, 3]")
        if torch.any((observed_mask != 0) & (observed_mask != 1)):
            raise ValueError("observed_mask values must be binary")
        if torch.any(observed_mask.sum(dim=1) == 0):
            raise ValueError("each sample must contain an observed modality")
        availability = observed_mask.float()
        complete = (availability.sum(dim=1, keepdim=True) == 3).to(
            availability.dtype
        )
        return torch.cat((complete, 1.0 - availability), dim=1)

    def forward(self, observed_mask):
        tag = self.build_tag(observed_mask)
        shift = self.projection(tag)
        diagnostics = {
            "enabled": True,
            "tag": tag.detach(),
            "tag_mean": tag.detach().mean(dim=0),
            "shift_abs_mean": shift.detach().abs().mean(),
            "shift_norm_mean": shift.detach().norm(dim=1).mean(),
            "column_norms": self.projection.weight.detach().norm(dim=0),
        }
        return shift, diagnostics
