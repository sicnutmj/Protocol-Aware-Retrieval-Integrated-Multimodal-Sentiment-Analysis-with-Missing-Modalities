"""Improvement 17: label-semantic contrastive missing-text residual.

The adapter is deliberately narrow: it is active only when text is absent and
uses only observed non-verbal representations.  A zero-initialized injection
scale makes a newly attached adapter exactly identical to the retained
first+seventh+FPFR foundation at epoch 0.  Complete text representations and
sentiment labels are training-only targets; inference uses neither.
"""

import torch
from torch import nn
import torch.nn.functional as F


class LabelSemanticMissingTextResidual(nn.Module):
    MODALITIES = 3
    TEXT_INDEX = 0
    AUDIO_INDEX = 1
    VIDEO_INDEX = 2

    def __init__(self, embedding_dim, hidden_dim=128, max_scale=1.0):
        super().__init__()
        if embedding_dim < 1:
            raise ValueError("embedding_dim must be positive")
        if hidden_dim < 1:
            raise ValueError("hidden_dim must be positive")
        if max_scale <= 0:
            raise ValueError("max_scale must be positive")

        self.embedding_dim = int(embedding_dim)
        self.max_scale = float(max_scale)
        context_dim = 5 * self.embedding_dim + self.MODALITIES
        self.residual_predictor = nn.Sequential(
            nn.LayerNorm(context_dim),
            nn.Linear(context_dim, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, self.embedding_dim),
        )
        self.injection_scale_logit = nn.Parameter(torch.zeros(()))

    def _validate_features(self, name, features, batch_size):
        if len(features) != self.MODALITIES:
            raise ValueError("{} must contain exactly three tensors".format(name))
        expected = (batch_size, self.embedding_dim)
        for index, feature in enumerate(features):
            if feature.shape != expected:
                raise ValueError(
                    "{}[{}] must have shape {}, got {}".format(
                        name, index, expected, tuple(feature.shape)
                    )
                )

    def forward(
        self,
        sample_representation,
        enhanced_features,
        raw_features,
        observed_mask,
    ):
        if sample_representation.ndim != 2:
            raise ValueError("sample_representation must be a 2D tensor")
        batch_size = sample_representation.shape[0]
        expected = (batch_size, self.embedding_dim)
        if sample_representation.shape != expected:
            raise ValueError(
                "sample_representation must have shape {}, got {}".format(
                    expected, tuple(sample_representation.shape)
                )
            )
        self._validate_features("enhanced_features", enhanced_features, batch_size)
        self._validate_features("raw_features", raw_features, batch_size)
        if observed_mask.shape != (batch_size, self.MODALITIES):
            raise ValueError(
                "observed_mask must have shape [{}, 3]".format(batch_size)
            )
        availability = observed_mask.to(
            device=sample_representation.device,
            dtype=sample_representation.dtype,
        )
        if torch.any((availability != 0) & (availability != 1)):
            raise ValueError("observed_mask values must be binary")
        if torch.any(availability.sum(dim=1) == 0):
            raise ValueError("each sample must contain an observed modality")

        audio_available = availability[:, self.AUDIO_INDEX:self.AUDIO_INDEX + 1]
        video_available = availability[:, self.VIDEO_INDEX:self.VIDEO_INDEX + 1]
        context = torch.cat(
            (
                sample_representation,
                raw_features[self.AUDIO_INDEX] * audio_available,
                raw_features[self.VIDEO_INDEX] * video_available,
                enhanced_features[self.AUDIO_INDEX] * audio_available,
                enhanced_features[self.VIDEO_INDEX] * video_available,
                availability,
            ),
            dim=1,
        )
        predicted_residual = self.residual_predictor(context)
        base_text = enhanced_features[self.TEXT_INDEX]
        candidate_text = base_text.detach() + predicted_residual
        eligible = 1.0 - availability[:, self.TEXT_INDEX]
        scale = self.max_scale * torch.tanh(self.injection_scale_logit)
        addition = eligible.unsqueeze(1) * scale * predicted_residual

        corrected = list(enhanced_features)
        corrected[self.TEXT_INDEX] = base_text + addition
        diagnostics = {
            "enabled": True,
            "eligible": eligible,
            "eligible_count": eligible.sum().detach(),
            "scale": scale.detach(),
            "predicted_residual": predicted_residual,
            "candidate_text": candidate_text,
            "base_text": base_text,
            "corrected_text": corrected[self.TEXT_INDEX],
            "prediction_norm": predicted_residual.norm(dim=1).mean().detach(),
            "injected_norm": addition.norm(dim=1).mean().detach(),
        }
        return tuple(corrected), diagnostics


def label_semantic_missing_text_objective(
    diagnostics,
    complete_text_target,
    labels,
    temperature=0.5,
    semantic_weighting=True,
):
    """Return paired reconstruction and in-batch contrastive objectives."""
    if temperature <= 0:
        raise ValueError("temperature must be positive")
    required = (
        "eligible",
        "predicted_residual",
        "candidate_text",
        "base_text",
        "corrected_text",
    )
    if not diagnostics.get("enabled", False) or any(
        name not in diagnostics for name in required
    ):
        raise ValueError("enabled missing-text diagnostics are required")

    target = complete_text_target.detach()
    if target.shape != diagnostics["candidate_text"].shape:
        raise ValueError("complete text target shape must match candidate text")
    eligible = diagnostics["eligible"].bool()
    zero = diagnostics["candidate_text"].sum() * 0.0
    if not eligible.any():
        return zero, zero, {
            "eligible_count": eligible.float().sum().detach(),
            "positive_similarity": zero.detach(),
            "negative_similarity": zero.detach(),
            "semantic_weight": zero.detach(),
            "candidate_target_gap": zero.detach(),
        }

    selected_target = target[eligible]
    selected_base = diagnostics["base_text"][eligible].detach()
    selected_residual = diagnostics["predicted_residual"][eligible]
    selected_candidate = diagnostics["candidate_text"][eligible]
    selected_corrected = diagnostics["corrected_text"][eligible]
    residual_target = selected_target - selected_base
    pair_loss = 0.5 * (
        F.smooth_l1_loss(selected_residual, residual_target)
        + F.smooth_l1_loss(selected_corrected, selected_target)
    )

    queries = F.normalize(selected_candidate, p=2, dim=1, eps=1e-8)
    keys = F.normalize(selected_target, p=2, dim=1, eps=1e-8)
    logits = torch.matmul(queries, keys.transpose(0, 1)) / temperature
    sample_count = logits.shape[0]
    targets = torch.arange(sample_count, device=logits.device)
    semantic_weights = torch.ones_like(logits)
    if semantic_weighting and sample_count > 1:
        selected_labels = labels.detach().view(-1)[eligible]
        label_gap = torch.abs(
            selected_labels.unsqueeze(1) - selected_labels.unsqueeze(0)
        )
        semantic_weights = torch.sigmoid(label_gap)
        semantic_weights.fill_diagonal_(1.0)
        logits = logits + torch.log(semantic_weights.clamp_min(1e-8))
    contrastive_loss = F.cross_entropy(logits, targets)

    similarity = torch.matmul(queries.detach(), keys.detach().transpose(0, 1))
    diagonal = torch.eye(
        sample_count, dtype=torch.bool, device=similarity.device
    )
    positive_similarity = similarity.diagonal().mean()
    if sample_count > 1:
        negative_similarity = similarity[~diagonal].mean()
        mean_semantic_weight = semantic_weights.detach()[~diagonal].mean()
    else:
        negative_similarity = similarity.new_zeros(())
        mean_semantic_weight = similarity.new_zeros(())
    info = {
        "eligible_count": eligible.float().sum().detach(),
        "positive_similarity": positive_similarity,
        "negative_similarity": negative_similarity,
        "semantic_weight": mean_semantic_weight,
        "candidate_target_gap": F.smooth_l1_loss(
            selected_candidate.detach(), selected_target
        ),
    }
    return pair_loss, contrastive_loss, info
