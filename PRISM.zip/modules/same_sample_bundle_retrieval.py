"""Sentiment-consistent same-sample bundle retrieval (SCBR).

SCBR is an evaluation-time, train-bank completion branch.  It ranks complete
training donors only in the native spaces of the modalities that are observed
for a query.  A frozen foundation prediction supplies a continuous sentiment
prior, and the same donor indices provide every missing target modality.  This
preserves cross-modal pairing without learning a cross-modal query mapper.
"""

import torch
from torch import nn
import torch.nn.functional as F


MODALITIES = ("l", "a", "v")


class SentimentConsistentBundleRetrieval(nn.Module):
    def __init__(
        self,
        embedding_dim,
        top_k=2,
        temperature=0.1,
        sentiment_weight=0.25,
        sentiment_temperature=0.5,
        injection_scale=0.0,
    ):
        super().__init__()
        if embedding_dim < 1:
            raise ValueError("embedding_dim must be positive")
        if top_k < 1:
            raise ValueError("top_k must be positive")
        if temperature <= 0 or sentiment_temperature <= 0:
            raise ValueError("temperatures must be positive")
        if sentiment_weight < 0:
            raise ValueError("sentiment_weight must be non-negative")
        if not 0.0 <= injection_scale <= 1.0:
            raise ValueError("injection_scale must be in [0, 1]")

        self.embedding_dim = embedding_dim
        self.top_k = top_k
        self.temperature = temperature
        self.sentiment_weight = sentiment_weight
        self.sentiment_temperature = sentiment_temperature
        self.register_buffer(
            "injection_scale",
            torch.tensor(float(injection_scale)),
        )
        self.register_buffer(
            "bank_labels",
            torch.empty(0),
            persistent=False,
        )
        for modality in MODALITIES:
            self.register_buffer(
                "bank_{}".format(modality),
                torch.empty(0, embedding_dim),
                persistent=False,
            )

    def set_injection_scale(self, scale):
        scale = float(scale)
        if not 0.0 <= scale <= 1.0:
            raise ValueError("injection scale must be in [0, 1]")
        self.injection_scale.fill_(scale)

    def set_reference_bank(self, banks, labels):
        labels = labels.detach().view(-1)
        if labels.numel() < self.top_k:
            raise ValueError("reference bank is smaller than top_k")
        for modality in MODALITIES:
            if modality not in banks:
                raise ValueError("reference bank is missing {}".format(modality))
            bank = banks[modality]
            if bank.ndim != 2 or bank.size(1) != self.embedding_dim:
                raise ValueError(
                    "{} bank must have shape [items, {}]".format(
                        modality, self.embedding_dim
                    )
                )
            if bank.size(0) != labels.numel():
                raise ValueError("all banks and labels must have the same size")
            setattr(self, "bank_{}".format(modality), bank.detach().clone())
        self.bank_labels = labels.clone()

    def reference_bank_size(self):
        return int(self.bank_labels.numel())

    def _rank_donors(self, raw_features, observed_mask, seed_sentiment):
        batch_size = raw_features[0].size(0)
        bank_size = self.reference_bank_size()
        if bank_size < self.top_k:
            raise RuntimeError("SCBR reference bank has not been built")

        similarity_sum = raw_features[0].new_zeros(batch_size, bank_size)
        observed_count = observed_mask.sum(dim=1)
        for modality_index, modality in enumerate(MODALITIES):
            query = F.normalize(raw_features[modality_index], dim=-1, eps=1e-8)
            bank = F.normalize(
                getattr(self, "bank_{}".format(modality)),
                dim=-1,
                eps=1e-8,
            )
            similarity = query @ bank.transpose(0, 1)
            similarity_sum = similarity_sum + similarity * observed_mask[
                :, modality_index
            ].to(dtype=similarity.dtype).unsqueeze(1)

        observable_similarity = similarity_sum / observed_count.clamp_min(
            1
        ).to(dtype=similarity_sum.dtype).unsqueeze(1)
        sentiment_gap = torch.abs(
            seed_sentiment.detach().view(-1, 1)
            - self.bank_labels.to(dtype=similarity_sum.dtype).view(1, -1)
        )
        scores = observable_similarity - self.sentiment_weight * (
            sentiment_gap / self.sentiment_temperature
        )
        no_observation = observed_count == 0
        scores = scores.masked_fill(no_observation.unsqueeze(1), float("-inf"))

        values, indices = torch.topk(
            scores,
            k=self.top_k,
            dim=1,
            largest=True,
            sorted=True,
        )
        weights = F.softmax(values / self.temperature, dim=1)
        return (
            indices,
            weights,
            observable_similarity.gather(1, indices),
            sentiment_gap.gather(1, indices),
            ~no_observation,
        )

    def forward(
        self,
        raw_features,
        observed_mask,
        base_retrieved,
        seed_sentiment,
    ):
        if len(raw_features) != 3 or len(base_retrieved) != 3:
            raise ValueError("SCBR expects three raw and retrieved modalities")
        observed_mask = observed_mask.to(dtype=torch.bool)
        if observed_mask.ndim != 2 or observed_mask.size(1) != 3:
            raise ValueError("observed_mask must have shape [batch, 3]")
        if seed_sentiment.numel() != observed_mask.size(0):
            raise ValueError("seed_sentiment must contain one value per sample")

        (
            donor_indices,
            donor_weights,
            donor_similarities,
            donor_sentiment_gaps,
            has_observation,
        ) = self._rank_donors(
            raw_features,
            observed_mask,
            seed_sentiment,
        )

        completed = []
        eligible_counts = []
        scale = self.injection_scale.to(dtype=base_retrieved[0].dtype)
        for target_index, modality in enumerate(MODALITIES):
            base = base_retrieved[target_index]
            bank = getattr(self, "bank_{}".format(modality))
            selected = bank[donor_indices]
            # Preserve q0's neighbour-slot magnitude convention: uniform
            # weights retain unit slot weights rather than shrinking by 1/K.
            selected = selected * (
                donor_weights * selected.size(1)
            ).unsqueeze(-1)
            candidate = base.clone()
            neighbour_count = min(self.top_k, candidate.size(1) - 2)
            candidate[:, 1:1 + neighbour_count] = selected[:, :neighbour_count]
            eligible = (~observed_mask[:, target_index]) & has_observation
            delta = (candidate - base) * eligible.view(-1, 1, 1).to(
                dtype=base.dtype
            )
            completed.append(base + scale * delta)
            eligible_counts.append(eligible.sum().detach())

        diagnostics = {
            "enabled": True,
            "injection_scale": self.injection_scale.detach().clone(),
            "eligible_count": torch.stack(eligible_counts),
            "top1_similarity": donor_similarities[:, 0].mean().detach(),
            "top1_sentiment_gap": donor_sentiment_gaps[:, 0].mean().detach(),
            "observed_modalities": observed_mask.sum(dim=1).float().mean().detach(),
            "bank_size": torch.tensor(
                self.reference_bank_size(),
                device=observed_mask.device,
                dtype=torch.long,
            ),
            "donor_indices": donor_indices.detach(),
        }
        return tuple(completed), diagnostics
