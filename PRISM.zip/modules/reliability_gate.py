import math

import torch
from torch import nn
import torch.nn.functional as F


def select_counterfactual_scale_targets(candidate_errors, teacher_scales):
    """Select the lowest-error executable scale for every sample/branch."""
    if candidate_errors.ndim != 3:
        raise ValueError(
            "candidate_errors must be [batch, modality, scale]"
        )
    if teacher_scales.ndim != 1:
        raise ValueError("teacher_scales must be one-dimensional")
    if candidate_errors.size(2) != teacher_scales.numel():
        raise ValueError(
            "candidate_errors and teacher_scales disagree on scale count"
        )
    if teacher_scales.numel() < 2:
        raise ValueError("at least two teacher scales are required")
    best_error, best_index = candidate_errors.min(dim=2)
    target_scales = teacher_scales[best_index]
    return target_scales, best_error, best_index


class FixedScaleGate(nn.Module):
    """Parameter-free control that uniformly scales enhanced branches."""

    def __init__(self, scale=0.85, min_scale=0.7):
        super().__init__()
        if not 0.0 <= min_scale < 1.0:
            raise ValueError("min_scale must be in [0, 1)")
        if not min_scale <= scale <= 1.0:
            raise ValueError("scale must be between min_scale and 1")
        self.scale = float(scale)
        self.min_scale = float(min_scale)

    def forward(
        self,
        candidate,
        sample_context,
        observed_mask,
        retrieval_diagnostics,
    ):
        if candidate.ndim != 2:
            raise ValueError("candidate must be [batch, dim]")
        if sample_context.shape != candidate.shape:
            raise ValueError(
                "candidate and sample_context must have the same shape"
            )
        observed = observed_mask.to(
            device=candidate.device,
            dtype=candidate.dtype,
        ).view(-1)
        if observed.size(0) != candidate.size(0):
            raise ValueError("observed_mask must contain one value per sample")

        multiplier = candidate.new_full((candidate.size(0),), self.scale)
        normalized_scale = (
            (self.scale - self.min_scale) / (1.0 - self.min_scale)
        )
        reliability = candidate.new_full(
            (candidate.size(0),), normalized_scale
        )
        calibrated = candidate * multiplier.unsqueeze(-1)
        diagnostics = {
            "reliability": reliability.detach(),
            "multiplier": multiplier.detach(),
            "observed": observed.detach(),
            "quality": {},
        }
        return calibrated, diagnostics


class ResidualReliabilityGate(nn.Module):
    """Sample-wise bounded calibration for raw and enhanced features.

    The final projection is zero-initialized, so every branch starts with a
    multiplier of exactly one. This preserves the ungated model at the start
    of training while still allowing the gate to learn immediately.
    """

    RAW_BRANCH = 0
    ENHANCED_BRANCH = 1

    def __init__(
        self,
        embedding_dim,
        hidden_dim=None,
        dropout=0.1,
        max_adjustment=0.5,
        num_modalities=3,
    ):
        super().__init__()
        if embedding_dim < 1:
            raise ValueError("embedding_dim must be positive")
        if hidden_dim is not None and hidden_dim < 1:
            raise ValueError("hidden_dim must be positive")
        if not 0.0 <= dropout < 1.0:
            raise ValueError("dropout must be in [0, 1)")
        if not 0.0 <= max_adjustment < 1.0:
            raise ValueError("max_adjustment must be in [0, 1)")
        if num_modalities < 1:
            raise ValueError("num_modalities must be positive")

        hidden_dim = hidden_dim or max(16, embedding_dim // 2)
        metadata_dim = max(4, min(16, embedding_dim // 8))

        self.embedding_dim = embedding_dim
        self.max_adjustment = max_adjustment
        self.num_modalities = num_modalities
        self.candidate_norm = nn.LayerNorm(embedding_dim)
        self.context_norm = nn.LayerNorm(embedding_dim)
        self.modality_embedding = nn.Embedding(num_modalities, metadata_dim)
        self.branch_embedding = nn.Embedding(2, metadata_dim)

        input_dim = embedding_dim * 4 + metadata_dim * 2 + 1
        self.network = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, 1),
        )
        self.reset_identity()

    def reset_identity(self):
        """Make the initial calibrated representation equal to the input."""
        final_layer = self.network[-1]
        nn.init.zeros_(final_layer.weight)
        nn.init.zeros_(final_layer.bias)

    def forward(
        self,
        candidate,
        sample_context,
        observed_mask,
        modality_index,
        branch_index,
    ):
        if candidate.ndim != 2 or sample_context.ndim != 2:
            raise ValueError("candidate and sample_context must be [batch, dim]")
        if candidate.shape != sample_context.shape:
            raise ValueError("candidate and sample_context must have the same shape")
        if candidate.size(1) != self.embedding_dim:
            raise ValueError(
                "embedding dimension mismatch: expected {}, got {}".format(
                    self.embedding_dim, candidate.size(1)
                )
            )
        if not 0 <= modality_index < self.num_modalities:
            raise ValueError("modality_index is out of range")
        if branch_index not in (self.RAW_BRANCH, self.ENHANCED_BRANCH):
            raise ValueError("branch_index must be RAW_BRANCH or ENHANCED_BRANCH")

        observed = observed_mask.to(
            device=candidate.device,
            dtype=candidate.dtype,
        ).view(-1, 1)
        if observed.size(0) != candidate.size(0):
            raise ValueError("observed_mask must contain one value per sample")

        candidate_normalized = self.candidate_norm(candidate)
        context_normalized = self.context_norm(sample_context)
        modality_ids = torch.full(
            (candidate.size(0),),
            modality_index,
            device=candidate.device,
            dtype=torch.long,
        )
        branch_ids = torch.full(
            (candidate.size(0),),
            branch_index,
            device=candidate.device,
            dtype=torch.long,
        )

        gate_input = torch.cat(
            [
                candidate_normalized,
                context_normalized,
                torch.abs(candidate_normalized - context_normalized),
                candidate_normalized * context_normalized,
                self.modality_embedding(modality_ids),
                self.branch_embedding(branch_ids),
                observed,
            ],
            dim=-1,
        )
        reliability = torch.sigmoid(self.network(gate_input))
        multiplier = 1.0 + self.max_adjustment * (2.0 * reliability - 1.0)

        calibrated = candidate * multiplier
        if branch_index == self.RAW_BRANCH:
            # Missing raw features must remain absent rather than becoming a
            # duplicate of the sample-level context.
            calibrated = calibrated * observed

        diagnostics = {
            "reliability": reliability.squeeze(-1).detach(),
            "multiplier": multiplier.squeeze(-1).detach(),
            "observed": observed.squeeze(-1).detach(),
        }
        return calibrated, diagnostics


class QualityAwareReliabilityGate(nn.Module):
    """Conservatively suppress retrieved enhancements using quality signals.

    Raw observed representations bypass this module. The gate is shared by
    all modalities so that it must learn a quality-to-reliability mapping
    instead of a free modality-specific scaling bias.
    """

    QUALITY_NAMES = (
        "agreement",
        "difference",
        "topk_confidence",
        "valid_ratio",
        "support_ratio",
        "neighbour_dispersion",
        "observed",
    )

    def __init__(
        self,
        embedding_dim,
        hidden_dim=32,
        min_scale=0.7,
        init_bias=4.0,
    ):
        super().__init__()
        if embedding_dim < 1:
            raise ValueError("embedding_dim must be positive")
        if hidden_dim < 1:
            raise ValueError("hidden_dim must be positive")
        if not 0.0 <= min_scale < 1.0:
            raise ValueError("min_scale must be in [0, 1)")
        if not torch.isfinite(torch.tensor(float(init_bias))):
            raise ValueError("init_bias must be finite")

        self.embedding_dim = embedding_dim
        self.min_scale = min_scale
        self.init_bias = float(init_bias)
        self.network = nn.Sequential(
            nn.Linear(len(self.QUALITY_NAMES), hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, 1),
        )
        self.reset_near_identity()

    def reset_near_identity(self):
        """Start close to one while retaining a useful sigmoid gradient."""
        final_layer = self.network[-1]
        nn.init.zeros_(final_layer.weight)
        nn.init.constant_(final_layer.bias, self.init_bias)

    @staticmethod
    def _read_diagnostic(diagnostics, name, candidate):
        if name not in diagnostics:
            raise ValueError(
                "retrieval diagnostics are missing required field: {}".format(
                    name
                )
            )
        value = diagnostics[name].to(
            device=candidate.device,
            dtype=candidate.dtype,
        ).view(-1)
        if value.size(0) != candidate.size(0):
            raise ValueError(
                "retrieval diagnostic {} must contain one value per sample".format(
                    name
                )
            )
        return value

    def forward(
        self,
        candidate,
        sample_context,
        observed_mask,
        retrieval_diagnostics,
    ):
        observed, quality, quality_vector = self._prepare_quality(
            candidate,
            sample_context,
            observed_mask,
            retrieval_diagnostics,
        )
        reliability = torch.sigmoid(self.network(quality_vector))
        multiplier = self.min_scale + (1.0 - self.min_scale) * reliability
        calibrated = candidate * multiplier

        diagnostics = {
            "reliability": reliability.squeeze(-1).detach(),
            "multiplier": multiplier.squeeze(-1).detach(),
            "observed": observed.detach(),
            "quality": {
                name: value.detach() for name, value in quality.items()
                if name != "observed"
            },
        }
        return calibrated, diagnostics

    def _prepare_quality(
        self,
        candidate,
        sample_context,
        observed_mask,
        retrieval_diagnostics,
    ):
        if candidate.ndim != 2 or sample_context.ndim != 2:
            raise ValueError("candidate and sample_context must be [batch, dim]")
        if candidate.shape != sample_context.shape:
            raise ValueError("candidate and sample_context must have the same shape")
        if candidate.size(1) != self.embedding_dim:
            raise ValueError(
                "embedding dimension mismatch: expected {}, got {}".format(
                    self.embedding_dim, candidate.size(1)
                )
            )

        observed = observed_mask.to(
            device=candidate.device,
            dtype=candidate.dtype,
        ).view(-1)
        if observed.size(0) != candidate.size(0):
            raise ValueError("observed_mask must contain one value per sample")

        # Quality estimators are treated as measurements, not optimization
        # targets for the upstream encoders. Gradients still reach candidate
        # directly through calibrated = candidate * multiplier.
        candidate_quality = candidate.detach()
        context_quality = sample_context.detach()
        candidate_normalized = F.layer_norm(
            candidate_quality, (self.embedding_dim,)
        )
        context_normalized = F.layer_norm(
            context_quality, (self.embedding_dim,)
        )
        agreement = (
            F.cosine_similarity(
                candidate_normalized,
                context_normalized,
                dim=-1,
                eps=1e-8,
            )
            .add(1.0)
            .mul(0.5)
            .clamp(min=0.0, max=1.0)
        )
        difference = torch.tanh(
            torch.abs(candidate_normalized - context_normalized).mean(dim=-1)
        )
        topk_confidence = self._read_diagnostic(
            retrieval_diagnostics, "topk_confidence", candidate
        ).clamp(min=0.0, max=1.0)
        valid_ratio = self._read_diagnostic(
            retrieval_diagnostics, "valid_ratio", candidate
        ).clamp(min=0.0, max=1.0)
        support_ratio = self._read_diagnostic(
            retrieval_diagnostics, "support_ratio", candidate
        ).clamp(min=0.0, max=1.0)
        neighbour_dispersion = (
            self._read_diagnostic(
                retrieval_diagnostics, "neighbour_dispersion", candidate
            )
            .clamp(min=0.0, max=2.0)
            .mul(0.5)
        )

        quality = {
            "agreement": agreement,
            "difference": difference,
            "topk_confidence": topk_confidence,
            "valid_ratio": valid_ratio,
            "support_ratio": support_ratio,
            "neighbour_dispersion": neighbour_dispersion,
            "observed": observed,
        }
        quality_vector = torch.stack(
            [quality[name] for name in self.QUALITY_NAMES], dim=-1
        )
        return observed, quality, quality_vector


class QualityAwareReliabilityGateV22(QualityAwareReliabilityGate):
    """Gate-V2.2 with a less saturated near-identity initialization.

    V2.1 used a fixed output bias of 4.0. That produces a safe initial scale,
    but also places the sigmoid in a low-gradient region. V2.2 specifies the
    desired initial multiplier directly and derives the corresponding logit.
    An initial scale of 0.98 remains conservative while providing a materially
    stronger gradient for learning sample-wise quality differences.
    """

    def __init__(
        self,
        embedding_dim,
        hidden_dim=32,
        min_scale=0.7,
        init_scale=0.98,
    ):
        if not min_scale < init_scale < 1.0:
            raise ValueError("init_scale must be strictly between min_scale and 1")

        initial_reliability = (
            (float(init_scale) - float(min_scale))
            / (1.0 - float(min_scale))
        )
        init_bias = math.log(
            initial_reliability / (1.0 - initial_reliability)
        )
        self.init_scale = float(init_scale)
        self.initial_reliability = initial_reliability
        super().__init__(
            embedding_dim=embedding_dim,
            hidden_dim=hidden_dim,
            min_scale=min_scale,
            init_bias=init_bias,
        )


class CounterfactualHarmGate(QualityAwareReliabilityGate):
    """Gate-V2.3: predict whether an enhanced branch harms prediction.

    Unlike V2.1/V2.2, the output logit represents harm rather than generic
    reliability. The multiplier is detached from the task-loss path, so the
    gate cannot collapse into an unconstrained branch-weight learner. It is
    trained explicitly from counterfactual branch-removal targets.
    """

    QUALITY_NAMES = (
        "agreement",
        "difference",
        "topk_confidence",
        "valid_ratio",
        "support_ratio",
        "neighbour_dispersion",
    )

    def __init__(
        self,
        embedding_dim,
        hidden_dim=32,
        min_scale=0.7,
        init_harm_probability=0.02,
    ):
        if not 0.0 < init_harm_probability < 1.0:
            raise ValueError("init_harm_probability must be in (0, 1)")
        self.init_harm_probability = float(init_harm_probability)
        init_bias = math.log(
            self.init_harm_probability
            / (1.0 - self.init_harm_probability)
        )
        super().__init__(
            embedding_dim=embedding_dim,
            hidden_dim=hidden_dim,
            min_scale=min_scale,
            init_bias=init_bias,
        )

    def forward(
        self,
        candidate,
        sample_context,
        observed_mask,
        retrieval_diagnostics,
    ):
        observed, quality, quality_vector = self._prepare_quality(
            candidate,
            sample_context,
            observed_mask,
            retrieval_diagnostics,
        )
        harm_logit = self.network(quality_vector)
        harm_probability = torch.sigmoid(harm_logit)
        reliability = 1.0 - harm_probability
        multiplier = 1.0 - (
            (1.0 - self.min_scale) * harm_probability
        )

        # Counterfactual supervision is the only optimization path into the
        # gate. The task loss still reaches the enhanced representation.
        calibrated = candidate * multiplier.detach()
        diagnostics = {
            "reliability": reliability.squeeze(-1).detach(),
            "harm_probability": harm_probability.squeeze(-1).detach(),
            "harm_logit": harm_logit.squeeze(-1),
            "multiplier": multiplier.squeeze(-1).detach(),
            "observed": observed.detach(),
            "quality": {
                name: value.detach() for name, value in quality.items()
                if name != "observed"
            },
        }
        return calibrated, diagnostics


class CounterfactualScaleGateV24(QualityAwareReliabilityGate):
    """Gate-V2.4: regress an executable counterfactual scale.

    A learnable prior captures the average scale for each
    ``modality x availability`` group.  A shared quality network predicts only
    a bounded sample residual around that prior.  Keeping these two terms
    explicit makes a fixed group reweighting distinguishable from genuine
    sample-wise reliability variation in the diagnostics.

    As in V2.3, the multiplier is detached from the task-loss path.  The gate
    is optimized only against counterfactual scale targets constructed with
    the same scale range that the gate can execute.
    """

    QUALITY_NAMES = (
        "agreement",
        "difference",
        "topk_confidence",
        "valid_ratio",
        "support_ratio",
        "neighbour_dispersion",
    )

    def __init__(
        self,
        embedding_dim,
        hidden_dim=32,
        min_scale=0.7,
        init_scale=0.98,
        max_residual_logit=8.0,
        num_modalities=3,
    ):
        if not min_scale < init_scale < 1.0:
            raise ValueError(
                "init_scale must be strictly between min_scale and 1"
            )
        if max_residual_logit <= 0.0:
            raise ValueError("max_residual_logit must be positive")
        if num_modalities < 1:
            raise ValueError("num_modalities must be positive")

        initial_reliability = (
            (float(init_scale) - float(min_scale))
            / (1.0 - float(min_scale))
        )
        initial_group_logit = math.log(
            initial_reliability / (1.0 - initial_reliability)
        )

        # The inherited MLP is the sample-residual head, so it starts at zero.
        super().__init__(
            embedding_dim=embedding_dim,
            hidden_dim=hidden_dim,
            min_scale=min_scale,
            init_bias=0.0,
        )
        self.init_scale = float(init_scale)
        self.initial_reliability = initial_reliability
        self.initial_group_logit = initial_group_logit
        self.max_residual_logit = float(max_residual_logit)
        self.num_modalities = int(num_modalities)
        # Name this parameter as a bias so the optimizer does not weight-decay
        # the interpretable group prior toward an arbitrary scale.
        self.group_bias = nn.Parameter(
            torch.full(
                (self.num_modalities, 2),
                initial_group_logit,
            )
        )

    def forward(
        self,
        candidate,
        sample_context,
        observed_mask,
        retrieval_diagnostics,
        modality_index,
    ):
        if not 0 <= modality_index < self.num_modalities:
            raise ValueError("modality_index is out of range")

        observed, quality, quality_vector = self._prepare_quality(
            candidate,
            sample_context,
            observed_mask,
            retrieval_diagnostics,
        )
        group_index = observed.long().clamp(min=0, max=1)
        group_logit = self.group_bias[modality_index, group_index]
        raw_residual = self.network(quality_vector).squeeze(-1)
        residual_logit = self.max_residual_logit * torch.tanh(
            raw_residual / self.max_residual_logit
        )
        scale_logit = group_logit + residual_logit
        reliability = torch.sigmoid(scale_logit)
        multiplier = self.min_scale + (
            (1.0 - self.min_scale) * reliability
        )
        prior_reliability = torch.sigmoid(group_logit)
        prior_scale = self.min_scale + (
            (1.0 - self.min_scale) * prior_reliability
        )

        calibrated = candidate * multiplier.unsqueeze(-1).detach()
        diagnostics = {
            "reliability": reliability.detach(),
            "multiplier": multiplier.detach(),
            # This is the explicit optimization path used by the V2.4 teacher.
            "scale_prediction": multiplier,
            "prior_scale": prior_scale.detach(),
            "residual_logit": residual_logit.detach(),
            "observed": observed.detach(),
            "quality": {
                name: value.detach() for name, value in quality.items()
                if name != "observed"
            },
        }
        return calibrated, diagnostics
