"""Improvement 18: privileged disentangled representation purification.

The complete-view branch is training-only.  At inference the adapter predicts a
small residual from the incomplete-view features already produced by the
retained first+seventh+FPFR model.  Only missing enhanced modality tokens are
changed, and zero-initialized scales make the initial model exactly FPFR.
"""

import torch
from torch import nn
import torch.nn.functional as F


class PrivilegedDisentangledPurification(nn.Module):
    MODALITIES = 3

    def __init__(
        self,
        embedding_dim,
        hidden_dim=128,
        subspace_dim=64,
        max_scale=1.0,
    ):
        super().__init__()
        if embedding_dim < 1 or hidden_dim < 1 or subspace_dim < 1:
            raise ValueError("PDRP dimensions must be positive")
        if max_scale <= 0:
            raise ValueError("max_scale must be positive")
        self.embedding_dim = int(embedding_dim)
        self.subspace_dim = int(subspace_dim)
        self.max_scale = float(max_scale)

        def projector():
            return nn.Sequential(
                nn.LayerNorm(self.embedding_dim),
                nn.Linear(self.embedding_dim, hidden_dim),
                nn.GELU(),
                nn.Linear(hidden_dim, self.subspace_dim),
            )

        self.shared_projectors = nn.ModuleList(
            projector() for _ in range(self.MODALITIES)
        )
        self.complementary_projectors = nn.ModuleList(
            projector() for _ in range(self.MODALITIES)
        )
        context_dim = (
            4 * self.embedding_dim
            + 2 * self.subspace_dim
            + self.MODALITIES
        )
        self.residual_predictors = nn.ModuleList(
            nn.Sequential(
                nn.LayerNorm(context_dim),
                nn.Linear(context_dim, hidden_dim),
                nn.GELU(),
                nn.Linear(hidden_dim, self.embedding_dim),
            )
            for _ in range(self.MODALITIES)
        )
        self.injection_scale_logits = nn.Parameter(
            torch.zeros(self.MODALITIES)
        )

    def reset_identity(self):
        with torch.no_grad():
            self.injection_scale_logits.zero_()

    def _validate(self, features, batch_size, name):
        if len(features) != self.MODALITIES:
            raise ValueError("{} must contain three tensors".format(name))
        expected = (batch_size, self.embedding_dim)
        for index, feature in enumerate(features):
            if feature.shape != expected:
                raise ValueError(
                    "{}[{}] must have shape {}, got {}".format(
                        name, index, expected, tuple(feature.shape)
                    )
                )

    def forward(
        self,
        sample_representation,
        enhanced_features,
        raw_features,
        observed_mask,
    ):
        if sample_representation.ndim != 2:
            raise ValueError("sample_representation must be 2D")
        batch_size = sample_representation.shape[0]
        if sample_representation.shape[1] != self.embedding_dim:
            raise ValueError("sample representation dimension mismatch")
        self._validate(enhanced_features, batch_size, "enhanced_features")
        self._validate(raw_features, batch_size, "raw_features")
        if observed_mask.shape != (batch_size, self.MODALITIES):
            raise ValueError("observed_mask must have shape [batch, 3]")

        availability = observed_mask.to(
            device=sample_representation.device,
            dtype=sample_representation.dtype,
        )
        if torch.any((availability != 0) & (availability != 1)):
            raise ValueError("observed_mask values must be binary")
        observed_count = availability.sum(dim=1, keepdim=True).clamp_min(1.0)
        observed_enhanced = sum(
            feature * availability[:, index:index + 1]
            for index, feature in enumerate(enhanced_features)
        ) / observed_count
        observed_raw = sum(
            feature * availability[:, index:index + 1]
            for index, feature in enumerate(raw_features)
        ) / observed_count

        shared = torch.stack(
            [
                projector(enhanced_features[index])
                for index, projector in enumerate(self.shared_projectors)
            ],
            dim=1,
        )
        complementary = torch.stack(
            [
                projector(enhanced_features[index])
                for index, projector in enumerate(
                    self.complementary_projectors
                )
            ],
            dim=1,
        )
        scales = self.max_scale * torch.tanh(self.injection_scale_logits)
        corrected = []
        residuals = []
        injected = []
        for index in range(self.MODALITIES):
            context = torch.cat(
                (
                    sample_representation,
                    enhanced_features[index],
                    observed_enhanced,
                    observed_raw,
                    shared[:, index],
                    complementary[:, index],
                    availability,
                ),
                dim=1,
            )
            residual = self.residual_predictors[index](context)
            missing = 1.0 - availability[:, index:index + 1]
            addition = missing * scales[index] * residual
            corrected.append(enhanced_features[index] + addition)
            residuals.append(residual)
            injected.append(addition)

        residuals = torch.stack(residuals, dim=1)
        injected = torch.stack(injected, dim=1)
        diagnostics = {
            "enabled": True,
            "eligible": 1.0 - availability,
            "eligible_count": (1.0 - availability).sum().detach(),
            "shared": shared,
            "complementary": complementary,
            "residuals": residuals,
            "scales": scales.detach(),
            "residual_norm": residuals.norm(dim=-1).mean().detach(),
            "injected_norm": injected.norm(dim=-1).mean().detach(),
        }
        return tuple(corrected), diagnostics


def privileged_disentangled_objective(
    student_diagnostics,
    teacher_diagnostics,
    separation_margin=1.0,
):
    """Align missing shared factors and quarantine complementary factors.

    The shared target is the normalized complete-view consensus.  Orthogonality
    and margin losses follow the paper's shared/complementary decomposition but
    are evaluated only inside the isolated adapter.
    """
    if separation_margin < 0:
        raise ValueError("separation_margin must be non-negative")
    for diagnostics in (student_diagnostics, teacher_diagnostics):
        if not diagnostics.get("enabled", False):
            raise ValueError("enabled PDRP diagnostics are required")

    student_shared = student_diagnostics["shared"]
    student_complementary = student_diagnostics["complementary"]
    teacher_shared = teacher_diagnostics["shared"].detach()
    eligible = student_diagnostics["eligible"].bool()
    zero = student_shared.sum() * 0.0

    teacher_consensus = F.normalize(
        teacher_shared, p=2, dim=-1, eps=1e-8
    ).mean(dim=1)
    teacher_consensus = F.normalize(
        teacher_consensus, p=2, dim=-1, eps=1e-8
    )
    normalized_student = F.normalize(
        student_shared, p=2, dim=-1, eps=1e-8
    )
    expanded_target = teacher_consensus.unsqueeze(1).expand_as(
        normalized_student
    )
    if eligible.any():
        shared_loss = (
            1.0
            - (normalized_student * expanded_target).sum(dim=-1)[eligible]
        ).mean()
        orthogonality_loss = (
            F.cosine_similarity(
                student_shared[eligible],
                student_complementary[eligible],
                dim=-1,
                eps=1e-8,
            ).pow(2).mean()
        )
    else:
        shared_loss = zero
        orthogonality_loss = zero

    pair_losses = []
    for left, right in ((0, 1), (0, 2), (1, 2)):
        distance = torch.norm(
            student_complementary[:, left]
            - student_complementary[:, right],
            dim=-1,
        )
        pair_losses.append(F.relu(separation_margin - distance))
    separation_loss = torch.stack(pair_losses, dim=1).mean()
    diagnostics = {
        "eligible_count": eligible.float().sum().detach(),
        "shared_cosine": (
            (normalized_student * expanded_target).sum(dim=-1)[eligible]
            .mean().detach() if eligible.any() else zero.detach()
        ),
        "orthogonality": orthogonality_loss.detach(),
        "separation": separation_loss.detach(),
    }
    return shared_loss, orthogonality_loss, separation_loss, diagnostics
