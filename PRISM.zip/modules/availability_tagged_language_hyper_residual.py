"""Improvement 19: availability-tagged language-dominated hyper residual.

Language is the only query.  Enhanced and raw audio/video features form the
auxiliary token set, while explicit availability tags distinguish observed
evidence from missing-aware enhanced estimates.  A zero-initialized residual
scale preserves the retained first+seventh+FPFR model exactly at epoch zero.
"""

import math

import torch
from torch import nn


class AvailabilityTaggedLanguageHyperResidual(nn.Module):
    MODALITIES = 3
    TEXT_INDEX = 0
    AUDIO_INDEX = 1
    VIDEO_INDEX = 2
    AUXILIARY_TOKENS = 4

    def __init__(
        self,
        embedding_dim,
        hidden_dim=128,
        max_scale=0.5,
        mode='language_query',
    ):
        super().__init__()
        if embedding_dim < 1 or hidden_dim < 1:
            raise ValueError("AT-LDHR dimensions must be positive")
        if max_scale <= 0:
            raise ValueError("max_scale must be positive")
        if mode not in ('availability_only', 'language_query'):
            raise ValueError("unknown AT-LDHR mode: {}".format(mode))

        self.embedding_dim = int(embedding_dim)
        self.max_scale = float(max_scale)
        self.mode = mode
        self.query_projection = nn.Linear(
            self.embedding_dim, self.embedding_dim
        )
        self.key_projection = nn.Linear(
            self.embedding_dim, self.embedding_dim
        )
        self.value_projection = nn.Linear(
            self.embedding_dim, self.embedding_dim
        )
        self.token_embeddings = nn.Parameter(
            torch.empty(self.AUXILIARY_TOKENS, self.embedding_dim)
        )
        self.availability_embeddings = nn.Parameter(
            torch.empty(2, self.embedding_dim)
        )
        self.availability_logits = nn.Parameter(
            torch.zeros(self.AUXILIARY_TOKENS, 2)
        )
        self.residual_predictor = nn.Sequential(
            nn.LayerNorm(3 * self.embedding_dim + self.MODALITIES),
            nn.Linear(3 * self.embedding_dim + self.MODALITIES, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, self.embedding_dim),
        )
        self.injection_scale_logit = nn.Parameter(torch.zeros(()))
        nn.init.normal_(self.token_embeddings, mean=0.0, std=0.02)
        nn.init.normal_(self.availability_embeddings, mean=0.0, std=0.02)

    def reset_identity(self):
        with torch.no_grad():
            self.injection_scale_logit.zero_()

    def _validate_features(self, features, batch_size, name):
        if len(features) != self.MODALITIES:
            raise ValueError("{} must contain three tensors".format(name))
        expected = (batch_size, self.embedding_dim)
        for index, feature in enumerate(features):
            if feature.shape != expected:
                raise ValueError(
                    "{}[{}] must have shape {}, got {}".format(
                        name, index, expected, tuple(feature.shape)
                    )
                )

    def forward(
        self,
        sample_representation,
        enhanced_features,
        raw_features,
        observed_mask,
    ):
        if sample_representation.ndim != 2:
            raise ValueError("sample_representation must be 2D")
        batch_size = sample_representation.shape[0]
        if sample_representation.shape[1] != self.embedding_dim:
            raise ValueError("sample representation dimension mismatch")
        self._validate_features(
            enhanced_features, batch_size, "enhanced_features"
        )
        self._validate_features(raw_features, batch_size, "raw_features")
        if observed_mask.shape != (batch_size, self.MODALITIES):
            raise ValueError("observed_mask must have shape [batch, 3]")

        availability = observed_mask.to(
            device=sample_representation.device,
            dtype=sample_representation.dtype,
        )
        if torch.any((availability != 0) & (availability != 1)):
            raise ValueError("observed_mask values must be binary")
        status = availability.long()
        auxiliary = torch.stack(
            (
                enhanced_features[self.AUDIO_INDEX],
                enhanced_features[self.VIDEO_INDEX],
                raw_features[self.AUDIO_INDEX],
                raw_features[self.VIDEO_INDEX],
            ),
            dim=1,
        )
        auxiliary_status = torch.stack(
            (
                status[:, self.AUDIO_INDEX],
                status[:, self.VIDEO_INDEX],
                status[:, self.AUDIO_INDEX],
                status[:, self.VIDEO_INDEX],
            ),
            dim=1,
        )
        tagged = (
            auxiliary
            + self.token_embeddings.unsqueeze(0)
            + self.availability_embeddings[auxiliary_status]
        )
        available_logits = self.availability_logits.unsqueeze(0).expand(
            batch_size, -1, -1
        ).gather(2, auxiliary_status.unsqueeze(-1)).squeeze(-1)
        if self.mode == 'language_query':
            query = self.query_projection(
                enhanced_features[self.TEXT_INDEX]
            )
            keys = self.key_projection(tagged)
            content_logits = torch.einsum(
                'bd,btd->bt', query, keys
            ) / math.sqrt(self.embedding_dim)
            logits = available_logits + content_logits
        else:
            logits = available_logits

        # Missing raw features are exact zeros and must never become learned
        # pseudo-observations through their tag embeddings.  Missing enhanced
        # features remain eligible because they contain the retained IIE
        # missing-aware retrieval and seventh-improvement estimates.
        valid_tokens = torch.ones_like(auxiliary_status, dtype=torch.bool)
        valid_tokens[:, 2] = auxiliary_status[:, 2].bool()
        valid_tokens[:, 3] = auxiliary_status[:, 3].bool()
        logits = logits.masked_fill(~valid_tokens, torch.finfo(logits.dtype).min)
        attention = torch.softmax(logits, dim=1)
        values = self.value_projection(tagged)
        hyper = torch.sum(attention.unsqueeze(-1) * values, dim=1)

        language = enhanced_features[self.TEXT_INDEX]
        residual = self.residual_predictor(
            torch.cat(
                (language, hyper, sample_representation, availability),
                dim=1,
            )
        )
        scale = self.max_scale * torch.tanh(self.injection_scale_logit)
        eligible = availability[:, self.TEXT_INDEX:self.TEXT_INDEX + 1]
        addition = eligible * scale * residual
        corrected = list(enhanced_features)
        corrected[self.TEXT_INDEX] = language + addition

        diagnostics = {
            'enabled': True,
            'mode': self.mode,
            'attention': attention.detach(),
            'attention_entropy': (
                -(attention * attention.clamp_min(1e-8).log()).sum(dim=1)
                .mean().detach()
            ),
            'eligible_count': eligible.sum().detach(),
            'scale': scale.detach(),
            'residual_norm': residual.norm(dim=1).mean().detach(),
            'injected_norm': addition.norm(dim=1).mean().detach(),
        }
        return tuple(corrected), diagnostics
