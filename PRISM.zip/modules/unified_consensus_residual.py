"""Frozen failed improvement-9 unified consensus residual ablation.

The module borrows UniMF's MMSeq idea without reconstructing a missing
modality or replacing IIE's proven fusion head.  One consensus token reads
the seven frozen IIE representations and predicts an additive sentiment
residual.  Missing raw-modality tokens are masked, while their retrieval-
enhanced counterparts remain visible.  It is retained only for exact
reproduction and is not part of the active first+seventh foundation.
"""

import torch
from torch import nn


class _ConsensusLayer(nn.Module):
    def __init__(self, embedding_dim, num_heads, dropout):
        super().__init__()
        self.query_norm = nn.LayerNorm(embedding_dim)
        self.token_norm = nn.LayerNorm(embedding_dim)
        self.attention = nn.MultiheadAttention(
            embedding_dim,
            num_heads,
            dropout=dropout,
        )
        self.attention_dropout = nn.Dropout(dropout)
        self.ffn_norm = nn.LayerNorm(embedding_dim)
        self.ffn = nn.Sequential(
            nn.Linear(embedding_dim, embedding_dim * 2),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(embedding_dim * 2, embedding_dim),
        )
        self.ffn_dropout = nn.Dropout(dropout)

    def forward(self, query, tokens, key_padding_mask):
        update, attention = self.attention(
            self.query_norm(query),
            self.token_norm(tokens),
            self.token_norm(tokens),
            key_padding_mask=key_padding_mask,
            need_weights=True,
        )
        query = query + self.attention_dropout(update)
        query = query + self.ffn_dropout(self.ffn(self.ffn_norm(query)))
        return query, attention


class AvailabilityMaskedUnifiedConsensusResidual(nn.Module):
    """Read seven IIE branches with a UniMF-inspired consensus token."""

    NUM_REPRESENTATIONS = 7

    def __init__(
        self,
        embedding_dim,
        output_dim=1,
        num_heads=4,
        num_layers=2,
        hidden_dim=96,
        dropout=0.1,
    ):
        super().__init__()
        if embedding_dim < 1:
            raise ValueError("embedding_dim must be positive")
        if num_heads < 1 or embedding_dim % num_heads:
            raise ValueError("num_heads must evenly divide embedding_dim")
        if num_layers < 1:
            raise ValueError("num_layers must be positive")
        if hidden_dim < 1:
            raise ValueError("hidden_dim must be positive")
        if not 0.0 <= dropout < 1.0:
            raise ValueError("dropout must be in [0, 1)")

        self.embedding_dim = embedding_dim
        self.output_dim = output_dim
        self.consensus_token = nn.Parameter(torch.zeros(1, 1, embedding_dim))
        self.branch_embedding = nn.Embedding(3, embedding_dim)
        self.modality_embedding = nn.Embedding(4, embedding_dim)
        self.availability_embedding = nn.Embedding(2, embedding_dim)
        self.observed_count_embedding = nn.Embedding(4, embedding_dim)
        self.layers = nn.ModuleList([
            _ConsensusLayer(embedding_dim, num_heads, dropout)
            for _ in range(num_layers)
        ])
        self.output_norm = nn.LayerNorm(embedding_dim)
        self.residual_head = nn.Sequential(
            nn.Linear(embedding_dim, hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, output_dim),
        )

        self.register_buffer(
            "branch_indices",
            torch.tensor([0, 1, 1, 1, 2, 2, 2], dtype=torch.long),
        )
        self.register_buffer(
            "modality_indices",
            torch.tensor([0, 1, 2, 3, 1, 2, 3], dtype=torch.long),
        )
        self.reset_identity()

    def reset_identity(self):
        """Make the complete adapter an exact additive identity at epoch 0."""
        final_layer = self.residual_head[-1]
        nn.init.zeros_(final_layer.weight)
        nn.init.zeros_(final_layer.bias)

    def _validate_inputs(self, representations, observed_mask, base_prediction):
        if len(representations) != self.NUM_REPRESENTATIONS:
            raise ValueError("AMUCR requires exactly seven representations")
        reference = representations[0]
        if reference.dim() != 2 or reference.size(1) != self.embedding_dim:
            raise ValueError("representations must have shape [batch, embedding_dim]")
        for representation in representations[1:]:
            if representation.shape != reference.shape:
                raise ValueError("all seven representations must share one shape")
        if observed_mask.shape != (reference.size(0), 3):
            raise ValueError("observed_mask must have shape [batch, 3]")
        availability = observed_mask.to(device=reference.device)
        if torch.any((availability != 0) & (availability != 1)):
            raise ValueError("observed_mask values must be binary")
        if torch.any(availability.sum(dim=1) == 0):
            raise ValueError("each sample must contain at least one observed modality")
        if base_prediction.shape != (reference.size(0), self.output_dim):
            raise ValueError("base_prediction has an incompatible shape")
        return availability.long()

    def forward(self, representations, observed_mask, base_prediction):
        availability = self._validate_inputs(
            representations, observed_mask, base_prediction
        )
        batch_size = base_prediction.size(0)
        tokens = torch.stack(tuple(representations), dim=0)

        branch = self.branch_embedding(self.branch_indices).unsqueeze(1)
        modality = self.modality_embedding(self.modality_indices).unsqueeze(1)
        token_availability = torch.cat(
            (
                availability.new_ones((batch_size, 1)),
                availability,
                availability,
            ),
            dim=1,
        )
        availability_embedding = self.availability_embedding(
            token_availability
        ).transpose(0, 1)
        tokens = tokens + branch + modality + availability_embedding

        observed_count = availability.sum(dim=1)
        query = self.consensus_token.expand(1, batch_size, -1)
        query = query + self.observed_count_embedding(observed_count).unsqueeze(0)

        # Keep sample and retrieval-enhanced tokens visible.  Only raw tokens
        # from actually missing modalities are excluded from consensus.
        key_padding_mask = torch.zeros(
            (batch_size, self.NUM_REPRESENTATIONS),
            dtype=torch.bool,
            device=base_prediction.device,
        )
        key_padding_mask[:, 4:7] = ~availability.bool()

        attention = None
        for layer in self.layers:
            query, attention = layer(query, tokens, key_padding_mask)

        consensus = self.output_norm(query.squeeze(0))
        residual = self.residual_head(consensus)
        prediction = base_prediction + residual
        diagnostics = {
            "enabled": True,
            "residual": residual.detach(),
            "residual_abs_mean": residual.detach().abs().mean(),
            "attention_mean": attention.detach().mean(dim=0).squeeze(0),
            "raw_masked_fraction": (
                (~availability.bool()).float().mean().detach()
            ),
        }
        return prediction, diagnostics
