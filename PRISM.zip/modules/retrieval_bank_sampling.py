"""Deterministic finite-bank selection for the formal E15 study."""

import hashlib

import torch


def deterministic_retrieval_bank_subset_indices(
    sample_ids, requested_size=0, subset_seed=3407
):
    """Return a stable nested subset ranked only by training sample identity.

    ``requested_size=0`` denotes the complete split and deliberately preserves
    its original ordering for exact compatibility with the frozen E06 M1 runs.
    Finite sizes are prefixes of one SHA-256 ordering, making the experimental
    banks nested and independent of DataLoader order or global RNG state.
    """
    flat_ids = sample_ids.detach().view(-1).cpu().to(torch.long)
    requested_size = int(requested_size)
    subset_seed = int(subset_seed)
    if requested_size < 0:
        raise ValueError("retrieval reference-bank size cannot be negative")
    if subset_seed < 0:
        raise ValueError("retrieval reference-bank seed cannot be negative")
    if requested_size > flat_ids.numel():
        raise ValueError(
            "retrieval reference-bank size {} exceeds training split {}".format(
                requested_size, flat_ids.numel()
            )
        )
    if requested_size == 0 or requested_size == flat_ids.numel():
        return torch.arange(flat_ids.numel(), dtype=torch.long)

    identifiers = [int(value) for value in flat_ids.tolist()]
    ranked = sorted(
        range(len(identifiers)),
        key=lambda index: (
            hashlib.sha256(
                "{}:{}".format(subset_seed, identifiers[index]).encode("ascii")
            ).digest(),
            identifiers[index],
        ),
    )
    return torch.tensor(ranked[:requested_size], dtype=torch.long)
