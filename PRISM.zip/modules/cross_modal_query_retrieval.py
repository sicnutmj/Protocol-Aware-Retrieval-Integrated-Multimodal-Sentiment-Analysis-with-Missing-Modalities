"""Availability-guided cross-modal queries for frozen q0 retrieval.

The module never injects a generated modality directly into IIE.  Available
modalities predict a query in a missing target modality's space, that query
retrieves real target representations from a train-only reference bank, and a
zero-initialized scalar mixes the retrieved slots with q0's original fallback.
"""

import torch
from torch import nn
import torch.nn.functional as F


MODALITIES = ("l", "a", "v")


class AvailabilityGuidedCrossModalQueryRetrieval(nn.Module):
    def __init__(
        self,
        embedding_dim,
        hidden_dim=128,
        top_k=2,
        temperature=0.1,
        match_temperature=0.1,
    ):
        super().__init__()
        if embedding_dim < 1 or hidden_dim < 1:
            raise ValueError("embedding dimensions must be positive")
        if top_k < 1:
            raise ValueError("top_k must be positive")
        if temperature <= 0 or match_temperature <= 0:
            raise ValueError("temperatures must be positive")

        self.embedding_dim = embedding_dim
        self.top_k = top_k
        self.temperature = temperature
        self.match_temperature = match_temperature
        self.mappers = nn.ModuleDict({
            "{}_to_{}".format(source, target): nn.Sequential(
                nn.Linear(embedding_dim, hidden_dim),
                nn.ReLU(),
                nn.Linear(hidden_dim, embedding_dim),
            )
            for source in MODALITIES
            for target in MODALITIES
            if source != target
        })
        # Directly clamped parameters give an exact zero at initialization and
        # a non-zero one-sided gradient when retrieval improves task loss.
        self.mix_parameters = nn.Parameter(torch.zeros(3))
        for modality in MODALITIES:
            self.register_buffer(
                "bank_{}".format(modality),
                torch.empty(0, embedding_dim),
                persistent=False,
            )

    def reset_identity(self):
        with torch.no_grad():
            self.mix_parameters.zero_()

    def set_reference_banks(self, banks):
        for modality in MODALITIES:
            if modality not in banks:
                raise ValueError("reference bank is missing {}".format(modality))
            bank = banks[modality]
            if bank.ndim != 2 or bank.size(1) != self.embedding_dim:
                raise ValueError(
                    "{} bank must have shape [items, {}]".format(
                        modality, self.embedding_dim
                    )
                )
            if bank.size(0) < self.top_k:
                raise ValueError(
                    "{} bank needs at least {} items".format(
                        modality, self.top_k
                    )
                )
            setattr(
                self,
                "bank_{}".format(modality),
                bank.detach().clone(),
            )

    def reference_bank_sizes(self):
        return {
            modality: int(getattr(self, "bank_{}".format(modality)).size(0))
            for modality in MODALITIES
        }

    def _cross_modal_query(self, raw_features, observed_mask, target_index):
        target = MODALITIES[target_index]
        mapped = []
        weights = []
        for source_index, source in enumerate(MODALITIES):
            if source_index == target_index:
                continue
            source_observed = observed_mask[:, source_index].to(
                dtype=raw_features[source_index].dtype
            )
            mapped.append(
                self.mappers["{}_to_{}".format(source, target)](
                    raw_features[source_index]
                )
                * source_observed.unsqueeze(1)
            )
            weights.append(source_observed)
        query = torch.stack(mapped, dim=0).sum(dim=0)
        source_count = torch.stack(weights, dim=0).sum(dim=0)
        query = query / source_count.clamp_min(1.0).unsqueeze(1)
        query = F.normalize(query, dim=-1, eps=1e-8)
        return query, source_count > 0

    def _retrieve(self, query, bank, exclude_target=None):
        normalized_bank = F.normalize(bank, dim=-1, eps=1e-8)
        similarities = query @ normalized_bank.transpose(0, 1)
        if exclude_target is not None:
            target_similarity = (
                F.normalize(exclude_target, dim=-1, eps=1e-8)
                @ normalized_bank.transpose(0, 1)
            )
            self_values, self_indices = target_similarity.max(
                dim=1, keepdim=True
            )
            # A subsampled bank does not contain every training item.  Exclude
            # only an effectively identical representation, not merely the
            # closest unrelated reference.
            self_mask = torch.zeros_like(similarities, dtype=torch.bool)
            self_mask.scatter_(1, self_indices, self_values > 1.0 - 1e-5)
            similarities = similarities.masked_fill(
                self_mask, float("-inf")
            )
        values, indices = torch.topk(
            similarities,
            k=min(self.top_k, bank.size(0)),
            dim=1,
            largest=True,
            sorted=True,
        )
        selected = bank[indices]
        weights = F.softmax(values / self.temperature, dim=1)
        # Match q0's slot scale: uniform neighbours retain unit slot weights.
        slot_weights = weights * selected.size(1)
        selected = selected * slot_weights.unsqueeze(-1)
        return selected, values, indices

    def _matching_loss(self, query, complete_target, eligible):
        if complete_target is None or int(eligible.sum().item()) < 2:
            return query.sum() * 0.0
        selected_query = query[eligible]
        selected_target = F.normalize(
            complete_target.detach()[eligible], dim=-1, eps=1e-8
        )
        logits = (
            selected_query @ selected_target.transpose(0, 1)
        ) / self.match_temperature
        labels = torch.arange(logits.size(0), device=logits.device)
        return F.cross_entropy(logits, labels)

    def forward(
        self,
        raw_features,
        observed_mask,
        base_retrieved,
        complete_targets=None,
    ):
        if len(raw_features) != 3 or len(base_retrieved) != 3:
            raise ValueError("AGCQR expects three raw and retrieved modalities")
        observed_mask = observed_mask.to(dtype=torch.bool)
        if observed_mask.ndim != 2 or observed_mask.size(1) != 3:
            raise ValueError("observed_mask must have shape [batch, 3]")
        if complete_targets is not None and len(complete_targets) != 3:
            raise ValueError("complete_targets must contain three modalities")

        mixed_retrieved = []
        losses = []
        eligible_counts = []
        top1_similarities = []
        mix_scales = self.mix_parameters.clamp(min=0.0, max=1.0)

        for target_index, target in enumerate(MODALITIES):
            bank = getattr(self, "bank_{}".format(target))
            if bank.size(0) < self.top_k:
                raise RuntimeError(
                    "AGCQR reference bank for {} has not been built".format(
                        target
                    )
                )
            query, has_source = self._cross_modal_query(
                raw_features, observed_mask, target_index
            )
            missing = ~observed_mask[:, target_index]
            eligible = missing & has_source
            complete_target = (
                None
                if complete_targets is None
                else complete_targets[target_index]
            )
            selected, similarities, _ = self._retrieve(
                query,
                bank,
                exclude_target=(complete_target if self.training else None),
            )
            base = base_retrieved[target_index]
            candidate = base.clone()
            neighbour_count = min(self.top_k, candidate.size(1) - 2)
            candidate[:, 1:1 + neighbour_count] = selected[:, :neighbour_count]
            candidate[:, -1] = bank.mean(dim=0)
            mask = eligible.view(-1, 1, 1).to(dtype=base.dtype)
            delta = (candidate - base) * mask
            mixed_retrieved.append(base + mix_scales[target_index] * delta)
            losses.append(
                self._matching_loss(query, complete_target, eligible)
            )
            eligible_counts.append(eligible.sum().detach())
            if bool(eligible.any()):
                top1_similarities.append(
                    similarities[eligible, 0].mean().detach()
                )
            else:
                top1_similarities.append(base.new_zeros(()))

        query_loss = torch.stack(losses).mean()
        diagnostics = {
            "enabled": True,
            "query_loss": query_loss.detach(),
            "mix_scales": mix_scales.detach(),
            "eligible_count": torch.stack(eligible_counts),
            "top1_similarity": torch.stack(top1_similarities),
            "bank_sizes": torch.tensor(
                [
                    getattr(self, "bank_{}".format(modality)).size(0)
                    for modality in MODALITIES
                ],
                device=observed_mask.device,
                dtype=torch.long,
            ),
        }
        return tuple(mixed_retrieved), query_loss, diagnostics
