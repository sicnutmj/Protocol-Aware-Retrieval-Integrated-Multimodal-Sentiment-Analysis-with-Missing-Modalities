"""Frozen failed sixth ablation: availability-aware multi-stage fusion.

This module is retained only to reproduce the August 6, 2026 experiment.  It
is not part of the active q0 baseline and must be enabled explicitly through
``--fusion_mode=availability_multistage``.
"""

import torch
from torch import nn


class AvailabilityAwareMultiStageFusion(nn.Module):
    """Frozen ablation that fuses unimodal, bimodal, and trimodal stages.

    Each modality node retains both the raw IIE representation and its
    retrieval-enhanced representation.  The availability flag is supplied at
    every stage so reconstructed/missing branches cannot be confused with
    genuinely observed inputs.  A pair containing no observed modality is
    excluded from the weighted bimodal and trimodal summaries.
    """

    MODALITY_PAIRS = ((0, 1), (0, 2), (1, 2))
    REMAINING_MODALITIES = (2, 1, 0)

    def __init__(self, embedding_dim, output_dim=1, dropout=0.1):
        super().__init__()
        if embedding_dim < 1:
            raise ValueError("embedding_dim must be positive")
        if output_dim < 1:
            raise ValueError("output_dim must be positive")

        self.embedding_dim = int(embedding_dim)
        hidden_score_dim = max(16, self.embedding_dim // 2)

        self.modality_projectors = nn.ModuleList(
            self._projection(2 * self.embedding_dim + 1)
            for _ in range(3)
        )
        self.pair_projection = self._projection(2 * self.embedding_dim + 2)
        self.trimodal_projection = self._projection(
            2 * self.embedding_dim + 3
        )
        self.pair_embeddings = nn.Embedding(3, self.embedding_dim)
        self.trimodal_path_embeddings = nn.Embedding(3, self.embedding_dim)

        self.unimodal_score = self._score_network(
            self.embedding_dim + 1, hidden_score_dim
        )
        self.bimodal_score = self._score_network(
            self.embedding_dim + 1, hidden_score_dim
        )
        self.trimodal_score = self._score_network(
            self.embedding_dim + 1, hidden_score_dim
        )

        self.classifier = nn.Sequential(
            nn.Linear(4 * self.embedding_dim, 3 * self.embedding_dim),
            nn.Dropout(dropout),
            nn.ReLU(),
            nn.Linear(3 * self.embedding_dim, output_dim),
        )

    def _projection(self, input_dim):
        return nn.Sequential(
            nn.Linear(input_dim, self.embedding_dim),
            nn.LayerNorm(self.embedding_dim),
            nn.GELU(),
        )

    @staticmethod
    def _score_network(input_dim, hidden_dim):
        return nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.Tanh(),
            nn.Linear(hidden_dim, 1),
        )

    @staticmethod
    def _validate_features(name, features, batch_size, embedding_dim):
        if len(features) != 3:
            raise ValueError("{} must contain exactly three tensors".format(name))
        expected = (batch_size, embedding_dim)
        for feature in features:
            if feature.shape != expected:
                raise ValueError(
                    "{} tensors must have shape {}, got {}".format(
                        name, expected, tuple(feature.shape)
                    )
                )

    @staticmethod
    def _weighted_summary(values, scores, valid=None):
        if valid is not None:
            scores = scores.masked_fill(~valid, torch.finfo(scores.dtype).min)
        weights = torch.softmax(scores, dim=1)
        if valid is not None:
            weights = weights * valid.to(weights.dtype)
            weights = weights / weights.sum(dim=1, keepdim=True).clamp_min(1e-12)
        summary = (values * weights.unsqueeze(-1)).sum(dim=1)
        return summary, weights

    def forward(
        self,
        sample_representation,
        enhanced_features,
        raw_features,
        observed_mask,
    ):
        if sample_representation.ndim != 2:
            raise ValueError("sample_representation must be a 2D tensor")
        batch_size, embedding_dim = sample_representation.shape
        if embedding_dim != self.embedding_dim:
            raise ValueError(
                "sample_representation dimension must be {}, got {}".format(
                    self.embedding_dim, embedding_dim
                )
            )
        self._validate_features(
            "enhanced_features", enhanced_features, batch_size, embedding_dim
        )
        self._validate_features(
            "raw_features", raw_features, batch_size, embedding_dim
        )
        if observed_mask.shape != (batch_size, 3):
            raise ValueError(
                "observed_mask must have shape [{}, 3]".format(batch_size)
            )

        availability = observed_mask.to(
            device=sample_representation.device,
            dtype=sample_representation.dtype,
        )
        if torch.any((availability != 0) & (availability != 1)):
            raise ValueError("observed_mask values must be binary")
        if torch.any(availability.sum(dim=1) == 0):
            raise ValueError("each sample must contain at least one observed modality")

        modality_nodes = []
        for modality_index in range(3):
            status = availability[:, modality_index:modality_index + 1]
            node_input = torch.cat(
                (
                    raw_features[modality_index],
                    enhanced_features[modality_index],
                    status,
                ),
                dim=1,
            )
            modality_nodes.append(
                self.modality_projectors[modality_index](node_input)
            )
        modality_nodes = torch.stack(modality_nodes, dim=1)
        unimodal_scores = self.unimodal_score(
            torch.cat((modality_nodes, availability.unsqueeze(-1)), dim=2)
        ).squeeze(-1)
        unimodal_summary, unimodal_weights = self._weighted_summary(
            modality_nodes, unimodal_scores
        )

        pair_nodes = []
        pair_availability = []
        for pair_index, (left, right) in enumerate(self.MODALITY_PAIRS):
            pair_status = availability[:, (left, right)]
            pair_input = torch.cat(
                (modality_nodes[:, left], modality_nodes[:, right], pair_status),
                dim=1,
            )
            pair_node = self.pair_projection(pair_input)
            pair_node = pair_node + self.pair_embeddings.weight[pair_index]
            pair_nodes.append(pair_node)
            pair_availability.append(pair_status.sum(dim=1))
        pair_nodes = torch.stack(pair_nodes, dim=1)
        pair_availability = torch.stack(pair_availability, dim=1)
        pair_valid = pair_availability > 0
        bimodal_scores = self.bimodal_score(
            torch.cat((pair_nodes, pair_availability.unsqueeze(-1)), dim=2)
        ).squeeze(-1)
        bimodal_summary, bimodal_weights = self._weighted_summary(
            pair_nodes, bimodal_scores, pair_valid
        )

        trimodal_nodes = []
        total_observed = availability.sum(dim=1, keepdim=True)
        for path_index, remaining in enumerate(self.REMAINING_MODALITIES):
            trimodal_input = torch.cat(
                (
                    pair_nodes[:, path_index],
                    modality_nodes[:, remaining],
                    availability,
                ),
                dim=1,
            )
            trimodal_node = self.trimodal_projection(trimodal_input)
            trimodal_node = (
                trimodal_node + self.trimodal_path_embeddings.weight[path_index]
            )
            trimodal_nodes.append(trimodal_node)
        trimodal_nodes = torch.stack(trimodal_nodes, dim=1)
        trimodal_scores = self.trimodal_score(
            torch.cat(
                (
                    trimodal_nodes,
                    total_observed.unsqueeze(1).expand(-1, 3, -1),
                ),
                dim=2,
            )
        ).squeeze(-1)
        trimodal_summary, trimodal_weights = self._weighted_summary(
            trimodal_nodes, trimodal_scores, pair_valid
        )

        fusion_hidden = torch.cat(
            (
                sample_representation,
                unimodal_summary,
                bimodal_summary,
                trimodal_summary,
            ),
            dim=1,
        )
        output = self.classifier(fusion_hidden)
        diagnostics = {
            "unimodal_weights": unimodal_weights.detach(),
            "bimodal_weights": bimodal_weights.detach(),
            "trimodal_weights": trimodal_weights.detach(),
            "pair_valid": pair_valid.detach(),
        }
        return output, fusion_hidden, diagnostics
