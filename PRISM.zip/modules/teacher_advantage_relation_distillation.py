import copy

import torch
import torch.nn as nn
import torch.nn.functional as F


class FrozenLateFusionTeacher(nn.Module):
    """Training-only snapshot of the late fusion path.

    The feature foundation is shared with the student only through detached
    complete-view representations.  This compact snapshot is intentionally
    kept outside ``IIEModel`` so it is never serialized or used at inference.
    """

    def __init__(self, transformer_encoder, fusion_head):
        super().__init__()
        self.transformer_encoder = copy.deepcopy(transformer_encoder)
        self.fusion_head = copy.deepcopy(fusion_head)
        self.requires_grad_(False)
        self.eval()

    def train(self, mode=True):
        # A teacher snapshot must remain deterministic even when its owner
        # enters training mode.
        return super().train(False)

    @torch.no_grad()
    def forward(self, representations):
        if len(representations) != 7:
            raise ValueError(
                "late-fusion teacher expects seven representations, got {}"
                .format(len(representations))
            )
        hidden = torch.stack(tuple(representations), dim=0)
        hidden = self.transformer_encoder(hidden)
        enhanced_nodes = hidden[1:4].permute(1, 0, 2).contiguous()
        flattened = torch.cat(tuple(hidden[index] for index in range(7)), dim=1)
        prediction = self.fusion_head(flattened)
        return enhanced_nodes, prediction


def modality_relation_graph(nodes):
    """Return per-sample cosine graphs for three enhanced modality nodes."""
    if nodes.ndim != 3 or nodes.shape[1] != 3:
        raise ValueError(
            "modality nodes must have shape [batch, 3, dim], got {}"
            .format(tuple(nodes.shape))
        )
    normalized = F.normalize(nodes, p=2, dim=-1, eps=1e-8)
    return torch.matmul(normalized, normalized.transpose(1, 2))


def teacher_advantage_relation_distillation(
    student_flattened,
    teacher_nodes,
    student_prediction,
    teacher_prediction,
    labels,
    advantage_margin=0.0,
):
    """Align modality relations only where the complete teacher is better."""
    if advantage_margin < 0:
        raise ValueError("advantage_margin must be non-negative")
    if student_flattened.ndim != 2 or student_flattened.shape[1] % 7 != 0:
        raise ValueError(
            "student flattened fusion input must have shape [batch, 7*d]"
        )
    batch_size = student_flattened.shape[0]
    if teacher_nodes.shape[0] != batch_size:
        raise ValueError("teacher and student batch sizes must match")

    representation_dim = student_flattened.shape[1] // 7
    student_nodes = student_flattened.reshape(
        batch_size, 7, representation_dim
    )[:, 1:4]
    student_graph = modality_relation_graph(student_nodes)
    teacher_graph = modality_relation_graph(teacher_nodes.detach())

    targets = labels.detach().view(-1)
    student_values = student_prediction.detach().view(-1)
    teacher_values = teacher_prediction.detach().view(-1)
    if not (
        targets.numel() == student_values.numel() == teacher_values.numel()
    ):
        raise ValueError("prediction and label batch sizes must match")

    student_error = torch.abs(student_values - targets)
    teacher_error = torch.abs(teacher_values - targets)
    eligible = teacher_error + advantage_margin < student_error

    off_diagonal = ~torch.eye(
        3, dtype=torch.bool, device=student_graph.device
    )
    per_sample_loss = (
        (student_graph - teacher_graph).pow(2)[:, off_diagonal].mean(dim=1)
    )
    if eligible.any():
        loss = per_sample_loss[eligible].mean()
    else:
        loss = student_flattened.sum() * 0.0

    diagnostics = {
        'coverage': eligible.float().mean().detach(),
        'eligible_count': eligible.float().sum().detach(),
        'teacher_mae': teacher_error.mean().detach(),
        'student_mae': student_error.mean().detach(),
        'teacher_advantage': (
            student_error - teacher_error
        )[eligible].mean().detach() if eligible.any() else teacher_error.new_zeros(()),
        'relation_gap': torch.abs(
            student_graph.detach() - teacher_graph
        )[:, off_diagonal].mean().detach(),
    }
    return loss, diagnostics
