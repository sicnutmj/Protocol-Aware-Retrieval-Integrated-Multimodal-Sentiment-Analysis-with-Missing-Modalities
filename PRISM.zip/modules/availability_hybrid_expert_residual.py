"""Availability-constrained private/shared expert residual.

This is the conservative improvement-14 adaptation of DERL's Hybrid Expert
Disentanglement module.  It reads the three frozen IIE retrieval-enhanced
modality representations, routes each through modality-private and parameter-
shared experts, and predicts an additive sentiment residual.  The proven
first+seventh prediction remains the main path.

Unlike the paper's ambiguous raw-cosine "orthogonality" objective, this module
uses squared cosine similarity, whose minimum is genuinely orthogonal.  The
final residual projection is zero-initialized for an exact epoch-0 identity.
"""

import math

import torch
from torch import nn
import torch.nn.functional as F


class _TwoLayerExpert(nn.Module):
    def __init__(self, embedding_dim, hidden_dim, dropout):
        super().__init__()
        self.network = nn.Sequential(
            nn.Linear(embedding_dim, hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, embedding_dim),
        )

    def forward(self, features):
        return self.network(features)


class AvailabilityConstrainedHybridExpertResidual(nn.Module):
    """Route frozen modality features through private and shared experts."""

    NUM_MODALITIES = 3

    def __init__(
        self,
        embedding_dim,
        output_dim=1,
        hidden_dim=64,
        private_experts=3,
        shared_experts=3,
        dropout=0.1,
        initial_temperature=None,
    ):
        super().__init__()
        if embedding_dim < 1 or output_dim < 1 or hidden_dim < 1:
            raise ValueError("dimensions must be positive")
        if private_experts < 1 or shared_experts < 1:
            raise ValueError("private_experts and shared_experts must be positive")
        if not 0.0 <= dropout < 1.0:
            raise ValueError("dropout must be in [0, 1)")

        self.embedding_dim = embedding_dim
        self.output_dim = output_dim
        self.private_expert_count = private_experts
        self.shared_expert_count = shared_experts
        self.total_expert_count = private_experts + shared_experts

        if initial_temperature is None:
            initial_temperature = 1.0 / self.total_expert_count
        if initial_temperature <= 0:
            raise ValueError("initial_temperature must be positive")

        self.modality_norms = nn.ModuleList([
            nn.LayerNorm(embedding_dim)
            for _ in range(self.NUM_MODALITIES)
        ])
        self.sample_norm = nn.LayerNorm(embedding_dim)
        self.private_experts = nn.ModuleList([
            nn.ModuleList([
                _TwoLayerExpert(embedding_dim, hidden_dim, dropout)
                for _ in range(private_experts)
            ])
            for _ in range(self.NUM_MODALITIES)
        ])
        self.shared_experts = nn.ModuleList([
            _TwoLayerExpert(embedding_dim, hidden_dim, dropout)
            for _ in range(shared_experts)
        ])

        router_input_dim = embedding_dim * 2 + self.NUM_MODALITIES
        self.routers = nn.ModuleList([
            nn.Sequential(
                nn.Linear(router_input_dim, hidden_dim),
                nn.ReLU(),
                nn.Linear(hidden_dim, self.total_expert_count),
            )
            for _ in range(self.NUM_MODALITIES)
        ])

        residual_input_dim = embedding_dim * 7 + self.NUM_MODALITIES
        self.residual_head = nn.Sequential(
            nn.Linear(residual_input_dim, hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, output_dim),
        )

        # Softplus keeps the learned routing temperature strictly positive.
        raw_temperature = math.log(math.expm1(initial_temperature))
        self.raw_temperature = nn.Parameter(
            torch.tensor(raw_temperature, dtype=torch.float32)
        )
        self.reset_identity()

    @property
    def temperature(self):
        return F.softplus(self.raw_temperature) + 1e-6

    def reset_identity(self):
        final_layer = self.residual_head[-1]
        nn.init.zeros_(final_layer.weight)
        nn.init.zeros_(final_layer.bias)

    def identity_diagnostics(self):
        final_layer = self.residual_head[-1]
        return {
            "final_weight_max": final_layer.weight.detach().abs().max().item(),
            "final_bias_max": final_layer.bias.detach().abs().max().item(),
            "temperature": self.temperature.detach().item(),
        }

    def _validate_inputs(
        self, enhanced_modalities, sample_representation, observed_mask,
        base_prediction,
    ):
        if len(enhanced_modalities) != self.NUM_MODALITIES:
            raise ValueError("ACHER expects three enhanced modality features")
        reference = enhanced_modalities[0]
        expected_shape = (reference.size(0), self.embedding_dim)
        if reference.dim() != 2 or tuple(reference.shape) != expected_shape:
            raise ValueError(
                "enhanced modalities must have shape [batch, embedding_dim]"
            )
        for features in enhanced_modalities[1:]:
            if tuple(features.shape) != expected_shape:
                raise ValueError("all enhanced modalities must share one shape")
        if tuple(sample_representation.shape) != expected_shape:
            raise ValueError("sample_representation has an incompatible shape")
        if tuple(observed_mask.shape) != (reference.size(0), 3):
            raise ValueError("observed_mask must have shape [batch, 3]")
        availability = observed_mask.to(device=reference.device)
        if torch.any((availability != 0) & (availability != 1)):
            raise ValueError("observed_mask values must be binary")
        if torch.any(availability.sum(dim=1) == 0):
            raise ValueError("each sample must contain an observed modality")
        if tuple(base_prediction.shape) != (
            reference.size(0), self.output_dim
        ):
            raise ValueError("base_prediction has an incompatible shape")
        return availability.to(dtype=reference.dtype)

    def forward(
        self,
        enhanced_modalities,
        sample_representation,
        observed_mask,
        base_prediction,
    ):
        availability = self._validate_inputs(
            enhanced_modalities,
            sample_representation,
            observed_mask,
            base_prediction,
        )
        sample_context = self.sample_norm(sample_representation)
        private_outputs = []
        shared_outputs = []
        routing_weights = []
        routing_entropy = []
        orthogonality_terms = []

        for modality_index, features in enumerate(enhanced_modalities):
            normalized = self.modality_norms[modality_index](features)
            router_input = torch.cat(
                (normalized, sample_context, availability), dim=1
            )
            logits = self.routers[modality_index](router_input)
            weights = F.softmax(logits / self.temperature, dim=1)

            private_stack = torch.stack([
                expert(normalized)
                for expert in self.private_experts[modality_index]
            ], dim=1)
            shared_stack = torch.stack([
                expert(normalized)
                for expert in self.shared_experts
            ], dim=1)
            private_weights = weights[:, :self.private_expert_count]
            shared_weights = weights[:, self.private_expert_count:]
            private = (
                private_stack * private_weights.unsqueeze(-1)
            ).sum(dim=1)
            shared = (
                shared_stack * shared_weights.unsqueeze(-1)
            ).sum(dim=1)

            private_outputs.append(private)
            shared_outputs.append(shared)
            routing_weights.append(weights)
            routing_entropy.append(
                -(weights * weights.clamp_min(1e-8).log()).sum(dim=1)
            )
            orthogonality_terms.append(
                F.cosine_similarity(private, shared, dim=1).pow(2)
            )

        residual_features = torch.cat(
            tuple(
                item
                for pair in zip(private_outputs, shared_outputs)
                for item in pair
            ) + (sample_context, availability),
            dim=1,
        )
        residual = self.residual_head(residual_features)
        prediction = base_prediction + residual
        route_tensor = torch.stack(routing_weights, dim=1)
        entropy_tensor = torch.stack(routing_entropy, dim=1)
        orthogonality_loss = torch.stack(
            orthogonality_terms, dim=1
        ).mean()

        diagnostics = {
            "enabled": True,
            "residual": residual.detach(),
            "residual_abs_mean": residual.detach().abs().mean(),
            "residual_norm_mean": residual.detach().norm(dim=1).mean(),
            "routing_weights": route_tensor.detach().mean(dim=0),
            "routing_entropy": entropy_tensor.detach().mean(dim=0),
            "private_mass": (
                route_tensor[:, :, :self.private_expert_count]
                .sum(dim=2).detach().mean(dim=0)
            ),
            "shared_mass": (
                route_tensor[:, :, self.private_expert_count:]
                .sum(dim=2).detach().mean(dim=0)
            ),
            "temperature": self.temperature.detach(),
            "orthogonality_loss": orthogonality_loss.detach(),
        }
        return prediction, orthogonality_loss, diagnostics
