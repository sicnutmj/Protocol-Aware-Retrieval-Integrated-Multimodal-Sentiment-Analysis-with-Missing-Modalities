import torch
from torch import nn


class AvailabilityAwareMMD(nn.Module):
    """Frozen ablation for availability-aware MMD consistency objectives.

    The active missing-aware q0 baseline uses ``mode='mixed'``, which exactly
    delegates to the original batch-level MMD objective.
    """

    MODES = ('mixed', 'status_separated', 'observed_only', 'none')

    def __init__(self, mmd_loss, mode='mixed', min_group_size=2):
        super().__init__()
        if mode not in self.MODES:
            raise ValueError("Unknown consistency mode: {}".format(mode))
        if min_group_size < 1:
            raise ValueError("min_group_size must be at least 1")
        self.mmd_loss = mmd_loss
        self.mode = mode
        self.min_group_size = min_group_size

    @staticmethod
    def _zero(reference):
        return reference.sum() * 0.0

    def _group_loss(self, enhanced, sample, selection):
        count = int(selection.sum().item())
        if count < self.min_group_size:
            return self._zero(enhanced), count, False
        return self.mmd_loss(enhanced[selection], sample[selection]), count, True

    def forward(self, enhanced, sample, observed_mask):
        if enhanced.shape[0] != sample.shape[0]:
            raise ValueError("enhanced and sample must have the same batch size")
        observed = observed_mask.to(device=enhanced.device, dtype=torch.bool)
        if observed.ndim != 1 or observed.numel() != enhanced.shape[0]:
            raise ValueError("observed_mask must contain one value per sample")

        batch_size = enhanced.shape[0]
        observed_count = int(observed.sum().item())
        missing_count = batch_size - observed_count
        zero = self._zero(enhanced)
        diagnostics = {
            'mode': self.mode,
            'batch_size': batch_size,
            'observed_count': observed_count,
            'missing_count': missing_count,
            'observed_used': False,
            'missing_used': False,
            'observed_weight': 0.0,
            'missing_weight': 0.0,
            'observed_loss': zero.detach(),
            'missing_loss': zero.detach(),
        }

        if self.mode == 'none':
            diagnostics['loss'] = zero.detach()
            return zero, diagnostics

        if self.mode == 'mixed':
            loss = self.mmd_loss(enhanced, sample)
            diagnostics['observed_used'] = observed_count > 0
            diagnostics['missing_used'] = missing_count > 0
            diagnostics['observed_weight'] = observed_count / batch_size
            diagnostics['missing_weight'] = missing_count / batch_size
            diagnostics['loss'] = loss.detach()
            return loss, diagnostics

        observed_loss, _, observed_used = self._group_loss(
            enhanced, sample, observed
        )
        diagnostics['observed_loss'] = observed_loss.detach()
        diagnostics['observed_used'] = observed_used

        if self.mode == 'observed_only':
            loss = observed_loss if observed_used else zero
            diagnostics['observed_weight'] = 1.0 if observed_used else 0.0
            diagnostics['loss'] = loss.detach()
            return loss, diagnostics

        missing_loss, _, missing_used = self._group_loss(
            enhanced, sample, ~observed
        )
        diagnostics['missing_loss'] = missing_loss.detach()
        diagnostics['missing_used'] = missing_used
        eligible_count = (
            (observed_count if observed_used else 0)
            + (missing_count if missing_used else 0)
        )
        if eligible_count == 0:
            loss = zero
        else:
            observed_weight = (
                observed_count / eligible_count if observed_used else 0.0
            )
            missing_weight = (
                missing_count / eligible_count if missing_used else 0.0
            )
            loss = observed_weight * observed_loss + missing_weight * missing_loss
            diagnostics['observed_weight'] = observed_weight
            diagnostics['missing_weight'] = missing_weight

        diagnostics['loss'] = loss.detach()
        return loss, diagnostics
