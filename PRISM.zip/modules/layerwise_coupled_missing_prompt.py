import math

import torch
from torch import nn


class LayerwiseCoupledMissingPrompt(nn.Module):
    """Prompt missing enhanced tokens between frozen fusion layers.

    Each layer reads the representation produced by the preceding frozen
    Transformer layer.  A small prompt bank is selected from the current
    sample/observed-modality context and is injected only into missing enhanced
    modality tokens.  Zero-initialized residual scales make the complete module
    an exact identity at epoch zero.
    """

    MODALITIES = 3
    ENHANCED_TOKEN_OFFSET = 1
    RAW_TOKEN_OFFSET = 4

    def __init__(
        self,
        embedding_dim,
        num_layers=2,
        prompt_length=2,
        hidden_dim=64,
        max_scale=0.5,
        prompt_init_std=0.02,
    ):
        super().__init__()
        if embedding_dim < 1:
            raise ValueError("embedding_dim must be positive")
        if num_layers < 1:
            raise ValueError("num_layers must be positive")
        if prompt_length < 1:
            raise ValueError("prompt_length must be positive")
        if hidden_dim < 1:
            raise ValueError("hidden_dim must be positive")
        if max_scale <= 0:
            raise ValueError("max_scale must be positive")
        if prompt_init_std <= 0:
            raise ValueError("prompt_init_std must be positive")

        self.embedding_dim = int(embedding_dim)
        self.num_layers = int(num_layers)
        self.prompt_length = int(prompt_length)
        self.max_scale = float(max_scale)

        context_dim = 2 * self.embedding_dim + self.MODALITIES
        self.context_encoders = nn.ModuleList(
            nn.Sequential(
                nn.Linear(context_dim, hidden_dim),
                nn.ReLU(),
                nn.Linear(hidden_dim, self.embedding_dim),
            )
            for _ in range(self.num_layers)
        )
        self.modality_embeddings = nn.Parameter(
            torch.empty(self.MODALITIES, self.embedding_dim)
        )
        self.prompt_bank = nn.Parameter(
            torch.empty(
                self.num_layers,
                self.MODALITIES,
                self.prompt_length,
                self.embedding_dim,
            )
        )
        self.channel_gates = nn.ModuleList(
            nn.Linear(self.embedding_dim, self.embedding_dim)
            for _ in range(self.num_layers)
        )
        self.residual_scale_logits = nn.Parameter(
            torch.zeros(self.num_layers, self.MODALITIES)
        )
        nn.init.normal_(self.modality_embeddings, std=prompt_init_std)
        nn.init.normal_(self.prompt_bank, std=prompt_init_std)

    def reset_identity(self):
        with torch.no_grad():
            self.residual_scale_logits.zero_()

    @staticmethod
    def _validate_mask(observed_mask, batch_size):
        if observed_mask.shape != (batch_size, 3):
            raise ValueError(
                "observed_mask must have shape [{}, 3]".format(batch_size)
            )
        if torch.any((observed_mask != 0) & (observed_mask != 1)):
            raise ValueError("observed_mask values must be binary")
        if torch.any(observed_mask.sum(dim=1) == 0):
            raise ValueError("each sample must contain an observed modality")

    def _prompt_residual(self, hidden, observed_mask, layer_index):
        if hidden.ndim != 3 or hidden.shape[0] != 7:
            raise ValueError("hidden must have shape [7, batch, embedding_dim]")
        if hidden.shape[2] != self.embedding_dim:
            raise ValueError(
                "hidden embedding dimension must be {}".format(
                    self.embedding_dim
                )
            )
        if not 0 <= layer_index < self.num_layers:
            raise ValueError("layer_index is out of range")

        batch_size = hidden.shape[1]
        availability = observed_mask.to(device=hidden.device, dtype=hidden.dtype)
        self._validate_mask(availability, batch_size)
        observed_count = availability.sum(dim=1, keepdim=True)
        raw_tokens = hidden[
            self.RAW_TOKEN_OFFSET:self.RAW_TOKEN_OFFSET + self.MODALITIES
        ].transpose(0, 1)
        observed_summary = (
            raw_tokens * availability.unsqueeze(-1)
        ).sum(dim=1) / observed_count
        context_input = torch.cat(
            (hidden[0], observed_summary, availability), dim=1
        )
        shared_query = self.context_encoders[layer_index](context_input)

        corrected = hidden.clone()
        attentions = []
        residual_norms = []
        scales = self.max_scale * torch.tanh(
            self.residual_scale_logits[layer_index]
        )
        for modality_index in range(self.MODALITIES):
            query = shared_query + self.modality_embeddings[modality_index]
            prompts = self.prompt_bank[layer_index, modality_index]
            logits = torch.matmul(query, prompts.transpose(0, 1))
            attention = torch.softmax(
                logits / math.sqrt(self.embedding_dim), dim=1
            )
            direction = torch.matmul(attention, prompts)
            channel_gate = torch.sigmoid(
                self.channel_gates[layer_index](query)
            )
            missing = (1.0 - availability[:, modality_index]).unsqueeze(1)
            residual = (
                missing
                * scales[modality_index]
                * channel_gate
                * direction
            )
            token_index = self.ENHANCED_TOKEN_OFFSET + modality_index
            corrected[token_index] = corrected[token_index] + residual
            attentions.append(attention)
            residual_norms.append(residual.norm(dim=1))

        diagnostics = {
            "attention": torch.stack(attentions, dim=1).detach(),
            "residual_norms": torch.stack(residual_norms, dim=1).detach(),
            "scales": scales.detach(),
            "missing_count": (1.0 - availability).sum(dim=0).detach(),
        }
        return corrected, diagnostics

    def forward(self, transformer_encoder, hidden, observed_mask):
        if len(transformer_encoder.layers) < self.num_layers:
            raise ValueError(
                "fusion encoder has fewer layers than the configured prompt depth"
            )

        layer_diagnostics = []
        output = hidden
        for layer_index, layer in enumerate(transformer_encoder.layers):
            if layer_index < self.num_layers:
                output, diagnostics = self._prompt_residual(
                    output, observed_mask, layer_index
                )
                layer_diagnostics.append(diagnostics)
            output = layer(output)
        if transformer_encoder.norm is not None:
            output = transformer_encoder.norm(output)

        attention = torch.stack(
            [item["attention"] for item in layer_diagnostics], dim=1
        )
        residual_norms = torch.stack(
            [item["residual_norms"] for item in layer_diagnostics], dim=1
        )
        scales = torch.stack(
            [item["scales"] for item in layer_diagnostics], dim=0
        )
        missing_count = layer_diagnostics[0]["missing_count"]
        diagnostics = {
            "enabled": True,
            "attention": attention,
            "residual_norms": residual_norms,
            "scales": scales,
            "missing_count": missing_count,
            "prompt_depth": self.num_layers,
            "prompt_length": self.prompt_length,
        }
        return output, diagnostics
