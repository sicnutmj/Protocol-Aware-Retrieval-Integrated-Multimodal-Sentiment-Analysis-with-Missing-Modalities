import torch
from torch import nn


class MissingOnlyDynamicPrompt(nn.Module):
    """Add sample-conditioned prompt residuals to missing branches only.

    The frozen q0 enhanced representation is the preliminary missing feature.
    A shared weighting network reads same-sample context and availability,
    while modality-specific prompt vectors provide correction directions.
    Residual scales start at zero, so the initial output exactly matches q0.
    """

    MODALITIES = 3

    def __init__(
        self,
        embedding_dim,
        hidden_dim=32,
        modality_embedding_dim=8,
        max_scale=1.0,
        prompt_init_std=0.02,
    ):
        super().__init__()
        if embedding_dim < 1:
            raise ValueError("embedding_dim must be positive")
        if hidden_dim < 1:
            raise ValueError("hidden_dim must be positive")
        if modality_embedding_dim < 1:
            raise ValueError("modality_embedding_dim must be positive")
        if max_scale <= 0:
            raise ValueError("max_scale must be positive")
        if prompt_init_std <= 0:
            raise ValueError("prompt_init_std must be positive")

        self.embedding_dim = int(embedding_dim)
        self.max_scale = float(max_scale)
        self.modality_embedding = nn.Embedding(
            self.MODALITIES, modality_embedding_dim
        )
        context_dim = 2 * self.embedding_dim + self.MODALITIES
        self.weighting_network = nn.Sequential(
            nn.Linear(context_dim + modality_embedding_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, self.embedding_dim),
            nn.Sigmoid(),
        )
        self.absent_prompts = nn.Parameter(
            torch.empty(self.MODALITIES, self.embedding_dim)
        )
        nn.init.normal_(self.absent_prompts, std=prompt_init_std)
        self.residual_scale_logits = nn.Parameter(torch.zeros(self.MODALITIES))

    @staticmethod
    def _validate_features(name, features, batch_size, embedding_dim):
        if len(features) != 3:
            raise ValueError("{} must contain exactly three tensors".format(name))
        expected = (batch_size, embedding_dim)
        for feature in features:
            if feature.shape != expected:
                raise ValueError(
                    "{} tensors must have shape {}, got {}".format(
                        name, expected, tuple(feature.shape)
                    )
                )

    def forward(
        self,
        sample_representation,
        enhanced_features,
        raw_features,
        observed_mask,
    ):
        if sample_representation.ndim != 2:
            raise ValueError("sample_representation must be a 2D tensor")
        batch_size, embedding_dim = sample_representation.shape
        if embedding_dim != self.embedding_dim:
            raise ValueError(
                "sample_representation dimension must be {}, got {}".format(
                    self.embedding_dim, embedding_dim
                )
            )
        self._validate_features(
            "enhanced_features", enhanced_features, batch_size, embedding_dim
        )
        self._validate_features(
            "raw_features", raw_features, batch_size, embedding_dim
        )
        if observed_mask.shape != (batch_size, self.MODALITIES):
            raise ValueError(
                "observed_mask must have shape [{}, 3]".format(batch_size)
            )

        availability = observed_mask.to(
            device=sample_representation.device,
            dtype=sample_representation.dtype,
        )
        if torch.any((availability != 0) & (availability != 1)):
            raise ValueError("observed_mask values must be binary")
        observed_count = availability.sum(dim=1, keepdim=True)
        if torch.any(observed_count == 0):
            raise ValueError("each sample must contain at least one observed modality")

        raw_stack = torch.stack(raw_features, dim=1)
        observed_summary = (
            raw_stack * availability.unsqueeze(-1)
        ).sum(dim=1) / observed_count
        shared_context = torch.cat(
            (sample_representation, observed_summary, availability), dim=1
        )

        prompted_features = []
        weights = []
        residual_norms = []
        scales = self.max_scale * torch.tanh(self.residual_scale_logits)
        for modality_index in range(self.MODALITIES):
            modality_ids = torch.full(
                (batch_size,),
                modality_index,
                device=sample_representation.device,
                dtype=torch.long,
            )
            context = torch.cat(
                (shared_context, self.modality_embedding(modality_ids)), dim=1
            )
            weight = self.weighting_network(context)
            prompt = self.absent_prompts[modality_index].unsqueeze(0)
            residual = scales[modality_index] * weight * prompt
            missing = (1.0 - availability[:, modality_index]).unsqueeze(1)
            applied_residual = missing * residual
            prompted_features.append(
                enhanced_features[modality_index] + applied_residual
            )
            weights.append(weight.mean(dim=1))
            residual_norms.append(applied_residual.norm(dim=1))

        diagnostics = {
            "weights": torch.stack(weights, dim=1).detach(),
            "residual_norms": torch.stack(residual_norms, dim=1).detach(),
            "scales": scales.detach(),
            "missing_fraction": (1.0 - availability).mean(dim=0).detach(),
        }
        return tuple(prompted_features), diagnostics
