import torch


MODALITIES = ('l', 'a', 'v')
ENHANCED_INDICES = {'l': 1, 'a': 2, 'v': 3}


@torch.no_grad()
def evaluate_enhanced_branch_counterfactuals(
    fuse_fn,
    representations,
    labels,
    observed_mask,
    threshold=1.0,
    factual_prediction=None,
):
    """Evaluate enhanced-branch necessity and sufficiency without training.

    The common sample representation and raw modality branches are preserved
    in every counterfactual. ``null`` removes all three enhanced branches,
    while ``branch_only`` adds exactly one enhancement back to that null path.
    """
    if len(representations) != 7:
        raise ValueError("IIE PNS audit requires exactly seven representations")
    if observed_mask.ndim != 2 or observed_mask.shape[1] != 3:
        raise ValueError("observed_mask must have shape [batch, 3]")
    if threshold <= 0:
        raise ValueError("threshold must be positive")

    batch_size = representations[0].shape[0]
    if any(item.shape[0] != batch_size for item in representations):
        raise ValueError("all representations must share the same batch size")
    targets = labels.view(-1)
    if targets.numel() != batch_size:
        raise ValueError("labels must contain one value per sample")

    def predict(items):
        prediction, _ = fuse_fn(tuple(items))
        return prediction.view(-1)

    factual = (
        predict(representations)
        if factual_prediction is None
        else factual_prediction.view(-1)
    )
    if factual.numel() != batch_size:
        raise ValueError("factual_prediction must contain one value per sample")

    null_representations = list(representations)
    for index in ENHANCED_INDICES.values():
        null_representations[index] = torch.zeros_like(representations[index])
    null_prediction = predict(null_representations)

    factual_error = torch.abs(factual - targets)
    null_error = torch.abs(null_prediction - targets)
    diagnostics = {}
    for modality_index, modality in enumerate(MODALITIES):
        branch_index = ENHANCED_INDICES[modality]

        removed = list(representations)
        removed[branch_index] = torch.zeros_like(
            representations[branch_index]
        )
        removed_prediction = predict(removed)

        branch_only = list(null_representations)
        branch_only[branch_index] = representations[branch_index]
        branch_prediction = predict(branch_only)

        removed_error = torch.abs(removed_prediction - targets)
        branch_error = torch.abs(branch_prediction - targets)
        necessity_margin = removed_error - factual_error
        sufficiency_margin = null_error - branch_error
        necessity_event = (
            (factual_error < threshold) & (removed_error > threshold)
        )
        sufficiency_event = (
            (branch_error < threshold) & (null_error > threshold)
        )
        diagnostics[modality] = {
            'observed': observed_mask[:, modality_index].bool(),
            'factual_error': factual_error,
            'removed_error': removed_error,
            'branch_only_error': branch_error,
            'null_error': null_error,
            'necessity_margin': necessity_margin,
            'sufficiency_margin': sufficiency_margin,
            'necessity_event': necessity_event,
            'sufficiency_event': sufficiency_event,
            'necessity_positive': necessity_margin > 0,
            'sufficiency_positive': sufficiency_margin > 0,
            'harmful': necessity_margin < 0,
        }
    return diagnostics


class PNSAuditAccumulator:
    """Accumulate exact sufficient statistics for a read-only PNS audit."""

    SUM_FIELDS = (
        'factual_error',
        'removed_error',
        'branch_only_error',
        'null_error',
        'necessity_margin',
        'sufficiency_margin',
    )
    COUNT_FIELDS = (
        'necessity_event',
        'sufficiency_event',
        'necessity_positive',
        'sufficiency_positive',
        'harmful',
    )

    def __init__(self):
        self.totals = {
            modality: {
                'count': 0,
                'observed': 0,
                **{field: 0.0 for field in self.SUM_FIELDS},
                **{field: 0 for field in self.COUNT_FIELDS},
            }
            for modality in MODALITIES
        }

    def update(self, diagnostics):
        for modality in MODALITIES:
            values = diagnostics[modality]
            count = int(values['observed'].numel())
            totals = self.totals[modality]
            totals['count'] += count
            totals['observed'] += int(values['observed'].sum().item())
            for field in self.SUM_FIELDS:
                totals[field] += float(values[field].sum().item())
            for field in self.COUNT_FIELDS:
                totals[field] += int(values[field].sum().item())

    def summaries(self):
        result = {}
        for modality, totals in self.totals.items():
            count = totals['count']
            if count == 0:
                raise RuntimeError("cannot summarize an empty PNS audit")
            summary = {
                'count': count,
                'observed_rate': totals['observed'] / count,
                **{
                    field: totals[field] / count
                    for field in self.SUM_FIELDS
                },
                **{
                    '{}_rate'.format(field): totals[field] / count
                    for field in self.COUNT_FIELDS
                },
            }
            summary['pns_event_score'] = (
                summary['necessity_event_rate']
                + summary['sufficiency_event_rate']
            )
            result[modality] = summary
        return result
