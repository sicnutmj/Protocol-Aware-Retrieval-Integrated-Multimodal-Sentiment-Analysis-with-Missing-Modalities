"""Confidence-gated complete-to-missing polarity consistency.

The complete view acts only as a stop-gradient training target.  Predictions
are converted into a two-class polarity distribution by treating ``[-y, y]``
as logits.  This preserves the regression head used at inference while making
the SSLMM-inspired confidence threshold meaningful.
"""

import torch
import torch.nn.functional as F


def confidence_gated_polarity_consistency(
    student_prediction,
    teacher_prediction,
    temperature=0.5,
    confidence_threshold=0.95,
):
    """Return a high-confidence teacher-to-student polarity KL loss."""
    if student_prediction.shape != teacher_prediction.shape:
        raise ValueError("student and teacher predictions must share one shape")
    if student_prediction.dim() != 2 or student_prediction.size(1) != 1:
        raise ValueError("predictions must have shape [batch, 1]")
    if temperature <= 0:
        raise ValueError("temperature must be positive")
    if not 0.5 <= confidence_threshold <= 1.0:
        raise ValueError("confidence_threshold must be in [0.5, 1]")

    student_logits = torch.cat(
        (-student_prediction, student_prediction), dim=1
    ) / temperature
    teacher_logits = torch.cat(
        (-teacher_prediction.detach(), teacher_prediction.detach()), dim=1
    ) / temperature
    teacher_probability = F.softmax(teacher_logits, dim=1)
    student_log_probability = F.log_softmax(student_logits, dim=1)
    teacher_log_probability = teacher_probability.clamp_min(1e-8).log()
    per_sample_kl = (
        teacher_probability
        * (teacher_log_probability - student_log_probability)
    ).sum(dim=1)

    confidence = teacher_probability.max(dim=1).values
    eligible = confidence >= confidence_threshold
    eligible_float = eligible.to(dtype=per_sample_kl.dtype)
    loss = (
        (per_sample_kl * eligible_float).sum()
        / eligible_float.sum().clamp_min(1.0)
    )

    teacher_sign = teacher_prediction.detach().view(-1) >= 0
    student_sign = student_prediction.detach().view(-1) >= 0
    disagreement = teacher_sign != student_sign
    eligible_count = eligible_float.sum()
    diagnostics = {
        "loss": loss.detach(),
        "coverage": eligible_float.mean().detach(),
        "eligible_count": eligible_count.detach(),
        "teacher_confidence": confidence.mean().detach(),
        "teacher_abs_prediction": (
            teacher_prediction.detach().abs().mean()
        ),
        "student_teacher_abs_gap": (
            student_prediction.detach() - teacher_prediction.detach()
        ).abs().mean(),
        "polarity_disagreement": disagreement.float().mean().detach(),
        "eligible_polarity_disagreement": (
            (disagreement.float() * eligible_float).sum()
            / eligible_count.clamp_min(1.0)
        ).detach(),
    }
    return loss, diagnostics
