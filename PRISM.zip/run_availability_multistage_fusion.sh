set -e
AMSF_ARGS=(
  --retrieval_mode=missing_aware
  --retrieval_queue_size=0
  --retrieval_metric_mode=raw
  --retrieval_missing_query=center
  --gate_mode=none
  --consistency_mode=mixed
  --distill_mode=none
  --fusion_mode=availability_multistage
  --early_stopping_patience=0
)
echo "Frozen failed sixth ablation: availability-guided multi-stage subset fusion"

run_protocol() {
  local protocol="$1"
  local train_batch_size="$2"
  local representation_dim="$3"
  local description="$4"
  shift 4

  echo "availability multi-stage fusion: protocol ${protocol} (${description})"
  python3 main.py "${AMSF_ARGS[@]}" \
    --fixed_protocol="${protocol}" \
    --learning_rate=2e-5 \
    --d_l="${representation_dim}" \
    --latent_dim="${representation_dim}" \
    --train_batch_size="${train_batch_size}" \
    --dataset=mosei \
    "$@"
}

# Preserve the protocol-specific settings of the frozen q0 experiment.
run_protocol 0 128 192 "L observed"
run_protocol 1 128 192 "A observed" \
  --missing_rate=0.05 \
  --layers=2 \
  --latent_layers=3
run_protocol 2 256 192 "V observed"
run_protocol 3 256 96  "L+A observed"
run_protocol 4 256 96  "L+V observed"
run_protocol 5 256 192 "A+V observed"
run_protocol 6 128 192 "L+A+V observed"
