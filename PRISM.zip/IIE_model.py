import torch
from torch import nn
import torch.nn.functional as F
from modules.transformer import TransformerEncoder
import numpy as np
from random import sample
import torch.nn.init as init
from torch.autograd import Variable
import time
from numbers import Number
import math
import logging
from typing import Optional, Tuple
import torch.utils.checkpoint
from torch.nn import CrossEntropyLoss, MSELoss
from einops import rearrange, repeat
from einops.layers.torch import Reduce
from torch.nn import L1Loss, MSELoss
from torch.autograd import Function
from math import pi, log
from functools import wraps
import os
from transformers import BertPreTrainedModel
from transformers.models.bert.modeling_bert import BertEmbeddings, BertEncoder, BertPooler
from transformers.activations import gelu, gelu_new
from transformers import BertConfig
import numpy as np
import torch.optim as optim
from itertools import chain
from latent_transformer import LatentTransformer
from utils import *
import torch
from torch import nn, einsum
import torch.nn as nn
import torch.nn.functional as F
from math import pi, log
from functools import wraps
import torch.nn.functional as F
from einops import rearrange, repeat
from einops.layers.torch import Reduce
from modules.transformer import TransformerEncoder
from modules.missing_aware_retrieval import (
    MissingAwareRetrieval,
    legacy_batch_retrieval,
)
from modules.availability_aware_mmd import AvailabilityAwareMMD
from modules.availability_aware_fusion import AvailabilityAwareMultiStageFusion
from modules.missing_dynamic_prompt import MissingOnlyDynamicPrompt
from modules.text_guided_reconstruction import (
    TextGuidedMissingNonverbalReconstruction,
)
from modules.label_semantic_missing_text_residual import (
    LabelSemanticMissingTextResidual,
)
from modules.privileged_disentangled_purification import (
    PrivilegedDisentangledPurification,
)
from modules.availability_tagged_language_hyper_residual import (
    AvailabilityTaggedLanguageHyperResidual,
)
from modules.layerwise_coupled_missing_prompt import (
    LayerwiseCoupledMissingPrompt,
)
from modules.unified_consensus_residual import (
    AvailabilityMaskedUnifiedConsensusResidual,
)
from modules.missing_tag_fusion_bias import AdditiveMissingTagFusionBias
from modules.cross_modal_query_retrieval import (
    AvailabilityGuidedCrossModalQueryRetrieval,
)
from modules.same_sample_bundle_retrieval import (
    SentimentConsistentBundleRetrieval,
)
from modules.training_similar_prior_enhancement import (
    TrainingSimilarPriorEnhancement,
)
from modules.availability_hybrid_expert_residual import (
    AvailabilityConstrainedHybridExpertResidual,
)
from modules.reliability_gate import (
    CounterfactualHarmGate,
    CounterfactualScaleGateV24,
    FixedScaleGate,
    QualityAwareReliabilityGate,
    QualityAwareReliabilityGateV22,
    ResidualReliabilityGate,
    select_counterfactual_scale_targets,
)
os.environ["CUDA_VISIBLE_DEVICES"] = "0"
DEVICE = torch.device("cuda:0")

logger = logging.getLogger(__name__)

_CONFIG_FOR_DOC = "BertConfig"
_TOKENIZER_FOR_DOC = "BertTokenizer"

BERT_PRETRAINED_MODEL_ARCHIVE_LIST = [
    "bert-base-uncased",
]


class DeterministicMaxPool1d(nn.Module):
    """AdaptiveMaxPool1d(1) equivalent with deterministic CUDA backward.

    PyTorch implements AdaptiveMaxPool1d through a 2-D adaptive pooling
    backward kernel that is explicitly nondeterministic on CUDA.  A direct
    indexed maximum over the complete temporal axis is mathematically
    equivalent when the requested output length is one.
    """

    def forward(self, features):
        return torch.max(features, dim=-1, keepdim=True).values

class BERT_TM(BertPreTrainedModel):
    def __init__(self, config, args):
        super().__init__(config)
        self.config = config
        self.config.output_hidden_states=True
        self.embeddings = BertEmbeddings(config)
        self.encoder = BertEncoder(config)
        self.init_weights()

    def get_input_embeddings(self):
        return self.embeddings.word_embeddings

    def set_input_embeddings(self, value):
        self.embeddings.word_embeddings = value

    def _prune_heads(self, heads_to_prune):
        """ Prunes heads of the model.
            heads_to_prune: dict of {layer_num: list of heads to prune in this layer}
            See base class PreTrainedModel
        """
        for layer, heads in heads_to_prune.items():
            self.encoder.layer[layer].attention.prune_heads(heads)

    def forward(
        self,
        input_ids,
        attention_mask=None,
        token_type_ids=None,
        position_ids=None,
        head_mask=None,
        inputs_embeds=None,
        encoder_hidden_states=None,
        encoder_attention_mask=None,
        output_attentions=None,
        output_hidden_states=None,
    ):
        r"""
    Return:
        :obj:`tuple(torch.FloatTensor)` comprising various elements depending on the configuration (:class:`~transformers.BertConfig`) and inputs:
        last_hidden_state (:obj:`torch.FloatTensor` of shape :obj:`(batch_size, sequence_length, hidden_size)`):
            Sequence of hidden-states at the output of the last layer of the model.
        pooler_output (:obj:`torch.FloatTensor`: of shape :obj:`(batch_size, hidden_size)`):
            Last layer hidden-state of the first token of the sequence (classification token)
            further processed by a Linear layer and a Tanh activation function. The Linear
            layer weights are trained from the next sentence prediction (classification)
            objective during pre-training.

            This output is usually *not* a good summary
            of the semantic content of the input, you're often better with averaging or pooling
            the sequence of hidden-states for the whole input sequence.
        hidden_states (:obj:`tuple(torch.FloatTensor)`, `optional`, returned when ``output_hidden_states=True`` is passed or when ``config.output_hidden_states=True``):
            Tuple of :obj:`torch.FloatTensor` (one for the output of the embeddings + one for the output of each layer)
            of shape :obj:`(batch_size, sequence_length, hidden_size)`.

            Hidden-states of the model at the output of each layer plus the initial embedding outputs.
        attentions (:obj:`tuple(torch.FloatTensor)`, `optional`, returned when ``output_attentions=True`` is passed or when ``config.output_attentions=True``):
            Tuple of :obj:`torch.FloatTensor` (one for each layer) of shape
            :obj:`(batch_size, num_heads, sequence_length, sequence_length)`.

            Attentions weights after the attention softmax, used to compute the weighted average in the self-attention
            heads.
        """
        output_attentions = (
            output_attentions
            if output_attentions is not None
            else self.config.output_attentions
        )
        output_hidden_states = (
            output_hidden_states
            if output_hidden_states is not None
            else self.config.output_hidden_states
        )

        if input_ids is not None and inputs_embeds is not None:
            raise ValueError(
                "You cannot specify both input_ids and inputs_embeds at the same time"
            )
        elif input_ids is not None:
            input_shape = input_ids.size()
        elif inputs_embeds is not None:
            input_shape = inputs_embeds.size()[:-1]
        else:
            raise ValueError(
                "You have to specify either input_ids or inputs_embeds")

        device = input_ids.device if input_ids is not None else inputs_embeds.device

        if attention_mask is None:
            attention_mask = torch.ones(input_shape, device=device)
        if token_type_ids is None:
            token_type_ids = torch.zeros(
                input_shape, dtype=torch.long, device=device)

        # We can provide a self-attention mask of dimensions [batch_size, from_seq_length, to_seq_length]
        # ourselves in which case we just need to make it broadcastable to all heads.
        extended_attention_mask: torch.Tensor = self.get_extended_attention_mask(
            attention_mask, input_shape, device
        )

        # If a 2D ou 3D attention mask is provided for the cross-attention
        # we need to make broadcastabe to [batch_size, num_heads, seq_length, seq_length]
        if self.config.is_decoder and encoder_hidden_states is not None:
            (
                encoder_batch_size,
                encoder_sequence_length,
                _,
            ) = encoder_hidden_states.size()
            encoder_hidden_shape = (
                encoder_batch_size, encoder_sequence_length)
            if encoder_attention_mask is None:
                encoder_attention_mask = torch.ones(
                    encoder_hidden_shape, device=device)
            encoder_extended_attention_mask = self.invert_attention_mask(
                encoder_attention_mask
            )
        else:
            encoder_extended_attention_mask = None

        # Prepare head mask if needed
        # 1.0 in head_mask indicate we keep the head
        # attention_probs has shape bsz x n_heads x N x N
        # input head_mask has shape [num_heads] or [num_hidden_layers x num_heads]
        # and head_mask is converted to shape [num_hidden_layers x batch x num_heads x seq_length x seq_length]
        head_mask = self.get_head_mask(
            head_mask, self.config.num_hidden_layers)

        embedding_output = self.embeddings(
            input_ids=input_ids,
            position_ids=position_ids,
            token_type_ids=token_type_ids,
            inputs_embeds=inputs_embeds,
        )

        encoder_outputs = self.encoder(
            embedding_output,
            attention_mask=extended_attention_mask,
            head_mask=head_mask,
            encoder_hidden_states=encoder_hidden_states,
            encoder_attention_mask=encoder_extended_attention_mask,
            output_attentions=output_attentions,
            output_hidden_states=output_hidden_states,
        )

        last_sequence_output = encoder_outputs[0]
        return last_sequence_output


class IIEModel(BertPreTrainedModel):
    def __init__(self, config, args = None):
        super().__init__(config)
        self.bert = BERT_TM(config, args)
        self.orig_d_l, self.orig_d_a, self.orig_d_v = args.TEXT_DIM, args.ACOUSTIC_DIM, args.VISUAL_DIM
        self.d_l, self.d_a, self.d_v =  args.d_l, args.d_l, args.d_l
        self.args = args
        self.bsz = args.train_batch_size 
        self.num_heads = args.num_heads
        self.layers = args.layers
        self.attn_dropout = args.attn_dropout
        self.attn_dropout_a = args.attn_dropout_a
        self.attn_dropout_v = args.attn_dropout_v
        self.relu_dropout = args.relu_dropout
        self.res_dropout = args.res_dropout
        self.embed_dropout = args.embed_dropout
        self.latent_depth = args.latent_layers
        self.activation = nn.ReLU()
        self.output_dim = args.output_dim
        self.alpha = args.alpha
        self.dropout = args.out_dropout
        self.fusion_mode = getattr(args, 'fusion_mode', 'flat')
        self.prompt_mode = getattr(args, 'prompt_mode', 'none')
        self.prompt_finetune_scope = getattr(
            args, 'prompt_finetune_scope', 'prompt_head'
        )
        self.reconstruction_mode = getattr(args, 'reconstruction_mode', 'none')
        self.consensus_mode = getattr(args, 'consensus_mode', 'none')
        self.tag_mode = getattr(args, 'tag_mode', 'none')
        self.cross_modal_retrieval_mode = getattr(
            args, 'cross_modal_retrieval_mode', 'none'
        )
        self.training_prior_mode = getattr(
            args, 'training_prior_mode', 'none'
        )
        self.hybrid_expert_mode = getattr(
            args, 'hybrid_expert_mode', 'none'
        )
        self.protocol_consistency_mode = getattr(
            args, 'protocol_consistency_mode', 'none'
        )
        self.protocol_fusion_readaptation = getattr(
            args, 'protocol_fusion_readaptation', False
        )
        self.protocol_adaptation_scope = getattr(
            args, 'protocol_adaptation_scope', 'fusion_all'
        )
        if self.protocol_adaptation_scope not in (
            'last_layer', 'fusion_all', 'late_transformer_fusion'
        ):
            raise ValueError(
                "Unknown protocol adaptation scope: {}".format(
                    self.protocol_adaptation_scope
                )
            )
        self.relation_distill_mode = getattr(
            args, 'relation_distill_mode', 'none'
        )
        self.missing_text_contrast_mode = getattr(
            args, 'missing_text_contrast_mode', 'none'
        )
        self.privileged_purification_mode = getattr(
            args, 'privileged_purification_mode', 'none'
        )
        self.language_hyper_mode = getattr(
            args, 'language_hyper_mode', 'none'
        )
        self.coupled_prompt_mode = getattr(
            args, 'coupled_prompt_mode', 'none'
        )
        if self.coupled_prompt_mode not in ('none', 'lcmpr'):
            raise ValueError(
                "Unknown coupled prompt mode: {}".format(
                    self.coupled_prompt_mode
                )
            )
        if self.language_hyper_mode not in (
            'none', 'availability_only', 'language_query'
        ):
            raise ValueError(
                "Unknown language hyper mode: {}".format(
                    self.language_hyper_mode
                )
            )
        if self.privileged_purification_mode not in (
            'none', 'task_only', 'full'
        ):
            raise ValueError(
                "Unknown privileged purification mode: {}".format(
                    self.privileged_purification_mode
                )
            )
        if self.missing_text_contrast_mode not in ('none', 'feature', 'label'):
            raise ValueError(
                "Unknown missing-text contrast mode: {}".format(
                    self.missing_text_contrast_mode
                )
            )
        if self.relation_distill_mode not in ('none', 'tag_mrd'):
            raise ValueError(
                "Unknown relation distillation mode: {}".format(
                    self.relation_distill_mode
                )
            )
        if self.protocol_consistency_mode not in ('none', 'pcmc'):
            raise ValueError(
                "Unknown protocol consistency mode: {}".format(
                    self.protocol_consistency_mode
                )
            )
        self.text_trans = self.Get_Modality_Network(modality='l')
        self.audio_trans = self.Get_Modality_Network(modality='a')
        self.video_trans = self.Get_Modality_Network(modality='v')
        self.MMD_loss = MMDLoss()
        self.consistency_mode = getattr(args, 'consistency_mode', 'mixed')
        self.consistency_min_group_size = getattr(
            args, 'consistency_min_group_size', 2
        )
        self.availability_aware_mmd = AvailabilityAwareMMD(
            self.MMD_loss,
            mode=self.consistency_mode,
            min_group_size=self.consistency_min_group_size,
        )
        self.latent_sample = self.get_latent_network(self_type='sam')
        self.latent_text = self.get_latent_network(self_type='mod_l')
        self.latent_audio = self.get_latent_network(self_type='mod_a')
        self.latent_video = self.get_latent_network(self_type='mod_v')
        retrieval_top_k = getattr(args, 'retrieval_top_k', 2)
        retrieval_queue_size = getattr(args, 'retrieval_queue_size', 0)
        retrieval_temperature = getattr(args, 'retrieval_temperature', 0.1)
        retrieval_metric_mode = getattr(args, 'retrieval_metric_mode', 'raw')
        retrieval_projection_dim = getattr(
            args, 'retrieval_projection_dim', 64
        )
        retrieval_missing_query = getattr(
            args, 'retrieval_missing_query', 'center'
        )
        retrieval_label_temperature = getattr(
            args, 'retrieval_label_temperature', 0.5
        )
        retrieval_candidate_source = getattr(
            args, 'retrieval_candidate_source', 'batch'
        )
        retrieval_candidate_filter = getattr(
            args, 'retrieval_candidate_filter', 'observed_only'
        )
        retrieval_composition = getattr(
            args, 'retrieval_composition', 'prototype_neighbours'
        )
        retrieval_selection = getattr(
            args, 'retrieval_selection', 'similarity'
        )
        retrieval_random_seed = getattr(args, 'retrieval_random_seed', 3407)
        self.retrieval_mode = getattr(
            args, 'retrieval_mode', 'missing_aware'
        )
        self.retrieval_top_k = retrieval_top_k
        self.retrieval_metric_mode = retrieval_metric_mode
        self.retrieval_missing_query = retrieval_missing_query
        self.modality_retrieval = nn.ModuleDict({
            'l': MissingAwareRetrieval(
                self.d_l,
                top_k=retrieval_top_k,
                queue_size=retrieval_queue_size,
                temperature=retrieval_temperature,
                metric_mode=retrieval_metric_mode,
                projection_dim=retrieval_projection_dim,
                missing_query_mode=retrieval_missing_query,
                sample_embedding_dim=self.d_l,
                label_temperature=retrieval_label_temperature,
                candidate_source=retrieval_candidate_source,
                candidate_filter=retrieval_candidate_filter,
                composition_mode=retrieval_composition,
                selection_mode=retrieval_selection,
                random_seed=retrieval_random_seed,
            ),
            'a': MissingAwareRetrieval(
                self.d_a,
                top_k=retrieval_top_k,
                queue_size=retrieval_queue_size,
                temperature=retrieval_temperature,
                metric_mode=retrieval_metric_mode,
                projection_dim=retrieval_projection_dim,
                missing_query_mode=retrieval_missing_query,
                sample_embedding_dim=self.d_l,
                label_temperature=retrieval_label_temperature,
                candidate_source=retrieval_candidate_source,
                candidate_filter=retrieval_candidate_filter,
                composition_mode=retrieval_composition,
                selection_mode=retrieval_selection,
                random_seed=retrieval_random_seed + 100003,
            ),
            'v': MissingAwareRetrieval(
                self.d_v,
                top_k=retrieval_top_k,
                queue_size=retrieval_queue_size,
                temperature=retrieval_temperature,
                metric_mode=retrieval_metric_mode,
                projection_dim=retrieval_projection_dim,
                missing_query_mode=retrieval_missing_query,
                sample_embedding_dim=self.d_l,
                label_temperature=retrieval_label_temperature,
                candidate_source=retrieval_candidate_source,
                candidate_filter=retrieval_candidate_filter,
                composition_mode=retrieval_composition,
                selection_mode=retrieval_selection,
                random_seed=retrieval_random_seed + 200003,
            ),
        })
        if self.cross_modal_retrieval_mode == 'agcqr':
            self.cross_modal_query_retrieval = (
                AvailabilityGuidedCrossModalQueryRetrieval(
                    embedding_dim=self.d_l,
                    hidden_dim=getattr(
                        args, 'cross_modal_retrieval_hidden_dim', 128
                    ),
                    top_k=retrieval_top_k,
                    temperature=getattr(
                        args, 'cross_modal_retrieval_temperature', 0.1
                    ),
                    match_temperature=getattr(
                        args, 'cross_modal_match_temperature', 0.1
                    ),
                )
            )
            self.same_sample_bundle_retrieval = None
        elif self.cross_modal_retrieval_mode == 'scbr':
            self.cross_modal_query_retrieval = None
            self.same_sample_bundle_retrieval = (
                SentimentConsistentBundleRetrieval(
                    embedding_dim=self.d_l,
                    top_k=retrieval_top_k,
                    temperature=getattr(
                        args, 'bundle_retrieval_temperature', 0.1
                    ),
                    sentiment_weight=getattr(
                        args, 'bundle_sentiment_weight', 0.25
                    ),
                    sentiment_temperature=getattr(
                        args, 'bundle_sentiment_temperature', 0.5
                    ),
                    injection_scale=0.0,
                )
            )
        elif self.cross_modal_retrieval_mode == 'none':
            self.cross_modal_query_retrieval = None
            self.same_sample_bundle_retrieval = None
        else:
            raise ValueError(
                "Unknown cross-modal retrieval mode: {}".format(
                    self.cross_modal_retrieval_mode
                )
            )
        if self.training_prior_mode == 'tspe':
            self.training_similar_prior = TrainingSimilarPriorEnhancement(
                mix_ratio=getattr(args, 'training_prior_mix_ratio', 0.1),
                top_k=getattr(args, 'training_prior_top_k', 2),
                similarity_min=getattr(
                    args, 'training_prior_similarity_min', 0.90
                ),
                similarity_max=getattr(
                    args, 'training_prior_similarity_max', 0.95
                ),
                score_temperature=getattr(
                    args, 'training_prior_score_temperature', 0.1
                ),
                label_weight=getattr(
                    args, 'training_prior_label_weight', 0.25
                ),
                label_temperature=getattr(
                    args, 'training_prior_label_temperature', 0.5
                ),
            )
        elif self.training_prior_mode == 'none':
            self.training_similar_prior = None
        else:
            raise ValueError(
                "Unknown training prior mode: {}".format(
                    self.training_prior_mode
                )
            )
        if self.hybrid_expert_mode == 'acher':
            self.availability_hybrid_expert_residual = (
                AvailabilityConstrainedHybridExpertResidual(
                    embedding_dim=self.d_l,
                    output_dim=self.output_dim,
                    hidden_dim=getattr(args, 'hybrid_expert_hidden_dim', 64),
                    private_experts=getattr(
                        args, 'hybrid_expert_private_count', 3
                    ),
                    shared_experts=getattr(
                        args, 'hybrid_expert_shared_count', 3
                    ),
                    dropout=getattr(args, 'hybrid_expert_dropout', 0.1),
                    initial_temperature=getattr(
                        args, 'hybrid_expert_initial_temperature', None
                    ),
                )
            )
        elif self.hybrid_expert_mode == 'none':
            self.availability_hybrid_expert_residual = None
        else:
            raise ValueError(
                "Unknown hybrid expert mode: {}".format(
                    self.hybrid_expert_mode
                )
            )
        if self.prompt_mode == 'missing_dynamic':
            self.dynamic_prompt_adapter = MissingOnlyDynamicPrompt(
                embedding_dim=self.d_l,
                hidden_dim=getattr(args, 'prompt_hidden_dim', 32),
                modality_embedding_dim=getattr(
                    args, 'prompt_modality_embedding_dim', 8
                ),
                max_scale=getattr(args, 'prompt_max_scale', 1.0),
                prompt_init_std=getattr(args, 'prompt_init_std', 0.02),
            )
        elif self.prompt_mode == 'none':
            self.dynamic_prompt_adapter = None
        else:
            raise ValueError("Unknown prompt mode: {}".format(self.prompt_mode))
        # Frozen failed eighth ablation. Explicit opt-in only; the active
        # foundation keeps reconstruction_mode=none.
        if self.reconstruction_mode == 'text_guided_nonverbal':
            self.text_guided_reconstructor = (
                TextGuidedMissingNonverbalReconstruction(
                    embedding_dim=self.d_l,
                    hidden_dim=getattr(args, 'reconstruction_hidden_dim', 128),
                    max_scale=getattr(args, 'reconstruction_max_scale', 1.0),
                )
            )
        elif self.reconstruction_mode == 'none':
            self.text_guided_reconstructor = None
        else:
            raise ValueError(
                "Unknown reconstruction mode: {}".format(
                    self.reconstruction_mode
                )
            )
        if self.missing_text_contrast_mode in ('feature', 'label'):
            self.missing_text_contrast_residual = (
                LabelSemanticMissingTextResidual(
                    embedding_dim=self.d_l,
                    hidden_dim=getattr(
                        args, 'missing_text_contrast_hidden_dim', 128
                    ),
                    max_scale=getattr(
                        args, 'missing_text_contrast_max_scale', 1.0
                    ),
                )
            )
        else:
            self.missing_text_contrast_residual = None
        if self.privileged_purification_mode in ('task_only', 'full'):
            self.privileged_disentangled_purification = (
                PrivilegedDisentangledPurification(
                    embedding_dim=self.d_l,
                    hidden_dim=getattr(
                        args, 'privileged_purification_hidden_dim', 128
                    ),
                    subspace_dim=getattr(
                        args, 'privileged_purification_subspace_dim', 64
                    ),
                    max_scale=getattr(
                        args, 'privileged_purification_max_scale', 1.0
                    ),
                )
            )
        else:
            self.privileged_disentangled_purification = None
        if self.language_hyper_mode in (
            'availability_only', 'language_query'
        ):
            self.availability_tagged_language_hyper_residual = (
                AvailabilityTaggedLanguageHyperResidual(
                    embedding_dim=self.d_l,
                    hidden_dim=getattr(
                        args, 'language_hyper_hidden_dim', 128
                    ),
                    max_scale=getattr(
                        args, 'language_hyper_max_scale', 0.5
                    ),
                    mode=self.language_hyper_mode,
                )
            )
        else:
            self.availability_tagged_language_hyper_residual = None
        # Frozen failed ninth ablation. Explicit opt-in only; future work keeps
        # consensus_mode=none and loads the clean first+seventh checkpoint.
        if self.consensus_mode == 'amucr':
            self.unified_consensus_residual = (
                AvailabilityMaskedUnifiedConsensusResidual(
                    embedding_dim=self.d_l,
                    output_dim=self.output_dim,
                    num_heads=getattr(args, 'consensus_num_heads', 4),
                    num_layers=getattr(args, 'consensus_num_layers', 2),
                    hidden_dim=getattr(args, 'consensus_hidden_dim', self.d_l),
                    dropout=getattr(args, 'consensus_dropout', 0.1),
                )
            )
        elif self.consensus_mode == 'none':
            self.unified_consensus_residual = None
        else:
            raise ValueError(
                "Unknown consensus mode: {}".format(self.consensus_mode)
            )
        # Frozen failed tenth ablation. Future work keeps tag_mode=none and
        # loads the clean first+seventh checkpoint.
        if self.tag_mode == 'amtfb':
            self.missing_tag_fusion_bias = AdditiveMissingTagFusionBias(
                fusion_hidden_dim=self.d_l * 3,
            )
        elif self.tag_mode == 'none':
            self.missing_tag_fusion_bias = None
        else:
            raise ValueError("Unknown tag mode: {}".format(self.tag_mode))
        self.gate_mode = getattr(args, 'gate_mode', 'none')
        self.gate_hidden_dim = getattr(args, 'gate_hidden_dim', 32)
        self.gate_min_scale = getattr(args, 'gate_min_scale', 0.7)
        self.gate_init_bias = getattr(args, 'gate_init_bias', 4.0)
        self.gate_init_scale = getattr(args, 'gate_init_scale', 0.98)
        self.gate_fixed_scale = getattr(args, 'gate_fixed_scale', 0.85)
        self.gate_init_harm_probability = getattr(
            args, 'gate_init_harm_probability', 0.02
        )
        self.gate_teacher_mid_scale = getattr(
            args, 'gate_teacher_mid_scale', 0.85
        )
        self.gate_scale_loss_beta = getattr(
            args, 'gate_scale_loss_beta', 0.05
        )
        self.gate_max_residual_logit = getattr(
            args, 'gate_max_residual_logit', 8.0
        )
        self.gate_init_seed = getattr(args, 'gate_init_seed', 3407)
        if self.gate_mode == 'fixed_scale_ablation':
            self.reliability_gate = FixedScaleGate(
                scale=self.gate_fixed_scale,
                min_scale=self.gate_min_scale,
            )
        elif self.gate_mode in ('reliability', 'reliability_v1'):
            self.reliability_gate = ResidualReliabilityGate(
                embedding_dim=self.d_l,
                hidden_dim=getattr(args, 'gate_hidden_dim', 96),
                dropout=getattr(args, 'gate_dropout', 0.1),
                max_adjustment=getattr(args, 'gate_max_adjustment', 0.5),
            )
        elif self.gate_mode in (
            'none',
            'quality_reliability',
            'quality_reliability_v22',
            'counterfactual_harm_v23',
            'counterfactual_scale_v24',
        ):
            self.reliability_gate = None
        else:
            raise ValueError("Unknown gate mode: {}".format(self.gate_mode))
        if (
            self.gate_mode in (
                'quality_reliability',
                'quality_reliability_v22',
                'counterfactual_harm_v23',
                'counterfactual_scale_v24',
                'fixed_scale_ablation',
            )
            and self.retrieval_mode != 'missing_aware'
        ):
            raise ValueError(
                "quality reliability gates require missing-aware retrieval diagnostics"
            )
        
        # 1. Temporal convolutional layers
        self.proj_l_1 = nn.Conv1d(self.orig_d_l, self.d_l, kernel_size=1, padding=0, bias=False)#
        self.proj_a_1 = nn.Conv1d(self.orig_d_a, self.d_a, kernel_size=1, padding=0, bias=False)#
        self.proj_v_1 = nn.Conv1d(self.orig_d_v, self.d_v, kernel_size=1, padding=0, bias=False)#

        self.pool_audio = DeterministicMaxPool1d()
        self.pool_text = DeterministicMaxPool1d()
        self.pool_video = DeterministicMaxPool1d()
        
        # Frozen failed sixth ablation.  The active q0 baseline uses ``flat``;
        # keep this branch only for exact experiment reproduction.
        if self.fusion_mode == 'availability_multistage':
            self.transformer_encoder_all = None
            self.fusion_all = None
            self.availability_multistage_fusion = (
                AvailabilityAwareMultiStageFusion(
                    embedding_dim=self.d_l,
                    output_dim=self.output_dim,
                    dropout=self.dropout,
                )
            )
        elif self.fusion_mode == 'flat':
            encoder_layer_all = nn.TransformerEncoderLayer(
                d_model=self.d_l, nhead=self.num_heads
            )
            self.transformer_encoder_all = nn.TransformerEncoder(
                encoder_layer_all, num_layers=2
            )
            self.fusion_all = nn.Sequential()
            self.fusion_all.add_module(
                'fusion_layer_all',
                nn.Linear(in_features=self.d_l * 7, out_features=self.d_l * 3),
            )
            self.fusion_all.add_module(
                'fusion_layer_all_dropout', nn.Dropout(self.dropout)
            )
            self.fusion_all.add_module(
                'fusion_layer_all_activation', self.activation
            )
            self.fusion_all.add_module(
                'fusion_layer_all_all',
                nn.Linear(in_features=self.d_l * 3, out_features=self.output_dim),
            )
            self.availability_multistage_fusion = None
        else:
            raise ValueError("Unknown fusion mode: {}".format(self.fusion_mode))
        # Frozen failed improvement 20. Explicit opt-in is retained only for
        # reproduction; the active foundation keeps coupled_prompt_mode=none.
        if self.coupled_prompt_mode == 'lcmpr':
            if self.fusion_mode != 'flat':
                raise ValueError("LCMPR requires flat fusion")
            coupled_prompt_depth = getattr(args, 'coupled_prompt_depth', 2)
            if coupled_prompt_depth > len(self.transformer_encoder_all.layers):
                raise ValueError(
                    "coupled prompt depth exceeds fusion Transformer depth"
                )
            self.layerwise_coupled_missing_prompt = (
                LayerwiseCoupledMissingPrompt(
                    embedding_dim=self.d_l,
                    num_layers=coupled_prompt_depth,
                    prompt_length=getattr(args, 'coupled_prompt_length', 2),
                    hidden_dim=getattr(args, 'coupled_prompt_hidden_dim', 64),
                    max_scale=getattr(args, 'coupled_prompt_max_scale', 0.5),
                    prompt_init_std=getattr(
                        args, 'coupled_prompt_init_std', 0.02
                    ),
                )
            )
        else:
            self.layerwise_coupled_missing_prompt = None
        self.init_weights()
        if self.unified_consensus_residual is not None:
            self.unified_consensus_residual.reset_identity()
        if self.missing_tag_fusion_bias is not None:
            self.missing_tag_fusion_bias.reset_identity()
        if self.cross_modal_query_retrieval is not None:
            self.cross_modal_query_retrieval.reset_identity()
        if self.availability_hybrid_expert_residual is not None:
            self.availability_hybrid_expert_residual.reset_identity()
        if self.gate_mode in ('reliability', 'reliability_v1'):
            # BertPreTrainedModel.init_weights() also visits the gate. Restore
            # the exact identity initialization afterwards.
            self.reliability_gate.reset_identity()

    def initialize_quality_reliability_gate(self):
        """Create the quality gate after Hugging Face loading finishes.

        `from_pretrained` initializes missing parameters after `__init__` and
        would otherwise overwrite the gate's near-identity output bias. The
        isolated RNG context also keeps q0 backbone/training randomness paired.
        """
        if self.gate_mode not in (
            'quality_reliability',
            'quality_reliability_v22',
            'counterfactual_harm_v23',
            'counterfactual_scale_v24',
        ):
            return None

        target_device = next(self.parameters()).device
        with torch.random.fork_rng(devices=[]):
            torch.manual_seed(self.gate_init_seed)
            if self.gate_mode == 'counterfactual_scale_v24':
                gate = CounterfactualScaleGateV24(
                    embedding_dim=self.d_l,
                    hidden_dim=self.gate_hidden_dim,
                    min_scale=self.gate_min_scale,
                    init_scale=self.gate_init_scale,
                    max_residual_logit=self.gate_max_residual_logit,
                )
            elif self.gate_mode == 'counterfactual_harm_v23':
                gate = CounterfactualHarmGate(
                    embedding_dim=self.d_l,
                    hidden_dim=self.gate_hidden_dim,
                    min_scale=self.gate_min_scale,
                    init_harm_probability=(
                        self.gate_init_harm_probability
                    ),
                )
            elif self.gate_mode == 'quality_reliability_v22':
                gate = QualityAwareReliabilityGateV22(
                    embedding_dim=self.d_l,
                    hidden_dim=self.gate_hidden_dim,
                    min_scale=self.gate_min_scale,
                    init_scale=self.gate_init_scale,
                )
            else:
                gate = QualityAwareReliabilityGate(
                    embedding_dim=self.d_l,
                    hidden_dim=self.gate_hidden_dim,
                    min_scale=self.gate_min_scale,
                    init_bias=self.gate_init_bias,
                )
        self.reliability_gate = gate.to(target_device)
        return self.validate_quality_reliability_gate_initialization()

    def validate_quality_reliability_gate_initialization(self):
        if self.gate_mode not in (
            'quality_reliability',
            'quality_reliability_v22',
            'counterfactual_harm_v23',
            'counterfactual_scale_v24',
        ):
            return None
        if self.gate_mode == 'counterfactual_scale_v24':
            gate_version = "Gate-V2.4"
        elif self.gate_mode == 'counterfactual_harm_v23':
            gate_version = "Gate-V2.3"
        elif self.gate_mode == 'quality_reliability_v22':
            gate_version = "Gate-V2.2"
        else:
            gate_version = "Gate-V2.1"
        if self.reliability_gate is None:
            raise RuntimeError(
                "{} has not been initialized after from_pretrained".format(
                    gate_version
                )
            )

        final_layer = self.reliability_gate.network[-1]
        if torch.count_nonzero(final_layer.weight.detach()).item() != 0:
            raise RuntimeError(
                "{} output weight was overwritten during model loading".format(
                    gate_version
                )
            )
        expected_bias_value = self.reliability_gate.init_bias
        expected_bias = final_layer.bias.detach().new_full(
            final_layer.bias.shape, expected_bias_value
        )
        if not torch.allclose(
            final_layer.bias.detach(), expected_bias, atol=1e-7, rtol=0.0
        ):
            raise RuntimeError(
                "{} output bias was overwritten during model loading".format(
                    gate_version
                )
            )

        if self.gate_mode == 'counterfactual_scale_v24':
            expected_group_logit = self.reliability_gate.initial_group_logit
            expected_group_bias = (
                self.reliability_gate.group_bias.detach().new_full(
                    self.reliability_gate.group_bias.shape,
                    expected_group_logit,
                )
            )
            if not torch.allclose(
                self.reliability_gate.group_bias.detach(),
                expected_group_bias,
                atol=1e-7,
                rtol=0.0,
            ):
                raise RuntimeError(
                    "Gate-V2.4 group prior was overwritten during model loading"
                )
            output_probability = torch.sigmoid(
                self.reliability_gate.group_bias.detach().float().mean()
            ).item()
        else:
            output_probability = torch.sigmoid(
                final_layer.bias.detach().float().mean()
            ).item()
        reliability = (
            1.0 - output_probability
            if self.gate_mode == 'counterfactual_harm_v23'
            else output_probability
        )
        scale = (
            self.gate_min_scale
            + (1.0 - self.gate_min_scale) * reliability
        )
        if not self.gate_min_scale <= scale <= 1.0:
            raise RuntimeError(
                "{} initial scale is out of bounds".format(gate_version)
            )
        if self.gate_mode == 'counterfactual_scale_v24':
            expected_scale = self.gate_init_scale
        elif self.gate_mode == 'counterfactual_harm_v23':
            expected_scale = 1.0 - (
                (1.0 - self.gate_min_scale)
                * self.gate_init_harm_probability
            )
        elif self.gate_mode == 'quality_reliability_v22':
            expected_scale = self.gate_init_scale
        else:
            expected_scale = self.gate_min_scale + (
                (1.0 - self.gate_min_scale)
                * torch.sigmoid(torch.tensor(self.gate_init_bias)).item()
            )
        if abs(scale - expected_scale) > 1e-6:
            raise RuntimeError(
                "{} initial scale does not match its configuration".format(
                    gate_version
                )
            )
        return {
            "version": gate_version,
            "reliability": reliability,
            "scale": scale,
            "min_scale": self.gate_min_scale,
            "init_bias": (
                self.reliability_gate.initial_group_logit
                if self.gate_mode == 'counterfactual_scale_v24'
                else expected_bias_value
            ),
        }

    def initialize_unified_consensus_residual(self):
        """Restore and verify the exact epoch-0 identity after HF loading."""
        if self.unified_consensus_residual is None:
            return None
        self.unified_consensus_residual.reset_identity()
        final_layer = self.unified_consensus_residual.residual_head[-1]
        return {
            "final_weight_max": final_layer.weight.detach().abs().max().item(),
            "final_bias_max": final_layer.bias.detach().abs().max().item(),
        }

    def initialize_availability_hybrid_expert_residual(self):
        """Restore and verify the improvement-14 epoch-0 identity."""
        if self.availability_hybrid_expert_residual is None:
            return None
        self.availability_hybrid_expert_residual.reset_identity()
        return self.availability_hybrid_expert_residual.identity_diagnostics()

    def initialize_missing_tag_fusion_bias(self):
        """Restore and verify the exact tag identity after HF loading."""
        if self.missing_tag_fusion_bias is None:
            return None
        self.missing_tag_fusion_bias.reset_identity()
        return {
            "projection_weight_max": (
                self.missing_tag_fusion_bias.projection.weight
                .detach().abs().max().item()
            ),
        }

    def initialize_layerwise_coupled_missing_prompt(self):
        """Restore the exact FPFR path before improvement-20 training."""
        if self.layerwise_coupled_missing_prompt is None:
            return None
        self.layerwise_coupled_missing_prompt.reset_identity()
        scales = self.layerwise_coupled_missing_prompt.residual_scale_logits
        return {
            'scale_logit_max': scales.detach().abs().max().item(),
            'prompt_depth': self.layerwise_coupled_missing_prompt.num_layers,
            'prompt_length': self.layerwise_coupled_missing_prompt.prompt_length,
        }

    def configure_missing_prompt_finetuning(self):
        """Freeze q0 and expose the selected seventh-improvement ablation."""
        if self.dynamic_prompt_adapter is None:
            return None
        if self.fusion_mode != 'flat' or self.fusion_all is None:
            raise ValueError("missing dynamic prompt requires flat q0 fusion")
        for parameter in self.parameters():
            parameter.requires_grad = False
        if self.prompt_finetune_scope == 'prompt_head':
            for parameter in self.dynamic_prompt_adapter.parameters():
                parameter.requires_grad = True
        elif self.prompt_finetune_scope != 'head_only':
            raise ValueError(
                "unknown prompt fine-tune scope: {}".format(
                    self.prompt_finetune_scope
                )
            )
        for parameter in self.fusion_all.parameters():
            parameter.requires_grad = True
        trainable_names = [
            name for name, parameter in self.named_parameters()
            if parameter.requires_grad
        ]
        return {
            "trainable_names": trainable_names,
            "trainable_parameters": sum(
                parameter.numel() for parameter in self.parameters()
                if parameter.requires_grad
            ),
            "total_parameters": sum(
                parameter.numel() for parameter in self.parameters()
            ),
        }

    def enforce_missing_prompt_finetune_mode(self):
        """Keep the frozen q0 feature extractor deterministic while tuning."""
        if self.dynamic_prompt_adapter is None:
            return
        self.eval()
        if self.prompt_finetune_scope == 'prompt_head':
            self.dynamic_prompt_adapter.train()
        self.fusion_all.train()

    def configure_training_prior_head_finetuning(self):
        """Freeze first+seventh and re-adapt only fusion_all with TSPE."""
        if self.training_similar_prior is None:
            return None
        if self.fusion_mode != 'flat' or self.fusion_all is None:
            raise ValueError("TSPE requires the flat first+seventh fusion")
        for parameter in self.parameters():
            parameter.requires_grad = False
        for parameter in self.fusion_all.parameters():
            parameter.requires_grad = True
        trainable_names = [
            name for name, parameter in self.named_parameters()
            if parameter.requires_grad
        ]
        return {
            "trainable_names": trainable_names,
            "trainable_parameters": sum(
                parameter.numel() for parameter in self.parameters()
                if parameter.requires_grad
            ),
            "total_parameters": sum(
                parameter.numel() for parameter in self.parameters()
            ),
        }

    def enforce_training_prior_finetune_mode(self):
        if self.training_similar_prior is None:
            return
        self.eval()
        self.training_similar_prior.train()
        self.fusion_all.train()

    def apply_training_similar_prior(self, features, observed_mask, labels):
        if self.training_similar_prior is None:
            return tuple(features), {"enabled": False}
        return self.training_similar_prior(
            features,
            observed_mask,
            labels=labels,
        )

    def configure_availability_hybrid_expert_finetuning(self):
        """Freeze first+seventh and expose only the ACHER branch."""
        if self.availability_hybrid_expert_residual is None:
            return None
        if self.fusion_mode != 'flat' or self.fusion_all is None:
            raise ValueError("ACHER requires the flat first+seventh fusion")
        for parameter in self.parameters():
            parameter.requires_grad = False
        for parameter in self.availability_hybrid_expert_residual.parameters():
            parameter.requires_grad = True
        trainable_names = [
            name for name, parameter in self.named_parameters()
            if parameter.requires_grad
        ]
        return {
            "trainable_names": trainable_names,
            "trainable_parameters": sum(
                parameter.numel() for parameter in self.parameters()
                if parameter.requires_grad
            ),
            "total_parameters": sum(
                parameter.numel() for parameter in self.parameters()
            ),
        }

    def configure_protocol_consistency_finetuning(self):
        """Freeze the foundation and expose the declared adaptation scope."""
        if (
            self.protocol_consistency_mode != 'pcmc'
            and not self.protocol_fusion_readaptation
        ):
            return None
        if self.fusion_mode != 'flat' or self.fusion_all is None:
            raise ValueError(
                "protocol fusion fine-tuning requires flat first+seventh fusion"
            )
        for parameter in self.parameters():
            parameter.requires_grad = False
        scope = (
            'fusion_all'
            if self.protocol_consistency_mode == 'pcmc'
            else self.protocol_adaptation_scope
        )
        if scope == 'last_layer':
            for parameter in self.fusion_all.fusion_layer_all_all.parameters():
                parameter.requires_grad = True
        elif scope == 'fusion_all':
            for parameter in self.fusion_all.parameters():
                parameter.requires_grad = True
        elif scope == 'late_transformer_fusion':
            for parameter in self.transformer_encoder_all.parameters():
                parameter.requires_grad = True
            for parameter in self.fusion_all.parameters():
                parameter.requires_grad = True
        else:
            raise ValueError("unknown protocol adaptation scope: {}".format(scope))
        trainable_names = [
            name for name, parameter in self.named_parameters()
            if parameter.requires_grad
        ]
        return {
            "trainable_names": trainable_names,
            "trainable_parameters": sum(
                parameter.numel() for parameter in self.parameters()
                if parameter.requires_grad
            ),
            "total_parameters": sum(
                parameter.numel() for parameter in self.parameters()
            ),
        }

    def enforce_protocol_consistency_finetune_mode(self):
        if (
            self.protocol_consistency_mode != 'pcmc'
            and not self.protocol_fusion_readaptation
        ):
            return
        self.eval()
        scope = (
            'fusion_all'
            if self.protocol_consistency_mode == 'pcmc'
            else self.protocol_adaptation_scope
        )
        if scope == 'last_layer':
            self.fusion_all.fusion_layer_all_all.train()
        elif scope == 'fusion_all':
            self.fusion_all.train()
        elif scope == 'late_transformer_fusion':
            self.transformer_encoder_all.train()
            self.fusion_all.train()

    def configure_relation_distillation_finetuning(self):
        """Freeze first+seventh+FPFR and expose only the late fusion path."""
        if self.relation_distill_mode != 'tag_mrd':
            return None
        if self.fusion_mode != 'flat' or self.fusion_all is None:
            raise ValueError("TAG-MRD requires the flat fusion path")
        for parameter in self.parameters():
            parameter.requires_grad = False
        for parameter in self.transformer_encoder_all.parameters():
            parameter.requires_grad = True
        for parameter in self.fusion_all.parameters():
            parameter.requires_grad = True
        trainable_names = [
            name for name, parameter in self.named_parameters()
            if parameter.requires_grad
        ]
        return {
            "trainable_names": trainable_names,
            "trainable_parameters": sum(
                parameter.numel() for parameter in self.parameters()
                if parameter.requires_grad
            ),
            "total_parameters": sum(
                parameter.numel() for parameter in self.parameters()
            ),
        }

    def enforce_relation_distillation_finetune_mode(self):
        if self.relation_distill_mode != 'tag_mrd':
            return
        self.eval()
        self.transformer_encoder_all.train()
        self.fusion_all.train()

    def configure_missing_text_contrast_finetuning(self):
        """Freeze first+seventh+FPFR and expose only improvement 17."""
        if self.missing_text_contrast_residual is None:
            return None
        if self.fusion_mode != 'flat' or self.fusion_all is None:
            raise ValueError("missing-text contrast requires the flat fusion path")
        for parameter in self.parameters():
            parameter.requires_grad = False
        for parameter in self.missing_text_contrast_residual.parameters():
            parameter.requires_grad = True
        trainable_names = [
            name for name, parameter in self.named_parameters()
            if parameter.requires_grad
        ]
        return {
            "trainable_names": trainable_names,
            "trainable_parameters": sum(
                parameter.numel() for parameter in self.parameters()
                if parameter.requires_grad
            ),
            "total_parameters": sum(
                parameter.numel() for parameter in self.parameters()
            ),
        }

    def enforce_missing_text_contrast_finetune_mode(self):
        if self.missing_text_contrast_residual is None:
            return
        self.eval()
        self.missing_text_contrast_residual.train()

    def configure_privileged_purification_finetuning(self):
        """Freeze first+seventh+FPFR and expose only the PDRP adapter."""
        if self.privileged_disentangled_purification is None:
            return None
        if self.fusion_mode != 'flat' or self.fusion_all is None:
            raise ValueError("PDRP requires the flat FPFR fusion path")
        for parameter in self.parameters():
            parameter.requires_grad = False
        for parameter in self.privileged_disentangled_purification.parameters():
            parameter.requires_grad = True
        trainable_names = [
            name for name, parameter in self.named_parameters()
            if parameter.requires_grad
        ]
        return {
            "trainable_names": trainable_names,
            "trainable_parameters": sum(
                parameter.numel() for parameter in self.parameters()
                if parameter.requires_grad
            ),
            "total_parameters": sum(
                parameter.numel() for parameter in self.parameters()
            ),
        }

    def enforce_privileged_purification_finetune_mode(self):
        if self.privileged_disentangled_purification is None:
            return
        self.eval()
        self.privileged_disentangled_purification.train()

    def configure_language_hyper_finetuning(self):
        """Freeze first+seventh+FPFR and expose only improvement 19."""
        if self.availability_tagged_language_hyper_residual is None:
            return None
        if self.fusion_mode != 'flat' or self.fusion_all is None:
            raise ValueError("AT-LDHR requires the flat FPFR fusion path")
        for parameter in self.parameters():
            parameter.requires_grad = False
        for parameter in (
            self.availability_tagged_language_hyper_residual.parameters()
        ):
            parameter.requires_grad = True
        trainable_names = [
            name for name, parameter in self.named_parameters()
            if parameter.requires_grad
        ]
        return {
            'trainable_names': trainable_names,
            'trainable_parameters': sum(
                parameter.numel() for parameter in self.parameters()
                if parameter.requires_grad
            ),
            'total_parameters': sum(
                parameter.numel() for parameter in self.parameters()
            ),
        }

    def enforce_language_hyper_finetune_mode(self):
        if self.availability_tagged_language_hyper_residual is None:
            return
        self.eval()
        self.availability_tagged_language_hyper_residual.train()

    def configure_coupled_prompt_finetuning(self):
        """Freeze first+seventh+FPFR and expose only improvement 20."""
        if self.layerwise_coupled_missing_prompt is None:
            return None
        if self.fusion_mode != 'flat' or self.fusion_all is None:
            raise ValueError("LCMPR requires the flat FPFR fusion path")
        for parameter in self.parameters():
            parameter.requires_grad = False
        for parameter in self.layerwise_coupled_missing_prompt.parameters():
            parameter.requires_grad = True
        trainable_names = [
            name for name, parameter in self.named_parameters()
            if parameter.requires_grad
        ]
        return {
            'trainable_names': trainable_names,
            'trainable_parameters': sum(
                parameter.numel() for parameter in self.parameters()
                if parameter.requires_grad
            ),
            'total_parameters': sum(
                parameter.numel() for parameter in self.parameters()
            ),
        }

    def enforce_coupled_prompt_finetune_mode(self):
        if self.layerwise_coupled_missing_prompt is None:
            return
        self.eval()
        self.layerwise_coupled_missing_prompt.train()

    def enforce_availability_hybrid_expert_finetune_mode(self):
        if self.availability_hybrid_expert_residual is None:
            return
        self.eval()
        self.availability_hybrid_expert_residual.train()

    def apply_availability_hybrid_expert_residual(
        self,
        enhanced_modalities,
        sample_representation,
        observed_mask,
        base_prediction,
    ):
        if self.availability_hybrid_expert_residual is None:
            zero = base_prediction.sum() * 0.0
            return base_prediction, zero, {"enabled": False}
        return self.availability_hybrid_expert_residual(
            enhanced_modalities,
            sample_representation,
            observed_mask,
            base_prediction,
        )

    def configure_text_guided_reconstruction_finetuning(self):
        """Reproduce frozen improvement 8 with an isolated reconstructor."""
        if self.text_guided_reconstructor is None:
            return None
        if self.fusion_mode != 'flat' or self.fusion_all is None:
            raise ValueError("text-guided reconstruction requires flat fusion")
        for parameter in self.parameters():
            parameter.requires_grad = False
        for parameter in self.text_guided_reconstructor.parameters():
            parameter.requires_grad = True
        trainable_names = [
            name for name, parameter in self.named_parameters()
            if parameter.requires_grad
        ]
        return {
            "trainable_names": trainable_names,
            "trainable_parameters": sum(
                parameter.numel() for parameter in self.parameters()
                if parameter.requires_grad
            ),
            "total_parameters": sum(
                parameter.numel() for parameter in self.parameters()
            ),
        }

    def configure_unified_consensus_finetuning(self):
        """Freeze the first+seventh foundation and expose only AMUCR."""
        if self.unified_consensus_residual is None:
            return None
        if self.fusion_mode != 'flat' or self.fusion_all is None:
            raise ValueError("AMUCR requires the flat first+seventh fusion")
        for parameter in self.parameters():
            parameter.requires_grad = False
        for parameter in self.unified_consensus_residual.parameters():
            parameter.requires_grad = True
        trainable_names = [
            name for name, parameter in self.named_parameters()
            if parameter.requires_grad
        ]
        return {
            "trainable_names": trainable_names,
            "trainable_parameters": sum(
                parameter.numel() for parameter in self.parameters()
                if parameter.requires_grad
            ),
            "total_parameters": sum(
                parameter.numel() for parameter in self.parameters()
            ),
        }

    def configure_missing_tag_finetuning(self):
        """Freeze the first+seventh foundation and expose only AMTFB."""
        if self.missing_tag_fusion_bias is None:
            return None
        if self.fusion_mode != 'flat' or self.fusion_all is None:
            raise ValueError("AMTFB requires the flat first+seventh fusion")
        for parameter in self.parameters():
            parameter.requires_grad = False
        for parameter in self.missing_tag_fusion_bias.parameters():
            parameter.requires_grad = True
        trainable_names = [
            name for name, parameter in self.named_parameters()
            if parameter.requires_grad
        ]
        return {
            "trainable_names": trainable_names,
            "trainable_parameters": sum(
                parameter.numel() for parameter in self.parameters()
                if parameter.requires_grad
            ),
            "total_parameters": sum(
                parameter.numel() for parameter in self.parameters()
            ),
        }

    def enforce_missing_tag_finetune_mode(self):
        """Keep the proven foundation deterministic while AMTFB trains."""
        if self.missing_tag_fusion_bias is None:
            return
        self.eval()
        self.missing_tag_fusion_bias.train()

    def enforce_unified_consensus_finetune_mode(self):
        """Keep the proven foundation deterministic while AMUCR trains."""
        if self.unified_consensus_residual is None:
            return
        self.eval()
        self.unified_consensus_residual.train()

    def enforce_text_guided_reconstruction_finetune_mode(self):
        if self.text_guided_reconstructor is None:
            return
        self.eval()
        self.text_guided_reconstructor.train()

    def configure_cross_modal_retrieval_finetuning(self):
        """Freeze first+seventh and expose only the AGCQR query module."""
        if self.cross_modal_query_retrieval is None:
            return None
        if self.fusion_mode != 'flat' or self.fusion_all is None:
            raise ValueError("AGCQR requires the flat first+seventh fusion")
        for parameter in self.parameters():
            parameter.requires_grad = False
        for parameter in self.cross_modal_query_retrieval.parameters():
            parameter.requires_grad = True
        trainable_names = [
            name for name, parameter in self.named_parameters()
            if parameter.requires_grad
        ]
        return {
            "trainable_names": trainable_names,
            "trainable_parameters": sum(
                parameter.numel() for parameter in self.parameters()
                if parameter.requires_grad
            ),
            "total_parameters": sum(
                parameter.numel() for parameter in self.parameters()
            ),
        }

    def enforce_cross_modal_retrieval_finetune_mode(self):
        if self.cross_modal_query_retrieval is None:
            return
        self.eval()
        self.cross_modal_query_retrieval.train()

    def set_cross_modal_reference_banks(self, banks):
        if self.cross_modal_query_retrieval is None:
            raise RuntimeError("AGCQR is disabled")
        self.cross_modal_query_retrieval.set_reference_banks(banks)

    def set_strict_retrieval_reference_banks(self, banks, sample_ids):
        """Install runtime-only, complete-training donors for E01."""
        if set(banks) != {'l', 'a', 'v'}:
            raise ValueError("strict retrieval requires l/a/v banks")
        expected_size = sample_ids.numel()
        for modality in ('l', 'a', 'v'):
            if banks[modality].size(0) != expected_size:
                raise ValueError("strict retrieval bank sizes must agree")
            self.modality_retrieval[modality].set_reference_bank(
                banks[modality], sample_ids
            )

    def configure_bundle_retrieval_evaluation(self):
        """Freeze the complete first+seventh foundation for SCBR search."""
        if self.same_sample_bundle_retrieval is None:
            return None
        if self.fusion_mode != 'flat' or self.fusion_all is None:
            raise ValueError("SCBR requires the flat first+seventh fusion")
        for parameter in self.parameters():
            parameter.requires_grad = False
        return {
            "trainable_names": [],
            "trainable_parameters": 0,
            "total_parameters": sum(
                parameter.numel() for parameter in self.parameters()
            ),
        }

    def set_bundle_reference_bank(self, banks, labels):
        if self.same_sample_bundle_retrieval is None:
            raise RuntimeError("SCBR is disabled")
        self.same_sample_bundle_retrieval.set_reference_bank(banks, labels)

    def set_bundle_injection_scale(self, scale):
        if self.same_sample_bundle_retrieval is None:
            raise RuntimeError("SCBR is disabled")
        self.same_sample_bundle_retrieval.set_injection_scale(scale)

    def apply_same_sample_bundle_retrieval(
        self,
        eh_sample,
        base_enhanced,
        raw_features,
        observed_mask,
        base_retrieved,
    ):
        if self.same_sample_bundle_retrieval is None:
            return base_retrieved, {"enabled": False}
        # SCBR is deliberately parameter-free.  The frozen foundation first
        # supplies a continuous sentiment anchor, then a second fusion uses the
        # completed neighbour slots.  No test label enters donor ranking.
        with torch.no_grad():
            seed_prediction, _ = self.fuse_representations(
                (eh_sample,) + tuple(base_enhanced) + tuple(raw_features),
                observed_mask,
            )
        return self.same_sample_bundle_retrieval(
            raw_features,
            observed_mask,
            base_retrieved,
            seed_prediction.view(-1),
        )

    def apply_dynamic_prompt(
        self, eh_sample, enhanced_features, raw_features, observed_mask
    ):
        if self.dynamic_prompt_adapter is None:
            return enhanced_features, {"enabled": False}
        if self.prompt_finetune_scope == 'head_only':
            return enhanced_features, {
                "enabled": False,
                "ablation": "head_only",
            }
        prompted, diagnostics = self.dynamic_prompt_adapter(
            eh_sample, enhanced_features, raw_features, observed_mask
        )
        diagnostics["enabled"] = True
        return prompted, diagnostics

    def apply_missing_text_contrast_residual(
        self,
        eh_sample,
        enhanced_features,
        raw_features,
        observed_mask,
    ):
        if self.missing_text_contrast_residual is None:
            return enhanced_features, {"enabled": False}
        return self.missing_text_contrast_residual(
            eh_sample,
            enhanced_features,
            raw_features,
            observed_mask,
        )

    def apply_privileged_purification(
        self,
        eh_sample,
        enhanced_features,
        raw_features,
        observed_mask,
    ):
        if self.privileged_disentangled_purification is None:
            return enhanced_features, {"enabled": False}
        return self.privileged_disentangled_purification(
            eh_sample,
            enhanced_features,
            raw_features,
            observed_mask,
        )

    def apply_language_hyper_residual(
        self,
        eh_sample,
        enhanced_features,
        raw_features,
        observed_mask,
    ):
        if self.availability_tagged_language_hyper_residual is None:
            return enhanced_features, {'enabled': False}
        return self.availability_tagged_language_hyper_residual(
            eh_sample,
            enhanced_features,
            raw_features,
            observed_mask,
        )

    def encode_complete_nonverbal_target(
        self, feature, projection, transformer, pool
    ):
        projected = projection(feature.transpose(1, 2)).permute(2, 0, 1)
        transformed = transformer(projected, projected, projected)
        transformed = transformed.permute(1, 2, 0)
        return pool(transformed).squeeze(-1)

    def encode_complete_raw_features(
        self,
        input_ids,
        visual,
        acoustic,
        attention_mask=None,
        token_type_ids=None,
    ):
        """Encode an unmasked T/A/V view for AGCQR bank construction."""
        texts = self.bert(
            input_ids,
            attention_mask=attention_mask,
            token_type_ids=token_type_ids,
        )
        return (
            self.encode_complete_nonverbal_target(
                texts, self.proj_l_1, self.text_trans, self.pool_text
            ),
            self.encode_complete_nonverbal_target(
                acoustic, self.proj_a_1, self.audio_trans, self.pool_audio
            ),
            self.encode_complete_nonverbal_target(
                visual, self.proj_v_1, self.video_trans, self.pool_video
            ),
        )

    def apply_text_guided_reconstruction(
        self,
        eh_sample,
        raw_features,
        observed_mask,
        complete_targets=None,
    ):
        if self.text_guided_reconstructor is None:
            return raw_features, None, {"enabled": False}
        return self.text_guided_reconstructor(
            eh_sample,
            raw_features[0],
            raw_features,
            observed_mask,
            complete_targets=complete_targets,
        )

    def Get_Modality_Network(self,modality='l'):
        if modality in ['l']:
            attn_dropout = self.attn_dropout
        elif modality in ['a']:
            attn_dropout = self.attn_dropout_a
        elif modality in ['v']:
            attn_dropout = self.attn_dropout_v
        else:
            raise ValueError("Unknown network type")
            
        return  TransformerEncoder(embed_dim=self.d_l,
                                  num_heads=self.num_heads,
                                  layers=self.layers,
                                  attn_dropout=self.attn_dropout,
                                  relu_dropout=self.relu_dropout,
                                  res_dropout=self.res_dropout,
                                  embed_dropout=self.embed_dropout,
                                  attn_mask=False)

    def get_latent_network(self,self_type='sam',layers=-1):
        if self_type in ['sam']:
            num_latents, mixup = 3, False# modify here
        elif self_type in ['mod_l', 'mod_a', 'mod_v']:
            num_latents, mixup = 4, True# modify crossmodal dropout      
        else:
            raise ValueError("Unknown network type")
            
        return LatentTransformer(num_latents=num_latents,
                                 latent_dim=self.d_l,
                                 input_dim=self.d_l,
                                 depth=self.latent_depth,
                                 heads=self.num_heads,
                                 latent_heads=self.num_heads,
                                 latent_dim_head=self.d_l//self.num_heads,
                                 dim_head=self.d_l//self.num_heads,
                                 mixup=mixup)
 
    def get_similar_embeddings(
        self,
        embeddings,
        observed_mask,
        modality,
        sample_query=None,
        labels=None,
        query_ids=None,
    ):
        if self.retrieval_mode == 'legacy':
            return legacy_batch_retrieval(
                embeddings, top_k=self.retrieval_top_k
            )
        return self.modality_retrieval[modality](
            embeddings,
            observed_mask,
            sample_query=sample_query,
            labels=labels,
            query_ids=query_ids,
        )

    def apply_reliability_gate(
        self,
        eh_sample,
        enhanced_features,
        raw_features,
        ps,
        retrieval_diagnostics,
    ):
        if (
            self.gate_mode in (
                'quality_reliability',
                'quality_reliability_v22',
                'counterfactual_harm_v23',
                'counterfactual_scale_v24',
            )
            and self.reliability_gate is None
        ):
            raise RuntimeError(
                "Quality reliability gate must be initialized after "
                "from_pretrained before use"
            )
        if self.reliability_gate is None:
            return enhanced_features, raw_features, {"enabled": False}

        if self.gate_mode in (
            'quality_reliability',
            'quality_reliability_v22',
            'counterfactual_harm_v23',
            'counterfactual_scale_v24',
            'fixed_scale_ablation',
        ):
            calibrated_enhanced = []
            calibrated_raw = []
            diagnostics = {
                "enabled": True,
                "mode": self.gate_mode,
            }
            for modality_index, modality in enumerate(('l', 'a', 'v')):
                observed_mask = ps[:, modality_index]
                gate_arguments = (
                    enhanced_features[modality_index],
                    eh_sample,
                    observed_mask,
                    retrieval_diagnostics[modality_index],
                )
                if self.gate_mode == 'counterfactual_scale_v24':
                    enhanced, enhanced_diagnostics = self.reliability_gate(
                        *gate_arguments,
                        modality_index=modality_index,
                    )
                else:
                    enhanced, enhanced_diagnostics = self.reliability_gate(
                        *gate_arguments
                    )
                raw_mask = observed_mask.to(
                    device=raw_features[modality_index].device,
                    dtype=raw_features[modality_index].dtype,
                ).view(-1, 1)
                calibrated_enhanced.append(enhanced)
                if self.gate_mode == 'fixed_scale_ablation':
                    # Keep the q0 raw path byte-for-byte unchanged. This
                    # ablation must differ only in the enhanced multiplier.
                    calibrated_raw.append(raw_features[modality_index])
                else:
                    calibrated_raw.append(
                        raw_features[modality_index] * raw_mask
                    )
                diagnostics[modality] = {
                    "enhanced": enhanced_diagnostics,
                }
            return (
                tuple(calibrated_enhanced),
                tuple(calibrated_raw),
                diagnostics,
            )

        calibrated_enhanced = []
        calibrated_raw = []
        diagnostics = {"enabled": True, "mode": "reliability_v1"}
        for modality_index, modality in enumerate(('l', 'a', 'v')):
            observed_mask = ps[:, modality_index]
            enhanced, enhanced_diagnostics = self.reliability_gate(
                enhanced_features[modality_index],
                eh_sample,
                observed_mask,
                modality_index,
                ResidualReliabilityGate.ENHANCED_BRANCH,
            )
            raw, raw_diagnostics = self.reliability_gate(
                raw_features[modality_index],
                eh_sample,
                observed_mask,
                modality_index,
                ResidualReliabilityGate.RAW_BRANCH,
            )
            calibrated_enhanced.append(enhanced)
            calibrated_raw.append(raw)
            diagnostics[modality] = {
                "enhanced": enhanced_diagnostics,
                "raw": raw_diagnostics,
            }

        return tuple(calibrated_enhanced), tuple(calibrated_raw), diagnostics

    def fuse_representations(self, representations, observed_mask=None):
        # Explicit opt-in only: availability_multistage is a frozen failure.
        if self.availability_multistage_fusion is not None:
            if observed_mask is None:
                raise ValueError(
                    "observed_mask is required for availability_multistage fusion"
                )
            output, hidden, diagnostics = self.availability_multistage_fusion(
                representations[0],
                representations[1:4],
                representations[4:7],
                observed_mask,
            )
            self._last_fusion_diagnostics = diagnostics
            self._last_tag_diagnostics = {"enabled": False}
            return output, hidden
        hidden = torch.stack(representations, dim=0)
        if self.layerwise_coupled_missing_prompt is None:
            hidden = self.transformer_encoder_all(hidden)
            self._last_coupled_prompt_diagnostics = {"enabled": False}
        else:
            if observed_mask is None:
                raise ValueError("observed_mask is required for LCMPR")
            hidden, self._last_coupled_prompt_diagnostics = (
                self.layerwise_coupled_missing_prompt(
                    self.transformer_encoder_all,
                    hidden,
                    observed_mask,
                )
            )
        flattened = torch.cat(tuple(hidden[index] for index in range(7)), dim=1)
        if self.missing_tag_fusion_bias is None:
            output = self.fusion_all(flattened)
            self._last_tag_diagnostics = {"enabled": False}
        else:
            if observed_mask is None:
                raise ValueError("observed_mask is required for AMTFB")
            tag_shift, tag_diagnostics = self.missing_tag_fusion_bias(
                observed_mask
            )
            fusion_hidden = (
                self.fusion_all.fusion_layer_all(flattened) + tag_shift
            )
            fusion_hidden = self.fusion_all.fusion_layer_all_dropout(
                fusion_hidden
            )
            fusion_hidden = self.fusion_all.fusion_layer_all_activation(
                fusion_hidden
            )
            output = self.fusion_all.fusion_layer_all_all(fusion_hidden)
            self._last_tag_diagnostics = tag_diagnostics
        self._last_fusion_diagnostics = {"mode": "flat"}
        return output, flattened

    def apply_unified_consensus_residual(
        self, representations, observed_mask, base_output
    ):
        if self.unified_consensus_residual is None:
            return base_output, {"enabled": False}
        return self.unified_consensus_residual(
            representations,
            observed_mask,
            base_output,
        )

    def counterfactual_harm_supervision(
        self,
        ungated_representations,
        labels,
        gate_diagnostics,
    ):
        """Supervise harm logits with deterministic branch-removal evidence."""
        if self.gate_mode != 'counterfactual_harm_v23':
            return None, None

        harm_logits = torch.stack(
            [
                gate_diagnostics[modality]["enhanced"]["harm_logit"]
                for modality in ('l', 'a', 'v')
            ],
            dim=1,
        )
        detached_representations = tuple(
            representation.detach()
            for representation in ungated_representations
        )

        transformer_training = self.transformer_encoder_all.training
        fusion_training = self.fusion_all.training
        self.transformer_encoder_all.eval()
        self.fusion_all.eval()
        try:
            with torch.no_grad():
                factual_prediction, _ = self.fuse_representations(
                    detached_representations
                )
                removed_predictions = []
                for enhanced_index in (1, 2, 3):
                    counterfactual = list(detached_representations)
                    counterfactual[enhanced_index] = torch.zeros_like(
                        counterfactual[enhanced_index]
                    )
                    prediction, _ = self.fuse_representations(
                        tuple(counterfactual)
                    )
                    removed_predictions.append(prediction.view(-1))
        finally:
            self.transformer_encoder_all.train(transformer_training)
            self.fusion_all.train(fusion_training)

        targets = labels.detach().view(-1)
        factual_error = torch.abs(
            factual_prediction.detach().view(-1) - targets
        )
        removed_error = torch.stack(
            [
                torch.abs(prediction.detach() - targets)
                for prediction in removed_predictions
            ],
            dim=1,
        )
        # Positive margin means the full q0 branch increases error, so its
        # enhancement is harmful for this sample. Normalization is batch-local
        # and detached; it controls target scale without a protocol-specific
        # threshold.
        harm_margin = factual_error.unsqueeze(1) - removed_error
        normalizer = harm_margin.detach().abs().mean().clamp_min(1e-4)
        harm_target = (
            1.0
            - torch.exp(
                -torch.relu(harm_margin.detach()) / normalizer
            )
        ).clamp(min=0.0, max=1.0)
        gate_loss = F.binary_cross_entropy_with_logits(
            harm_logits,
            harm_target,
        )
        supervision_diagnostics = {
            "loss": gate_loss.detach(),
            "harm_target_mean": harm_target.mean().detach(),
            "harmful_fraction": (harm_margin > 0.0).float().mean().detach(),
            "absolute_margin_mean": harm_margin.abs().mean().detach(),
            "target_by_modality": harm_target.mean(dim=0).detach(),
        }
        return gate_loss, supervision_diagnostics

    def counterfactual_scale_supervision(
        self,
        ungated_representations,
        labels,
        gate_diagnostics,
    ):
        """Teach V2.4 the best scale among executable counterfactuals.

        The factual branch (scale 1.0) is evaluated once.  Each enhanced
        branch is then evaluated at the configured middle scale and at the
        gate's minimum scale.  The scale with the lowest per-sample absolute
        error becomes a detached regression target for that branch.
        """
        if self.gate_mode != 'counterfactual_scale_v24':
            return None, None
        if not self.gate_min_scale < self.gate_teacher_mid_scale < 1.0:
            raise ValueError(
                "gate_teacher_mid_scale must be strictly between "
                "gate_min_scale and 1"
            )
        if self.gate_scale_loss_beta <= 0.0:
            raise ValueError("gate_scale_loss_beta must be positive")

        predicted_scales = torch.stack(
            [
                gate_diagnostics[modality]["enhanced"]["scale_prediction"]
                for modality in ('l', 'a', 'v')
            ],
            dim=1,
        )
        detached_representations = tuple(
            representation.detach()
            for representation in ungated_representations
        )
        targets = labels.detach().view(-1)
        teacher_scales = predicted_scales.detach().new_tensor(
            [1.0, self.gate_teacher_mid_scale, self.gate_min_scale]
        )

        transformer_training = self.transformer_encoder_all.training
        fusion_training = self.fusion_all.training
        self.transformer_encoder_all.eval()
        self.fusion_all.eval()
        try:
            with torch.no_grad():
                factual_prediction, _ = self.fuse_representations(
                    detached_representations
                )
                factual_error = torch.abs(
                    factual_prediction.view(-1) - targets
                )
                errors_by_modality = []
                for enhanced_index in (1, 2, 3):
                    candidate_errors = [factual_error]
                    for scale in teacher_scales[1:]:
                        counterfactual = list(detached_representations)
                        counterfactual[enhanced_index] = (
                            counterfactual[enhanced_index] * scale
                        )
                        prediction, _ = self.fuse_representations(
                            tuple(counterfactual)
                        )
                        candidate_errors.append(
                            torch.abs(prediction.view(-1) - targets)
                        )
                    errors_by_modality.append(
                        torch.stack(candidate_errors, dim=1)
                    )
                candidate_errors = torch.stack(
                    errors_by_modality, dim=1
                )
        finally:
            self.transformer_encoder_all.train(transformer_training)
            self.fusion_all.train(fusion_training)

        target_scales, best_error, best_index = (
            select_counterfactual_scale_targets(
                candidate_errors, teacher_scales
            )
        )
        gate_loss = F.smooth_l1_loss(
            predicted_scales,
            target_scales,
            beta=self.gate_scale_loss_beta,
        )

        selection_fraction = torch.stack(
            [
                (best_index == index).float().mean(dim=0)
                for index in range(teacher_scales.numel())
            ],
            dim=1,
        )
        observed = torch.stack(
            [
                gate_diagnostics[modality]["enhanced"]["observed"]
                for modality in ('l', 'a', 'v')
            ],
            dim=1,
        ).bool()
        # Sufficient statistics support exact epoch-level, within-group
        # target/prediction standard deviations and Pearson correlations.
        group_statistics = predicted_scales.detach().new_zeros((3, 2, 6))
        detached_prediction = predicted_scales.detach()
        detached_target = target_scales.detach()
        for modality_index in range(3):
            for status_index in range(2):
                selection = observed[:, modality_index] == bool(status_index)
                group_target = detached_target[selection, modality_index]
                group_prediction = detached_prediction[
                    selection, modality_index
                ]
                group_statistics[modality_index, status_index] = torch.stack(
                    [
                        group_target.new_tensor(float(group_target.numel())),
                        group_target.sum(),
                        group_target.square().sum(),
                        group_prediction.sum(),
                        group_prediction.square().sum(),
                        (group_target * group_prediction).sum(),
                    ]
                )

        supervision_diagnostics = {
            "loss": gate_loss.detach(),
            "scale_mae": torch.abs(
                predicted_scales.detach() - target_scales
            ).mean(),
            "target_scale_mean": target_scales.mean().detach(),
            "predicted_scale_mean": predicted_scales.mean().detach(),
            "oracle_gain_mean": (
                factual_error.unsqueeze(1) - best_error
            ).mean().detach(),
            "target_by_modality": target_scales.mean(dim=0).detach(),
            "prediction_by_modality": (
                predicted_scales.mean(dim=0).detach()
            ),
            "selection_fraction": selection_fraction.detach(),
            "teacher_scales": teacher_scales.detach(),
            "group_statistics": group_statistics.detach(),
        }
        return gate_loss, supervision_diagnostics

    def forward(
        self,
        input_ids,
        visual,
        acoustic,
        ps,
        attention_mask=None,
        token_type_ids=None,
        position_ids=None,
        head_mask=None,
        inputs_embeds=None,
        labels=None,
        retrieval_labels=None,
        retrieval_query_ids=None,
        compute_reconstruction_targets=False,
        compute_cross_modal_targets=False,
        output_attentions=None,
        output_hidden_states=None,):
        
        texts = self.bert(
            input_ids,
            attention_mask=attention_mask,
            token_type_ids=token_type_ids,
            position_ids=position_ids,
            head_mask=head_mask,
            inputs_embeds=inputs_embeds,
            output_attentions=output_attentions,
            output_hidden_states=output_hidden_states,
        )
        
        x_l, x_a, x_v = generate_missing_modalities(ps, texts, acoustic, visual)
        x_l = x_l.transpose(1, 2)
        x_a = x_a.transpose(1, 2)
        x_v = x_v.transpose(1, 2)
        
        # Note that the input is incomplete
        proj_x_l = self.proj_l_1(x_l)
        proj_x_a = self.proj_a_1(x_a)
        proj_x_v = self.proj_v_1(x_v)
        
        proj_x_l = proj_x_l.permute(2, 0, 1)
        proj_x_a = proj_x_a.permute(2, 0, 1)
        proj_x_v = proj_x_v.permute(2, 0, 1)
   
        trans_text = self.text_trans(proj_x_l,proj_x_l,proj_x_l)
        trans_text = trans_text.permute(1,2,0)
        trans_audio = self.audio_trans(proj_x_a,proj_x_a,proj_x_a)
        trans_audio = trans_audio.permute(1,2,0)
        trans_video = self.video_trans(proj_x_v,proj_x_v,proj_x_v)
        trans_video = trans_video.permute(1,2,0)
        last_x_l = self.pool_text(trans_text).squeeze()
        last_x_a = self.pool_audio(trans_audio).squeeze()
        last_x_v = self.pool_video(trans_video).squeeze()
        (
            (last_x_l, last_x_a, last_x_v),
            prior_enhancement_diagnostics,
        ) = self.apply_training_similar_prior(
            (last_x_l, last_x_a, last_x_v),
            ps,
            labels,
        )

        cross_modal_targets = None
        if (
            self.cross_modal_query_retrieval is not None
            and compute_cross_modal_targets
        ):
            with torch.no_grad():
                cross_modal_targets = (
                    self.encode_complete_nonverbal_target(
                        texts,
                        self.proj_l_1,
                        self.text_trans,
                        self.pool_text,
                    ),
                    self.encode_complete_nonverbal_target(
                        acoustic,
                        self.proj_a_1,
                        self.audio_trans,
                        self.pool_audio,
                    ),
                    self.encode_complete_nonverbal_target(
                        visual,
                        self.proj_v_1,
                        self.video_trans,
                        self.pool_video,
                    ),
                )

        # here for intra-sample enhancement
        modality_all = torch.stack([last_x_l, last_x_a, last_x_v], dim=0)
        modality_all = modality_all.permute(1, 0, 2)
        eh_sample = self.latent_sample(modality_all)
        # here for intra-modal enhancement
        similar_texts, retrieval_l = self.get_similar_embeddings(
            last_x_l, ps[:, 0], 'l', eh_sample, retrieval_labels,
            retrieval_query_ids,
        )
        similar_audios, retrieval_a = self.get_similar_embeddings(
            last_x_a, ps[:, 1], 'a', eh_sample, retrieval_labels,
            retrieval_query_ids,
        )
        similar_videos, retrieval_v = self.get_similar_embeddings(
            last_x_v, ps[:, 2], 'v', eh_sample, retrieval_labels,
            retrieval_query_ids,
        )
        cross_modal_query_loss = last_x_l.sum() * 0.0
        cross_modal_query_diagnostics = {"enabled": False}
        if self.cross_modal_query_retrieval is not None:
            (
                (similar_texts, similar_audios, similar_videos),
                cross_modal_query_loss,
                cross_modal_query_diagnostics,
            ) = self.cross_modal_query_retrieval(
                (last_x_l, last_x_a, last_x_v),
                ps,
                (similar_texts, similar_audios, similar_videos),
                complete_targets=cross_modal_targets,
            )

        base_enhanced = (
            self.latent_text(similar_texts),
            self.latent_audio(similar_audios),
            self.latent_video(similar_videos),
        )
        bundle_retrieval_diagnostics = {"enabled": False}
        if self.same_sample_bundle_retrieval is not None:
            (
                (similar_texts, similar_audios, similar_videos),
                bundle_retrieval_diagnostics,
            ) = self.apply_same_sample_bundle_retrieval(
                eh_sample,
                base_enhanced,
                (last_x_l, last_x_a, last_x_v),
                ps,
                (similar_texts, similar_audios, similar_videos),
            )
            if bundle_retrieval_diagnostics[
                "injection_scale"
            ].item() == 0.0:
                eh_l, eh_a, eh_v = base_enhanced
            else:
                eh_l = self.latent_text(similar_texts)
                eh_a = self.latent_audio(similar_audios)
                eh_v = self.latent_video(similar_videos)
        else:
            eh_l, eh_a, eh_v = base_enhanced
        
        loss_l, mmd_l = self.availability_aware_mmd(
            eh_l, eh_sample, ps[:, 0]
        )
        loss_a, mmd_a = self.availability_aware_mmd(
            eh_a, eh_sample, ps[:, 1]
        )
        loss_v, mmd_v = self.availability_aware_mmd(
            eh_v, eh_sample, ps[:, 2]
        )

        # Seventh improvement: preserve q0/MMD, then correct only missing
        # enhanced branches with same-sample dynamic prompt residuals.
        prompted_enhanced, prompt_diagnostics = self.apply_dynamic_prompt(
            eh_sample,
            (eh_l, eh_a, eh_v),
            (last_x_l, last_x_a, last_x_v),
            ps,
        )
        (
            prompted_enhanced,
            missing_text_contrast_diagnostics,
        ) = self.apply_missing_text_contrast_residual(
            eh_sample,
            prompted_enhanced,
            (last_x_l, last_x_a, last_x_v),
            ps,
        )

        complete_targets = None
        if (
            self.text_guided_reconstructor is not None
            and compute_reconstruction_targets
        ):
            with torch.no_grad():
                complete_targets = (
                    self.encode_complete_nonverbal_target(
                        acoustic,
                        self.proj_a_1,
                        self.audio_trans,
                        self.pool_audio,
                    ),
                    self.encode_complete_nonverbal_target(
                        visual,
                        self.proj_v_1,
                        self.video_trans,
                        self.pool_video,
                    ),
                )
        reconstructed_raw, reconstruction_loss, reconstruction_diagnostics = (
            self.apply_text_guided_reconstruction(
                eh_sample,
                (last_x_l, last_x_a, last_x_v),
                ps,
                complete_targets=complete_targets,
            )
        )

        # fusion and prediction
        gated_enhanced, gated_raw, gate_diagnostics = self.apply_reliability_gate(
            eh_sample,
            prompted_enhanced,
            reconstructed_raw,
            ps,
            (retrieval_l, retrieval_a, retrieval_v),
        )
        gated_enhanced, language_hyper_diagnostics = (
            self.apply_language_hyper_residual(
                eh_sample,
                gated_enhanced,
                gated_raw,
                ps,
            )
        )
        gated_enhanced, privileged_purification_diagnostics = (
            self.apply_privileged_purification(
                eh_sample,
                gated_enhanced,
                gated_raw,
                ps,
            )
        )
        fusion_representations = (
            (eh_sample,) + gated_enhanced + gated_raw
        )
        output, hidden = self.fuse_representations(fusion_representations, ps)
        output, consensus_diagnostics = self.apply_unified_consensus_residual(
            fusion_representations, ps, output
        )
        (
            output,
            hybrid_expert_orthogonality_loss,
            hybrid_expert_diagnostics,
        ) = self.apply_availability_hybrid_expert_residual(
            gated_enhanced,
            eh_sample,
            ps,
            output,
        )
        gate_supervision_loss = None
        gate_supervision_diagnostics = None
        if labels is not None:
            ungated_representations = (
                (eh_sample, eh_l, eh_a, eh_v) + gated_raw
            )
            if self.gate_mode == 'counterfactual_harm_v23':
                gate_supervision_loss, gate_supervision_diagnostics = (
                    self.counterfactual_harm_supervision(
                        ungated_representations,
                        labels,
                        gate_diagnostics,
                    )
                )
            elif self.gate_mode == 'counterfactual_scale_v24':
                gate_supervision_loss, gate_supervision_diagnostics = (
                    self.counterfactual_scale_supervision(
                        ungated_representations,
                        labels,
                        gate_diagnostics,
                    )
                )
        mmd_losses = (loss_l + loss_a + loss_v) / 3 * self.alpha
        retrieval_loss = sum(
            diagnostics['retrieval_loss']
            for diagnostics in (retrieval_l, retrieval_a, retrieval_v)
        ) / 3
        res = {
                "mmd_losses": mmd_losses,
                "retrieval_loss": retrieval_loss,
                "cross_modal_query_loss": cross_modal_query_loss,
                "cross_modal_query_diagnostics": (
                    cross_modal_query_diagnostics
                ),
                "bundle_retrieval_diagnostics": (
                    bundle_retrieval_diagnostics
                ),
                "prior_enhancement_diagnostics": (
                    prior_enhancement_diagnostics
                ),
                "mmd_diagnostics": {
                    "mode": self.consistency_mode,
                    "l": mmd_l,
                    "a": mmd_a,
                    "v": mmd_v,
                },
                "predictions": output,
                "sample_representation": eh_sample,
                "fusion_representations": fusion_representations,
                "fusion_diagnostics": self._last_fusion_diagnostics,
                "coupled_prompt_diagnostics": (
                    self._last_coupled_prompt_diagnostics
                ),
                "tag_diagnostics": self._last_tag_diagnostics,
                "consensus_diagnostics": consensus_diagnostics,
                "hybrid_expert_orthogonality_loss": (
                    hybrid_expert_orthogonality_loss
                ),
                "hybrid_expert_diagnostics": hybrid_expert_diagnostics,
                "hidden": hidden,
                "retrieval_diagnostics": {
                    "l": retrieval_l,
                    "a": retrieval_a,
                    "v": retrieval_v,
                },
                "prompt_diagnostics": prompt_diagnostics,
                "missing_text_contrast_diagnostics": (
                    missing_text_contrast_diagnostics
                ),
                "privileged_purification_diagnostics": (
                    privileged_purification_diagnostics
                ),
                "language_hyper_diagnostics": language_hyper_diagnostics,
                "reconstruction_loss": reconstruction_loss,
                "reconstruction_diagnostics": reconstruction_diagnostics,
                "gate_diagnostics": gate_diagnostics,
                "gate_supervision_loss": gate_supervision_loss,
                "gate_supervision_diagnostics": (
                    gate_supervision_diagnostics
                ),
        }
        return res

    def test(
        self,
        input_ids,
        visual,
        acoustic,
        ps,
        label_ids=None,
        attention_mask=None,
        token_type_ids=None,
        position_ids=None,
        head_mask=None,
        inputs_embeds=None,
        labels=None,
        retrieval_query_ids=None,
        output_attentions=None,
        output_hidden_states=None,):
        
        texts = self.bert(
            input_ids,
            attention_mask=attention_mask,
            token_type_ids=token_type_ids,
            position_ids=position_ids,
            head_mask=head_mask,
            inputs_embeds=inputs_embeds,
            output_attentions=output_attentions,
            output_hidden_states=output_hidden_states,
        )
        
        x_l, x_a, x_v = generate_missing_modalities(ps, texts, acoustic, visual)
        x_l = x_l.transpose(1, 2)
        x_a = x_a.transpose(1, 2)
        x_v = x_v.transpose(1, 2)
        
        # Note that the input is incomplete
        proj_x_l = self.proj_l_1(x_l)
        proj_x_a = self.proj_a_1(x_a)
        proj_x_v = self.proj_v_1(x_v)
        
        proj_x_l = proj_x_l.permute(2, 0, 1)
        proj_x_a = proj_x_a.permute(2, 0, 1)
        proj_x_v = proj_x_v.permute(2, 0, 1)
   
        trans_text = self.text_trans(proj_x_l,proj_x_l,proj_x_l)
        trans_text = trans_text.permute(1,2,0)
        trans_audio = self.audio_trans(proj_x_a,proj_x_a,proj_x_a)
        trans_audio = trans_audio.permute(1,2,0)
        trans_video = self.video_trans(proj_x_v,proj_x_v,proj_x_v)
        trans_video = trans_video.permute(1,2,0)
        last_x_l = self.pool_text(trans_text).squeeze()
        last_x_a = self.pool_audio(trans_audio).squeeze()
        last_x_v = self.pool_video(trans_video).squeeze()
        (
            (last_x_l, last_x_a, last_x_v),
            prior_enhancement_diagnostics,
        ) = self.apply_training_similar_prior(
            (last_x_l, last_x_a, last_x_v),
            ps,
            labels,
        )

        # here for intra-sample enhancement
        modality_all = torch.stack([last_x_l, last_x_a, last_x_v], dim=0)
        modality_all = modality_all.permute(1, 0, 2)
        
        eh_sample = self.latent_sample(modality_all)
        # here for intra-modal enhancement
        similar_texts, retrieval_l = self.get_similar_embeddings(
            last_x_l, ps[:, 0], 'l', eh_sample, None,
            retrieval_query_ids,
        )
        similar_audios, retrieval_a = self.get_similar_embeddings(
            last_x_a, ps[:, 1], 'a', eh_sample, None,
            retrieval_query_ids,
        )
        similar_videos, retrieval_v = self.get_similar_embeddings(
            last_x_v, ps[:, 2], 'v', eh_sample, None,
            retrieval_query_ids,
        )
        cross_modal_query_loss = last_x_l.sum() * 0.0
        cross_modal_query_diagnostics = {"enabled": False}
        if self.cross_modal_query_retrieval is not None:
            (
                (similar_texts, similar_audios, similar_videos),
                cross_modal_query_loss,
                cross_modal_query_diagnostics,
            ) = self.cross_modal_query_retrieval(
                (last_x_l, last_x_a, last_x_v),
                ps,
                (similar_texts, similar_audios, similar_videos),
                complete_targets=None,
            )

        base_enhanced = (
            self.latent_text(similar_texts),
            self.latent_audio(similar_audios),
            self.latent_video(similar_videos),
        )
        bundle_retrieval_diagnostics = {"enabled": False}
        if self.same_sample_bundle_retrieval is not None:
            (
                (similar_texts, similar_audios, similar_videos),
                bundle_retrieval_diagnostics,
            ) = self.apply_same_sample_bundle_retrieval(
                eh_sample,
                base_enhanced,
                (last_x_l, last_x_a, last_x_v),
                ps,
                (similar_texts, similar_audios, similar_videos),
            )
            if bundle_retrieval_diagnostics[
                "injection_scale"
            ].item() == 0.0:
                eh_l, eh_a, eh_v = base_enhanced
            else:
                eh_l = self.latent_text(similar_texts)
                eh_a = self.latent_audio(similar_audios)
                eh_v = self.latent_video(similar_videos)
        else:
            eh_l, eh_a, eh_v = base_enhanced

        prompted_enhanced, prompt_diagnostics = self.apply_dynamic_prompt(
            eh_sample,
            (eh_l, eh_a, eh_v),
            (last_x_l, last_x_a, last_x_v),
            ps,
        )
        (
            prompted_enhanced,
            missing_text_contrast_diagnostics,
        ) = self.apply_missing_text_contrast_residual(
            eh_sample,
            prompted_enhanced,
            (last_x_l, last_x_a, last_x_v),
            ps,
        )
        reconstructed_raw, _, reconstruction_diagnostics = (
            self.apply_text_guided_reconstruction(
                eh_sample,
                (last_x_l, last_x_a, last_x_v),
                ps,
                complete_targets=None,
            )
        )
        
        # fusion and prediction
        gated_enhanced, gated_raw, gate_diagnostics = self.apply_reliability_gate(
            eh_sample,
            prompted_enhanced,
            reconstructed_raw,
            ps,
            (retrieval_l, retrieval_a, retrieval_v),
        )
        gated_enhanced, language_hyper_diagnostics = (
            self.apply_language_hyper_residual(
                eh_sample,
                gated_enhanced,
                gated_raw,
                ps,
            )
        )
        # Keep inference identical to ``forward``: improvement 18 purifies
        # missing enhanced tokens after reliability calibration and before
        # the frozen FPFR late-fusion path.
        gated_enhanced, privileged_purification_diagnostics = (
            self.apply_privileged_purification(
                eh_sample,
                gated_enhanced,
                gated_raw,
                ps,
            )
        )
        fusion_representations = (
            (eh_sample,) + gated_enhanced + gated_raw
        )
        output, hidden = self.fuse_representations(fusion_representations, ps)
        output, consensus_diagnostics = self.apply_unified_consensus_residual(
            fusion_representations, ps, output
        )
        (
            output,
            hybrid_expert_orthogonality_loss,
            hybrid_expert_diagnostics,
        ) = self.apply_availability_hybrid_expert_residual(
            gated_enhanced,
            eh_sample,
            ps,
            output,
        )
        gate_supervision_loss = None
        gate_supervision_diagnostics = None
        if (
            labels is not None
            and self.gate_mode == 'counterfactual_scale_v24'
        ):
            gate_supervision_loss, gate_supervision_diagnostics = (
                self.counterfactual_scale_supervision(
                    (eh_sample, eh_l, eh_a, eh_v) + gated_raw,
                    labels,
                    gate_diagnostics,
                )
            )
        res = {
                "predictions": output,
                "sample_representation": eh_sample,
                "fusion_representations": fusion_representations,
                "fusion_diagnostics": self._last_fusion_diagnostics,
                "coupled_prompt_diagnostics": (
                    self._last_coupled_prompt_diagnostics
                ),
                "tag_diagnostics": self._last_tag_diagnostics,
                "consensus_diagnostics": consensus_diagnostics,
                "hybrid_expert_orthogonality_loss": (
                    hybrid_expert_orthogonality_loss
                ),
                "hybrid_expert_diagnostics": hybrid_expert_diagnostics,
                "hidden": hidden,
                "retrieval_diagnostics": {
                    "l": retrieval_l,
                    "a": retrieval_a,
                    "v": retrieval_v,
                },
                "cross_modal_query_loss": cross_modal_query_loss,
                "cross_modal_query_diagnostics": (
                    cross_modal_query_diagnostics
                ),
                "bundle_retrieval_diagnostics": (
                    bundle_retrieval_diagnostics
                ),
                "prior_enhancement_diagnostics": (
                    prior_enhancement_diagnostics
                ),
                "prompt_diagnostics": prompt_diagnostics,
                "missing_text_contrast_diagnostics": (
                    missing_text_contrast_diagnostics
                ),
                "privileged_purification_diagnostics": (
                    privileged_purification_diagnostics
                ),
                "language_hyper_diagnostics": language_hyper_diagnostics,
                "reconstruction_diagnostics": reconstruction_diagnostics,
                "gate_diagnostics": gate_diagnostics,
                "gate_supervision_loss": gate_supervision_loss,
                "gate_supervision_diagnostics": (
                    gate_supervision_diagnostics
                ),
        }
        return res
