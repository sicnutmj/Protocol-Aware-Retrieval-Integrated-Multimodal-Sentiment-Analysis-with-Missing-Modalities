set -e

if [ "${E01_SMOKE:-0}" != "1" ]; then
  echo "Set E01_SMOKE=1 to run the non-formal one-epoch E01 GPU smoke test." >&2
  exit 2
fi

SMOKE_ROOT="${SMOKE_ROOT:-tmp/e01_smoke}"
mkdir -p "${SMOKE_ROOT}/checkpoints" "${SMOKE_ROOT}/logs"

echo "E01 smoke test: strict complete-training donor bank, protocol 6, one epoch"
echo "Outputs are diagnostic only and are excluded from paper_experiments."

python3 main.py \
  --retrieval_mode=missing_aware \
  --retrieval_candidate_source=train_bank \
  --retrieval_queue_size=0 \
  --retrieval_metric_mode=raw \
  --retrieval_missing_query=center \
  --retrieval_bank_batch_size=256 \
  --retrieval_bank_refresh_epochs=1 \
  --gate_mode=none \
  --consistency_mode=mixed \
  --fusion_mode=flat \
  --prompt_mode=none \
  --fixed_protocol=6 \
  --learning_rate=2e-5 \
  --d_l=192 \
  --latent_dim=192 \
  --train_batch_size=128 \
  --dev_batch_size=128 \
  --test_batch_size=128 \
  --dataset=mosei \
  --n_epochs=1 \
  --early_stopping_patience=0 \
  --best_model_dir="${SMOKE_ROOT}/checkpoints" \
  --log_dir="${SMOKE_ROOT}/logs"
