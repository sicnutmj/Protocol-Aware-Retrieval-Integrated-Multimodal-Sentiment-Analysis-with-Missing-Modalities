"""Execute and audit the formal E16 retrieval-temperature sensitivity study."""

from __future__ import annotations

import argparse
import json
import math
import os
import statistics
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path

from paper_experiment import code_fingerprints, resolve_dataset_path, sha256_file
from run_e06_mosei_primary import METRICS, PROTOCOL_SETTINGS, write_immutable_json
from run_e14_retrieval_topk import (
    _validate_frozen_reference_arguments,
    _validate_result,
)


DATASET = "mosei"
PROTOCOLS = ("0", "3", "5", "6")
SEEDS = (1111, 3407, 7777)
TEMPERATURE_VALUES = (0.05, 0.1, 0.2, 0.5, 1.0)
REFERENCE_TEMPERATURE = 0.1
NEW_TEMPERATURE_VALUES = tuple(
    value for value in TEMPERATURE_VALUES if value != REFERENCE_TEMPERATURE
)
TEMPERATURE_TAGS = {0.05: "005", 0.2: "020", 0.5: "050", 1.0: "100"}
FULL_BANK_SIZE = 16326
SPLIT_SIZES = {"train": 16326, "dev": 1871, "test": 4659}
REPORT_METRICS = ("best_dev_mae",) + METRICS
LOWER_IS_BETTER = frozenset(("best_dev_mae", "test_mae"))
COMPATIBILITY_FILES = (
    "IIE_model.py",
    "utils.py",
    "latent_transformer.py",
    "modules/missing_aware_retrieval.py",
)


@dataclass(frozen=True)
class RunSpec:
    temperature: float
    protocol: str
    seed: int
    run_id: str


def _temperature_tag(value):
    try:
        return TEMPERATURE_TAGS[float(value)]
    except KeyError:
        raise ValueError("No E16 run-id tag for temperature {}".format(value))


def build_matrix(
    protocols=PROTOCOLS, seeds=SEEDS, temperatures=NEW_TEMPERATURE_VALUES
):
    protocols = tuple(str(value) for value in protocols)
    seeds = tuple(int(value) for value in seeds)
    temperatures = tuple(float(value) for value in temperatures)
    unknown_protocols = sorted(set(protocols) - set(PROTOCOLS))
    unknown_seeds = sorted(set(seeds) - set(SEEDS))
    unknown_temperatures = sorted(set(temperatures) - set(NEW_TEMPERATURE_VALUES))
    if unknown_protocols or unknown_seeds or unknown_temperatures:
        raise ValueError(
            "Unknown E16 selection | protocols={} | seeds={} | temperatures={}".format(
                unknown_protocols, unknown_seeds, unknown_temperatures
            )
        )
    ordered = tuple(
        value for value in NEW_TEMPERATURE_VALUES if value in temperatures
    )
    return [
        RunSpec(
            temperature=temperature,
            protocol=protocol,
            seed=seed,
            run_id="E16_T{}_mosei_p{}_s{}".format(
                _temperature_tag(temperature), protocol, seed
            ),
        )
        for seed in seeds
        for protocol in protocols
        for temperature in ordered
    ]


def _manifest_path(workspace, run_id):
    return workspace / "paper_experiments" / "manifests" / (run_id + ".json")


def _read_json(path):
    with open(path, "r", encoding="utf-8") as stream:
        return json.load(stream)


def reference_run_id(protocol, seed):
    return "E06R1_M1_mosei_p{}_s{}".format(protocol, seed)


def command_for_spec(workspace, spec):
    settings = PROTOCOL_SETTINGS[spec.protocol]
    return [
        sys.executable, "main.py", "--paper_experiment",
        "--paper_run_id={}".format(spec.run_id),
        "--paper_method_id=M1", "--paper_stage_id=E16",
        "--paper_manifest_dir=paper_experiments/manifests",
        "--dataset=mosei", "--fixed_protocol={}".format(spec.protocol),
        "--seed={}".format(spec.seed),
        "--train_batch_size={}".format(settings["train_batch_size"]),
        "--dev_batch_size=128", "--test_batch_size=128",
        "--d_l={}".format(settings["representation_dim"]),
        "--latent_dim={}".format(settings["representation_dim"]),
        "--layers={}".format(settings["layers"]),
        "--latent_layers={}".format(settings["latent_layers"]),
        "--missing_rate={}".format(settings["missing_rate"]),
        "--weight_decay=1e-4", "--retrieval_mode=missing_aware",
        "--retrieval_candidate_source=train_bank",
        "--retrieval_candidate_filter=observed_only",
        "--retrieval_composition=prototype_neighbours",
        "--retrieval_selection=similarity", "--retrieval_random_seed=3407",
        "--retrieval_top_k=2", "--retrieval_temperature={}".format(
            spec.temperature
        ),
        "--retrieval_queue_size=0", "--retrieval_metric_mode=raw",
        "--retrieval_missing_query=center", "--retrieval_bank_batch_size=256",
        "--retrieval_bank_refresh_epochs=1", "--retrieval_reference_bank_size=0",
        "--retrieval_reference_bank_seed=3407",
        "--gate_mode=none", "--consistency_mode=mixed", "--distill_mode=none",
        "--fusion_mode=flat", "--prompt_mode=none",
        "--reconstruction_mode=none", "--consensus_mode=none",
        "--tag_mode=none", "--cross_modal_retrieval_mode=none",
        "--training_prior_mode=none", "--hybrid_expert_mode=none",
        "--protocol_consistency_mode=none", "--relation_distill_mode=none",
        "--missing_text_contrast_mode=none",
        "--privileged_purification_mode=none", "--language_hyper_mode=none",
        "--coupled_prompt_mode=none", "--early_stopping_min_delta=0.0",
        "--learning_rate=2e-5", "--n_epochs=100",
        "--early_stopping_patience=12",
    ]


def _expected_arguments(temperature):
    return {
        "retrieval_mode": "missing_aware",
        "retrieval_candidate_source": "train_bank",
        "retrieval_candidate_filter": "observed_only",
        "retrieval_composition": "prototype_neighbours",
        "retrieval_selection": "similarity",
        "retrieval_random_seed": 3407,
        "retrieval_top_k": 2,
        "retrieval_temperature": float(temperature),
        "retrieval_queue_size": 0,
        "retrieval_reference_bank_size": 0,
        "retrieval_reference_bank_seed": 3407,
        "protocol_fusion_readaptation": False,
        "load": 0,
    }


def _validate_arguments(arguments, expected, label, legacy_defaults=None):
    legacy_defaults = legacy_defaults or {}
    mismatches = {}
    for key, value in expected.items():
        actual = arguments[key] if key in arguments else legacy_defaults.get(key)
        if actual != value:
            mismatches[key] = (value, actual)
    if mismatches:
        raise RuntimeError("{} argument mismatch: {}".format(label, mismatches))


def _validate_full_bank_record(result, label):
    record = (result.get("data_provenance") or {}).get("strict_retrieval_bank")
    if not isinstance(record, dict):
        raise RuntimeError("{} lacks strict retrieval-bank provenance".format(label))
    expected = {
        "source": "complete_training_split_only",
        "available_count": FULL_BANK_SIZE,
        "requested_size": 0,
        "actual_size": FULL_BANK_SIZE,
        "subset_seed": 3407,
        "selection": "sha256_seeded_sample_id_nested_prefix",
        "validation_donors": 0,
        "test_donors": 0,
        "self_exclusion_ids": True,
        "runtime_only": True,
    }
    mismatches = {
        key: (value, record.get(key))
        for key, value in expected.items()
        if record.get(key) != value
    }
    if mismatches or not record.get("selected_ids_sha256"):
        raise RuntimeError(
            "{} full-bank provenance mismatch: {}".format(label, mismatches)
        )
    return record


def _validate_new_manifest(workspace, spec, verify_checkpoint=True):
    path = _manifest_path(workspace, spec.run_id)
    if not path.is_file():
        return None
    manifest = _read_json(path)
    if manifest.get("status") != "complete":
        raise RuntimeError(
            "E16 run id exists with status {!r}; inspect it and do not overwrite: {}".format(
                manifest.get("status"), path
            )
        )
    expected = {
        "run_id": spec.run_id, "method_id": "M1", "stage_id": "E16",
        "dataset": DATASET, "protocol": spec.protocol, "seed": spec.seed,
    }
    mismatches = {
        key: (value, manifest.get(key)) for key, value in expected.items()
        if manifest.get(key) != value
    }
    if mismatches:
        raise RuntimeError("E16 new-run identity mismatch: {}".format(mismatches))
    if manifest.get("lineage") is not None:
        raise RuntimeError("E16 sensitivity runs must be independent M1 roots")
    _validate_arguments(
        manifest.get("arguments") or {},
        _expected_arguments(spec.temperature), spec.run_id,
    )
    result = _validate_result(manifest, spec.run_id)
    _validate_full_bank_record(result, spec.run_id)
    outputs = manifest.get("outputs") or {}
    checkpoint = Path(outputs.get("best_model_path", ""))
    if verify_checkpoint:
        if not checkpoint.is_file():
            raise FileNotFoundError("E16 checkpoint is missing: {}".format(checkpoint))
        if sha256_file(checkpoint) != outputs.get("best_model_sha256"):
            raise RuntimeError("E16 checkpoint SHA256 mismatch")
    elif not outputs.get("best_model_sha256"):
        raise RuntimeError("E16 manifest lacks checkpoint SHA256")
    return manifest


def _validate_reference_manifest(workspace, protocol, seed, dataset_sha=None):
    run_id = reference_run_id(protocol, seed)
    path = _manifest_path(workspace, run_id)
    if not path.is_file():
        raise FileNotFoundError("E16 temperature=0.1 reference is missing: {}".format(path))
    manifest = _read_json(path)
    expected = {
        "status": "complete", "run_id": run_id, "method_id": "M1",
        "stage_id": "E06", "dataset": DATASET, "protocol": protocol,
        "seed": seed,
    }
    mismatches = {
        key: (value, manifest.get(key)) for key, value in expected.items()
        if manifest.get(key) != value
    }
    if mismatches:
        raise RuntimeError("E16 reference identity mismatch: {}".format(mismatches))
    if manifest.get("lineage") is not None:
        raise RuntimeError("E16 M1 reference unexpectedly declares lineage")
    arguments = manifest.get("arguments") or {}
    _validate_frozen_reference_arguments(arguments, run_id)
    _validate_arguments(
        arguments,
        {
            "retrieval_temperature": REFERENCE_TEMPERATURE,
            "retrieval_reference_bank_size": 0,
            "retrieval_reference_bank_seed": 3407,
        },
        run_id,
        legacy_defaults={
            "retrieval_temperature": REFERENCE_TEMPERATURE,
            "retrieval_reference_bank_size": 0,
            "retrieval_reference_bank_seed": 3407,
        },
    )
    result = _validate_result(manifest, run_id)
    current_sha = result["data_provenance"]["dataset_sha256"]
    if dataset_sha is not None and current_sha != dataset_sha:
        raise RuntimeError("E16 reference dataset SHA256 mismatch")
    return manifest


def validate_frozen_e15_audit(workspace, dataset_sha):
    path = workspace / "paper_results" / "E15_retrieval_bank_size_audit.json"
    if not path.is_file():
        raise FileNotFoundError("E16 requires the frozen E15 audit: {}".format(path))
    audit = _read_json(path)
    expected = {
        "stage_id": "E15", "completed_new_run_count": 48,
        "completed_reused_reference_count": 12,
        "completed_total_sensitivity_cells": 60,
        "test_metrics_consulted_for_training_or_selection": False,
    }
    mismatches = {
        key: (value, audit.get(key)) for key, value in expected.items()
        if audit.get(key) != value
    }
    if mismatches:
        raise RuntimeError("E16 frozen E15 audit mismatch: {}".format(mismatches))
    if audit.get("dataset_sha256") != dataset_sha:
        raise RuntimeError("E16 frozen E15 audit uses another MOSEI file")
    frozen_code = audit.get("new_run_code_sha256") or {}
    current_code = {
        name: sha256_file(workspace / name) for name in COMPATIBILITY_FILES
    }
    mismatched_code = {
        name: (frozen_code.get(name), current_code[name])
        for name in COMPATIBILITY_FILES
        if frozen_code.get(name) != current_code[name]
    }
    if mismatched_code:
        raise RuntimeError(
            "E16 retrieval computation drifted after E15: {}".format(
                mismatched_code
            )
        )
    return {
        "path": str(path.resolve()), "sha256": sha256_file(path),
        "compatible_code_sha256": current_code,
    }


def preflight_references(workspace, protocols, seeds):
    dataset_path = resolve_dataset_path(workspace, DATASET)
    dataset_sha = sha256_file(dataset_path)
    audit_record = validate_frozen_e15_audit(workspace, dataset_sha)
    checked = []
    for seed in seeds:
        for protocol in protocols:
            manifest = _validate_reference_manifest(
                workspace, protocol, seed, dataset_sha
            )
            checked.append(manifest["run_id"])
    print("E16 reference preflight verified | records={}".format(len(checked)))
    return {
        "reference_count": len(checked), "dataset_sha256": dataset_sha,
        "temperature_0_1_compatibility": {
            "contract": "frozen E06R1 M1 parser-default retrieval temperature",
            "value": REFERENCE_TEMPERATURE,
        },
        "frozen_E15_audit": audit_record,
    }


def _temperature_label(value):
    return str(float(value))


def _record(temperature, manifest, reused):
    result = manifest["result"]
    item = {
        "temperature": float(temperature),
        "temperature_label": _temperature_label(temperature),
        "protocol": manifest["protocol"], "seed": manifest["seed"],
        "source_stage": manifest["stage_id"], "source_run_id": manifest["run_id"],
        "reused_reference": bool(reused), "best_epoch": result["best_epoch"],
        "best_dev_mae": result["best_loss"],
    }
    item.update({metric: result[metric] for metric in METRICS})
    return item


def _metric_summary(values):
    return {
        "count": len(values),
        "mean": statistics.mean(values) if values else None,
        "sample_std": statistics.stdev(values) if len(values) > 1 else 0.0,
    }


def _gain(metric, baseline, candidate):
    if metric in LOWER_IS_BETTER:
        return float(baseline) - float(candidate)
    return float(candidate) - float(baseline)


def summarize_by_temperature(records):
    output = {}
    for temperature in TEMPERATURE_VALUES:
        selected = [
            item for item in records if item["temperature"] == temperature
        ]
        output[_temperature_label(temperature)] = {
            metric: _metric_summary([float(item[metric]) for item in selected])
            for metric in REPORT_METRICS
        }
    return output


def summarize_vs_reference(records, protocols, seeds):
    indexed = {
        (item["protocol"], item["seed"], item["temperature"]): item
        for item in records
    }
    output = {}
    for temperature in NEW_TEMPERATURE_VALUES:
        pairs = []
        for seed in seeds:
            for protocol in protocols:
                baseline = indexed[(protocol, seed, REFERENCE_TEMPERATURE)]
                candidate = indexed[(protocol, seed, temperature)]
                pairs.append({
                    "protocol": protocol, "seed": seed,
                    "baseline_temperature": REFERENCE_TEMPERATURE,
                    "candidate_temperature": temperature,
                    "gains": {
                        metric: _gain(metric, baseline[metric], candidate[metric])
                        for metric in REPORT_METRICS
                    },
                })
        summary = {}
        for metric in REPORT_METRICS:
            values = [pair["gains"][metric] for pair in pairs]
            summary[metric] = {
                "count": len(values), "mean_gain": statistics.mean(values),
                "wins": sum(value > 1e-12 for value in values),
                "ties": sum(abs(value) <= 1e-12 for value in values),
                "losses": sum(value < -1e-12 for value in values),
            }
        output[_temperature_label(temperature)] = {
            "summary": summary, "pairs": pairs
        }
    return output


def audit_matrix(
    workspace, specs, require_complete=True, perform_reference_preflight=True
):
    protocols = tuple(dict.fromkeys(spec.protocol for spec in specs))
    seeds = tuple(dict.fromkeys(spec.seed for spec in specs))
    records, missing_new, missing_reference = [], [], []
    new_code, dataset_sha = None, None
    for spec in specs:
        manifest = _validate_new_manifest(workspace, spec)
        if manifest is None:
            missing_new.append(spec.run_id)
            continue
        current_code = manifest.get("code_sha256")
        if new_code is None:
            new_code = current_code
        elif new_code != current_code:
            raise RuntimeError("E16 new runs mix code fingerprints")
        current_data = manifest["result"]["data_provenance"]["dataset_sha256"]
        if dataset_sha is None:
            dataset_sha = current_data
        elif dataset_sha != current_data:
            raise RuntimeError("E16 new runs mix MOSEI files")
        records.append(_record(spec.temperature, manifest, reused=False))

    for seed in seeds:
        for protocol in protocols:
            try:
                manifest = _validate_reference_manifest(
                    workspace, protocol, seed, dataset_sha
                )
            except FileNotFoundError:
                missing_reference.append(reference_run_id(protocol, seed))
                continue
            records.append(_record(REFERENCE_TEMPERATURE, manifest, reused=True))

    if require_complete and (missing_new or missing_reference):
        raise RuntimeError(
            "Incomplete E16 sensitivity | missing_new={} first_new={} | "
            "missing_reference={} first_reference={}".format(
                len(missing_new), missing_new[:5],
                len(missing_reference), missing_reference[:5],
            )
        )
    records.sort(key=lambda item: (
        seeds.index(int(item["seed"])), protocols.index(str(item["protocol"])),
        TEMPERATURE_VALUES.index(float(item["temperature"])),
    ))
    reference_preflight = None
    if require_complete and perform_reference_preflight:
        reference_preflight = preflight_references(workspace, protocols, seeds)
    return {
        "schema_version": 1, "stage_id": "E16", "dataset": DATASET,
        "purpose": "missing-aware retrieval-temperature sensitivity",
        "protocols": list(protocols), "seeds": list(seeds),
        "temperature_values": list(TEMPERATURE_VALUES),
        "reference_temperature": REFERENCE_TEMPERATURE,
        "expected_new_run_count": len(specs),
        "completed_new_run_count": len(specs) - len(missing_new),
        "expected_reused_reference_count": len(protocols) * len(seeds),
        "completed_reused_reference_count": (
            len(protocols) * len(seeds) - len(missing_reference)
        ),
        "expected_total_sensitivity_cells": (
            len(protocols) * len(seeds) * len(TEMPERATURE_VALUES)
        ),
        "completed_total_sensitivity_cells": len(records),
        "missing_new_run_ids": missing_new,
        "missing_reference_run_ids": missing_reference,
        "dataset_sha256": dataset_sha, "new_run_code_sha256": new_code,
        "reference_preflight": reference_preflight,
        "selection_split": "development", "selection_metric": "mae",
        "test_evaluation_count_per_new_run": 1,
        "test_metrics_consulted_for_training_or_selection": False,
        "summary_by_temperature": summarize_by_temperature(records),
        "effects_vs_temperature_0_1": summarize_vs_reference(
            records, protocols, seeds
        ),
        "records": records,
    }


def execute_matrix(workspace, specs):
    protocols = tuple(dict.fromkeys(spec.protocol for spec in specs))
    seeds = tuple(dict.fromkeys(spec.seed for spec in specs))
    preflight_references(workspace, protocols, seeds)
    completed_manifests = []
    for spec in specs:
        manifest = _validate_new_manifest(workspace, spec)
        if manifest is not None:
            completed_manifests.append(manifest)
    if completed_manifests:
        expected_code = code_fingerprints(workspace)
        expected_data = sha256_file(resolve_dataset_path(workspace, DATASET))
        for manifest in completed_manifests:
            if manifest.get("code_sha256") != expected_code:
                raise RuntimeError("E16 resume refused because code changed")
            if manifest["result"]["data_provenance"]["dataset_sha256"] != expected_data:
                raise RuntimeError("E16 resume refused because MOSEI changed")

    environment = os.environ.copy()
    environment["CUBLAS_WORKSPACE_CONFIG"] = ":4096:8"
    completed = skipped = 0
    for index, spec in enumerate(specs, start=1):
        if _validate_new_manifest(workspace, spec) is not None:
            skipped += 1
            print("[{}/{}] SKIP complete {}".format(index, len(specs), spec.run_id))
            continue
        print("[{}/{}] RUN {}".format(index, len(specs), spec.run_id), flush=True)
        subprocess.check_call(
            command_for_spec(workspace, spec), cwd=str(workspace), env=environment
        )
        _validate_new_manifest(workspace, spec)
        subprocess.check_call(
            [sys.executable, "refresh_paper_registry.py", "--workspace", "."],
            cwd=str(workspace), env=environment,
        )
        completed += 1
    print("E16 execution finished | new={} | skipped={}".format(completed, skipped))


def _csv_values(value, cast):
    return tuple(cast(item.strip()) for item in value.split(",") if item.strip())


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--workspace", type=Path, default=Path("."))
    parser.add_argument("--protocols", default=",".join(PROTOCOLS))
    parser.add_argument("--seeds", default=",".join(str(seed) for seed in SEEDS))
    parser.add_argument(
        "--temperatures",
        default=",".join(str(value) for value in NEW_TEMPERATURE_VALUES),
    )
    parser.add_argument("--execute", action="store_true")
    parser.add_argument("--audit", action="store_true")
    parser.add_argument(
        "--audit_output", type=Path,
        default=Path("paper_results/E16_retrieval_temperature_audit.json"),
    )
    return parser.parse_args()


def main():
    args = parse_args()
    workspace = args.workspace.resolve()
    specs = build_matrix(
        _csv_values(args.protocols, str), _csv_values(args.seeds, int),
        _csv_values(args.temperatures, float),
    )
    if not args.execute and not args.audit:
        cells = len(set((spec.protocol, spec.seed) for spec in specs))
        print(
            "E16 dry-run plan | new_runs={} | reused_reference_records={} | "
            "total_sensitivity_cells={}".format(
                len(specs), cells, cells * len(TEMPERATURE_VALUES)
            )
        )
        for spec in specs:
            print("{} | temperature={} | reference={} | {}".format(
                spec.run_id, spec.temperature,
                reference_run_id(spec.protocol, spec.seed),
                " ".join(command_for_spec(workspace, spec)),
            ))
        return
    if args.execute:
        if os.environ.get("E16_EXECUTE") != "1":
            raise RuntimeError("Set E16_EXECUTE=1 to authorize the formal 48-run matrix")
        execute_matrix(workspace, specs)
    if args.audit:
        summary = audit_matrix(workspace, specs, require_complete=True)
        output = args.audit_output
        if not output.is_absolute():
            output = workspace / output
        write_immutable_json(output, summary)
        print("E16 audit verified: {}".format(output))


if __name__ == "__main__":
    main()
