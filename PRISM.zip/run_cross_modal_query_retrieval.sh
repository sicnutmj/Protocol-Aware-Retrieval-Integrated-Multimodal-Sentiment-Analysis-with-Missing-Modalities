set -e

SEVENTH_CHECKPOINT_DIR="${SEVENTH_CHECKPOINT_DIR:-best_modules}"
PROTOCOLS="${PROTOCOLS:-0 3 4}"
REFERENCE_BANK_SIZE="${REFERENCE_BANK_SIZE:-4096}"

AGCQR_ARGS=(
  --retrieval_mode=missing_aware
  --retrieval_queue_size=0
  --retrieval_metric_mode=raw
  --retrieval_missing_query=center
  --gate_mode=none
  --consistency_mode=mixed
  --distill_mode=none
  --fusion_mode=flat
  --prompt_mode=none
  --reconstruction_mode=none
  --consensus_mode=none
  --tag_mode=none
  --cross_modal_retrieval_mode=agcqr
  --cross_modal_retrieval_hidden_dim=128
  --cross_modal_retrieval_temperature=0.1
  --cross_modal_match_temperature=0.1
  --cross_modal_match_loss_weight=0.05
  --cross_modal_retrieval_learning_rate=1e-3
  --cross_modal_reference_bank_size="${REFERENCE_BANK_SIZE}"
  --cross_modal_reference_seed=3407
  --load=1
  --n_epochs=40
  --early_stopping_patience=12
  --early_stopping_min_delta=0.0
)

echo "Improvement 11: availability-guided cross-modal query retrieval (AGCQR)"
echo "Foundation: first-improvement q0 + frozen seventh fusion head"
echo "Reference source: complete views from the training split only"
echo "Checkpoint directory: ${SEVENTH_CHECKPOINT_DIR}"
echo "Protocols: ${PROTOCOLS}"
echo "Reference bank size: ${REFERENCE_BANK_SIZE}"

run_protocol() {
  local protocol="$1"
  local train_batch_size="$2"
  local representation_dim="$3"
  local description="$4"
  shift 4

  local checkpoint="${SEVENTH_CHECKPOINT_DIR}/iie_mosei_protocol_${protocol}_missing_aware_q0_seventh_head_best.pt"
  if [ ! -s "${checkpoint}" ]; then
    echo "Missing clean first+seventh checkpoint: ${checkpoint}" >&2
    echo "Run freeze_seventh_checkpoints.py before improvement 11." >&2
    exit 1
  fi

  echo "AGCQR: protocol ${protocol} (${description})"
  python3 main.py "${AGCQR_ARGS[@]}" \
    --fixed_protocol="${protocol}" \
    --model_path="${checkpoint}" \
    --learning_rate=1e-4 \
    --d_l="${representation_dim}" \
    --latent_dim="${representation_dim}" \
    --train_batch_size="${train_batch_size}" \
    --dataset=mosei \
    "$@"
}

for protocol in ${PROTOCOLS}; do
  case "${protocol}" in
    0) run_protocol 0 128 192 "L observed; query A+V" ;;
    1) run_protocol 1 128 192 "A observed; query L+V" \
         --missing_rate=0.05 \
         --layers=2 \
         --latent_layers=3 ;;
    2) run_protocol 2 256 192 "V observed; query L+A" ;;
    3) run_protocol 3 256 96  "L+A observed; query V" ;;
    4) run_protocol 4 256 96  "L+V observed; query A" ;;
    5) run_protocol 5 256 192 "A+V observed; query L" ;;
    6)
      echo "Protocol 6 has no missing modality; AGCQR is an exact no-op and is skipped."
      ;;
    *)
      echo "Unknown protocol: ${protocol}; expected values from 0 to 6" >&2
      exit 1
      ;;
  esac
done
