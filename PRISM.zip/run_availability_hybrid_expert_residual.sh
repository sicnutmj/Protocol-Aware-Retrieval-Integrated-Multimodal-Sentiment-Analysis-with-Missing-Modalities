set -e

SEVENTH_CHECKPOINT_DIR="${SEVENTH_CHECKPOINT_DIR:-best_modules}"
PROTOCOLS="${PROTOCOLS:-0 3 4}"
EXPERT_LR="${EXPERT_LR:-1e-3}"
ORTHOGONALITY_WEIGHT="${ORTHOGONALITY_WEIGHT:-0.01}"

ACHER_ARGS=(
  --retrieval_mode=missing_aware
  --retrieval_queue_size=0
  --retrieval_metric_mode=raw
  --retrieval_missing_query=center
  --gate_mode=none
  --consistency_mode=mixed
  --distill_mode=none
  --fusion_mode=flat
  --prompt_mode=none
  --reconstruction_mode=none
  --consensus_mode=none
  --tag_mode=none
  --cross_modal_retrieval_mode=none
  --training_prior_mode=none
  --hybrid_expert_mode=acher
  --hybrid_expert_hidden_dim=64
  --hybrid_expert_private_count=3
  --hybrid_expert_shared_count=3
  --hybrid_expert_dropout=0.1
  --hybrid_expert_learning_rate="${EXPERT_LR}"
  --hybrid_expert_orthogonality_weight="${ORTHOGONALITY_WEIGHT}"
  --load=1
  --n_epochs=40
  --early_stopping_patience=12
  --early_stopping_min_delta=0.0
)

echo "Improvement 14 pilot: availability-constrained hybrid expert residual (ACHER)"
echo "Foundation: first-improvement q0 + frozen seventh fusion head"
echo "Checkpoint directory: ${SEVENTH_CHECKPOINT_DIR}"
echo "Protocols: ${PROTOCOLS}"
echo "Expert LR=${EXPERT_LR}; orthogonality weight=${ORTHOGONALITY_WEIGHT}"

run_protocol() {
  local protocol="$1"
  local train_batch_size="$2"
  local representation_dim="$3"
  local description="$4"
  shift 4

  local checkpoint="${SEVENTH_CHECKPOINT_DIR}/iie_mosei_protocol_${protocol}_missing_aware_q0_seventh_head_best.pt"
  if [ ! -s "${checkpoint}" ]; then
    echo "Missing clean first+seventh checkpoint: ${checkpoint}" >&2
    exit 1
  fi

  echo "ACHER: protocol ${protocol} (${description})"
  python3 main.py "${ACHER_ARGS[@]}" \
    --fixed_protocol="${protocol}" \
    --model_path="${checkpoint}" \
    --learning_rate=1e-4 \
    --d_l="${representation_dim}" \
    --latent_dim="${representation_dim}" \
    --train_batch_size="${train_batch_size}" \
    --dataset=mosei \
    "$@"
}

for protocol in ${PROTOCOLS}; do
  case "${protocol}" in
    0) run_protocol 0 128 192 "L observed" ;;
    1) run_protocol 1 128 192 "A observed" \
         --missing_rate=0.05 \
         --layers=2 \
         --latent_layers=3 ;;
    2) run_protocol 2 256 192 "V observed" ;;
    3) run_protocol 3 256 96  "L+A observed" ;;
    4) run_protocol 4 256 96  "L+V observed" ;;
    5) run_protocol 5 256 192 "A+V observed" ;;
    6) run_protocol 6 128 192 "L+A+V observed" ;;
    *)
      echo "Unknown protocol: ${protocol}; expected values from 0 to 6" >&2
      exit 1
      ;;
  esac
done
