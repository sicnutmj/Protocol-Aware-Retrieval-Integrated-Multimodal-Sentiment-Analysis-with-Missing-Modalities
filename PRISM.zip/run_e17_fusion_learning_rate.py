"""Execute and audit the formal E17 fusion-head learning-rate sensitivity."""

from __future__ import annotations

import argparse
import json
import math
import os
import statistics
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path

from paper_experiment import code_fingerprints, resolve_dataset_path, sha256_file
from run_e06_mosei_primary import METRICS, PROTOCOL_SETTINGS, write_immutable_json


DATASET = "mosei"
PROTOCOLS = ("0", "3", "5", "6")
SEEDS = (1111, 3407, 7777)
LEARNING_RATE_VALUES = (1e-5, 5e-5, 1e-4, 5e-4)
REFERENCE_LEARNING_RATE = 1e-4
NEW_LEARNING_RATE_VALUES = tuple(
    value for value in LEARNING_RATE_VALUES
    if value != REFERENCE_LEARNING_RATE
)
LEARNING_RATE_TAGS = {1e-5: "1E5", 5e-5: "5E5", 5e-4: "5E4"}
FULL_BANK_SIZE = 16326
SPLIT_SIZES = {"train": 16326, "dev": 1871, "test": 4659}
REPORT_METRICS = ("best_dev_mae",) + METRICS
LOWER_IS_BETTER = frozenset(("best_dev_mae", "test_mae"))
COMPATIBILITY_FILES = (
    "IIE_model.py",
    "utils.py",
    "latent_transformer.py",
    "modules/missing_aware_retrieval.py",
)


@dataclass(frozen=True)
class RunSpec:
    learning_rate: float
    protocol: str
    seed: int
    run_id: str
    parent_run_id: str


def _learning_rate_tag(value):
    try:
        return LEARNING_RATE_TAGS[float(value)]
    except KeyError:
        raise ValueError("No E17 run-id tag for learning rate {}".format(value))


def _learning_rate_label(value):
    return "{:.0e}".format(float(value)).replace("e-0", "e-")


def parent_run_id(protocol, seed):
    return "E06R1_M1_mosei_p{}_s{}".format(protocol, seed)


def reference_run_id(protocol, seed):
    return "E06R1_M2_mosei_p{}_s{}".format(protocol, seed)


def build_matrix(
    protocols=PROTOCOLS, seeds=SEEDS,
    learning_rates=NEW_LEARNING_RATE_VALUES,
):
    protocols = tuple(str(value) for value in protocols)
    seeds = tuple(int(value) for value in seeds)
    learning_rates = tuple(float(value) for value in learning_rates)
    unknown_protocols = sorted(set(protocols) - set(PROTOCOLS))
    unknown_seeds = sorted(set(seeds) - set(SEEDS))
    unknown_rates = sorted(
        set(learning_rates) - set(NEW_LEARNING_RATE_VALUES)
    )
    if unknown_protocols or unknown_seeds or unknown_rates:
        raise ValueError(
            "Unknown E17 selection | protocols={} | seeds={} | "
            "learning_rates={}".format(
                unknown_protocols, unknown_seeds, unknown_rates
            )
        )
    ordered = tuple(
        value for value in NEW_LEARNING_RATE_VALUES
        if value in learning_rates
    )
    return [
        RunSpec(
            learning_rate=learning_rate,
            protocol=protocol,
            seed=seed,
            run_id="E17_LR{}_mosei_p{}_s{}".format(
                _learning_rate_tag(learning_rate), protocol, seed
            ),
            parent_run_id=parent_run_id(protocol, seed),
        )
        for seed in seeds
        for protocol in protocols
        for learning_rate in ordered
    ]


def _manifest_path(workspace, run_id):
    return workspace / "paper_experiments" / "manifests" / (run_id + ".json")


def _read_json(path):
    with open(path, "r", encoding="utf-8") as stream:
        return json.load(stream)


def _verify_checkpoint(manifest, label, verify_checkpoint=True):
    outputs = manifest.get("outputs") or {}
    checkpoint = Path(outputs.get("best_model_path", ""))
    if verify_checkpoint:
        if not checkpoint.is_file():
            raise FileNotFoundError(
                "{} checkpoint is missing: {}".format(label, checkpoint)
            )
        if sha256_file(checkpoint) != outputs.get("best_model_sha256"):
            raise RuntimeError("{} checkpoint SHA256 mismatch".format(label))
    elif not outputs.get("best_model_sha256"):
        raise RuntimeError("{} lacks checkpoint SHA256".format(label))
    return checkpoint


def _parent_checkpoint(workspace, spec):
    path = _manifest_path(workspace, spec.parent_run_id)
    if not path.is_file():
        raise FileNotFoundError("E17 parent manifest is missing: {}".format(path))
    manifest = _read_json(path)
    expected = {
        "status": "complete", "run_id": spec.parent_run_id,
        "method_id": "M1", "dataset": DATASET,
        "protocol": spec.protocol, "seed": spec.seed,
    }
    mismatches = {
        key: (value, manifest.get(key)) for key, value in expected.items()
        if manifest.get(key) != value
    }
    if mismatches:
        raise RuntimeError("E17 parent mismatch: {}".format(mismatches))
    if manifest.get("lineage") is not None:
        raise RuntimeError("E17 M1 parent unexpectedly declares lineage")
    return _verify_checkpoint(manifest, spec.parent_run_id).resolve()


def command_for_spec(workspace, spec, resolve_parent=True):
    settings = PROTOCOL_SETTINGS[spec.protocol]
    checkpoint = (
        _parent_checkpoint(workspace, spec)
        if resolve_parent else Path("<PARENT_CHECKPOINT>")
    )
    learning_rate = "{:.0e}".format(spec.learning_rate)
    return [
        sys.executable, "main.py", "--paper_experiment",
        "--paper_run_id={}".format(spec.run_id),
        "--paper_method_id=M2", "--paper_stage_id=E17",
        "--paper_manifest_dir=paper_experiments/manifests",
        "--paper_parent_run_id={}".format(spec.parent_run_id),
        "--model_path={}".format(checkpoint), "--load=1",
        "--dataset=mosei", "--fixed_protocol={}".format(spec.protocol),
        "--seed={}".format(spec.seed),
        "--train_batch_size={}".format(settings["train_batch_size"]),
        "--dev_batch_size=128", "--test_batch_size=128",
        "--d_l={}".format(settings["representation_dim"]),
        "--latent_dim={}".format(settings["representation_dim"]),
        "--layers={}".format(settings["layers"]),
        "--latent_layers={}".format(settings["latent_layers"]),
        "--missing_rate={}".format(settings["missing_rate"]),
        "--weight_decay=1e-4", "--retrieval_mode=missing_aware",
        "--retrieval_candidate_source=train_bank",
        "--retrieval_candidate_filter=observed_only",
        "--retrieval_composition=prototype_neighbours",
        "--retrieval_selection=similarity", "--retrieval_random_seed=3407",
        "--retrieval_top_k=2", "--retrieval_temperature=0.1",
        "--retrieval_queue_size=0", "--retrieval_metric_mode=raw",
        "--retrieval_missing_query=center", "--retrieval_bank_batch_size=256",
        "--retrieval_bank_refresh_epochs=1", "--retrieval_reference_bank_size=0",
        "--retrieval_reference_bank_seed=3407",
        "--gate_mode=none", "--consistency_mode=mixed", "--distill_mode=none",
        "--fusion_mode=flat", "--prompt_mode=none",
        "--reconstruction_mode=none", "--consensus_mode=none",
        "--tag_mode=none", "--cross_modal_retrieval_mode=none",
        "--training_prior_mode=none", "--hybrid_expert_mode=none",
        "--protocol_consistency_mode=none", "--relation_distill_mode=none",
        "--missing_text_contrast_mode=none",
        "--privileged_purification_mode=none", "--language_hyper_mode=none",
        "--coupled_prompt_mode=none", "--early_stopping_min_delta=0.0",
        "--protocol_fusion_readaptation",
        "--protocol_adaptation_scope=fusion_all",
        "--protocol_fusion_learning_rate={}".format(learning_rate),
        "--protocol_transformer_learning_rate=2e-5",
        "--learning_rate={}".format(learning_rate), "--n_epochs=40",
        "--early_stopping_patience=12",
    ]


def _expected_arguments(learning_rate):
    return {
        "retrieval_mode": "missing_aware",
        "retrieval_candidate_source": "train_bank",
        "retrieval_candidate_filter": "observed_only",
        "retrieval_composition": "prototype_neighbours",
        "retrieval_selection": "similarity",
        "retrieval_random_seed": 3407,
        "retrieval_top_k": 2,
        "retrieval_temperature": 0.1,
        "retrieval_queue_size": 0,
        "retrieval_reference_bank_size": 0,
        "retrieval_reference_bank_seed": 3407,
        "protocol_fusion_readaptation": True,
        "protocol_adaptation_scope": "fusion_all",
        "protocol_fusion_learning_rate": float(learning_rate),
        "protocol_transformer_learning_rate": 2e-5,
        "learning_rate": float(learning_rate),
        "load": 1,
    }


def _validate_arguments(arguments, expected, label, legacy_defaults=None):
    legacy_defaults = legacy_defaults or {}
    mismatches = {}
    for key, value in expected.items():
        actual = arguments[key] if key in arguments else legacy_defaults.get(key)
        if actual != value:
            mismatches[key] = (value, actual)
    if mismatches:
        raise RuntimeError("{} argument mismatch: {}".format(label, mismatches))


def _validate_result(manifest, label):
    result = manifest.get("result") or {}
    expected = {
        "test_evaluation_count": 1,
        "selection_split": "development",
        "selection_metric": "mae",
    }
    mismatches = {
        key: (value, result.get(key)) for key, value in expected.items()
        if result.get(key) != value
    }
    if mismatches:
        raise RuntimeError("{} result contract mismatch: {}".format(label, mismatches))
    for key in ("best_loss",) + METRICS:
        value = result.get(key)
        if not isinstance(value, (int, float)) or not math.isfinite(value):
            raise RuntimeError("{} lacks finite {}".format(label, key))
    provenance = result.get("data_provenance") or {}
    if provenance.get("split_sizes") != SPLIT_SIZES:
        raise RuntimeError("{} has wrong MOSEI split sizes".format(label))
    if provenance.get("fixed_protocol") != str(manifest.get("protocol")):
        raise RuntimeError("{} has wrong fixed-protocol provenance".format(label))
    if not provenance.get("dataset_sha256"):
        raise RuntimeError("{} lacks dataset SHA256".format(label))
    gate = result.get("adaptation_gate") or {}
    if gate.get("outcome") not in ("improved", "fallback_parent"):
        raise RuntimeError("{} lacks a valid adaptation gate".format(label))
    if gate.get("test_metrics_consulted") is not False:
        raise RuntimeError("{} adaptation gate consulted test metrics".format(label))
    return result


def _validate_full_bank_record(result, label):
    record = (result.get("data_provenance") or {}).get("strict_retrieval_bank")
    if not isinstance(record, dict):
        raise RuntimeError("{} lacks strict retrieval-bank provenance".format(label))
    expected = {
        "source": "complete_training_split_only",
        "available_count": FULL_BANK_SIZE,
        "requested_size": 0,
        "actual_size": FULL_BANK_SIZE,
        "subset_seed": 3407,
        "selection": "sha256_seeded_sample_id_nested_prefix",
        "validation_donors": 0,
        "test_donors": 0,
        "self_exclusion_ids": True,
        "runtime_only": True,
    }
    mismatches = {
        key: (value, record.get(key)) for key, value in expected.items()
        if record.get(key) != value
    }
    if mismatches or not record.get("selected_ids_sha256"):
        raise RuntimeError(
            "{} full-bank provenance mismatch: {}".format(label, mismatches)
        )
    return record


def _validate_new_manifest(workspace, spec, verify_checkpoint=True):
    path = _manifest_path(workspace, spec.run_id)
    if not path.is_file():
        return None
    manifest = _read_json(path)
    if manifest.get("status") != "complete":
        raise RuntimeError(
            "E17 run id exists with status {!r}; inspect it and do not overwrite: {}"
            .format(manifest.get("status"), path)
        )
    expected = {
        "run_id": spec.run_id, "method_id": "M2", "stage_id": "E17",
        "dataset": DATASET, "protocol": spec.protocol, "seed": spec.seed,
    }
    mismatches = {
        key: (value, manifest.get(key)) for key, value in expected.items()
        if manifest.get(key) != value
    }
    if mismatches:
        raise RuntimeError("E17 new-run identity mismatch: {}".format(mismatches))
    lineage = manifest.get("lineage") or {}
    if lineage.get("parent_method_id") != "M1":
        raise RuntimeError("E17 parent method mismatch")
    if lineage.get("parent_run_id") != spec.parent_run_id:
        raise RuntimeError("E17 parent run mismatch")
    _validate_arguments(
        manifest.get("arguments") or {},
        _expected_arguments(spec.learning_rate), spec.run_id,
    )
    result = _validate_result(manifest, spec.run_id)
    _validate_full_bank_record(result, spec.run_id)
    _verify_checkpoint(manifest, spec.run_id, verify_checkpoint)
    return manifest


def _validate_reference_manifest(
    workspace, protocol, seed, dataset_sha=None, verify_checkpoint=True,
):
    run_id = reference_run_id(protocol, seed)
    path = _manifest_path(workspace, run_id)
    if not path.is_file():
        raise FileNotFoundError("E17 learning-rate reference is missing: {}".format(path))
    manifest = _read_json(path)
    expected = {
        "status": "complete", "run_id": run_id, "method_id": "M2",
        "stage_id": "E06", "dataset": DATASET,
        "protocol": protocol, "seed": seed,
    }
    mismatches = {
        key: (value, manifest.get(key)) for key, value in expected.items()
        if manifest.get(key) != value
    }
    if mismatches:
        raise RuntimeError("E17 reference identity mismatch: {}".format(mismatches))
    lineage = manifest.get("lineage") or {}
    if lineage.get("parent_method_id") != "M1":
        raise RuntimeError("E17 reference parent method mismatch")
    if lineage.get("parent_run_id") != parent_run_id(protocol, seed):
        raise RuntimeError("E17 reference parent run mismatch")
    legacy_defaults = {
        "retrieval_candidate_filter": "observed_only",
        "retrieval_composition": "prototype_neighbours",
        "retrieval_selection": "similarity",
        "retrieval_random_seed": 3407,
        "retrieval_top_k": 2,
        "retrieval_temperature": 0.1,
        "retrieval_reference_bank_size": 0,
        "retrieval_reference_bank_seed": 3407,
        "protocol_adaptation_scope": "fusion_all",
        "protocol_transformer_learning_rate": 2e-5,
    }
    _validate_arguments(
        manifest.get("arguments") or {},
        _expected_arguments(REFERENCE_LEARNING_RATE), run_id,
        legacy_defaults=legacy_defaults,
    )
    result = _validate_result(manifest, run_id)
    current_sha = result["data_provenance"]["dataset_sha256"]
    if dataset_sha is not None and current_sha != dataset_sha:
        raise RuntimeError("E17 reference dataset SHA256 mismatch")
    _verify_checkpoint(manifest, run_id, verify_checkpoint)
    return manifest


def _validate_parent_manifest(workspace, protocol, seed, dataset_sha):
    run_id = parent_run_id(protocol, seed)
    path = _manifest_path(workspace, run_id)
    if not path.is_file():
        raise FileNotFoundError("E17 M1 parent is missing: {}".format(path))
    manifest = _read_json(path)
    expected = {
        "status": "complete", "run_id": run_id, "method_id": "M1",
        "stage_id": "E06", "dataset": DATASET,
        "protocol": protocol, "seed": seed,
    }
    mismatches = {
        key: (value, manifest.get(key)) for key, value in expected.items()
        if manifest.get(key) != value
    }
    if mismatches or manifest.get("lineage") is not None:
        raise RuntimeError("E17 M1 parent identity mismatch: {}".format(mismatches))
    result = manifest.get("result") or {}
    if (result.get("data_provenance") or {}).get("dataset_sha256") != dataset_sha:
        raise RuntimeError("E17 M1 parent dataset SHA256 mismatch")
    _verify_checkpoint(manifest, run_id)
    return manifest


def _validate_frozen_audit(workspace, name, expected, dataset_sha):
    path = workspace / "paper_results" / name
    if not path.is_file():
        raise FileNotFoundError("E17 requires frozen audit: {}".format(path))
    audit = _read_json(path)
    mismatches = {
        key: (value, audit.get(key)) for key, value in expected.items()
        if audit.get(key) != value
    }
    if mismatches:
        raise RuntimeError("E17 frozen audit mismatch: {}".format(mismatches))
    if audit.get("dataset_sha256") != dataset_sha:
        raise RuntimeError("E17 frozen audit uses another MOSEI file")
    if audit.get("missing_new_run_ids") or audit.get("missing_reference_run_ids"):
        raise RuntimeError("E17 frozen audit is incomplete")
    return {"path": str(path.resolve()), "sha256": sha256_file(path)}


def preflight_references(workspace, protocols, seeds):
    dataset_sha = sha256_file(resolve_dataset_path(workspace, DATASET))
    e13 = _validate_frozen_audit(
        workspace, "E13_fusion_adaptation_audit.json",
        {
            "stage_id": "E13", "completed_new_run_count": 70,
            "completed_reused_reference_count": 105,
            "completed_total_ablation_cells": 175,
            "test_metrics_consulted_for_training_or_selection": False,
        },
        dataset_sha,
    )
    e16_path = workspace / "paper_results" / "E16_retrieval_temperature_audit.json"
    e16 = _validate_frozen_audit(
        workspace, e16_path.name,
        {
            "stage_id": "E16", "completed_new_run_count": 48,
            "completed_reused_reference_count": 12,
            "completed_total_sensitivity_cells": 60,
            "reference_temperature": 0.1,
            "test_metrics_consulted_for_training_or_selection": False,
        },
        dataset_sha,
    )
    e16_audit = _read_json(e16_path)
    frozen_code = e16_audit.get("new_run_code_sha256") or {}
    current_code = {
        name: sha256_file(workspace / name) for name in COMPATIBILITY_FILES
    }
    mismatched_code = {
        name: (frozen_code.get(name), current_code[name])
        for name in COMPATIBILITY_FILES
        if frozen_code.get(name) != current_code[name]
    }
    if mismatched_code:
        raise RuntimeError(
            "E17 model/retrieval computation drifted after E16: {}".format(
                mismatched_code
            )
        )
    parents, references = [], []
    for seed in seeds:
        for protocol in protocols:
            parents.append(_validate_parent_manifest(
                workspace, protocol, seed, dataset_sha
            )["run_id"])
            references.append(_validate_reference_manifest(
                workspace, protocol, seed, dataset_sha
            )["run_id"])
    print(
        "E17 reference preflight verified | parents={} | references={}".format(
            len(parents), len(references)
        )
    )
    return {
        "parent_count": len(parents), "reference_count": len(references),
        "dataset_sha256": dataset_sha,
        "compatible_code_sha256": current_code,
        "frozen_E13_audit": e13, "frozen_E16_audit": e16,
    }


def _record(learning_rate, manifest, reused):
    result = manifest["result"]
    item = {
        "learning_rate": float(learning_rate),
        "learning_rate_label": _learning_rate_label(learning_rate),
        "protocol": manifest["protocol"], "seed": manifest["seed"],
        "source_stage": manifest["stage_id"], "source_run_id": manifest["run_id"],
        "reused_reference": bool(reused), "best_epoch": result["best_epoch"],
        "best_dev_mae": result["best_loss"],
        "adaptation_outcome": result["adaptation_gate"]["outcome"],
    }
    item.update({metric: result[metric] for metric in METRICS})
    return item


def _metric_summary(values):
    return {
        "count": len(values),
        "mean": statistics.mean(values) if values else None,
        "sample_std": statistics.stdev(values) if len(values) > 1 else 0.0,
    }


def _gain(metric, baseline, candidate):
    if metric in LOWER_IS_BETTER:
        return float(baseline) - float(candidate)
    return float(candidate) - float(baseline)


def summarize_by_learning_rate(records):
    output = {}
    for learning_rate in LEARNING_RATE_VALUES:
        selected = [
            item for item in records
            if item["learning_rate"] == learning_rate
        ]
        output[_learning_rate_label(learning_rate)] = {
            metric: _metric_summary([float(item[metric]) for item in selected])
            for metric in REPORT_METRICS
        }
        output[_learning_rate_label(learning_rate)]["adaptation_outcomes"] = {
            outcome: sum(
                item["adaptation_outcome"] == outcome for item in selected
            )
            for outcome in ("improved", "fallback_parent")
        }
    return output


def summarize_vs_reference(records, protocols, seeds):
    indexed = {
        (item["protocol"], item["seed"], item["learning_rate"]): item
        for item in records
    }
    output = {}
    for learning_rate in NEW_LEARNING_RATE_VALUES:
        pairs = []
        for seed in seeds:
            for protocol in protocols:
                baseline = indexed[(protocol, seed, REFERENCE_LEARNING_RATE)]
                candidate = indexed[(protocol, seed, learning_rate)]
                pairs.append({
                    "protocol": protocol, "seed": seed,
                    "baseline_learning_rate": REFERENCE_LEARNING_RATE,
                    "candidate_learning_rate": learning_rate,
                    "gains": {
                        metric: _gain(metric, baseline[metric], candidate[metric])
                        for metric in REPORT_METRICS
                    },
                })
        summary = {}
        for metric in REPORT_METRICS:
            values = [pair["gains"][metric] for pair in pairs]
            summary[metric] = {
                "count": len(values), "mean_gain": statistics.mean(values),
                "wins": sum(value > 1e-12 for value in values),
                "ties": sum(abs(value) <= 1e-12 for value in values),
                "losses": sum(value < -1e-12 for value in values),
            }
        output[_learning_rate_label(learning_rate)] = {
            "summary": summary, "pairs": pairs
        }
    return output


def audit_matrix(
    workspace, specs, require_complete=True, perform_reference_preflight=True,
):
    protocols = tuple(dict.fromkeys(spec.protocol for spec in specs))
    seeds = tuple(dict.fromkeys(spec.seed for spec in specs))
    records, missing_new, missing_reference = [], [], []
    new_code, dataset_sha = None, None
    for spec in specs:
        manifest = _validate_new_manifest(workspace, spec)
        if manifest is None:
            missing_new.append(spec.run_id)
            continue
        current_code = manifest.get("code_sha256")
        if new_code is None:
            new_code = current_code
        elif new_code != current_code:
            raise RuntimeError("E17 new runs mix code fingerprints")
        current_data = manifest["result"]["data_provenance"]["dataset_sha256"]
        if dataset_sha is None:
            dataset_sha = current_data
        elif dataset_sha != current_data:
            raise RuntimeError("E17 new runs mix MOSEI files")
        records.append(_record(spec.learning_rate, manifest, reused=False))

    for seed in seeds:
        for protocol in protocols:
            try:
                manifest = _validate_reference_manifest(
                    workspace, protocol, seed, dataset_sha,
                    verify_checkpoint=require_complete,
                )
            except FileNotFoundError:
                missing_reference.append(reference_run_id(protocol, seed))
                continue
            records.append(_record(
                REFERENCE_LEARNING_RATE, manifest, reused=True
            ))

    if require_complete and (missing_new or missing_reference):
        raise RuntimeError(
            "Incomplete E17 sensitivity | missing_new={} first_new={} | "
            "missing_reference={} first_reference={}".format(
                len(missing_new), missing_new[:5],
                len(missing_reference), missing_reference[:5],
            )
        )
    records.sort(key=lambda item: (
        seeds.index(int(item["seed"])),
        protocols.index(str(item["protocol"])),
        LEARNING_RATE_VALUES.index(float(item["learning_rate"])),
    ))
    reference_preflight = None
    if require_complete and perform_reference_preflight:
        reference_preflight = preflight_references(workspace, protocols, seeds)
    return {
        "schema_version": 1, "stage_id": "E17", "dataset": DATASET,
        "purpose": "fusion_all learning-rate sensitivity",
        "protocols": list(protocols), "seeds": list(seeds),
        "learning_rate_values": list(LEARNING_RATE_VALUES),
        "reference_learning_rate": REFERENCE_LEARNING_RATE,
        "expected_new_run_count": len(specs),
        "completed_new_run_count": len(specs) - len(missing_new),
        "expected_reused_reference_count": len(protocols) * len(seeds),
        "completed_reused_reference_count": (
            len(protocols) * len(seeds) - len(missing_reference)
        ),
        "expected_total_sensitivity_cells": (
            len(protocols) * len(seeds) * len(LEARNING_RATE_VALUES)
        ),
        "completed_total_sensitivity_cells": len(records),
        "missing_new_run_ids": missing_new,
        "missing_reference_run_ids": missing_reference,
        "dataset_sha256": dataset_sha, "new_run_code_sha256": new_code,
        "reference_preflight": reference_preflight,
        "selection_split": "development", "selection_metric": "mae",
        "test_evaluation_count_per_new_run": 1,
        "test_metrics_consulted_for_training_or_selection": False,
        "summary_by_learning_rate": summarize_by_learning_rate(records),
        "effects_vs_learning_rate_1e_4": summarize_vs_reference(
            records, protocols, seeds
        ),
        "records": records,
    }


def execute_matrix(workspace, specs):
    protocols = tuple(dict.fromkeys(spec.protocol for spec in specs))
    seeds = tuple(dict.fromkeys(spec.seed for spec in specs))
    preflight_references(workspace, protocols, seeds)
    completed_manifests = []
    for spec in specs:
        manifest = _validate_new_manifest(workspace, spec)
        if manifest is not None:
            completed_manifests.append(manifest)
    if completed_manifests:
        expected_code = code_fingerprints(workspace)
        expected_data = sha256_file(resolve_dataset_path(workspace, DATASET))
        for manifest in completed_manifests:
            if manifest.get("code_sha256") != expected_code:
                raise RuntimeError("E17 resume refused because code changed")
            if manifest["result"]["data_provenance"]["dataset_sha256"] != expected_data:
                raise RuntimeError("E17 resume refused because MOSEI changed")

    environment = os.environ.copy()
    environment["CUBLAS_WORKSPACE_CONFIG"] = ":4096:8"
    completed = skipped = 0
    for index, spec in enumerate(specs, start=1):
        if _validate_new_manifest(workspace, spec) is not None:
            skipped += 1
            print("[{}/{}] SKIP complete {}".format(index, len(specs), spec.run_id))
            continue
        print("[{}/{}] RUN {}".format(index, len(specs), spec.run_id), flush=True)
        subprocess.check_call(
            command_for_spec(workspace, spec), cwd=str(workspace), env=environment
        )
        _validate_new_manifest(workspace, spec)
        subprocess.check_call(
            [sys.executable, "refresh_paper_registry.py", "--workspace", "."],
            cwd=str(workspace), env=environment,
        )
        completed += 1
    print("E17 execution finished | new={} | skipped={}".format(completed, skipped))


def _csv_values(value, cast):
    return tuple(cast(item.strip()) for item in value.split(",") if item.strip())


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--workspace", type=Path, default=Path("."))
    parser.add_argument("--protocols", default=",".join(PROTOCOLS))
    parser.add_argument("--seeds", default=",".join(str(seed) for seed in SEEDS))
    parser.add_argument(
        "--learning_rates",
        default=",".join(str(value) for value in NEW_LEARNING_RATE_VALUES),
    )
    parser.add_argument("--execute", action="store_true")
    parser.add_argument("--audit", action="store_true")
    parser.add_argument(
        "--audit_output", type=Path,
        default=Path("paper_results/E17_fusion_learning_rate_audit.json"),
    )
    return parser.parse_args()


def main():
    args = parse_args()
    workspace = args.workspace.resolve()
    specs = build_matrix(
        _csv_values(args.protocols, str), _csv_values(args.seeds, int),
        _csv_values(args.learning_rates, float),
    )
    if not args.execute and not args.audit:
        cells = len(set((spec.protocol, spec.seed) for spec in specs))
        print(
            "E17 dry-run plan | new_runs={} | reused_reference_records={} | "
            "total_sensitivity_cells={}".format(
                len(specs), cells, cells * len(LEARNING_RATE_VALUES)
            )
        )
        for spec in specs:
            print("{} | fusion_lr={} | parent={} | reference={} | {}".format(
                spec.run_id, spec.learning_rate, spec.parent_run_id,
                reference_run_id(spec.protocol, spec.seed),
                " ".join(command_for_spec(workspace, spec, resolve_parent=False)),
            ))
        return
    if args.execute:
        if os.environ.get("E17_EXECUTE") != "1":
            raise RuntimeError("Set E17_EXECUTE=1 to authorize the formal 36-run matrix")
        execute_matrix(workspace, specs)
    if args.audit:
        summary = audit_matrix(workspace, specs, require_complete=True)
        output = args.audit_output
        if not output.is_absolute():
            output = workspace / output
        write_immutable_json(output, summary)
        print("E17 audit verified: {}".format(output))


if __name__ == "__main__":
    main()
