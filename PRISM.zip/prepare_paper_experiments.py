"""Create the formal paper-experiment directory boundary."""

from __future__ import annotations

import argparse
import csv
from pathlib import Path


DEFAULT_SEEDS = (1111, 2222, 3407, 5576, 7777)
REGISTRY_FIELDS = (
    "run_id",
    "method_id",
    "stage_id",
    "dataset",
    "protocol",
    "seed",
    "status",
    "best_epoch",
    "best_dev_mae",
    "test_mae",
    "test_corr",
    "test_acc2",
    "test_f1",
    "checkpoint_path",
    "checkpoint_sha256",
    "manifest_path",
    "notes",
)


def initialize_workspace(workspace: Path, seeds=DEFAULT_SEEDS) -> None:
    workspace = workspace.resolve()
    directories = (
        workspace / "paper_experiments" / "configs",
        workspace / "paper_experiments" / "manifests",
        workspace / "paper_checkpoints",
        workspace / "paper_logs",
        workspace / "paper_results",
    )
    for directory in directories:
        directory.mkdir(parents=True, exist_ok=True)

    seeds_path = workspace / "paper_experiments" / "seeds.txt"
    if not seeds_path.exists():
        seeds_path.write_text(
            "\n".join(str(seed) for seed in seeds) + "\n",
            encoding="utf-8",
        )

    registry_path = workspace / "paper_experiments" / "registry.csv"
    if not registry_path.exists():
        with open(registry_path, "w", encoding="utf-8", newline="") as stream:
            csv.DictWriter(stream, fieldnames=REGISTRY_FIELDS).writeheader()

    print("Formal paper workspace initialized at {}".format(workspace))
    for directory in directories:
        print(directory)
    print(seeds_path)
    print(registry_path)


def parse_args():
    parser = argparse.ArgumentParser(
        description="Initialize directories for formal paper experiments"
    )
    parser.add_argument(
        "--workspace",
        type=Path,
        default=Path("."),
        help="IIE repository root (default: current directory)",
    )
    return parser.parse_args()


if __name__ == "__main__":
    options = parse_args()
    initialize_workspace(options.workspace)

