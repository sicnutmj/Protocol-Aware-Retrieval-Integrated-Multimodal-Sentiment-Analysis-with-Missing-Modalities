set -e

FPFR_CHECKPOINT_DIR="${FPFR_CHECKPOINT_DIR:-best_modules}"
PROTOCOLS="${PROTOCOLS:-5}"
RUN_FEATURE_CONTROL="${RUN_FEATURE_CONTROL:-1}"
RUN_LABEL_FULL="${RUN_LABEL_FULL:-1}"
ADAPTER_LR="${ADAPTER_LR:-1e-3}"
PAIR_WEIGHT="${PAIR_WEIGHT:-0.1}"
CONTRAST_WEIGHT="${CONTRAST_WEIGHT:-0.01}"
TEMPERATURE="${TEMPERATURE:-0.5}"
HIDDEN_DIM="${HIDDEN_DIM:-128}"
MAX_SCALE="${MAX_SCALE:-1.0}"

LSCMR_ARGS=(
  --retrieval_mode=missing_aware
  --retrieval_queue_size=0
  --retrieval_metric_mode=raw
  --retrieval_missing_query=center
  --gate_mode=none
  --consistency_mode=mixed
  --distill_mode=none
  --fusion_mode=flat
  --prompt_mode=none
  --reconstruction_mode=none
  --consensus_mode=none
  --tag_mode=none
  --cross_modal_retrieval_mode=none
  --training_prior_mode=none
  --hybrid_expert_mode=none
  --protocol_consistency_mode=none
  --relation_distill_mode=none
  --missing_text_contrast_hidden_dim="${HIDDEN_DIM}"
  --missing_text_contrast_max_scale="${MAX_SCALE}"
  --missing_text_contrast_temperature="${TEMPERATURE}"
  --missing_text_pair_loss_weight="${PAIR_WEIGHT}"
  --missing_text_contrast_loss_weight="${CONTRAST_WEIGHT}"
  --missing_text_contrast_learning_rate="${ADAPTER_LR}"
  --load=1
  --n_epochs=40
  --early_stopping_patience=12
  --early_stopping_min_delta=0.0
)

echo "Improvement 17 pilot: label-semantic contrastive missing-text residual (LSCMR)"
echo "Foundation: first + seventh + FPFR; all foundation parameters frozen"
echo "Checkpoint directory: ${FPFR_CHECKPOINT_DIR}"
echo "Protocols: ${PROTOCOLS} (text-missing protocols only: 1, 2, 5)"
echo "Runs: feature control=${RUN_FEATURE_CONTROL}; label-semantic full=${RUN_LABEL_FULL}"
echo "Adapter LR=${ADAPTER_LR}; pair weight=${PAIR_WEIGHT}; contrast weight=${CONTRAST_WEIGHT}"
echo "Temperature=${TEMPERATURE}; hidden dim=${HIDDEN_DIM}; max scale=${MAX_SCALE}"

run_protocol() {
  local protocol="$1"
  local train_batch_size="$2"
  local representation_dim="$3"
  local description="$4"
  shift 4
  local extra_args=("$@")

  local checkpoint="${FPFR_CHECKPOINT_DIR}/iie_mosei_protocol_${protocol}_missing_aware_q0_fusion_fpfr_best.pt"
  if [ ! -s "${checkpoint}" ]; then
    echo "Missing first+seventh+FPFR checkpoint: ${checkpoint}" >&2
    exit 1
  fi

  run_variant() {
    local mode="$1"
    local variant="$2"
    echo "LSCMR ${variant}: protocol ${protocol} (${description})"
    python3 main.py "${LSCMR_ARGS[@]}" \
      --missing_text_contrast_mode="${mode}" \
      --fixed_protocol="${protocol}" \
      --model_path="${checkpoint}" \
      --learning_rate=1e-4 \
      --d_l="${representation_dim}" \
      --latent_dim="${representation_dim}" \
      --train_batch_size="${train_batch_size}" \
      --dataset=mosei \
      "${extra_args[@]}"
  }

  if [ "${RUN_FEATURE_CONTROL}" = "1" ]; then
    run_variant feature "ordinary-InfoNCE control"
  fi
  if [ "${RUN_LABEL_FULL}" = "1" ]; then
    run_variant label "label-semantic full"
  fi
}

for protocol in ${PROTOCOLS}; do
  case "${protocol}" in
    1) run_protocol 1 128 192 "A observed; text missing" \
         --missing_rate=0.05 \
         --layers=2 \
         --latent_layers=3 ;;
    2) run_protocol 2 256 192 "V observed; text missing" ;;
    5) run_protocol 5 256 192 "A+V observed; text missing" ;;
    *)
      echo "Protocol ${protocol} is not eligible; use only 1, 2, or 5" >&2
      exit 1
      ;;
  esac
done
