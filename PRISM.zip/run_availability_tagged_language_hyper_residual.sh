set -e

FPFR_CHECKPOINT_DIR="${FPFR_CHECKPOINT_DIR:-best_modules}"
PROTOCOLS="${PROTOCOLS:-3}"
RUN_AVAILABILITY_CONTROL="${RUN_AVAILABILITY_CONTROL:-1}"
RUN_LANGUAGE_QUERY="${RUN_LANGUAGE_QUERY:-1}"
ADAPTER_LR="${ADAPTER_LR:-1e-3}"
HIDDEN_DIM="${HIDDEN_DIM:-128}"
MAX_SCALE="${MAX_SCALE:-0.5}"

AT_LDHR_ARGS=(
  --retrieval_mode=missing_aware
  --retrieval_queue_size=0
  --retrieval_metric_mode=raw
  --retrieval_missing_query=center
  --gate_mode=none
  --consistency_mode=mixed
  --distill_mode=none
  --fusion_mode=flat
  --prompt_mode=none
  --reconstruction_mode=none
  --consensus_mode=none
  --tag_mode=none
  --cross_modal_retrieval_mode=none
  --training_prior_mode=none
  --hybrid_expert_mode=none
  --protocol_consistency_mode=none
  --relation_distill_mode=none
  --missing_text_contrast_mode=none
  --privileged_purification_mode=none
  --language_hyper_hidden_dim="${HIDDEN_DIM}"
  --language_hyper_max_scale="${MAX_SCALE}"
  --language_hyper_learning_rate="${ADAPTER_LR}"
  --load=1
  --n_epochs=40
  --early_stopping_patience=12
  --early_stopping_min_delta=0.0
)

echo "Improvement 19 pilot: availability-tagged language-dominated hyper residual (AT-LDHR)"
echo "Foundation: first + seventh + FPFR; every foundation parameter frozen"
echo "Checkpoint directory: ${FPFR_CHECKPOINT_DIR}"
echo "Pilot protocols: ${PROTOCOLS} (strict pilot supports protocol 3 only)"
echo "Runs: availability-only control=${RUN_AVAILABILITY_CONTROL}; language-query=${RUN_LANGUAGE_QUERY}"
echo "Adapter LR=${ADAPTER_LR}; hidden dim=${HIDDEN_DIM}; max scale=${MAX_SCALE}"

run_variant() {
  local mode="$1"
  local description="$2"
  local checkpoint="${FPFR_CHECKPOINT_DIR}/iie_mosei_protocol_3_missing_aware_q0_fusion_fpfr_best.pt"
  if [ ! -s "${checkpoint}" ]; then
    echo "Missing first+seventh+FPFR protocol-3 checkpoint: ${checkpoint}" >&2
    exit 1
  fi
  echo "AT-LDHR ${description}: protocol 3 (L+A observed; V missing)"
  python3 main.py "${AT_LDHR_ARGS[@]}" \
    --language_hyper_mode="${mode}" \
    --fixed_protocol=3 \
    --model_path="${checkpoint}" \
    --learning_rate=1e-4 \
    --d_l=96 \
    --latent_dim=96 \
    --train_batch_size=256 \
    --dataset=mosei
}

for protocol in ${PROTOCOLS}; do
  if [ "${protocol}" != "3" ]; then
    echo "Strict AT-LDHR pilot supports protocol 3 only; received ${protocol}" >&2
    exit 1
  fi
done

if [ "${RUN_AVAILABILITY_CONTROL}" = "1" ]; then
  run_variant availability_only "availability-only matched control"
fi
if [ "${RUN_LANGUAGE_QUERY}" = "1" ]; then
  run_variant language_query "language-query full"
fi
