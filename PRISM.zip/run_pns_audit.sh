set -e
AUDIT_ARGS=(
  --retrieval_mode=missing_aware
  --retrieval_queue_size=0
  --retrieval_metric_mode=raw
  --retrieval_missing_query=center
  --gate_mode=none
  --consistency_mode=mixed
  --distill_mode=none
  --pns_audit
  --pns_threshold=1.0
  --load=1
)
echo "Read-only PNS branch audit for frozen q0 checkpoints"

run_protocol() {
  local protocol="$1"
  local representation_dim="$2"
  shift 2

  python3 main.py "${AUDIT_ARGS[@]}" \
    --fixed_protocol="${protocol}" \
    --d_l="${representation_dim}" \
    --latent_dim="${representation_dim}" \
    --dataset=mosei \
    --model_path="best_modules/iie_mosei_protocol_${protocol}_missing_aware_q0_best.pt" \
    "$@"
}

run_protocol 0 192
run_protocol 1 192 --missing_rate=0.05 --layers=2 --latent_layers=3
run_protocol 2 192
run_protocol 3 96
run_protocol 4 96
run_protocol 5 192
run_protocol 6 192
